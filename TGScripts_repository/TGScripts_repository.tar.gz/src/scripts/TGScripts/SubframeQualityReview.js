#engine v8
#include "lib/TGFileProtection.js"
// ImageView imports AstrometricMetadata, whose constructor needs this module
// name. Define library constants before the FIRST include, including ImageView.
// A test that includes this script can hide an incorrect standalone load order.
// VERSION belongs to each imported library; do not inherit or leak it.
#ifdef VERSION
#undef VERSION
#endif
#ifgteq __PI_BUILD__ 1719
#define VERSION "3.0.0"
#define SETTINGS_VERSION 3
#else
#define VERSION "2.2.0"
#define SETTINGS_VERSION 2
#endif
#define SETTINGS_MODULE "SQRPhotometry"
#define SOLVER_SETTINGS_MODULE "SQRPhotometrySolver"
#include <pjsr/controls/ImageView.js>
#include <pjsr/KeyCodes.jsh>
#include <pjsr/ImageOp.jsh>
#include <pjsr/controls/DateTimeEditor.js>
#ifndef SQR_NO_PHOTOMETRY
// These src/scripts engines are internal components covered by this script's
// signature. Revalidate compatibility after PixInsight updates and re-sign
// SubframeQualityReview whenever any of these included components changes.
#include <../src/scripts/AperturePhotometry/AperturePhotometryConfig.js>
#include <../src/scripts/AperturePhotometry/AperturePhotometryEngine.js>
#undef VERSION
#ifgteq __PI_BUILD__ 1719
#define VERSION "6.6.1"
#else
#define VERSION "6.5.0"
#endif
#include <../src/scripts/ImageSolver/ImageSolverEngine.js>
#endif
#undef VERSION
#ifndef SQR_LIBRARY
#feature-id SubframeQualityReview : TG Scripts > Subframe Quality Review
#feature-info Review registered WBPP lights against a filter master or the best subframe, measure field quality with optional corners, and review WBPP run-log exclusions and move marked original light files.
#endif

/* Subframe Quality Review 0.78.3 -- PixInsight 1.9.6+, V8.
 * Original implementation for the TGScripts workflow, 2026.
 * Run-log rejection marks are editable. Moving originals requires confirmation.
 * Uses native ImageAnalysis measurements, including independent regional fits.
 */
/*
 * Workflow and data ownership
 * --------------------------
 * sqrScan builds session.groups from registered WBPP lights and verifies each
 * row.original against the raw-light root. A row holds source metadata, cached
 * regional metrics, ranking results and a separate manual reject flag.
 *
 * sqrAnalyze measures registered pixels; sqrRank only recomputes derived data.
 * Metrics use region indices: 0 field, 1 center, 2..5 the four named corners.
 * A master's comparison row is kept outside group.rows so it cannot enter the
 * subframe baselines, REVIEW quota, or original-file move loop accidentally.
 *
 * The dialog owns the in-memory session, rendered preview bitmaps and timers.
 * sqrMove and sqrRestore change original-file locations after plan confirmation.
 * Process instances store options, not measured sessions or pending decisions.
 */
// Release policy: PATCH for fixes/performance; MINOR for new features or
// meaningful behavior changes (reset PATCH to zero). Use 1.0.0 for the stable
// release milestone, then MAJOR for incompatible changes (reset MINOR/PATCH).
const SQR_VERSION='0.78.3';
const SQR_MASTER_GROUP_PROPERTY='SubframeQualityReview:RegisteredGroup';
const SQR_MAX_CORNER_PERCENT=40;
const SQR_EXTINCTION_RETRY_SENSITIVITY=0.65;
const SQR_FILE=#__FILE__;
const SQR_REGIONS=['Field','Center','Top left','Top right','Bottom left','Bottom right'];
const SQR_BLINK_MODES=['master','best','sequence','mosaic-master','mosaic-best','trail'];
const SQR_TRAIL_REVIEW_LIMIT=40;

/** Defaults shared by the UI and saved process instances. Weights are relative;
 * corner measurement is opt-in, and no rejection flag is an option. */
function sqrDefaults(){return {wbpp:'',originals:'',destination:'',wbppImport:null,observingSite:null,siteHeadersOnly:false,percent:10,measureCorners:false,reference:'best',trailWidth:9,
   patch:22,autoCornerSize:true,margin:2,minStars:10,signalWeight:40,starsWeight:15,fwhmWeight:100,eccentricityWeight:40,cornerWeight:20,backgroundWeight:20,skyScoreKPI:'skyQuality',belowMeanWeight:20,guideWeight:25,correlationOnly:false,rankOfRanks:false,
   maxFits:2000,displaySTF:true,alignBrightness:true,blinkInterval:.75,mosaicCornerPercent:10,regionRotation:'off',reviewOrder:0,reviewReverse:false,histogramOrder:'value',scatterX:'0:fwhm',scatterY:'0:signal',logFolder:'',logTimeZone:'auto',logUTCOffset:0,guidingMode:'available',qualityCollapsed:false,inputsCollapsed:false,reviewInfoCollapsed:false,messagesCollapsed:false,
   fwhmEnabled:true,fwhmAperture:0,fwhmSeeing:0,fwhmGoodPercent:115,fwhmMediumPercent:135,fwhmSeeingGood:1.5,fwhmSeeingMedium:2.5,fwhmAltitude:45,fwhmOptics:0,fwhmWavelengths:{},
   bortleClass:6,sqmReading:0,sqmTime:'',sqmTimeFromLog:false,recommendation:{snrPercent:95,minFrames:20,includeRejected:false,useROI:false,roi:null,geometry:null,plotKPI:'score'}};}

// Approximate visual-class / surface-brightness correspondence, in mag/arcsec²:
// https://www.handprint.com/ASTRO/bortle.html . The end classes are open-ended.
// Classes 8 and 9 share one photometric range; do not invent a separating limit.
const SQR_BORTLE_RANGES=[null,[null,21.99],[21.99,21.89],[21.89,21.69],[21.69,20.49],
   [20.49,19.50],[19.50,18.94],[18.94,18.38],[18.38,null],[18.38,null]];
function sqrBortleOptions(o={}){let value=o.bortleClass??sqrDefaults().bortleClass;
   return {bortleClass:Number.isInteger(value)&&value>=0&&value<=9?value:0};}
function sqrSQMReading(o={}){return Number.isFinite(o.sqmReading)&&o.sqmReading>0&&o.sqmReading<=30?o.sqmReading:0;}
function sqrSkyComparisonEnabled(o){return !!sqrBortleOptions(o).bortleClass||sqrSQMReading(o)>0;}
function sqrBortleLabel(value){return String(value);}
// The final brightness interval covers both visual classes 8 and 9. Report
// that ambiguity rather than inventing a distinction from one meter reading.
function sqrSQMBortle(value){if(!(value>0))return 0;for(let i=1;i<=7;++i)if(value>=SQR_BORTLE_RANGES[i][1])return i;return 8;}
function sqrSkyBortleLabel(model){return model.autoBortle&&model.bortleClass===8?'8–9':sqrBortleLabel(model.bortleClass);}
/** One parser for typed/pasted values, the picker, and calibration. Normalize
 * unambiguous separators and optional seconds, but reject invalid civil dates
 * and timezone suffixes. This is site-local wall time, never computer time. */
function sqrNormalizeSQMTime(value){
   let text=String(value||'').trim(),m=text.match(/^(\d{4})[-/](\d{2})[-/](\d{2})[T ](\d{2}):(\d{2})(?::(\d{2}))?$/);
   if(!m||Number(m[1])<100)return null;
   let stamp=m[1]+'-'+m[2]+'-'+m[3]+' '+m[4]+':'+m[5]+':'+(m[6]||'00');
   return sqrLogTime(stamp,'utc')===null?null:stamp;
}
const SQR_SQM_TIME_HELP='Reading date and local time: YYYY-MM-DD HH:MM[:SS], for example 2026-11-08 22:30:00. Valid entries are formatted with seconds when editing finishes. The earliest light-frame sequence in the Autorun logs supplies the preset. Edit it to the actual SQM reading time. The inferred/custom UTC offset converts it to image UTC timestamps. A missing or ambiguous time does not fall back to Gaia.';
/** Parse local acquisition-site time using the same evidence as the logs.
 * Require the date too: an observing session can cross midnight or span nights.
 * Never substitute this computer's timezone or silently fall back to Gaia. */
function sqrSQMTime(options,session){
   let stamp=sqrNormalizeSQMTime(options.sqmTime),wall=stamp?sqrLogTime(stamp,'utc'):null;
   if(wall===null)return {time:null,reason:'Enter the SQM local date and time as YYYY-MM-DD HH:MM[:SS].'};
   let clock=sqrInferLogClock(session,options.logTimeZone,options.logUTCOffset),time=sqrLocalToUTC(wall,clock);
   return {time,reason:time===null?'SQM time has no unambiguous UTC offset. Scan images or set a custom UTC offset.':'',clock};
}
function sqrExposureMidpoint(row){let start=sqrAcquisitionTime(row),exposure=sqrExposure(row);return start===null||exposure===null?null:start+exposure*500;}
/** Suggest a picker value without claiming that it was the reading time.
 * Date arithmetic uses UTC components solely as a timezone-free wall clock. */
function sqrSQMTimeSeed(session,row,imagingStart=null){
   if(imagingStart?.text)return imagingStart.text;
   if(!session)return '';
   let candidate=row&&!row.isMaster?row:session?.groups.flatMap(g=>g.rows).find(r=>sqrExposureMidpoint(r)!==null),time=candidate?sqrExposureMidpoint(candidate):null;
   if(time===null)return '';
   let o=session.options,clock=sqrInferLogClock(session,o.logTimeZone,o.logUTCOffset);
   let offsets=clock.offsets.filter(offset=>sqrLocalToUTC(time+offset,clock)===time);
   return offsets.length===1?new Date(time+offsets[0]).toISOString().slice(0,19).replace('T',' '):'';
}
/** Convert surface brightness to the reference frame's linear pixel units.
 * ZP uses integrated stellar flux, not flux/second, so exposure is already in
 * the zero point. Pixel area is arcsec^2. The calibration pedestal is additive.
 * The selected Bortle class never sets the photometric zero point. With SQM,
 * intensity ratios instead transfer the reading from its timed reference. */
function sqrSkyToImage(magnitude,c){return c.method==='sqm'?c.pedestal+(c.anchorBackground-c.pedestal)*Math.pow(10,.4*(c.sqmReading-magnitude)):
   c.pedestal+c.pixelArea*Math.pow(10,.4*(c.zeroPoint-magnitude));}
function sqrImageToSky(value,c){return value>c.pedestal?c.method==='sqm'?c.sqmReading-2.5*Math.log10((value-c.pedestal)/(c.anchorBackground-c.pedestal)):
   c.zeroPoint-2.5*Math.log10((value-c.pedestal)/c.pixelArea):null;}
/** Gaia EDR3/DR3 to Johnson V, Riello et al. 2021, table C.2.
 * Restrict the colour range conservatively to limit L/green passband mismatch.
 * This is a V estimate, not a synthetic SQM passband measurement. */
function sqrGaiaV(m){let g=Number(m?.Gmag),bp=Number(m?.BPmag),rp=Number(m?.RPmag),x=bp-rp;
   if(![m?.Gmag,m?.BPmag,m?.RPmag].every(v=>v!==null&&v!==undefined&&String(v).trim()!==''))return null;
   return [g,bp,rp].every(Number.isFinite)&&g>0&&g<25&&bp>0&&rp>0&&x>=.5&&x<=1.5?g-(-.02704+.01424*x-.2156*x*x+.01426*x*x*x):null;}
function sqrSkyZeroPoint(stars){
   let points=stars.filter(s=>s.valid&&s.flags===0&&!s.isObject&&s.flux>0).map(s=>({star:s,v:sqrGaiaV(s.catalogMagnitudes)}))
      .filter(p=>p.v!==null).map(p=>({...p,z:p.v+2.5*Math.log10(p.star.flux)}));
   for(let i=0;i<3&&points.length;++i){let center=sqrMedian(points.map(p=>p.z)),sigma=1.4826*sqrMedian(points.map(p=>Math.abs(p.z-center))),limit=Math.max(.05,3*sigma);
      points=points.filter(p=>Math.abs(p.z-center)<=limit);}
   if(points.length<20)throw new Error('Fewer than 20 reliable Gaia colour-matched stars. No sky calibration was applied.');
   let zeroPoint=sqrMedian(points.map(p=>p.z)),scatter=1.4826*sqrMedian(points.map(p=>Math.abs(p.z-zeroPoint)));
   if(scatter>.35)throw new Error('Stellar calibration scatter exceeds 0.35 mag. No sky calibration was applied.');
   return {zeroPoint,stars:points.length,scatter};
}
function sqrSkyPixelArea(metadata,width,height){
   let x=width/2,y=height/2,a=metadata.Convert_I_RD(new Point(x,y)),b=metadata.Convert_I_RD(new Point(x+1,y)),c=metadata.Convert_I_RD(new Point(x,y+1));
   if(!a||!b||!c)throw new Error('The reference frame needs a valid astrometric solution.');
   let dra=p=>((p.x-a.x+540)%360-180)*Math.cos(a.y*Math.PI/180),area=Math.abs(dra(b)*(c.y-a.y)-dra(c)*(b.y-a.y))*3600*3600;
   if(!Number.isFinite(area)||area<=0)throw new Error('Cannot determine the reference pixel area.');return area;
}
function sqrSkyPedestal(metadata){let raw=metadata.keywords?.PEDESTAL;if(raw===undefined)return 0;
   let value=Number(String(raw).replace(/[dD]/,'e'));if(!Number.isFinite(value))throw new Error('Invalid PEDESTAL keyword.');return Math.abs(value)/65535;}
function sqrSkyColorTransfer(group){return !!group&&group.channels!==3&&['R','B'].includes(sqrFilterWavelength(group.filter).key);}
function sqrSkyFilterSupported(group){return !!group&&(group.channels===3||['L','G','R','B'].includes(sqrFilterWavelength(group.filter).key)||/^V$/i.test(String(group.filter).trim()));}
/** One reference per comparable group: nearest exposure midpoint for SQM,
 * otherwise the original default field score. Work on copies: display score
 * modes, weights and table order must not change reference selection. */
// Cache only the default-score reference, not the calibration or display score.
// Compare the ranking inputs on every lookup so in-place edits, remeasurement,
// guiding updates and rejection changes cannot leave a stale reference. A
// WeakMap keeps this transient state out of saved sessions and releases old groups.
const SQR_SKY_REFERENCES=new WeakMap;
function sqrSkyReference(session,group){
   if(!session||!group)return null;
   if(sqrSQMReading(session.options)){
      let {time}=sqrSQMTime(session.options,session);if(time===null)return null;
      // Choose by exposure midpoint, independently of display score/order.
      // Exclude masters, rejected/moved frames and unusable backgrounds.
      let rows=group.rows.filter(r=>!r.isMaster&&!r.reject&&!r.moved&&sqrExposureMidpoint(r)!==null&&
         sqrSkyBackground(r,!!session.options.measureCorners)>sqrSkyPedestal(r.registered));
      rows.sort((a,b)=>Math.abs(sqrExposureMidpoint(a)-time)-Math.abs(sqrExposureMidpoint(b)-time)||
         sqrExposureMidpoint(a)-sqrExposureMidpoint(b)||a.registered.path.localeCompare(b.registered.path));
      return rows[0]||null;
   }
   let minStars=session.options.minStars??sqrDefaults().minStars;
   let signature=JSON.stringify([minStars,!!session.guiding?.enabled,group.rows.map(r=>[
      r.registered.path,r.registered.fingerprint,r.registered.channels,r.isMaster,r.reject,r.moved,
      r.metrics,r.backgroundMeans,r.relativeTransparency,r.transparencyInfo,r.guiding,r.guideQuality,r.guidePenalty])]);
   let cached=SQR_SKY_REFERENCES.get(group);
   if(cached?.signature===signature)return cached.path===null?null:group.rows.find(r=>r.registered.path===cached.path)||null;
   let options={...sqrDefaults(),minStars},copy={...group,master:null,masterRow:null,rows:group.rows.map(r=>({...r,metrics:Object.fromEntries(Object.entries(r.metrics||{}).map(([k,v])=>[k,{...v}]))}))};
   sqrRank({options,groups:[copy],guiding:session.guiding});
   let best=copy.rows.filter(r=>!r.isMaster&&!r.reject&&!r.moved&&Number.isFinite(r.scoreWithoutCorners)&&sqrSkyBackground(r,false)>0)
      .sort((a,b)=>b.scoreWithoutCorners-a.scoreWithoutCorners||a.registered.path.localeCompare(b.registered.path))[0];
   let path=best?best.registered.path:null;SQR_SKY_REFERENCES.set(group,{signature,path});
   return best?group.rows.find(r=>r.registered.path===path):null;
}
/** A single zero point cannot be transferred between exposures, cameras,
 * gains, filters or sampling geometries. Refuse a misleading shared overlay. */
function sqrSkyComparable(a,b){
   return ['camera','filter','gain','binX','binY','width','height','channels'].every(k=>String(a[k]??'')===String(b[k]??''))&&
      a.exposure>0&&b.exposure>0&&Math.abs(a.exposure-b.exposure)<.001&&sqrSkyPedestal(a)===sqrSkyPedestal(b);
}
function sqrSkyCalibration(group){let c=group?.skyCalibration;if(!c?.valid)return null;
   let row=group.rows.find(r=>r.registered.path===c.path);
   return row&&row.registered.fingerprint===c.fingerprint&&group.rows.every(r=>sqrSkyComparable(row.registered,r.registered))?c:null;}
/** Transfer only between separate RGB filters from the same setup and field.
 * Each group must remain internally comparable. Exposure and pedestal can
 * differ between groups: the measured, pedestal-subtracted ratio includes
 * their relative response. This is a relative sky estimate, not R/B photometry. */
function sqrSkyTransferCompatible(a,b){
   return !!a.camera&&a.camera===b.camera&&['gain','binX','binY','width','height','channels','object'].every(k=>String(a[k]??'')===String(b[k]??''));
}
function sqrSkyTimedBackgrounds(group,withCorners){
   return group.rows.filter(r=>!r.isMaster&&!r.reject&&!r.moved).map(row=>({row,time:sqrExposureMidpoint(row),background:sqrSkyBackground(row,withCorners)}))
      .filter(p=>p.time!==null&&Number.isFinite(p.background)&&p.background>sqrSkyPedestal(p.row.registered))
      .sort((a,b)=>a.time-b.time||a.row.registered.path.localeCompare(b.row.registered.path));
}
/** Find the nearest-in-time G/colour pair using sorted lists and a moving
 * pointer. Do not compare every frame with every other frame. Re-evaluate
 * cached means/eligibility on lookup so remeasurement, corner toggles and
 * rejection cannot retain an obsolete transfer. No image pixels are reread. */
function sqrSkyTransferPlan(session,group){
   const fail=reason=>({valid:false,reason});
   let target=sqrSkyTimedBackgrounds(group,!!session.options.measureCorners);
   if(!target.length)return fail('Measure this group first; no eligible frame has a usable timestamp and background.');
   if(!group.rows.every(r=>sqrSkyComparable(target[0].row.registered,r.registered)))return fail('This filter group needs matching camera, gain, exposure, binning, pedestal and image dimensions.');
   let greenGroups=session.groups.filter(g=>g.channels===1&&sqrFilterWavelength(g.filter).key==='G');
   if(!greenGroups.length)return fail('Red and blue sky shading requires a measured green-filter group.');
   let best=null;
   for(let greenGroup of greenGroups){
      // Equal timestamps prefer the first path, consistently on either side
      // of the moving pointer and independently of the Review sort order.
      let green=sqrSkyTimedBackgrounds(greenGroup,!!session.options.measureCorners).filter((p,i,a)=>i===0||p.time!==a[i-1].time),reference=sqrSkyReference(session,greenGroup);
      if(!green.length||!reference||!sqrSkyTransferCompatible(target[0].row.registered,green[0].row.registered)||
         !greenGroup.rows.every(r=>sqrSkyComparable(green[0].row.registered,r.registered)))continue;
      let anchor=sqrExposureMidpoint(reference),j=0;
      for(let colour of target){
         while(j<green.length&&green[j].time<colour.time)++j;
         for(let index of [j-1,j])if(index>=0&&index<green.length){
            let g=green[index],gap=Math.abs(g.time-colour.time),distance=anchor===null?0:Math.abs(g.time-anchor),
               key=[colour.row.registered.path,g.row.registered.path].join('\n');
            if(!best||gap<best.gap||gap===best.gap&&(distance<best.distance||distance===best.distance&&
               (colour.time<best.colour.time||colour.time===best.colour.time&&key<best.key)))
               best={valid:true,greenGroup,green:g,colour,gap,distance,key};
         }
      }
   }
   return best||fail('No compatible measured green-filter group has usable timestamps and backgrounds.');
}
function sqrSkyTransferCalibration(session,plan,source){
   if(!plan?.valid||!source)return null;
   let r=plan.colour.row.registered,g=plan.green.row.registered,pedestal=sqrSkyPedestal(r),greenPedestal=sqrSkyPedestal(g),
      factor=(plan.colour.background-pedestal)/(plan.green.background-greenPedestal);
   if(!(factor>0)||!Number.isFinite(factor))return null;
   let c={...source,path:r.path,fingerprint:r.fingerprint,pedestal,channel:sqrFilterWavelength(r.filter).name,
      referenceMidpoint:plan.colour.time,backgroundBasis:session.options.measureCorners?'preview minimum':'whole image',
      transfer:{sourcePath:source.path,greenPath:g.path,greenTime:plan.green.time,colourTime:plan.colour.time,
         gap:plan.gap,factor,greenBackground:plan.green.background,colourBackground:plan.colour.background}};
   if(source.method==='sqm'){
      c.anchorBackground=pedestal+factor*(source.anchorBackground-source.pedestal);
      if(!Number.isFinite(c.anchorBackground)||!(c.anchorBackground>pedestal))return null;
   }else{
      c.zeroPoint=source.zeroPoint+2.5*Math.log10(factor);
      if(!Number.isFinite(c.zeroPoint))return null;
   }
   return c;
}
/** Keep the two calibration sources independently reusable. A change in SQM,
 * time/offset, reference eligibility or file identity cannot reuse a stale
 * overlay. Corner scoring uses the same cached background basis as the plot. */
function sqrCurrentSkyCalibration(session,group){
   if(!session||!group)return null;
   if(sqrSkyColorTransfer(group)){let plan=sqrSkyTransferPlan(session,group);return plan.valid?sqrSkyTransferCalibration(session,plan,sqrCurrentSkyCalibration(session,plan.greenGroup)):null;}
   let o=session.options,sqm=sqrSQMReading(o),stored=sqm?group.skySQMCalibration:group.skyGaiaCalibration;
   let c=sqrSkyCalibration({...group,skyCalibration:stored||group.skyCalibration});if(!c)return null;
   if((c.method==='sqm')!==!!sqm)return null;
   let row=sqrSkyReference(session,group);if(!row||row.registered.path!==c.path)return null;
   if(!sqm)return c;
   let time=sqrSQMTime(o,session).time,bg=sqrSkyBackground(row,!!o.measureCorners);
   if(time===null||c.sqmReading!==sqm||c.measurementTime!==time||!(bg>c.pedestal))return null;
   return {...c,anchorBackground:bg,backgroundBasis:o.measureCorners?'preview minimum':'whole image'};
}
function sqrBortleModel(options,group=null,session=null,calibration=undefined){
   let sqmReading=sqrSQMReading(options),autoBortle=sqmReading>0,bortleClass=autoBortle?sqrSQMBortle(sqmReading):sqrBortleOptions(options).bortleClass;
   let m={bortleClass,sqmReading,autoBortle,enabled:bortleClass>0,valid:false,reason:''};
   session={...(session||{groups:group?[group]:[]}),options};
   if(!m.enabled)return {...m,reason:'Select a Bortle class beside Calibrate sky, or enter Session SQM and its reading time.'};
   if(group&&!sqrSkyFilterSupported(group))return {...m,reason:'Sky comparison supports luminance, green, V, RGB, and red/blue estimates transferred from green.'};
   if(autoBortle){let t=sqrSQMTime(options,session);if(t.time===null)return {...m,reason:t.reason};}
   // A caller drawing the sky plot can share its already validated calibration
   // with the Calibrate sky button. Explicit null means validation found none.
   let c=calibration===undefined?sqrCurrentSkyCalibration(session,group):calibration;
   if(!c)return {...m,reason:group?.skyCalibrationError||(sqrSkyColorTransfer(group)?sqrSkyTransferPlan(session,group).reason||'Calibrate the compatible green-filter group to enable red/blue sky shading.':autoBortle?'Measure images to match an eligible exposure to the SQM reading time.':'Sky-background calibration runs after measurements, or when Bortle is selected for measured images.')};
   let [dark,bright]=SQR_BORTLE_RANGES[bortleClass]||[null,null],goodValue=dark===null?null:sqrSkyToImage(dark,c),mediumValue=bright===null?null:sqrSkyToImage(bright,c);
   // With SQM the reference background is the anchor; Gaia is not involved.
   let sqmValue=sqmReading>0?sqrSkyToImage(sqmReading,c):null;
   if(![goodValue,mediumValue,sqmValue].filter(v=>v!==null).every(v=>Number.isFinite(v)&&v>c.pedestal))return {...m,reason:'Sky conversion is outside the usable numeric range.'};
   return {...m,valid:true,calibration:c,dark,bright,goodValue,mediumValue,sqmValue};
}
function sqrBortleGrade(value,m){return m.goodValue!==null&&value<m.goodValue?'Good':m.mediumValue!==null&&value>m.mediumValue?'Bad':'Medium';}
function sqrSkyPlotDetails(m){
   if(!m?.valid)return m?.reason||'Sky calibration unavailable.';let c=m.calibration;
   if(c.transfer){let t=c.transfer;return c.channel+' relative estimate from green\nGreen calibration reference: '+sqrFileName(t.sourcePath)+
      '\nGreen transfer frame: '+sqrFileName(t.greenPath)+'\n'+c.channel+' transfer frame: '+sqrFileName(c.path)+
      '\nExposure midpoints (UTC): '+new Date(t.greenTime).toISOString()+' / '+new Date(t.colourTime).toISOString()+
      '\nPair time gap: '+(t.gap/60000).toFixed(1)+' min\nBackground basis: '+c.backgroundBasis+
      '\nMeasured backgrounds (green / '+c.channel.toLowerCase()+'): '+sqrFmt(t.greenBackground,6)+' / '+sqrFmt(t.colourBackground,6)+
      '\nRelative response: '+sqrFmt(t.factor,6)+(c.method==='sqm'?'\nSQM reading: '+c.sqmReading.toFixed(2)+' mag/arcsec² at '+new Date(c.measurementTime).toISOString()+' (UTC)':'\nGreen calibration: '+c.stars+' local Gaia stars; scatter '+c.scatter.toFixed(3)+' mag')+
      '\nAssumes similar sky brightness between the paired exposures and a stable filter response across the group. Larger time gaps, changing sky colour or transparency make this estimate less reliable. This is not independent red/blue sky photometry.';}
   return 'Reference: '+sqrFileName(c.path)+'\n'+(c.method==='sqm'?
      'Reading: '+new Date(c.measurementTime).toISOString()+' (UTC)\nExposure midpoint: '+new Date(c.referenceMidpoint).toISOString()+' (UTC)\nTime difference: '+(Math.abs(c.referenceMidpoint-c.measurementTime)/60000).toFixed(1)+' min\nBackground: '+sqrFmt(c.anchorBackground,6)+' image units ('+c.backgroundBasis+')':
      c.stars+' local Gaia stars\nCalibration scatter: '+c.scatter.toFixed(3)+' mag\nChannel: '+c.channel+(c.astrometryRebuilt?'\nSky coordinates rebuilt':''));
}
const SQR_GRADE_COLORS={Good:'#63b66a',Medium:'#f2cd40',Bad:'#e56b70'};
const SQR_GRADE_TEXT={Good:'#a6e3a1',Medium:'#f9e2af',Bad:'#f38ba8'};
const SQR_GRADE_OPACITY=0.25;
const SQR_PLOT_SURROUND='#1e1e2e';
const SQR_PLOT_TEXT='#cdd6f4';
const SQR_PLOT_LABEL_SIZE='clamp(16px,1.36vw,21px)';
// Reserve the same two heading rows and axis gutters on both tabs. A longer
// legend or tick label can claim extra room without squeezing the other labels.
const SQR_CHART_CSS='*{box-sizing:border-box}html,body{margin:0;width:100%;height:100%;overflow:hidden;background:'+SQR_PLOT_SURROUND+';color:'+SQR_PLOT_TEXT+';font-family:"Segoe UI",system-ui,sans-serif}'+
   '.container{height:100%;display:flex;flex-direction:column}header{flex:none;display:grid;grid-template-rows:auto minmax(1.2em,auto);row-gap:3px;text-align:center;padding:clamp(8px,1.6vh,16px) 12px 6px;font-size:clamp(14px,1.2vw,18px)}'+
   '.title{margin:0;font-weight:600;font-size:clamp(20px,1.9vw,26px);line-height:1.2}'+
   '.category-legend,.bortle-legend,.interpretation{line-height:1.2}'+
   '.plot-region{flex:1;min-height:0;position:relative;display:flex;font-size:'+SQR_PLOT_LABEL_SIZE+';--side-gap:clamp(12px,2.8vw,54px)}'+
   '.plot-field{position:absolute;top:clamp(1.95em,4.6vh,2.5em);bottom:calc(3.2em + clamp(10px,3.3vh,34px));'+
      'left:calc(var(--side-gap) + max(7ch,var(--y-ticks,0ch)) + 2.5em);right:calc(var(--side-gap) + max(3ch,var(--x-end,0ch)) + .5em)}'+
   '.plot-field svg{width:100%;height:100%;display:block;overflow:visible}.empty{margin:auto;padding:24px;text-align:center}';
const SQR_SHADED_PLOT={background:'#ffffff',grid:'#adb3b6',mean:'#25693c',sqm:'#94316d',focus:'#955010',hover:'#303842'};
const SQR_UNGRADED_PLOT={...SQR_SHADED_PLOT,background:sqrGradeSwatch(SQR_GRADE_COLORS.Good)};
const SQR_SELECTED_BAR='#35b5cf';
function sqrPlotBands(data){return data.skyBands||data.guideBands||data.eccentricityBands||data.fwhmBands||[];}
function sqrPlotPalette(data,bands){
   // A white base belongs only to the data rectangle with visible grading bands.
   return bands.some(b=>Math.min(data.high,b.high??data.high)>Math.max(data.low,b.low??data.low))?SQR_SHADED_PLOT:SQR_UNGRADED_PLOT;
}
// Native legend cells are opaque. Composite their samples on the same white base as the bands.
function sqrGradeSwatch(color){
   return '#'+[1,3,5].map(i=>{
      let ink=parseInt(color.slice(i,i+2),16);
      return Math.round(255+(ink-255)*SQR_GRADE_OPACITY).toString(16).padStart(2,'0');
   }).join('');
}
// Describe only the bands the plot can shade. Classes 8 and 9 share an
// interval, including when either class is selected manually.
function sqrBortleShading(model){
   if(!model?.valid)return [];
   let first=Math.min(8,model.bortleClass),last=first===8?9:first;
   return [{label:'Good',first:1,last:first-1,low:null,high:model.goodValue,color:SQR_GRADE_COLORS.Good},
      {label:'Medium',first,last,low:model.goodValue,high:model.mediumValue,color:SQR_GRADE_COLORS.Medium},
      {label:'Bad',first:last+1,last:9,low:model.mediumValue,high:null,color:SQR_GRADE_COLORS.Bad}].filter(b=>b.first<=b.last);
}
/** Explain the exact automatic lookup from the same static limits that drive
 * calibration and shading. Reuse the plot's validated calibration, including
 * its current field/corner background basis; never measure again for help. */
function sqrBortleRangeInformation(model=null){
   let rows=[],calibration=model?.valid?model.calibration:null,shading=sqrBortleShading(model);
   for(let i=1;i<=8;++i){let [upper,lower]=SQR_BORTLE_RANGES[i],range=upper===null?'SQM ≥ '+lower.toFixed(2):lower===null?'SQM < '+upper.toFixed(2):lower.toFixed(2)+' ≤ SQM < '+upper.toFixed(2);
      let imageRange='—';
      if(calibration){
         let low=upper===null?null:sqrSkyToImage(upper,calibration),high=lower===null?null:sqrSkyToImage(lower,calibration);
         // Significant digits keep faint-image ranges readable without rounding
         // them all to zero. Display formatting never changes the band limits.
         const value=x=>String(Number(x.toPrecision(6)));
         if([low,high].filter(x=>x!==null).every(Number.isFinite))
            imageRange=low===null?'sky ≤ '+value(high):high===null?'sky > '+value(low):value(low)+' < sky ≤ '+value(high);
      }
      let band=shading.find(b=>i>=b.first&&i<=b.last),shade=band?
         '<td width="76" align="center" bgcolor="'+sqrGradeSwatch(band.color)+'"><font color="#263746">'+band.label+'</font></td>':'<td width="76" align="center">—</td>';
      rows.push('<tr><td>'+sqrHTML(i===8?'8–9':String(i))+'</td><td>'+sqrHTML(range)+'</td><td>'+sqrHTML(imageRange)+'</td>'+shade+'</tr>');}
   return '<h3>SQM-to-Bortle ranges</h3><p>Ranges used by this script, in mag/arcsec². Higher SQM values mean darker skies.</p>'+
      '<table width="100%" cellspacing="6" cellpadding="3"><tr><th align="left">Bortle class</th><th align="left">SQM reading</th><th align="left">Sky brightness<br/>(image units)</th><th width="76" align="center">Shading</th></tr>'+rows.join('')+'</table>'+
      '<p>'+(calibration?'Calibrated sky values use the current plot calibration; lower values mean darker skies. Values are rounded for display.':'Calibrated sky values and shading are unavailable until the plot has a usable sky calibration.')+'</p>'+
      '<p>These are approximate brightness equivalents. At an exact boundary, the automatic lookup chooses the darker class. Shading includes both boundary values in Medium. Classes 8 and 9 share one range; a reading alone cannot distinguish them.</p>';
}
/** Native rich-text tables keep samples, marker names and meanings aligned.
 * Color names remain explicit so the legend also works without color vision.
 * Only reference markers and shading relevant to this plot are included. */
function sqrPlotReadingGuide(data){
   let k=data.kpi,sky=k.key==='skyBackground';
   let axis=k.metric==='eccentricity'?'Fits all plotted eccentricities, including the master, with headroom within 0–1.':k.metric==='fwhm'&&data.fwhmBands?'Includes measured values and all grading ranges.':
      data.guideBands&&k.key==='guideMax'?'Includes zero, measured values and all guiding ranges.':
      sky?'Fits all plotted backgrounds, including the master, with headroom. Bortle and SQM limits do not expand it.':
      'Fits subframes with headroom. An outlying master is clipped and marked by an arrow; hover for its true value.';
   if(k.key==='belowMeanFraction')axis='Fits subframes with headroom, within 0–100%.';
   let order=data.order==='time'?'Earliest first; '+(data.hasMaster?'master first; ':'')+'unknown times last. Spacing shows image sequence, not elapsed time.':'Lowest to highest KPI value, independently of the Review table.';
   let tips=[['Bars',k.key==='belowMeanFraction'?'One bar per subframe; the master is excluded. A blank position means no measurement.':'One bar per image. A blank position means no measurement.'],['Inspect','Hover for image values. Click a bar to select that image in Review and measurements.'],['Order',order],['Vertical axis',axis]];
   let html='<h3>Reading the plot</h3><table width="100%" cellspacing="3" cellpadding="4">'+tips.map(([name,text])=>'<tr><td width="94" valign="top"><b>'+name+'</b></td><td>'+sqrHTML(text)+'</td></tr>').join('')+'</table>';
   html+='<h4>Colors and markers</h4><table width="100%" cellspacing="4" cellpadding="5"><tr><th width="56" align="left">Sample</th><th width="140" align="left">Marker</th><th align="left">Meaning</th></tr>';
   const group=label=>'<tr><td colspan="3" bgcolor="#e8edf2"><font color="#263746"><b>'+label+'</b></font></td></tr>';
   let bands=sqrPlotBands(data),palette=sqrPlotPalette(data,bands);
   const item=(color,label,meaning,line=false)=>'<tr><td width="56" align="center" bgcolor="'+(line?palette.background:color)+'">'+(line?'<font color="'+color+'"><b>━ ━ ━</b></font>':'&nbsp;')+'</td><td width="140"><b>'+sqrHTML(label)+'</b></td><td>'+sqrHTML(meaning)+'</td></tr>';
   html+=group('Image bars')+[
      [SQR_SELECTED_BAR,'Cyan bar','Selected image. A dark teal border marks its full column.'],['#cba6f7','Purple bar','REVIEW candidate'],['#2d6cb5','Blue bar','Other kept subframe'],['#e57373','Red bar','Rejected or moved original']
   ].map(row=>item(...row)).join('')+(data.hasMaster?item('#f9a825','Gold bar','Comparison master'):'');
   html+=group('Reference lines')+item(palette.mean,'Green dashed','Mean of measured, unrejected subframes; excludes the master.',true);
   if(sky&&data.skyModel?.valid&&data.skyModel.sqmValue!==null)html+=item(palette.sqm,'Pink dashed','Session SQM: below the line is darker; above is brighter.',true);
   if(data.showAutofocus&&data.autofocus?.length)html+=item(palette.focus,'Orange / AF','Autofocus start; AF shows the final focus position when known. Hover over a tag for details. '+data.autofocus.length+' starts in range.',true);
   if(bands.length){
      html+=group('Background shading');
      for(let band of bands){
         let meaning=band.label;
         if(sky)meaning+=' · Bortle '+(band.first===band.last?String(band.first):band.first+'–'+band.last);
         html+=item(sqrGradeSwatch(band.color),(band.label==='Good'?'Green':band.label==='Medium'?'Yellow':'Red')+' shading',meaning);
      }
   }
   return html+'</table><p><i>Selection overrides the bar color with cyan. A status outline may remain visible.'+(palette===SQR_UNGRADED_PLOT?' Pale green is the default background when no grading bands are visible.':' Background shading grades the measurement; it does not indicate selection or rejection.')+'</i></p>';
}
function sqrPlotInformation(data){
   if(!data?.kpi)return null;let k=data.kpi,sky=k.key==='skyBackground',parts=[];
   const paragraph=text=>text?'<p>'+sqrHTML(text).replace(/\n/g,'<br/>')+'</p>':'';
   // Explanations live here only: never duplicate them in the chart header,
   // native control tooltips or footer. Bar hovers retain per-image data.
   let definition=data.scoreDefinition||k.definition;
   if(k.metric==='fwhm')definition='Full width at half maximum of the fitted star profiles in '+(k.region===0?'the usable field':SQR_REGIONS[k.region].toLowerCase())+', measured in pixels. Displayed values use one decimal place; grading and scoring use the full precision.';
   if(definition)parts.push(paragraph(definition));
   if(data.detail)parts.push(paragraph(data.detail));
   if(k.corners)parts.push(paragraph('Requires regional measurements. Stored measurements remain available for plotting when corner scoring is disabled. '+(k.region===1?'Center FWHM supplies the corner-to-center size ratios.':k.region>=2?'Individual corner measurements contribute through Corner quality with manual weights; strongly correlated KPI scoring can also select them independently.':'')));
   if(k.guiding){
      parts.push(paragraph('Guiding measurements use the log samples matched to each exposure. Missing or incomplete coverage does not count as zero error. The master has no guiding interval.'));
      if(k.key==='guideQuality')parts.push(paragraph('This combined error determines the guiding penalty in Score. It has no Good / Medium / Bad background bands.'));
      else parts.push(paragraph(Number.isFinite(data.guideScale)&&data.guideScale>0?
         'Category limits use the imaging pixel scale: Good up to one pixel scale; Medium up to 1.75 times that scale; Bad above. The smaller X/Y scale is used if they differ. These errors contribute to Score through Guiding quality.':
         'Guiding thresholds unavailable: a valid imaging pixel scale is required. These errors contribute to Score through Guiding quality.'));
   }
   if(sky){
      parts.push(paragraph('With Session SQM, the nearest eligible exposure midpoint supplies the broadband reference and its background is assigned the reading directly. Without SQM, local Gaia photometry calibrates the best default-scoring eligible subframe. Separate red and blue groups use a relative transfer from green, based on the closest-in-time pair of measured backgrounds. Choose a Bortle class to enable shading, or — to disable it. Calibrate sky appears only while a current calibration is unavailable.'));
   }
   if(!parts.length&&!data.items)return null;
   if(data.items)parts.push(sqrPlotReadingGuide(data));
   if(sky)parts.push(sqrBortleRangeInformation(data.skyModel));
   return {title:k.label+' — information',sky,plot:!!data.items,html:'<html><body>'+parts.join('')+'</body></html>'};
}
function sqrSkyMeasurementImage(window){let source=window.mainView.image;if(source.numberOfNominalChannels<3)return source;
   let green=new Image;green.assign(source,new Rect(0,0,source.width,source.height),1,1);return green;}
/** Some acquisition/WBPP headers contain approximate or stale WCS data.
 * Re-solve only the engine-owned reference window, using the local catalogue
 * that just answered the query. ImageSolver updates in-memory metadata only;
 * no save operation or diagnostic output is enabled. Keep measured fluxes. */
function sqrSkySolveCoordinates(window,catalogId){
   console.writeln('Rebuilding reference sky coordinates with the configured local Gaia catalog...');
   let solver=new ImageSolver;
   solver.metadata.ExtractMetadata(window);solver.metadata.ensureValidReferenceSystemForSolution();
   let cfg=solver.solverCfg;cfg.catalogMode=CatalogMode.LocalXPSDServer;cfg.catalog=catalogId;cfg.autoMagnitude=false;cfg.magnitude=18;
   cfg.maxIterations=20;cfg.showStars=cfg.showStarMatches=cfg.showSimplifiedSurfaces=cfg.showDistortion=false;
   cfg.generateDistortModel=cfg.generateErrorImg=false;
   solver.solveImage(window);
   return solver.metadata;
}
// A detection can contribute only when exactly one catalogue source lies
// within the matching radius and that source has exactly one candidate.
function sqrSkyMatchedStars(stars,records,metadata,radius){
   let cells=new Map, matches=new Map;
   for(let star of stars){
      let key=Math.floor(star.pos.x/radius)+','+Math.floor(star.pos.y/radius);
      if(!cells.has(key))cells.set(key,[]);
      cells.get(key).push(star);
   }
   for(let record of records){
      if(!record?.posRD)continue;
      let p=metadata.Convert_RD_I(record.posRD);
      if(!p||!Number.isFinite(p.x)||!Number.isFinite(p.y))continue;
      let x=Math.floor(p.x/radius),y=Math.floor(p.y/radius),near=[];
      for(let dx=-1;dx<=1;++dx)for(let dy=-1;dy<=1;++dy){
         let bucket=cells.get((x+dx)+','+(y+dy));
         if(bucket)for(let star of bucket)
            if((star.pos.x-p.x)**2+(star.pos.y-p.y)**2<=radius*radius)near.push(star);
      }
      for(let star of near)matches.set(star,near.length===1&&!matches.has(star)?record:null);
   }
   return stars.filter(s=>matches.get(s)).map(s=>({valid:true,flags:0,flux:s.flux,catalogMagnitudes:matches.get(s)}));
}
function sqrSkyPhotometryConfig(){
   let config=new PhotometryConfiguration('SQRPhotometry');
   config.maxStars=500;config.normalizeByExposure=false;config.backgroundMode=BackgroundMode.Annulus;
   config.photometryMode=PhotometryMode.AutoAperture;config.apertureFWHM=5;
   config.annulusInner=2.5;config.annulusOuter=4;config.detection.minSNR=20;config.detection.upperLimit=.95;
   return config;
}
// AperturePhotometry 3 separates source detection and aperture flux
// measurement. Only one image is needed here. Query configured XPSD
// catalogues directly so a fallback can never start an online search.
function sqrSkyMeasureGaia(job){
   let config=sqrSkyPhotometryConfig();
   let catalogs=[new GaiaDR3SPXPSDCatalog,new GaiaDR3XPSDCatalog,new GaiaEDR3XPSDCatalog].filter(c=>{
      let server=c.newXPSDServer();server.command='get-info';server.verbosity=0;server.executeGlobal();return server.isValid;
   });
   if(!catalogs.length)throw new Error('Configure a local Gaia DR3/SP, DR3 or EDR3 database in PixInsight to calibrate sky brightness.');
   let window=AperturePhotometryEngine.OpenImage(job.path),image=null;
   try{
      let engine=new AperturePhotometryEngine(config),target=new PhotometryTarget(job.path,window);
      image=sqrSkyMeasurementImage(window);target.width=image.width;target.height=image.height;target.exposure=job.exposure;
      let metadata=new AstrometricMetadata;metadata.ExtractMetadata(window);
      let solved=false;
      if(!metadata.projection||!metadata.ref_I_G){metadata=sqrSkySolveCoordinates(window,catalogs[0].name);solved=true;}
      target.metadata=metadata;
      let stars=engine.DetectStars(image,target);engine.MeasureDetectedStars(image,target,stars);
      stars=stars.filter(s=>s.valid&&s.flags===0&&s.flux>0).sort((a,b)=>b.flux-a.flux);
      if(stars.length<20)throw new Error('Fewer than 20 usable stars were measured on the Gaia reference frame.');
      let radius=Math.max(2,Math.min(5,target.robustFWHM||2));
      for(;;){
         let errors=[],queried=null;
         for(let catalog of catalogs){
            if(console.abortRequested)throw new Error('Operation aborted.');
            try{
               catalog.Load(metadata);queried=catalog;
               let matched=sqrSkyMatchedStars(stars,catalog.objects,metadata,radius);
               let calibration=sqrSkyZeroPoint(matched.slice(0,config.maxStars));
               return {...calibration,valid:true,pixelArea:sqrSkyPixelArea(metadata,image.width,image.height),
                  pedestal:job.pedestal,path:job.path,fingerprint:job.fingerprint,catalog:catalog.name,channel:job.channels===3?'Green':'Mono',
                  astrometryRebuilt:solved,date:new Date().toISOString()};
            }catch(e){if(console.abortRequested)throw e;errors.push(catalog.name+': '+(e.message||String(e)));}
         }
         if(solved||!queried)throw new Error(errors.join('\n'));
         metadata=sqrSkySolveCoordinates(window,queried.name);solved=true;
      }
   }finally{if(image&&window.mainView.image.numberOfNominalChannels>=3)image.free();window.forceClose();}
}
/** Reuse the installed official AperturePhotometry engine. Query only local
 * configured Gaia databases; catalogue fallbacks reuse the measured stars.
 * The engine owns and closes its temporary image. Source files stay unchanged. */
function sqrSkyWorker(job){let result={valid:false},originalMeasurement=AperturePhotometryEngine.MeasurementImage;
   if(typeof AperturePhotometryEngine.prototype.MeasureDetectedStars==='function'){
      try{return sqrSkyMeasureGaia(job);}catch(e){return {valid:false,error:e.message||String(e)};}
   }
   try{
      let config=sqrSkyPhotometryConfig();config.starSource=StarSource.Catalog;config.calibrateMagnitudes=true;
      config.catalogId='GaiaDR3_XPSD';config.catalogBand='G';
      // Photometry and the plotted background both use G for an RGB image.
      AperturePhotometryEngine.MeasurementImage=sqrSkyMeasurementImage;
      let engine=new AperturePhotometryEngine(config),catalogSources=engine.CatalogSources.bind(engine),catalogName='Gaia DR3 (local)',catalogId='GaiaDR3_XPSD';
      engine.CatalogSources=function(target){let descriptor=PhotometricCatalogById('GaiaDR3_XPSD'),create=descriptor.create;
         try{for(let [name,factory] of [['Gaia DR3/SP (local)',()=>new GaiaDR3SPXPSDCatalog],['Gaia DR3 (local)',create],['Gaia EDR3 (local)',()=>new GaiaEDR3XPSDCatalog]]){
            if(console.abortRequested)throw new Error('Operation aborted.');descriptor.create=factory;catalogName=name;catalogId=factory().name;let sources=catalogSources(target);if(sources?.length)return sources;
         }return null;}finally{descriptor.create=create;}};
      let identify=engine.Identify.bind(engine);
      engine.Identify=function(target){identify(target);
         if(!Number.isFinite(target.catalogMatched))throw new Error(engine.catalogErrors?.join('\n')||'The configured local Gaia databases returned no catalog matches.');
         if(target.catalogMatched<20&&target.stars.filter(s=>s.valid).length>=20){
            target.metadata=sqrSkySolveCoordinates(engine.currentWindow,catalogId);target.skyAstrometryRebuilt=true;
            for(let star of target.stars){star.catalogMagnitude=null;star.catalogMagnitudes=null;star.flags|=StarFlag.Unmatched;}
            identify(target);
         }
      };
      engine.SetTargetFiles([job.path]);
      engine.monitor={header:s=>console.writeln(s),begin:s=>console.writeln(s),end:()=>{},note:s=>console.writeln(s),aborted:()=>console.abortRequested};
      engine.Measure((index,target)=>{
         if(target.error)throw new Error(target.error);
         // The engine's median > .05 heuristic also flags bright, long linear
         // exposures. It cannot establish a stretch; use unmodified WBPP data.
         let calibration=sqrSkyZeroPoint(target.stars),area=sqrSkyPixelArea(target.metadata,job.width,job.height);
         result={...calibration,valid:true,pixelArea:area,pedestal:job.pedestal,path:job.path,fingerprint:job.fingerprint,catalog:catalogName,channel:job.channels===3?'Green':'Mono',astrometryRebuilt:!!target.skyAstrometryRebuilt,date:new Date().toISOString()};return true;
      });
      if(!result.valid)throw new Error(engine.catalogErrors?.join('\n')||'No photometric calibration returned. Check the astrometric solution and local Gaia databases.');
   }catch(e){result={valid:false,error:e.message||String(e)};}finally{AperturePhotometryEngine.MeasurementImage=originalMeasurement;}
   return result;
}
function sqrCalibrateSky(session,group,notify){
   if(!sqrSkyFilterSupported(group))throw new Error('Sky comparison supports luminance, green, V, RGB, and red/blue estimates transferred from green.');
   if(sqrSkyColorTransfer(group)){
      let plan=sqrSkyTransferPlan(session,group);if(!plan.valid)throw new Error(plan.reason);
      let source=sqrCalibrateSky(session,plan.greenGroup,notify);
      for(let row of [plan.colour.row,plan.green.row])if(sqrFingerprint(row.registered.path)!==row.registered.fingerprint)throw new Error('A sky-transfer reference file has changed. Refresh the file list and measure again.');
      let result=sqrSkyTransferCalibration(session,plan,source);if(!result)throw new Error('The green-to-colour background conversion is outside the usable numeric range.');
      group.skyCalibration=result;delete group.skyCalibrationError;return result;
   }
   let sqm=sqrSQMReading(session.options),readingTime=sqm?sqrSQMTime(session.options,session):null;
   if(sqm&&readingTime.time===null)throw new Error(readingTime.reason);
   let row=sqrSkyReference(session,group);if(!row)throw new Error(sqm?'No eligible measured frame has a valid exposure time and background for SQM calibration.':'Measure the group first; no eligible reference has a valid default field score and background.');
   if(!group.rows.every(r=>sqrSkyComparable(row.registered,r.registered)))throw new Error('A shared sky calibration requires the same camera, filter, gain, exposure, binning, pedestal and image dimensions.');
   let path=row.registered.path,fingerprint=sqrFingerprint(path);
   if(fingerprint!==row.registered.fingerprint)throw new Error('The reference file has changed. Refresh the file list and measure again.');
   let current=sqrCurrentSkyCalibration(session,group);
   if(current){delete group.skyCalibrationError;group.skyCalibration=current;return current;}
   let job={...row.registered,path,fingerprint,pedestal:sqrSkyPedestal(row.registered)};
   if(sqm){
      if(group.skyCalibration?.valid&&group.skyCalibration.method!=='sqm'&&!group.skyGaiaCalibration)
         group.skyGaiaCalibration=group.skyCalibration;
      // A measured relative intensity needs no catalog, WCS or pixel area:
      // I(mu)-pedestal = (Iref-pedestal) * 10^[0.4*(SQM-mu)].
      // Use cached means on the same field/corner basis as the plotted KPI.
      let anchorBackground=sqrSkyBackground(row,!!session.options.measureCorners);
      let result={valid:true,method:'sqm',path,fingerprint,pedestal:job.pedestal,sqmReading:sqm,
         measurementTime:readingTime.time,referenceMidpoint:sqrExposureMidpoint(row),anchorBackground,
         backgroundBasis:session.options.measureCorners?'preview minimum':'whole image',channel:job.channels===3?'Green':'Mono'};
      group.skySQMCalibration=result;group.skyCalibration=result;delete group.skyCalibrationError;return result;
   }
   sqrTick(notify,'Calibrating sky from '+sqrFileName(path)+' — local Gaia');
   let result=sqrSkyWorker(job);if(!result.valid)throw new Error(result.error||'No sky calibration returned.');
   result.method='gaia';group.skyGaiaCalibration=result;group.skyCalibration=result;delete group.skyCalibrationError;return result;
}
/** One calibration reference per measured, compatible group. Failed/unsupported
 * groups keep their quality measurements; repeat requests reuse a valid result.
 * Called after measurement or when Bortle/SQM is specified afterwards. */
function sqrAutoCalibrateSky(session,notify){
   let result={calibrated:0,reused:0,failed:0,skipped:0};
   if(!session||!sqrSkyComparisonEnabled(session.options))return result;
   // Prepare direct calibrations first, independently of the visible group order.
   // R/B reuse green; they never launch their own photometry.
   for(let group of session.groups.slice().sort((a,b)=>Number(sqrSkyColorTransfer(a))-Number(sqrSkyColorTransfer(b)))){
      if(!sqrSkyFilterSupported(group)||!group.rows.some(r=>r.metrics[0])){++result.skipped;continue;}
      if(console.abortRequested)throw new Error('Sky-background calibration aborted.');
      try{
         // A failed green calibration must not be retried once for every colour
         // during the same measurement run. The manual button can retry later.
         if(sqrSkyColorTransfer(group)){let plan=sqrSkyTransferPlan(session,group);if(!plan.valid)throw new Error(plan.reason);
            if(!sqrCurrentSkyCalibration(session,plan.greenGroup))throw new Error(plan.greenGroup.skyCalibrationError||'The compatible green group has no usable sky calibration.');}
         let previous=sqrCurrentSkyCalibration(session,group);sqrCalibrateSky(session,group,notify);++result[previous?'reused':'calibrated'];}
      catch(e){if(console.abortRequested)throw e;group.skyCalibrationError=e.message||String(e);++result.failed;
         console.warningln('Sky brightness · '+(group.label||group.filter)+': '+group.skyCalibrationError);}
   }
   return result;
}
function sqrSkyCalibrationSummary(result){return !result?'':result.calibrated||result.reused||result.failed?
   ' Sky brightness: '+result.calibrated+' calibrated, '+result.reused+' reused'+(result.failed?', '+result.failed+' unavailable (see console)':'')+'.':'';}
function sqrSkyCalibrationText(c){if(c.transfer)return 'Sky calibrated: '+c.channel+' relative estimate from green · paired frames '+(c.transfer.gap/60000).toFixed(1)+' min apart.';
   return 'Sky calibrated: '+sqrFileName(c.path)+(c.method==='sqm'?
   ' · SQM '+c.sqmReading.toFixed(2)+' · exposure midpoint '+new Date(c.referenceMidpoint).toISOString()+' · '+
   (Math.abs(c.referenceMidpoint-c.measurementTime)/60000).toFixed(1)+' min from reading':
   ' · '+c.stars+' local Gaia stars · '+c.channel+' · scatter '+c.scatter.toFixed(3)+' mag'+(c.astrometryRebuilt?' · sky coordinates rebuilt':''));}


const SQR_FWHM_KEYS=['fwhmEnabled','fwhmAperture','fwhmSeeing','fwhmGoodPercent','fwhmMediumPercent','fwhmSeeingGood','fwhmSeeingMedium','fwhmAltitude','fwhmOptics','fwhmWavelengths'];
// Share the telescope list across reviews. Each process instance keeps its own active diameter.
const SQR_APERTURE_PRESETS_KEY='TGScripts/SubframeQualityReview/aperturePresets';
function sqrParseAperturePresets(text){
   let tokens=text.trim().split(/[,;\s]+/).filter(Boolean);
   if(tokens.some(token=>!/^\d+$/.test(token)||Number(token)<1||Number(token)>50000))return null;
   return [...new Set(tokens.map(Number))].sort((a,b)=>a-b);
}
function sqrReadAperturePresets(){
   let text=Settings.read(SQR_APERTURE_PRESETS_KEY,DataType.String);
   return Settings.lastReadOK?(sqrParseAperturePresets(text)||[]):[];
}
function sqrFWHMOptions(o={}){let defaults=sqrDefaults(),result=Object.fromEntries(SQR_FWHM_KEYS.map(key=>[key,o[key]??defaults[key]]));
   // Draft edits and process instances must not share a mutable override map.
   result.fwhmWavelengths=o.fwhmWavelengths&&typeof o.fwhmWavelengths==='object'&&!Array.isArray(o.fwhmWavelengths)?{...o.fwhmWavelengths}:{};return result;}
/** Exact filter aliases only: an unfamiliar name uses the green default.
 * Broadband values represent a passband; SII represents its two-line blend. */
function sqrFilterWavelength(filter){
   let name=String(filter??'').trim(),key=name.toUpperCase().replace(/Α/g,'A').replace(/[\s_\-\[\]]/g,'');
   let bands=[['Luminance',550,['L','LUMINANCE']],['Red',650,['R','RED']],['Green',550,['G','GREEN']],['Blue',450,['B','BLUE']],
      ['H-alpha',656.3,['H','HA','HALPHA','HYDROGENALPHA']],['OIII',500.7,['O','OIII','O3']],['SII',672.4,['S','SII','S2']]];
   let band=bands.find(b=>b[2].includes(key));return {filter:name,key:band?band[2][0]:'?'+key,name:band?band[0]:'Green default',nm:band?band[1]:550,known:!!band};
}
function sqrFilterWavelengthText(band,wavelength=band.nm,custom=false){return 'Filter '+(band.filter||'(not selected)')+' → '+band.name+': '+sqrFmt(wavelength,1)+' nm'+(custom?' (custom)':'');}
/** Fixed, user-selected acceptance limits, not a fit to each exposure's blur.
 * Independent Gaussian variances add; applying this to atmospheric/Airy/Moffat
 * FWHM is only an approximation. Guiding and guide-camera autofocus data do not
 * enter this model. The optional optical allowance is supplied independently.
 * Aperture and reference altitude are always explicit user parameters.
 * Optical/seeing model: https://www.eso.org/observing/etc/doc/helperis.html
 * Seeing exponents: https://www.gtc.iac.es/observing/toolbox.php
 * Our zenith seeing reference is 550 nm instead of these sources' 500 nm. */
function sqrFWHMModel(options,scale,filter=''){
   let o=sqrFWHMOptions(options),m={enabled:!!o.fwhmEnabled,valid:false,parametersValid:false,reason:''};
   const fail=reason=>({...m,reason});
   if(!m.enabled)return {...m,parametersValid:true,reason:'FWHM quality bands are disabled.'};
   for(let key of SQR_FWHM_KEYS.filter(k=>!['fwhmEnabled','fwhmWavelengths'].includes(k)))if(!Number.isFinite(o[key]))return fail('FWHM grading parameters must be finite numbers.');
   if(o.fwhmAperture<=0||o.fwhmAperture>50000)return fail('Enter the telescope aperture in Input files and observing conditions (greater than 0 mm).');
   if(o.fwhmSeeing<0)return fail('Zenith seeing must not be negative; use zero when no estimate is available.');
   m.mode=o.fwhmSeeing>0?'relative':'fixed';m.seeing=o.fwhmSeeing;
   if(m.mode==='fixed'&&(o.fwhmSeeingGood<=0||o.fwhmSeeingMedium<=o.fwhmSeeingGood))return fail('Seeing limits must be positive, with Medium greater than Good.');
   if(m.mode==='relative'&&(o.fwhmGoodPercent<=0||o.fwhmMediumPercent<=o.fwhmGoodPercent))return fail('Relative limits must be positive, with Medium greater than Good.');
   if(o.fwhmAltitude<15||o.fwhmAltitude>90)return fail('Reference target altitude must be between 15° and 90°.');
   if(o.fwhmOptics<0)return fail('Extra optical blur must not be negative.');
   m.aperture=o.fwhmAperture;m.altitude=o.fwhmAltitude;m.filter=sqrFilterWavelength(filter);
   m.customWavelength=Object.prototype.hasOwnProperty.call(o.fwhmWavelengths,m.filter.key);m.wavelength=m.customWavelength?o.fwhmWavelengths[m.filter.key]:m.filter.nm;
   if(!Number.isFinite(m.wavelength)||m.wavelength<300||m.wavelength>2500)return fail('Effective wavelength must be between 300 and 2500 nm.');
   m.parametersValid=true;
   m.airmass=1/Math.sin(o.fwhmAltitude*Math.PI/180);
   let seeingCorrection=Math.pow(m.airmass,.6)*Math.pow(m.wavelength/550,-.2);
   m.diffraction=1.028*(180*3600/Math.PI)*m.wavelength*1e-6/o.fwhmAperture;
   m.seeingGood=o.fwhmSeeingGood*seeingCorrection;m.seeingMedium=o.fwhmSeeingMedium*seeingCorrection;
   m.optics=o.fwhmOptics;
   if(m.mode==='relative'){
      m.correctedSeeing=o.fwhmSeeing*seeingCorrection;m.expectedArcsec=Math.hypot(m.diffraction,m.correctedSeeing,m.optics);
      m.goodPercent=o.fwhmGoodPercent;m.mediumPercent=o.fwhmMediumPercent;
      m.goodArcsec=m.expectedArcsec*m.goodPercent/100;m.mediumArcsec=m.expectedArcsec*m.mediumPercent/100;
   }else{
      m.goodArcsec=Math.hypot(m.diffraction,m.seeingGood,m.optics);
      m.mediumArcsec=Math.hypot(m.diffraction,m.seeingMedium,m.optics);
   }
   if(!Number.isFinite(m.goodArcsec)||!Number.isFinite(m.mediumArcsec)||m.mediumArcsec<=m.goodArcsec)return fail('The FWHM limits are not numerically distinguishable. Check the input values.');
   // The measured scalar FWHM has no angular axis information. Do not silently
   // use the conservative min(X,Y) scale intended for the guiding thresholds.
   if(scale?.reason)return fail('Image pixel scale unavailable: '+scale.reason+'.');
   if(!Number.isFinite(scale?.x)||!Number.isFinite(scale?.y)||scale.x<=0||scale.y<=0)return fail('A valid image pixel scale on both axes is required. Scan images with matching masters.');
   if(Math.abs(scale.x-scale.y)/Math.max(scale.x,scale.y)>.001)return fail('X/Y pixel scales differ by more than 0.1%; scalar FWHM grading is unavailable.');
   m.scale=(scale.x+scale.y)/2;m.good=m.goodArcsec/m.scale;m.medium=m.mediumArcsec/m.scale;
   if(m.mode==='relative')m.expected=m.expectedArcsec/m.scale;
   if(!Number.isFinite(m.good)||!Number.isFinite(m.medium)||m.medium<=m.good)return fail('The calculated FWHM limits are invalid for this pixel scale.');
   return {...m,valid:true};
}
function sqrFWHMCategory(value,model){return model?.valid&&Number.isFinite(value)&&value>=0?(value<=model.good?'Good':value<=model.medium?'Medium':'Bad'):'Unavailable';}
function sqrFWHMDescription(model,includeLimits=true){
   if(!model?.valid)return model?.reason||'Set the telescope aperture and reference conditions in FWHM grading.';
   return (model.mode==='relative'?'Expected FWHM '+sqrFmt(model.expected,1)+' px for zenith seeing '+sqrFmt(model.seeing,2)+'″. ':'')+(includeLimits?'Model limits: Good ≤ '+sqrFmt(model.good,1)+' px · Medium ≤ '+sqrFmt(model.medium,1)+' px · Bad above. ':'')+'Aperture '+sqrFmt(model.aperture,0)+' mm, altitude '+sqrFmt(model.altitude,1)+'°. '+sqrFilterWavelengthText(model.filter,model.wavelength,model.customWavelength)+'.';
}
/** Keep the model explanation readable in PixInsight's native rich-text view.
 * Values come from the current model; rounding is presentation-only. */
function sqrFWHMModelInformation(m){
   const table=rows=>'<table width="100%" cellspacing="3" cellpadding="4">'+rows.map(([label,value])=>'<tr><td width="210"><b>'+sqrHTML(label)+'</b></td><td>'+sqrHTML(value)+'</td></tr>').join('')+'</table>';
   let html='<html><body><h3>Current grading</h3>';
   if(m?.valid){
      html+='<p>'+(m.mode==='relative'?'<b>Expected FWHM: '+sqrFmt(m.expected,1)+' px</b><br/>Limits are '+sqrFmt(m.goodPercent,1)+'% and '+sqrFmt(m.mediumPercent,1)+'% of the expected width.':'Limits use the chosen Good and Medium seeing conditions.')+'</p>';
      html+='<table width="100%" cellspacing="3" cellpadding="5"><tr><th align="left" width="210">Grade</th><th align="left">Measured FWHM</th></tr>'+[
         ['Good','≤ '+sqrFmt(m.good,1)+' px'],['Medium','> '+sqrFmt(m.good,1)+' to '+sqrFmt(m.medium,1)+' px'],['Bad','> '+sqrFmt(m.medium,1)+' px']
      ].map(([label,value])=>'<tr><td bgcolor="'+sqrGradeSwatch(SQR_GRADE_COLORS[label])+'"><font color="#263746"><b>'+label+'</b></font></td><td>'+sqrHTML(value)+'</td></tr>').join('')+'</table>';
      html+='<h3>Reference conditions</h3>'+table([
         ['Telescope aperture',sqrFmt(m.aperture,0)+' mm'],['Target altitude',sqrFmt(m.altitude,1)+'° · airmass '+sqrFmt(m.airmass,2)],
         ['Filter and wavelength',(m.filter.filter||'Not selected')+' · '+m.filter.name+' · '+sqrFmt(m.wavelength,1)+' nm'+(m.customWavelength?' (custom)':'')],
         ['Image scale',sqrFmt(m.scale,3)+' arcsec/pixel'],
         ['Zenith seeing (550 nm)',m.mode==='relative'?sqrFmt(m.seeing,2)+' arcsec':'Good: '+sqrFmt(m.seeingGood/Math.pow(m.airmass,.6)/Math.pow(m.wavelength/550,-.2),2)+' arcsec; Medium: '+sqrFmt(m.seeingMedium/Math.pow(m.airmass,.6)/Math.pow(m.wavelength/550,-.2),2)+' arcsec']
      ]);
      html+='<h3>Blur contributions</h3>'+table([
         ['Diffraction',sqrFmt(m.diffraction/m.scale,1)+' px'],
         ['Seeing at target',m.mode==='relative'?sqrFmt(m.correctedSeeing/m.scale,1)+' px':'Good boundary: '+sqrFmt(m.seeingGood/m.scale,1)+' px; Medium boundary: '+sqrFmt(m.seeingMedium/m.scale,1)+' px'],
         ['Additional optical blur',sqrFmt(m.optics/m.scale,1)+' px']
      ]);
   }else html+='<p>'+sqrHTML(m?.reason||'Set the telescope aperture and reference conditions.')+'</p>';
   html+='<h3>How the limits are calculated</h3><p><b>Total FWHM = √(diffraction² + corrected seeing² + optical blur²)</b></p>'+
      '<p>Seeing is adjusted for altitude and wavelength. The image scale converts the resulting width to pixels. Values are shown with one decimal place; grading uses full precision.</p>'+
      '<h3>Where the inputs come from</h3><p>Set aperture and zenith seeing in <b>Input files and observing conditions</b>. Image scale comes from the master metadata. Set altitude, wavelength and optional optical blur in <b>FWHM grading</b>.</p>'+
      '<h3>Filter wavelength defaults</h3>'+table([['L / G / unknown','550.0 nm'],['R','650.0 nm'],['B','450.0 nm'],['H (H-alpha)','656.3 nm'],['O (OIII)','500.7 nm'],['S (SII)','672.4 nm']])+
      '<p>Broadband wavelengths are representative values.</p><h3>Using the model</h3><p>This is an approximate visual grading guide. Real star profiles and image sampling can differ. Guide-camera data are excluded. The bands do not change scores or rejection decisions.</p></body></html>';
   return {title:'FWHM grading — model information',model:true,html};
}
// Validate saved intervals as well as UI input; legacy instances use the default.
function sqrBlinkInterval(value){return Number.isFinite(value)?Math.max(.1,Math.min(10,value)):sqrDefaults().blinkInterval;}
// Normalize paths for I/O, then compare case-insensitively for this Windows
// workflow. The trailing slash in sqrUnder prevents matching a sibling prefix.
function sqrPath(p){return File.fullPath(String(p).trim()).replace(/\\/g,'/').replace(/\/$/,'');}
function sqrKey(p){let s=String(p).replace(/\\/g,'/').replace(/\/$/,'');return s.toLowerCase();}
function sqrSameWindowsRunFolder(a,b){
   // Keep the drive or UNC share as one root. fullPath expands relative and
   // short paths, but can retain the caller's capitalization for long names.
   const parts=path=>File.fullPath(path).replace(/\\/g,'/').match(/^[/]{2}[^/]+[/][^/]+|[^/]+/g);
   const left=parts(a),right=parts(b);
   if(left.length!==right.length||left[0].toLowerCase()!==right[0].toLowerCase())return false;
   function entryName(components,i){
      const find=new FileFind;
      try{return find.begin(components.slice(0,i+1).join('/'))?find.name:null;}
      finally{find.end();}
   }
   // Compare the names returned by the parent directory, including ancestors:
   // two case-sensitive sibling folders can each contain a child named Lights.
   for(let i=1;i<left.length;++i)if(left[i]!==right[i]){
      const name=entryName(left,i);
      if(name===null||name!==entryName(right,i))return false;
   }
   return true;
}
function sqrSameRunFolder(left,right){
   const a=String(left||'').trim(),b=String(right||'').trim();
   if(a===b)return true;
   if(!a||!b)return false;
   try{
      if(!File.directoryExists(a)||!File.directoryExists(b))return false;
      return CoreApplication.platform==='Windows'?sqrSameWindowsRunFolder(a,b):File.sameFile(a,b);
   }catch(e){return false;} // An edited path may be incomplete or inaccessible.
}
function sqrSameRunFolders(a,b){
   return sqrSameRunFolder(a.wbpp,b.wbpp)&&sqrSameRunFolder(a.originals,b.originals);
}
function sqrUnder(p,root){return sqrKey(p)===sqrKey(root)||sqrKey(p).startsWith(sqrKey(root)+'/');}
function sqrDir(p){return File.extractDrive(p)+File.extractDirectory(p);}
// New instances save one shared log folder. Import an older single-log setting
// as its parent folder; an explicit new (even empty) folder takes precedence.
function sqrLogFolderOption(o={}){
   if(typeof o.logFolder==='string')return o.logFolder.trim();
   let old=String(o.autorunLog||'').trim();return old?sqrDir(old):'';
}
/** Resolve the standard installed PIDoc manual first. The remaining paths
 * support a repository checkout or a local bundle without registering it.
 * Explicit parameters make the same path rules usable by validation harnesses. */
function sqrDocumentationPath(scriptFile=SQR_FILE,docDirectory=CoreApplication.docDirPath){
   let relative='/scripts/SubframeQualityReview/SubframeQualityReview.html',dir=sqrDir(scriptFile);
   let candidates=[docDirectory.replace(/[\\/]+$/,'')+relative,
      File.fullPath(dir+'/../../../doc'+relative),dir+'/doc'+relative,dir+'/SubframeQualityReview.html'];
   return candidates.find(path=>File.exists(path))||'';
}
function sqrShowDocumentation(){
   let page=sqrDocumentationPath();
   if(page)Dialog.openBrowser(page,'Subframe Quality Review - User Guide');
   else new MessageBox('The Subframe Quality Review user guide is missing. Check that the TGScripts installation includes its documentation.',
      'User documentation not found',StdIcon.Warning,StdButton.Ok).execute();
}
function sqrBase(p){return File.extractName(p);}
function sqrFileName(p){return File.extractNameAndSuffix(p);}
function sqrImageFile(p){return /\.(xisf|fit|fits|fts)$/i.test(p);}
// Robust group statistics ignore unavailable values. The scale floor prevents
// a nearly identical set of measurements from producing unbounded penalties.
function sqrMedian(a){let s=a.filter(Number.isFinite).sort((a,b)=>a-b),n=s.length;return n?(n%2?s[(n-1)/2]:(s[n/2-1]+s[n/2])/2):NaN;}
function sqrSummary(a){let m=sqrMedian(a),mad=sqrMedian(a.map(x=>Math.abs(x-m)));return {median:m,scale:Math.max(1.4826*mad,Math.abs(m)*0.02,1e-12)};}
/** Convert a measurement to a nonnegative, capped poor-quality deviation.
 * lower=true means a smaller value is worse; better-than-median values add zero.
 * Missing-data flags are handled separately by sqrRank, not inferred from zero. */
function sqrBad(x,s,lower){return Number.isFinite(x)&&Number.isFinite(s.median)?Math.min(10,Math.max(0,(lower?s.median-x:x-s.median)/s.scale)):0;}
function sqrFmt(x,n=3){return Number.isFinite(x)?x.toFixed(n):'n/a';}
// Report guiding to tenths, including decimal half-way values such as 0.95.
// This is presentation only; never feed rounded values back into scoring.
function sqrGuideNumber(x){return Number.isFinite(x)?(Math.round((x+Number.EPSILON)*10)/10).toFixed(1):'n/a';}
function sqrStamp(){return new Date().toISOString().replace(/[:.]/g,'-');}
// Size and modification time detect changes since scanning; this is a cheap
// identity check for cache/move validation, not a cryptographic content hash.
function sqrFingerprint(path){let f=new FileInfo(path);if(!f.exists||!f.isFile)throw new Error('Missing file: '+path);return String(f.size)+'|'+f.lastModified.toISOString();}
// Long loops yield to PixInsight, report progress and honor console aborts.
function sqrTick(notify,text){if(notify)notify(text);CoreApplication.processEvents();if(console.abortRequested)throw new Error('Operation aborted.');}
/** Recursively collect supported image paths, skipping explicit exclusions
 * and symbolic links so a scan does not escape through a linked directory. */
function sqrWalk(root,exclude=[],skipRepairCopies=false){
   let files=[];let visit=dir=>{
      if(exclude.some(p=>p&&sqrUnder(dir,p)))return;
      let f=new FileFind;
      if(f.begin(dir+'/*'))try{do{
         if(f.name==='.'||f.name==='..'||f.isSymbolicLink||(skipRepairCopies&&f.isDirectory&&f.name==='.sqr-trail-copies'))continue;
         let p=dir+'/'+f.name;if(f.isDirectory)visit(p);else if(sqrImageFile(p))files.push(p);
      }while(f.next());}finally{f.end();}
   };visit(sqrPath(root));return files.sort();
}
function sqrUnquote(v){let s=String(v||'').trim();return (s.startsWith("'")&&s.endsWith("'")?s.slice(1,-1).replace(/''/g,"'"):s).trim();}
// Only observation geometry/time is carried into measurement crops. Inherited
// noise, signal, normalization and WCS image transforms must not be copied.
const SQR_OBSERVATION_KEYS=['DATE-OBS','DATEOBS','DATE-END','DATEEND','TIME-OBS','TIMEOBS','TIME-END','TIMEEND','RA','DEC','OBJCTRA','OBJCTDEC',
   'OBSGEO-L','OBSGEO-B','OBSGEO-H','LONG-OBS','LAT-OBS','SITELONG','SITELAT','OBJCTALT','OBJCTAZ'];
const SQR_OBSERVATION_PROPERTIES=['Observation:Time:Start','Observation:Time:End','Observation:Center:RA',
   'Observation:Center:Dec','Observation:Location:Longitude','Observation:Location:Latitude','Observation:Location:Elevation'];
/** Return a complete UTC observation timestamp, or null when time is unknown.
 * ImageAnalysis ignores separate TIME-OBS/TIME-END keywords. Join them before
 * writing crops; never let a date-only value silently become midnight. Preserve
 * the fractional seconds verbatim, including precision finer than Date's ms. */
function sqrObservationTimestamp(dateValue,timeValue=''){
   let stamp=dateValue instanceof Date?(Number.isFinite(dateValue.getTime())?dateValue.toISOString():''):sqrUnquote(dateValue);
   if(/^\d{4}-\d{2}-\d{2}$/.test(stamp))stamp+='T'+sqrUnquote(timeValue);
   let m=stamp.match(/^(\d{4})-(\d{2})-(\d{2})[T ](\d{2}):(\d{2})(?::(\d{2})(\.\d+)?)?(Z|[+-]\d{2}:?\d{2})?$/i);
   if(!m)return null;
   let [year,month,day,hour,minute]=m.slice(1,6).map(Number),second=Number(m[6]||0);
   if(month<1||month>12||day<1||day>31||hour>23||minute>59||second>59)return null;
   let base=Date.parse(m[1]+'-'+m[2]+'-'+m[3]+'T'+m[4]+':'+m[5]+':'+(m[6]||'00')+'Z'),calendar=new Date(base);
   if(!Number.isFinite(base)||calendar.getUTCFullYear()!==year||calendar.getUTCMonth()!==month-1||calendar.getUTCDate()!==day)return null;
   let zone=m[8]||'Z',offset=0;
   if(zone.toUpperCase()!=='Z'){
      let parts=zone.slice(1).replace(':',''),hours=Number(parts.slice(0,2)),minutes=Number(parts.slice(2));
      if(hours>23||minutes>59)return null;
      offset=(hours*60+minutes)*(zone[0]==='-'?-1:1);
   }
   let utc=new Date(base-offset*60000);
   if(utc.getUTCFullYear()<0||utc.getUTCFullYear()>9999)return null;
   return utc.toISOString().slice(0,19)+(m[7]||'')+'Z';
}
/** Retain scalar observation metadata, preserving FITS angle conventions.
 * TimePoint properties become UTC FITS dates so worker payloads contain only
 * plain values. Native ImageAnalysis derives altitude and airmass; never use the
 * separate, user-specified FWHM model altitude for an observed frame. */
function sqrObservationMetadata(metadata){
   let k=metadata?.keywords||{},p=metadata?.properties||{},keywords=new Map,properties=[];
   let literal=value=>/^[+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:[EeDd][+-]?\d+)?$/.test(String(value).trim())?
      String(value).trim():"'"+String(value).replace(/'/g,"''")+"'";
   for(let name of SQR_OBSERVATION_KEYS)if(k[name]!==undefined&&String(k[name]).trim()!=='')keywords.set(name,[name,literal(k[name]),'']);
   for(let item of metadata?.observationKeywords||[])if(SQR_OBSERVATION_KEYS.includes(item[0]))keywords.set(item[0],item);
   for(let id of SQR_OBSERVATION_PROPERTIES)if(!id.startsWith('Observation:Time:')&&Number.isFinite(p[id]))properties.push([id,p[id]]);
   for(let [suffix,property] of [['OBS','Start'],['END','End']]){
      let names=['DATE-'+suffix,'DATE'+suffix,'TIME-'+suffix,'TIME'+suffix],value=name=>sqrUnquote(keywords.get(name)?.[1]);
      // Valid XISF properties retain priority. Canonical FITS names win over
      // non-hyphenated aliases, and raw keyword literals retain their priority.
      let stamp=sqrObservationTimestamp(p['Observation:Time:'+property])||
         sqrObservationTimestamp(value(names[0])||value(names[1]),value(names[2])||value(names[3]));
      for(let name of names)keywords.delete(name);
      if(stamp)keywords.set(names[0],[names[0],literal(stamp),'UTC observation time']);
   }
   // A celestial WCS reference is a valid fallback for target coordinates, but
   // its pixel transforms would be wrong after cropping and are not transferred.
   if(!properties.some(x=>x[0]==='Observation:Center:RA')&&!properties.some(x=>x[0]==='Observation:Center:Dec')&&
      !((k.RA!==undefined&&k.DEC!==undefined)||(k.OBJCTRA!==undefined&&k.OBJCTDEC!==undefined))&&
      /^RA---/.test(k.CTYPE1||'')&&/^DEC--/.test(k.CTYPE2||'')){
      let ra=String(k.CRVAL1??'').trim()?Number(k.CRVAL1):NaN,dec=String(k.CRVAL2??'').trim()?Number(k.CRVAL2):NaN;
      if(Number.isFinite(ra)&&Number.isFinite(dec))properties.push(['Observation:Center:RA',ra],['Observation:Center:Dec',dec]);
   }
   return {keywords:[...keywords.values()],properties};
}
function sqrValidSite(site){
   return Number.isFinite(site?.latitude)&&Math.abs(site.latitude)<=90&&
      Number.isFinite(site.longitude)&&Math.abs(site.longitude)<=180;
}
// Parse an entire FITS angle before accepting it as a run-wide location.
function sqrHeaderDegrees(value){
   let text=sqrUnquote(value),decimal=/^[+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:[dDeE][+-]?\d+)?$/;
   if(decimal.test(text))return Number(text.replace(/[dD]/,'e'));
   let m=/^([+-]?)(\d+)(?:\s*:\s*|\s+)(\d+(?:\.\d+)?)(?:(?:\s*:\s*|\s+)(\d+(?:\.\d+)?))?$/.exec(text);
   if(!m||+m[3]>=60||+(m[4]||0)>=60)return NaN;
   return (m[1]==='-'?-1:1)*(+m[2]+m[3]/60+(m[4]||0)/3600);
}
// A geographic site can be shared across the run. Horizontal telescope
// pointing is also useful to ImageAnalysis but belongs only to its exposure.
function sqrRecordedLocation(observation){
   let p=new Map(observation.properties),k=new Map(observation.keywords.map(item=>[item[0],item]));
   let site={latitude:p.get('Observation:Location:Latitude'),longitude:p.get('Observation:Location:Longitude')};
   if(sqrValidSite(site))
      return {site,properties:observation.properties.filter(item=>item[0].startsWith('Observation:Location:')),keywords:[]};
   for(let pair of [['OBSGEO-B','OBSGEO-L'],['LAT-OBS','LONG-OBS'],['SITELAT','SITELONG'],['OBJCTALT','OBJCTAZ']]){
      let [latitude,longitude]=pair.map(name=>sqrHeaderDegrees(k.get(name)?.[1]));
      if(Math.abs(latitude)<=90&&longitude>=(pair[0]==='OBJCTALT'?0:-180)&&longitude<=360)
         return {site:pair[0]==='OBJCTALT'?null:{latitude,longitude:longitude>180?longitude-360:longitude},properties:[],keywords:pair.map(name=>k.get(name))};
   }
   return null;
}
// All groups in one WBPP run share a site. Scanning has already read these
// headers. Keep this summary with the session, separate from saved profiles.
function sqrRunSite(session){
   if(!session)return null;
   if(session.headerSiteSummary)return session.headerSiteSummary;
   let summary={total:0,recorded:0,pointing:0,site:null};
   for(let group of session.groups)for(let row of group.rows){
      if(row.isMaster)continue;
      ++summary.total;
      let loc=sqrRecordedLocation(sqrObservationMetadata(row.registered));
      let original=!loc?.site&&row.original?sqrRecordedLocation(sqrObservationMetadata(row.original)):null;
      let site=loc?.site||original?.site;
      if(site){++summary.recorded;summary.site??=site;}
      else if(loc||original)++summary.pointing;
   }
   if(!summary.site)for(let group of session.groups){
      // The master may retain geographic metadata when the lights do not.
      // Its integration time and pointing can never stand in for an exposure.
      let site=group.masterHeaderSite||sqrRecordedLocation(sqrObservationMetadata(group.masterRow?.registered))?.site;
      if(site){summary.site=site;summary.fromMaster=true;break;}
   }
   return session.headerSiteSummary=summary;
}
function sqrRowObservation(row,site=null){
   let obs=sqrObservationMetadata(row.registered);
   if(sqrRecordedLocation(obs))return obs;
   let source=row.original?sqrRecordedLocation(sqrObservationMetadata(row.original)):null;
   let k=new Map(obs.keywords.map(item=>[item[0],item])),p=new Map(obs.properties);
   let hasTime=k.has('DATE-OBS')||k.has('DATE-END');
   let hasTarget=(p.has('Observation:Center:RA')&&p.has('Observation:Center:Dec'))||
      (k.has('RA')&&k.has('DEC'))||(k.has('OBJCTRA')&&k.has('OBJCTDEC'));
   obs.needsSite=!source&&hasTime&&hasTarget;
   if(obs.needsSite&&sqrValidSite(site))source={keywords:[],properties:[
      ['Observation:Location:Latitude',site.latitude],['Observation:Location:Longitude',site.longitude]]};
   if(source){
      for(let name of ['OBSGEO-B','OBSGEO-L','LAT-OBS','LONG-OBS','SITELAT','SITELONG','OBJCTALT','OBJCTAZ'])k.delete(name);
      p.delete('Observation:Location:Latitude');p.delete('Observation:Location:Longitude');
      for(let item of source.keywords)k.set(item[0],item);
      for(let item of source.properties)p.set(item[0],item[1]);
      obs.keywords=[...k.values()];obs.properties=[...p.entries()];
   }
   return obs;
}
function sqrGroupNeedsSite(group){
   return group.rows.some(r=>sqrRowObservation(r).needsSite);
}
function sqrExtinctionSiteKey(group,site){
   return sqrValidSite(site)&&sqrGroupNeedsSite(group)?site.latitude+','+site.longitude:'';
}
/** Read headers and image geometry without loading pixels. Multi-image files
 * are rejected by default; master reading may explicitly allow the first image.
 * The format instance is always closed, including on malformed-file errors. */
function sqrMetadata(path,allowMultiple=false){
   let f=new FileFormatInstance(new FileFormat(File.extractExtension(path),true,false));
   try{
      let d=f.open(path,'verbosity 0');if(!d||!d.length||(!allowMultiple&&d.length!==1))throw new Error('Expected one image: '+path);
      let k={},observationKeywords=[];for(let v of f.keywords){let name=v.name.toUpperCase();k[name]=sqrUnquote(v.value);
         if(SQR_OBSERVATION_KEYS.includes(name))observationKeywords.push([name,String(v.value),'']);}
      // Camera identification may be stored only as an XISF property. Masters
      // additionally need three scalar scale properties; never load pixels.
      let ids=['Instrument:Camera:Name','Instrument:FrameExposureTime',...SQR_OBSERVATION_PROPERTIES];
      if(allowMultiple)ids.push('Instrument:Telescope:FocalLength','Instrument:Sensor:XPixelSize','Instrument:Sensor:YPixelSize',SQR_MASTER_GROUP_PROPERTY);
      else ids.push('Instrument:ExposureTime');
      let properties={};if(f.format.canStoreImageProperties)for(let p of f.imageProperties){
         // Installed PJSR returns [id,type]; accept named descriptors as well.
         let id=Array.isArray(p)?p[0]:p.id;
         if(ids.includes(id)){let value=f.readImageProperty(id);properties[id]=value instanceof Date?value.toISOString():value;}
      }
      return {path:path,fingerprint:sqrFingerprint(path),width:d[0].width,height:d[0].height,
         channels:d[0].numberOfChannels,keywords:k,properties,observationKeywords,date:k['DATE-OBS']||k.DATEOBS||'',
         camera:sqrUnquote(properties['Instrument:Camera:Name'])||k.INSTRUME||'',filter:k.FILTER||'',
         // An averaged WBPP master retains the normalization frame's exposure.
         // Total integration time is NOT the exposure represented by its pixels.
         exposure:sqrPositiveMetadata(properties['Instrument:FrameExposureTime'])??sqrPositiveMetadata(k.EXPTIME)??sqrPositiveMetadata(k.EXPOSURE)??sqrPositiveMetadata(properties['Instrument:ExposureTime'])??0,
         binX:k.XBINNING||k.CCDXBIN||'',binY:k.YBINNING||k.CCDYBIN||'',gain:k.GAIN||'',
         object:k.OBJECT||'',type:k.IMAGETYP||k.FRAME||''};
   }finally{f.close();}
}
// FITS may use D for a scientific-notation exponent. Reject missing, nonnumeric,
// zero and negative values instead of producing a plausible but incorrect scale.
function sqrPositiveMetadata(value){let n=Number(sqrUnquote(value).replace(/[dD]/,'e'));return Number.isFinite(n)&&n>0?n:null;}
/** Nominal angular sampling from focal length and effective image-pixel size.
 * XISF focal lengths are in metres; FITS FOCALLEN is in millimetres. Both pixel
 * sizes are in micrometres and already include binning (PixInsight convention).
 * Never multiply by XBINNING/YBINNING again or assume a missing axis is square. */
function sqrPixelScale(metadata){
   let p=metadata.properties||{},k=metadata.keywords||{},f=sqrPositiveMetadata(p['Instrument:Telescope:FocalLength']);
   let focalLength=f!==null?f*1000:sqrPositiveMetadata(k.FOCALLEN);
   let pixelSizeX=sqrPositiveMetadata(p['Instrument:Sensor:XPixelSize'])??sqrPositiveMetadata(k.XPIXSZ)??sqrPositiveMetadata(k.PIXSIZE);
   let pixelSizeY=sqrPositiveMetadata(p['Instrument:Sensor:YPixelSize'])??sqrPositiveMetadata(k.YPIXSZ)??sqrPositiveMetadata(k.PIXSIZE);
   const arcsecPerRadian=180*3600/Math.PI;
   const scale=pixel=>{let n=focalLength&&pixel?arcsecPerRadian*pixel/(1000*focalLength):null;return Number.isFinite(n)&&n>0?n:null;};
   return {x:scale(pixelSizeX),y:scale(pixelSizeY),focalLength,pixelSizeX,pixelSizeY,camera:metadata.camera||'',width:metadata.width,height:metadata.height,
      reason:!focalLength?'missing or invalid focal length':!pixelSizeX&&!pixelSizeY?'missing or invalid pixel size':''};
}
// Cache one header read per matched master/group. Status updates and blinking
// reuse this result; rescanning builds fresh groups and refreshes the metadata.
function sqrMasterScale(group){
   if(!group)return {x:null,y:null,reason:'no group selected'};
   let path=group.master||'';if(group.pixelScale?.path===path)return group.pixelScale;
   let result={x:null,y:null,reason:'no matched master'};
   group.masterHeaderSite=null;
   if(path)try{let header=sqrMetadata(path,true);result=sqrPixelScale(header);
      group.masterHeaderSite=sqrRecordedLocation(sqrObservationMetadata(header))?.site||null;}
   catch(e){if(console.abortRequested)throw e;result.reason='master metadata could not be read';result.error=String(e);}
   return group.pixelScale={...result,path};
}
/** One camera and one nominal sampling for the entire review, independent of
 * filter selection. Verify every registered frame, associated original and
 * matched master. Missing identities remain explicitly unverified. */
function sqrSessionPixelScale(session){
   let result={x:null,y:null,cameras:[],missingCamera:[],masters:[],reason:'no images scanned'},names={},seen=new Set;
   if(!session?.groups?.length)return result;
   const camera=m=>{if(!m?.path||seen.has(sqrKey(m.path)))return;seen.add(sqrKey(m.path));
      let name=String(m.camera||'').trim().replace(/\s+/g,' ');if(name)names[name.toLowerCase()]??=name;else result.missingCamera.push(m.path);};
   let mismatch=false;
   for(let g of session.groups){
      for(let r of g.rows){camera(r.registered);camera(r.original);}
      let s=sqrMasterScale(g);if(s.path){camera(s);if(!result.masters.some(m=>sqrKey(m.path)===sqrKey(s.path)))result.masters.push(s);
         mismatch||=(g.width>0&&s.width>0&&s.width!==g.width)||(g.height>0&&s.height>0&&s.height!==g.height);}
   }
   result.cameras=Object.values(names).sort();
   if(result.cameras.length>1){result.reason='different cameras in the input images';return result;}
   if(mismatch){result.reason='master and registered image dimensions differ';return result;}
   // Compare at the displayed precision, allowing insignificant header rounding.
   // A shared camera alone cannot guarantee equal sampling with different optics
   // or binning, so conflicting master scales are never silently combined.
   for(let axis of ['x','y']){let values=result.masters.map(m=>m[axis]).filter(v=>Number.isFinite(v)&&v>0);
      if(new Set(values.map(v=>v.toFixed(3))).size>1){result.reason='master scales disagree; check focal length, pixel size and binning';return result;}
      result[axis]=values.length?sqrMedian(values):null;
   }
   result.reason=result.x===null&&result.y===null?(result.masters[0]?.reason||'no matched master'):'';return result;
}
function sqrPixelScaleText(s){
   let value=s.reason?'unavailable — '+s.reason:s.x!==null&&s.y!==null&&s.x.toFixed(3)===s.y.toFixed(3)?s.x.toFixed(3)+' arcsec/pixel':
      'X '+(s.x===null?'unavailable':s.x.toFixed(3))+' · Y '+(s.y===null?'unavailable':s.y.toFixed(3))+' arcsec/pixel';
   let camera=s.cameras.length?s.cameras.join(', '):'unavailable';if(s.missingCamera.length)camera+=' (not fully verified)';
   return 'Pixel scale: '+value+' · Camera: '+camera;
}
function sqrIsLight(m){
   if(/master|flat|dark|bias/i.test(m.type)||/^master/i.test(sqrBase(m.path)))return false;
   return /light|science|object/i.test(m.type)||(!m.type&&/^light[_ -]/i.test(sqrBase(m.path)));
}
// Optional header fields constrain a match when both sides provide them.
// sqrFindOriginal adds mandatory date, camera and exposure requirements.
function sqrCompatible(a,b){
   if(a.date&&b.date&&a.date!==b.date)return false;
   for(let k of ['camera','filter','binX','binY','gain','object'])if(a[k]&&b[k]&&a[k]!==b[k])return false;
   return !(a.exposure&&b.exposure&&Math.abs(a.exposure-b.exposure)>0.001);
}
function sqrSourceStem(p){return sqrBase(p).replace(/(?:_(?:c|cc|d|r|a|ln|n))+$/i,'').toLowerCase();}
// Build once per scan. Buckets retain duplicates and input order; they narrow
// the lookup only, leaving identity and ambiguity checks to sqrFindOriginal.
function sqrIndexOriginals(raws){
   let names=new Map,dates=new Map;
   for(let r of raws){let name=sqrBase(r.path).toLowerCase();
      if(!names.has(name))names.set(name,[]);names.get(name).push(r);
      if(r.date){if(!dates.has(r.date))dates.set(r.date,[]);dates.get(r.date).push(r);}}
   return {names,dates};
}
/** Match a processed light to exactly one original. A stripped WBPP filename
 * is a candidate lookup, not proof of identity: acquisition metadata must agree.
 * Ambiguity remains unresolved and blocks moving that original. */
function sqrFindOriginal(reg,raws,index=null){
   let stem=sqrSourceStem(reg.path),named=index?(index.names.get(stem)||[]):raws.filter(r=>sqrBase(r.path).toLowerCase()===stem);
   // Retain all duplicates and the original name-before-date rule. An
   // incompatible name match must not fall back to another exposure by date.
   let candidates=named.length?named:index?(reg.date?index.dates.get(reg.date)||[]:[]):raws.filter(r=>reg.date&&r.date===reg.date);
   candidates=candidates.filter(r=>sqrCompatible(reg,r)&&reg.date&&r.date===reg.date&&reg.camera&&r.camera===reg.camera&&reg.exposure>0&&r.exposure>0);
   return candidates.length===1?{raw:candidates[0],state:'Verified'}:
      {raw:null,state:candidates.length>1?'Ambiguous original':'Original not verified'};
}
/** Find a filter master, using the WBPP group name to resolve multiple masters
 * for one filter. An empty result is deliberate when the association is unclear. */
function sqrMasterFor(group,masters){
   let filter=String(group.filter||'').trim().toLowerCase();if(!filter)return '';
   let matches=masters.filter(p=>/^masterLight(?:_|$)/i.test(sqrBase(p))&&sqrFilterFromName(p).toLowerCase()===filter);
   if(matches.length===1)return matches[0];
   // Several integrations can share a filter, e.g. distinct exposure groups.
   let name=group.directoryName.replace(/^Light_/i,'masterLight_');
   let exact=matches.filter(p=>sqrBase(p).toLowerCase()===name.toLowerCase());
   return exact.length===1?exact[0]:'';
}
function sqrFilterFromName(path){let name=sqrFileName(path).replace(/\.(xisf|fit|fits|fts)$/i,'');return ((name.match(/(?:^|_)FILTER[-_](.+?)(?:_(?:mono|cfa|rgb)(?:_|$)|$)/i)||[])[1]||'').trim();}
// Reuse the master row object while its path is unchanged: selection and cached
// measurements refer to this same object across table and plot refreshes.
function sqrMasterRow(group){
   if(!group.master){group.masterRow=null;return null;}
   if(!group.masterRow||sqrKey(group.masterRow.registered.path)!==sqrKey(group.master))group.masterRow={isMaster:true,
      registered:{path:group.master},original:null,match:'Integrated master',reject:false,moved:false,candidate:false,score:null,metrics:{},
      reasons:['Integrated master: comparison only; cannot be rejected.']};
   return group.masterRow;
}
function sqrGroupRows(group){let master=sqrMasterRow(group);return master?[...group.rows,master]:group.rows;}
/** Return UTC epoch milliseconds, or null when neither metadata source is valid.
 * Prefer the verified original, then the registered header; combine DATE-OBS and
 * TIME-OBS when needed. Offset-free observation times are interpreted as UTC.
 * Filename counters and local-clock filename strings never break timestamp ties. */
function sqrAcquisitionTime(row){
   for(let meta of [row.original,row.registered]){
      if(!meta)continue;let stamp=String(meta.date||'').trim();
      if(/^\d{4}-\d{2}-\d{2}$/.test(stamp))stamp+='T'+String(meta.keywords?.['TIME-OBS']||meta.keywords?.TIMEOBS||'').trim();
      let m=stamp.match(/^(\d{4})-(\d{2})-(\d{2})[T ](\d{2}):(\d{2}):(\d{2})(\.\d+)?(Z|[+-]\d{2}:?\d{2})?$/i);
      if(!m)continue;
      let [year,month,day,hour,minute,second]=m.slice(1,7).map(Number);
      if(month<1||month>12||day<1||day>new Date(Date.UTC(year,month,0)).getUTCDate()||hour>23||minute>59||second>59)continue;
      let zone=m[8]||'Z';if(/^[+-]\d{4}$/.test(zone))zone=zone.slice(0,3)+':'+zone.slice(3);
      let value=Date.parse(m[1]+'-'+m[2]+'-'+m[3]+'T'+m[4]+':'+m[5]+':'+m[6]+(m[7]||'')+zone.toUpperCase());
      if(Number.isFinite(value))return value;
   }return null;
}
function sqrAcquisitionLabel(row){let time=sqrAcquisitionTime(row);return time===null?'Acquisition time unavailable':'Acquired: '+new Date(time).toISOString()+' (UTC)';}
function sqrAcquisitionText(row){let time=row.isMaster?null:sqrAcquisitionTime(row);return time===null?'—':new Date(time).toISOString().replace('T',' ').replace('Z','');}
// Logs carry local wall time. The UI supplies the inferred/custom conversion;
// legacy local/UTC modes remain available only to callers of this helper.
function sqrLogTime(stamp,zone='local',offset=0){
   let m=stamp.match(/^(\d{4})[-/](\d{2})[-/](\d{2}) (\d{2}):(\d{2}):(\d{2})$/);if(!m)return null;
   let [year,month,day,hour,minute,second]=m.slice(1).map(Number);
   if(month<1||month>12||day<1||day>new Date(Date.UTC(year,month,0)).getUTCDate()||hour>23||minute>59||second>59)return null;
   let wall=Date.UTC(year,month-1,day,hour,minute,second);if(typeof zone==='function')return zone(wall);
   if(zone==='auto')return null;
   if(zone==='local')return new Date(year,month-1,day,hour,minute,second).getTime();
   if(zone==='offset'&&(!Number.isFinite(offset)||offset<-12||offset>14))return null;
   return wall-(zone==='offset'?offset*3600000:0);
}
// Read supported logs once, directly in the selected folder. Translations,
// subdirectories and symlinks do not add duplicate or unrelated observations.
function sqrIsAutorunLog(name){return /^Autorun_log(?:_|\.|$)/i.test(name);}
function sqrIsGuideLog(name){return /^PHD2_GuideLog(?:_|\.|$)/i.test(name);}
function sqrIsTranslatedLog(name){return /_CHN(?:_|\.|$)/i.test(name);}
function sqrReadLogFolder(folder){
   let dir=sqrPath(folder),paths=[],ignoredCHN=0;
   if(!File.directoryExists(dir))throw new Error('Log folder does not exist or is not accessible: '+folder);
   let find=new FileFind;
   if(find.begin(dir+'/*'))try{do{
      if(find.isDirectory||find.isSymbolicLink||(!sqrIsAutorunLog(find.name)&&!sqrIsGuideLog(find.name)))continue;
      if(sqrIsTranslatedLog(find.name)){++ignoredCHN;continue;}
      paths.push(dir+'/'+find.name);
   }while(find.next());}finally{find.end();}
   paths.sort((a,b)=>sqrKey(a).localeCompare(sqrKey(b)));
   let files=paths.map(path=>{
      try{return {path,text:File.readTextFile(path)};}
      catch(e){return {path,text:'',error:e.message||String(e)};}
   });
   return {files:files.filter(f=>sqrIsAutorunLog(sqrFileName(f.path))),guideFiles:files.filter(f=>sqrIsGuideLog(sqrFileName(f.path))),ignoredCHN};
}
/** Use the first explicitly logged LIGHT sequence, not the log's creation,
 * an Autorun start that may shoot flats, or a focusing/plate-solving exposure.
 * UTC components represent local wall time only; no timezone conversion is
 * needed to fill the local SQM editor. Parse cached text once per folder load. */
function sqrAutorunImagingStart(files){
   let first=null;
   for(let file of files){
      let name=sqrFileName(file.path);if(file.error||!sqrIsAutorunLog(name)||sqrIsTranslatedLog(name))continue;
      for(let line of String(file.text||'').split(/\r?\n|\r/)){
         let m=line.match(/^\s*(\d{4}[-/]\d{2}[-/]\d{2} \d{2}:\d{2}:\d{2})\s+Shooting\s+[1-9]\d*\s+light\s+frames?\b/i);if(!m)continue;
         let wallTime=sqrLogTime(m[1],'utc');if(wallTime===null)continue;
         if(!first||wallTime<first.wallTime||wallTime===first.wallTime&&sqrKey(file.path)<sqrKey(first.path))
            first={wallTime,text:new Date(wallTime).toISOString().slice(0,19).replace('T',' '),path:file.path};
      }
   }
   return first;
}
/** Filename clocks can refer to exposure start or completion. Compare both
 * against DATE-OBS and EXPTIME, allowing five seconds for rounding/readout.
 * Modern UTC offsets use 15-minute increments. Ambiguous candidates are kept
 * unresolved instead of guessing an offset from this computer's timezone. */
function sqrFilenameClock(path){
   let name=sqrFileName(path),matches=Array.from(name.matchAll(/(?:^|_)(\d{4})(\d{2})(\d{2})[-_](\d{2})(\d{2})(\d{2})(?=_|\.|$)/g));
   if(matches.length!==1)return null;let m=matches[0];return sqrLogTime(m[1]+'/'+m[2]+'/'+m[3]+' '+m[4]+':'+m[5]+':'+m[6],'utc');
}
function sqrExposure(row){return sqrPositiveMetadata(row.original?.exposure)??sqrPositiveMetadata(row.registered?.exposure);}
function sqrInferLogClock(session,mode='auto',hours=0){
   let clock={mode,anchors:[],offsets:[],unresolved:0,endNames:0};
   if(mode==='offset'){if(Number.isFinite(hours)&&hours>=-12&&hours<=14)clock.offsets=[hours*3600000];return clock;}
   let candidates=[];
   for(let row of session?.groups.flatMap(g=>g.rows)||[]){let utc=sqrAcquisitionTime(row),local=sqrFilenameClock(row.original?.path||row.registered.path),exposure=sqrExposure(row),options=[];
      if(utc!==null&&local!==null)for(let [basis,duration] of [['start',0],['end',exposure]]){
         if(duration===null)continue;let difference=local-utc-duration*1000,offset=Math.round(difference/900000)*900000;
         if(offset>=-12*3600000&&offset<=14*3600000&&Math.abs(difference-offset)<=5000&&!options.some(v=>v.offset===offset))options.push({utc,offset,basis});
      }
      candidates.push(options);
   }
   let known=new Set(candidates.filter(c=>c.length===1).map(c=>c[0].offset));
   for(let options of candidates){if(options.length>1&&known.size===1)options=options.filter(o=>known.has(o.offset));
      if(options.length!==1){++clock.unresolved;continue;}clock.anchors.push(options[0]);if(options[0].basis==='end')++clock.endNames;}
   clock.anchors.sort((a,b)=>a.utc-b.utc);clock.offsets=Array.from(new Set(clock.anchors.map(a=>a.offset))).sort((a,b)=>a-b);return clock;
}
function sqrOffsetText(ms){let minutes=Math.round(Math.abs(ms)/60000);return 'UTC'+(ms<0?'-':'+')+String(Math.floor(minutes/60)).padStart(2,'0')+':'+String(minutes%60).padStart(2,'0');}
function sqrClockText(clock){return clock.offsets.length?clock.offsets.map(sqrOffsetText).join(' / ')+(clock.mode==='offset'?' (custom)':' (inferred)'):'UTC offset unavailable — scan images or set a custom offset';}
// When offsets change between nights, accept a conversion only when nearby UTC
// anchors agree. Repeated local times at a clock change stay ambiguous.
function sqrLocalToUTC(wall,clock){
   if(wall===null||!clock.offsets.length)return null;if(clock.offsets.length===1)return wall-clock.offsets[0];
   let candidates=[];
   for(let offset of clock.offsets){let utc=wall-offset,i=sqrLowerBound(clock.anchors,utc,'utc'),a=clock.anchors[i-1],b=clock.anchors[i];
      if((!a||a.offset===offset)&&(!b||b.offset===offset))candidates.push(utc);}
   return candidates.length===1?candidates[0]:null;
}
function sqrLowerBound(rows,time,key='time'){let lo=0,hi=rows.length;while(lo<hi){let m=(lo+hi)>>>1;if(rows[m][key]<time)lo=m+1;else hi=m;}return lo;}
function sqrCSVLine(line){let fields=[],value='',quoted=false;for(let i=0;i<line.length;++i){let c=line[i];
   if(c==='"'){if(quoted&&line[i+1]==='"'){value+='"';++i;}else quoted=!quoted;}
   else if(c===','&&!quoted){fields.push(value);value='';}else value+=c;}fields.push(value);return quoted?null:fields;}
function sqrCSVNumber(value){if(value===undefined||String(value).trim()==='')return null;let n=Number(value);return Number.isFinite(n)?n:null;}
/** Parse local section starts and elapsed sample times separately. Each section
 * has its own guider scale and cadence. INFO records do not masquerade as CSV;
 * valid samples during in-exposure settling remain real guiding measurements. */
function sqrParseGuideFiles(files){
   let sections=[],invalid=0,errors=0;
   for(let file of files){if(file.error){++errors;continue;}let section=null,header=null,settling=false;
      for(let line of file.text.split(/\r?\n|\r/)){let m;
         if((m=line.match(/^Guiding Begins at (.+)$/))){section={start:sqrLogTime(m[1],'utc'),path:file.path,scale:null,exposure:null,rows:[],camera:''};sections.push(section);header=null;settling=false;continue;}
         if(/^Guiding Ends at |^Calibration Begins/.test(line)){section=null;header=null;continue;}if(!section)continue;
         if((m=line.match(/^Pixel scale = ([\d.]+) arc-sec\/px/)))section.scale=sqrPositiveMetadata(m[1]);
         else if((m=line.match(/^Exposure = ([\d.]+) ms/)))section.exposure=sqrPositiveMetadata(m[1])/1000;
         else if((m=line.match(/^Camera = ([^,]+)/)))section.camera=m[1].trim();
         else if(/^Frame,Time,/.test(line))header=sqrCSVLine(line);
         else if(/^INFO:/.test(line)){if(/Settling started/.test(line))settling=true;else if(/Settling complete|Settling failed/.test(line))settling=false;}
         else if(/^\d+,/.test(line)&&header){let fields=sqrCSVLine(line);if(!fields){++invalid;continue;}
            let get=name=>fields[header.indexOf(name)],elapsed=sqrCSVNumber(get('Time')),frame=sqrCSVNumber(get('Frame')),mount=get('mount');
            if(elapsed===null||elapsed<0||frame===null||section.start===null){++invalid;continue;}if(mount!=='Mount'&&mount!=='DROP')continue;
            let ra=sqrCSVNumber(get('RARawDistance')),dec=sqrCSVNumber(get('DECRawDistance')),code=sqrCSVNumber(get('ErrorCode'));
            let valid=mount==='Mount'&&code===0&&ra!==null&&dec!==null&&section.scale!==null;
            section.rows.push({elapsed,frame,error:valid?Math.hypot(ra,dec)*section.scale:null,dropped:mount==='DROP'||code!==0,settling});
         }
      }
   }
   for(let s of sections){let gaps=[];for(let i=1;i<s.rows.length;++i){let dt=s.rows[i].elapsed-s.rows[i-1].elapsed;if(dt>0)gaps.push(dt);}
      s.cadence=sqrMedian(gaps);if(!Number.isFinite(s.cadence))s.cadence=s.exposure||2;}
   return {sections,invalid,errors};
}
function sqrGuideTimeline(parsed,clock){
   let seen=new Map,duplicates=0,conflicts=0,unresolved=0;
   for(let s of parsed.sections){let start=sqrLocalToUTC(s.start,clock);if(start===null){++unresolved;continue;}
      for(let r of s.rows){let key=start+'|'+r.elapsed+'|'+r.frame,sample={...r,time:start+r.elapsed*1000,cadence:s.cadence,path:s.path},old=seen.get(key);
         if(old){++duplicates;if(old.error!==sample.error||old.dropped!==sample.dropped){if(!old.conflict)++conflicts;old.error=null;old.conflict=true;}continue;}seen.set(key,sample);}
   }
   return {rows:Array.from(seen.values()).sort((a,b)=>a.time-b.time),duplicates,conflicts,unresolved};
}
function sqrGuideCategory(ratio){return ratio<=1+1e-12?'Good guiding':ratio<=1.75+1e-12?'Medium guiding':'Bad guiding';}
function sqrGuidingScale(setup){let value=setup.reason?NaN:Math.min(setup.x??Infinity,setup.y??Infinity);return Number.isFinite(value)&&value>0?value:null;}
// Display the category boundaries in angular units, using the same scale as
// classification. Keep the internal scale-normalized penalty for Score.
function sqrGuideThresholdText(scale){return Number.isFinite(scale)&&scale>0?'Good ≤ '+sqrGuideNumber(scale)+'″ · Medium > '+sqrGuideNumber(scale)+'″ to '+sqrGuideNumber(1.75*scale)+'″ · Bad > '+sqrGuideNumber(1.75*scale)+'″':'Guiding thresholds unavailable';}
// Exclusion is per frame in available-only mode, or global in ignore mode.
// Keep statistics visible; this policy affects Score, completeness and flags.
function sqrIgnoreGuiding(row,options){return options.guidingMode==='ignore'||options.guideWeight===0||options.guidingMode==='available'&&!row.guiding?.scorable;}
/** Match only samples inside the exposure's half-open UTC interval. Coverage
 * uses short, cadence-limited support intervals, never bridges long guide gaps.
 * Partial statistics remain visible, but unreliable coverage has no score. */
function sqrGuideMeasurement(row,timeline,pixelScale){
   let start=sqrAcquisitionTime(row),duration=sqrExposure(row),result={min:null,max:null,avg:null,count:0,dropped:0,coverage:0,scorable:false,reason:''};
   if(start===null||duration===null){result.reason='Exposure timestamp or duration unavailable';return result;}
   let end=start+duration*1000,from=sqrLowerBound(timeline.rows,start),to=sqrLowerBound(timeline.rows,end),samples=timeline.rows.slice(from,to),valid=samples.filter(s=>s.error!==null);
   result.count=valid.length;result.dropped=samples.filter(s=>s.dropped).length;result.settling=valid.filter(s=>s.settling).length;result.conflicts=samples.filter(s=>s.conflict).length;
   if(!valid.length){result.reason=!timeline.rows.length?'No guide samples with resolved timestamps':end<=timeline.rows[0].time||start>timeline.rows[timeline.rows.length-1].time?'Exposure outside loaded guide-log coverage':samples.length?'No valid guide samples during this exposure':'Gap in loaded guide logs';return result;}
   let values=valid.map(s=>s.error);result.min=Math.min(...values);result.max=Math.max(...values);result.avg=values.reduce((a,b)=>a+b,0)/values.length;
   let covered=0,cursor=start,maxGap=0,cadence=sqrMedian(valid.map(s=>s.cadence));
   for(let s of valid){let a=Math.max(start,s.time-s.cadence*750),b=Math.min(end,s.time+s.cadence*750);maxGap=Math.max(maxGap,a-cursor);if(b>cursor){covered+=b-Math.max(cursor,a);cursor=b;}}
   maxGap=Math.max(maxGap,end-cursor);result.coverage=Math.min(1,covered/(end-start));result.maxGap=maxGap/1000;
   result.scorable=valid.length>=3&&result.coverage>=.9&&result.maxGap<=Math.max(10,3*cadence)&&!result.conflicts;
   result.reason=result.scorable?'':'Incomplete guiding coverage';result.composite=(result.min+2*result.avg+result.max)/4;
   if(!Number.isFinite(pixelScale)||pixelScale<=0){result.scorable=false;result.reason='Image pixel scale unavailable';}
   else{result.ratio=result.composite/pixelScale;result.category=sqrGuideCategory(result.ratio);result.pixelScale=pixelScale;}
   return result;
}
function sqrApplyGuiding(session,parsed,clock,enabled){
   if(!session)return;let scale=sqrGuidingScale(sqrSessionPixelScale(session)),timeline=sqrGuideTimeline(parsed,clock);
   session.guiding={enabled,clock:sqrClockText(clock),samples:timeline.rows.length,duplicates:timeline.duplicates,conflicts:timeline.conflicts,unresolved:timeline.unresolved,errors:parsed.errors};
   for(let g of session.groups)for(let r of sqrGroupRows(g)){
      r.guideMin=r.guideMax=r.guideAvg=r.guideQuality=r.guidePenalty=null;r.guiding=null;r.guidingIgnored=false;
      if(!enabled||r.isMaster)continue;let m=sqrGuideMeasurement(r,timeline,scale);r.guiding=m;r.guideMin=m.min;r.guideMax=m.max;r.guideAvg=m.avg;
      if(m.scorable){r.guideQuality=m.composite;r.guidePenalty=Math.min(10,Math.max(0,(m.ratio-1)/.75));}
      r.guidingIgnored=sqrIgnoreGuiding(r,session.options);
   }
}
function sqrGuideReport(row){let m=row.guiding;if(!m)return row.isMaster?'Integrated master: no single exposure interval.':'No PHD2 guide log loaded.';
   return (m.scorable?m.category:m.reason)+(row.guidingIgnored?' (excluded from Score)':'')+(m.count?' · min / max / average: '+sqrGuideNumber(m.min)+' / '+sqrGuideNumber(m.max)+' / '+sqrGuideNumber(m.avg)+' arcsec':'')+
      '\n'+m.count+' valid samples · '+(m.coverage*100).toFixed(1)+'% time coverage · '+m.dropped+' rejected guide samples'+(m.settling?' · '+m.settling+' samples while settling':'')+
      (m.pixelScale?'\n'+sqrGuideThresholdText(m.pixelScale)+'. Composite = (min + 2 × average + max) / 4.':'');}
function sqrGuideCell(row,key){let value=row[key];return Number.isFinite(value)?sqrGuideNumber(value)+(row.guiding?.scorable?'':'*'):'—';}
/** Pair each unique autofocus start with its final successful focus position.
 * Intermediate EAF samples are not results. A new start, end, or failure closes
 * the previous run so an incomplete run cannot borrow another run's position.
 * Only the start timestamp is retained for marker placement and reporting. */
function sqrParseAutorun(text,zone='local',offset=0){
   let runs=[],seen=new Set,invalid=0,active=null;
   for(let line of String(text).split(/\r?\n|\r/)){
      let m=line.match(/^\s*(\d{4}\/\d{2}\/\d{2} \d{2}:\d{2}:\d{2})\s+(.*)$/);if(!m)continue;
      let begin=m[2].match(/^\[AutoFocus\|Begin\]\s*(.*)$/i);
      if(begin){
         let time=sqrLogTime(m[1],zone,offset);
         if(time===null){++invalid;active=null;continue;}
         // An adjacent duplicate start keeps its open run; an old duplicate must
         // not reopen a finished run or attach its result to a different start.
         if(seen.has(time)){if(active?.start!==time)active=null;continue;}
         seen.add(time);active={start:time,startText:m[1],reason:begin[1],focusPosition:null};runs.push(active);
      }else if(/^\[AutoFocus\|End\]|^Auto focus failed\b/i.test(m[2]))active=null;
      else if(active){
         let result=m[2].match(/^Auto focus succeeded,\s*the focused position is\s+(\d+)\s*$/i);
         if(result){let position=Number(result[1]),time=sqrLogTime(m[1],zone,offset);
            if(Number.isSafeInteger(position)&&time!==null&&time>=active.start){active.focusPosition=position;active=null;}}
      }
   }
   return {runs:runs.sort((a,b)=>a.start-b.start),invalid};
}
/** Parse each log independently: an unfinished run must not borrow a focus
 * result from the next file. Merge duplicate starts after parsing, retaining
 * provenance and any available result. Conflicting results stay unavailable. */
function sqrParseAutorunFiles(files,zone='local',offset=0){
   let merged=new Map,invalid=0,duplicates=0,details=[];
   for(let file of files.slice().sort((a,b)=>sqrKey(a.path).localeCompare(sqrKey(b.path)))){
      if(file.error){details.push({path:file.path,error:file.error,starts:0,invalid:0});continue;}
      let parsed=sqrParseAutorun(file.text,zone,offset);invalid+=parsed.invalid;
      details.push({path:file.path,starts:parsed.runs.length,invalid:parsed.invalid});
      for(let run of parsed.runs){
         let known=merged.get(run.start);
         if(!known){merged.set(run.start,{...run,sourcePaths:[file.path]});continue;}
         ++duplicates;if(!known.sourcePaths.includes(file.path))known.sourcePaths.push(file.path);
         if(!known.reason)known.reason=run.reason;
         if(!known.focusConflict&&run.focusPosition!==null){
            if(known.focusPosition===null)known.focusPosition=run.focusPosition;
            else if(known.focusPosition!==run.focusPosition){known.focusPosition=null;known.focusConflict=true;}
         }
      }
   }
   let runs=Array.from(merged.values()).sort((a,b)=>a.start-b.start);
   return {runs,invalid,duplicates,conflicts:runs.filter(r=>r.focusConflict).length,files:details,errors:details.filter(f=>f.error).length};
}
function sqrFocusPositionText(run){return run.focusConflict?'conflicting log results':run.focusPosition??'not reported';}
function sqrAutofocusMarkers(items,runs){
   // Frame slots are equally spaced. Interpolate AF times between the surrounding
   // acquisition timestamps; master and unknown-time slots never set the range.
   let timed=items.map((item,i)=>({time:item.time,slot:i+.5,master:item.master})).filter(item=>!item.master&&Number.isFinite(item.time)).sort((a,b)=>a.time-b.time);
   if(!timed.length)return [];
   let points=[];for(let item of timed){let last=points[points.length-1];
      if(last&&last.time===item.time){last.slot=(last.slot*last.count+item.slot)/++last.count;}
      else points.push({...item,count:1});}
   let earliest=points[0].time,latest=points[points.length-1].time;
   let position=time=>{for(let i=0;i<points.length-1;++i){let a=points[i],b=points[i+1];
      if(time>=a.time&&time<=b.time)return a.slot+(time-a.time)/(b.time-a.time)*(b.slot-a.slot);}
      return time<=earliest?points[0].slot:points[points.length-1].slot;};
   return runs.filter(run=>run.start>=earliest&&run.start<=latest).map(run=>({...run,startSlot:position(run.start)}));
}
// Report all extracted starts. Time-range clipping belongs to the plot only,
// so an event outside the current filter group remains visible in the report.
function sqrAutofocusReport(path,result,zone,offset,error='',timeDescription=''){
   let convention=timeDescription||(zone==='local'?'Computer local time':zone==='utc'?'UTC':'UTC offset '+(offset>=0?'+':'')+offset+' hours');
   let lines=[(result.files?'Log folder: ':'Autorun log: ')+path,'Log timestamps: '+convention,''];
   if(error)return lines.concat(error).join('\n');
   if(result.files){
      lines.push('Autorun logs read: '+(result.files.length-result.errors)+' / '+result.files.length);
      for(let file of result.files)lines.push('  '+sqrFileName(file.path)+': '+(file.error?'could not read — '+file.error:file.starts+' autofocus starts'+(file.invalid?' · '+file.invalid+' invalid timestamps skipped':'')));
      if(!result.files.length)lines.push('No matching Autorun_log files found in this folder.');
      if(result.ignoredCHN)lines.push('Ignored _CHN translations: '+result.ignoredCHN);
      if(result.duplicates)lines.push('Duplicate starts merged: '+result.duplicates);
      if(result.conflicts)lines.push('Starts with conflicting focus positions: '+result.conflicts);
      lines.push('');
   }
   lines.push(result.runs.length+' autofocus start'+(result.runs.length===1?'':'s')+' extracted'+(result.invalid?' · '+result.invalid+' invalid timestamp'+(result.invalid===1?'':'s')+' skipped':''),
      'Log start → UTC (used in histograms) · Final focus position');
   for(let i=0;i<result.runs.length;++i){let run=result.runs[i];lines.push((i+1)+'. '+run.startText+' → '+new Date(run.start).toISOString()+' · Focus position: '+sqrFocusPositionText(run)+(run.sourcePaths?.length?' · Logs: '+run.sourcePaths.map(sqrFileName).join(', '):''));}
   if(!result.runs.length)lines.push('No valid [AutoFocus|Begin] timestamps found.');
   lines.push('','All extracted starts are listed. Histograms show only starts within the current group’s subframe time range.');
   return lines.join('\n');
}
/** Return a filtered/sorted copy without changing group membership or decisions.
 * Reverse measured values while retaining the default missing-data priorities.
 * Acquisition-time sorting keeps undated frames and the master at the end;
 * incomplete Below-mean Quality comparisons remain last in either direction.
 * Stable timestamp ties and filename tie-breaks are independent of direction.
 */
// Display order is independent of saved mode numbers, so rearranging the menu
// preserves the sorting criterion in existing process instances and sessions.
const SQR_REVIEW_SORTS=[
   [0,'Score'],[1,'PSF signal weight'],[2,'Star count'],[3,'Field FWHM'],[4,'Corner quality'],[5,'Filename'],
   [6,'R1: field rank'],[7,'R2: rank with corners'],[13,'R3: correlation rank'],[15,'R4: rank of ranks'],[8,'Acquisition time'],
   [9,'Below-mean Quality'],[10,'Guide minimum'],[11,'Guide maximum'],[12,'Guide average'],[14,'Sky brightness'],[16,'Transparency'],[17,'Sky quality'],[18,'Cloud extinction']
];
function sqrReviewOrderIndex(mode){return Math.max(0,SQR_REVIEW_SORTS.findIndex(item=>item[0]===mode));}
function sqrLowerScoreTargets(group,selected){
   if(!selected||selected.isMaster||!Number.isFinite(selected.score)||!group?.rows.includes(selected))return [];
   return group.rows.filter(r=>!r.isMaster&&!r.reject&&!r.moved&&Number.isFinite(r.score)&&r.score<selected.score);
}
function sqrReviewRows(group,candidatesOnly,mode,reverse=false){
   if(!group)return [];
   const direction=reverse?-1:1;
   const compare=(x,y)=>{
      // Signed infinity encodes existing unavailable-value placement. Do not
      // reverse these sentinels or subtract equal infinities (which yields NaN).
      if(x===y)return 0;
      if(!Number.isFinite(x)||!Number.isFinite(y))return x<y?-1:x>y?1:0;
      return direction*(x-y);
   };
   return sqrGroupRows(group).filter(r=>!candidatesOnly||(!r.isMaster&&sqrNeedsReview(r))).sort((a,b)=>{
      // Score and rank sorts keep the unscored comparison master last in both directions.
      if([0,6,7,13,15,18].includes(mode)&&!!a.isMaster!==!!b.isMaster)return a.isMaster?1:-1;
      let x,y;if(mode===1){x=a.metrics[0]?.signal??Infinity;y=b.metrics[0]?.signal??Infinity;}
      else if(mode===2){x=a.metrics[0]?.stars??Infinity;y=b.metrics[0]?.stars??Infinity;}
      else if(mode===3){x=-(a.metrics[0]?.fwhm??-Infinity);y=-(b.metrics[0]?.fwhm??-Infinity);}
      else if(mode===4){x=-(a.cornerSeverity??-Infinity);y=-(b.cornerSeverity??-Infinity);}
      else if(mode===14){x=Number.isFinite(a.skyBackground)?-a.skyBackground:Infinity;y=Number.isFinite(b.skyBackground)?-b.skyBackground:Infinity;}
      else if(mode===16){x=a.relativeTransparency??Infinity;y=b.relativeTransparency??Infinity;}
      else if(mode===18){x=-(a.cloudExtinction??-Infinity);y=-(b.cloudExtinction??-Infinity);}
      else if(mode===17){x=a.skyQuality??Infinity;y=b.skyQuality??Infinity;}
      else if(mode===5)return direction*a.registered.path.localeCompare(b.registered.path);
      else if(mode===6){x=a.rankWithoutCorners??Infinity;y=b.rankWithoutCorners??Infinity;}
      else if(mode===7){x=a.rankWithCorners??Infinity;y=b.rankWithCorners??Infinity;}
      else if(mode===13){x=a.rankCorrelated??Infinity;y=b.rankCorrelated??Infinity;}
      else if(mode===15){x=a.rankOfRanks??Infinity;y=b.rankOfRanks??Infinity;}
      else if(mode===8){
         if(!!a.isMaster!==!!b.isMaster)return a.isMaster?1:-1;
         let aTime=sqrAcquisitionTime(a),bTime=sqrAcquisitionTime(b);
         if((aTime===null)!==(bTime===null))return aTime===null?1:-1;
         // Reverse only known timestamps; undated subframes follow, then the master.
         // Equal timestamps retain their input order; filename suffixes do not rank them.
         return direction*((aTime??0)-(bTime??0));
      }
      else if(mode===9){if(!!a.belowMeanComplete!==!!b.belowMeanComplete)return a.belowMeanComplete?-1:1;
         x=-(a.belowMeanFraction??-Infinity);y=-(b.belowMeanFraction??-Infinity);
         return compare(x,y)||compare(a.score??Infinity,b.score??Infinity)||a.registered.path.localeCompare(b.registered.path);}
      else if(mode>=10&&mode<=12){
         // Guide values are numeric arcseconds, including displayed partial
         // measurements. Missing values follow in both directions; master last.
         if(!!a.isMaster!==!!b.isMaster)return a.isMaster?1:-1;
         let key=['guideMin','guideMax','guideAvg'][mode-10];
         x=Number.isFinite(a[key])?-a[key]:Infinity;y=Number.isFinite(b[key])?-b[key]:Infinity;
      }
      else{x=a.score??Infinity;y=b.score??Infinity;}
      return compare(x,y)||a.registered.path.localeCompare(b.registered.path);
   });
}
// Plot descriptors separate stored metrics from derived row-level indicators.
// Corner descriptors are offered only when actual values exist in the group.
// These absolute shape ranges guide visual inspection; they do not change the
// relative eccentricity penalties used by manual or correlation-based scoring.
const SQR_ECCENTRICITY_LIMITS={good:.42,medium:.60};
const SQR_ECCENTRICITY_DEFINITION='Eccentricity: 0 = round; closer to 1 = elongated. Bands are practical guidelines; Score compares measurements within the group.';
function sqrEccentricityCategory(value){return value<=SQR_ECCENTRICITY_LIMITS.good?'Good':value<=SQR_ECCENTRICITY_LIMITS.medium?'Medium':'Bad';}
const SQR_KPIS=[
   {label:'Score',key:'score',noMaster:true,direction:'Higher is better (0–1)',definition:'For manual or strongly correlated KPI scoring: Score = 1 − weighted mean penalty / 10. For rank-of-ranks scoring: Score is the mean of the available normalized R1, R2 and R3 ranks. Only subframes receive scores and ranks; the integrated master is excluded.'},
   {label:'PSF signal weight',metric:'signal',region:0,direction:'Higher is better',definition:'The PSF signal weight measured by ImageAnalysis in the usable field. Score compares this measurement with the other supported images in the same group.'},
   {label:'Star count',metric:'stars',region:0,integer:true,direction:'Higher is better',definition:'Number of detected stars reported by ImageAnalysis for the usable field. Comparisons use the other supported images in the same group.'},
   {label:'Field FWHM (px)',metric:'fwhm',region:0,direction:'Lower is better'},
   {label:'Corner quality',key:'cornerSeverity',corners:true,direction:'Lower is better',definition:'Corner quality is the worst penalty for star size, corner-to-center size ratio, or elongation across the four corners. Missing measurements are assessed separately.'},
   {label:'Field eccentricity',metric:'eccentricity',region:0,direction:'Lower is rounder',definition:SQR_ECCENTRICITY_DEFINITION},
   ...[1,2,3,4,5].map(region=>({label:SQR_REGIONS[region]+' FWHM (px)',metric:'fwhm',region,corners:true,direction:'Lower is better'})),
   ...[2,3,4,5].map(region=>({label:SQR_REGIONS[region]+' eccentricity',metric:'eccentricity',region,corners:true,direction:'Lower is rounder',definition:SQR_ECCENTRICITY_DEFINITION})),
   {label:'Below-mean Quality',key:'belowMeanFraction',percentage:true,direction:'Lower is better',definition:'Percentage of assessed indicators with worse-than-mean quality: worse indicators / available indicators. The manual KPI weights and corner/guiding settings define the indicators; selecting R3 or R4 does not change this KPI. Means use the supported subframes in the group, including rejected frames. An asterisk in the Review table marks incomplete coverage; unavailable measurements do not count as good.'},
   {label:'Guide minimum (arcsec)',key:'guideMin',guiding:true,direction:'Lower is better',definition:'Minimum combined RA/Dec displacement during the exposure, in arcseconds.'},
   {label:'Guide maximum (arcsec)',key:'guideMax',guiding:true,direction:'Lower is better',definition:'Maximum combined RA/Dec displacement during the exposure, in arcseconds.'},
   {label:'Guide average (arcsec)',key:'guideAvg',guiding:true,direction:'Lower is better',definition:'Arithmetic mean of the combined RA/Dec displacements during the exposure, in arcseconds.'},
   {label:'Guiding quality (arcsec)',key:'guideQuality',guiding:true,direction:'Lower is better',definition:'Guiding quality G = (minimum + 2 × average + maximum) / 4, in arcseconds.'},
   {label:'Sky brightness',key:'skyBackground',direction:'Lower is better',definition:'With corner scoring enabled: the lowest mean of the center and four corner previews. Otherwise: the whole-image mean. Values are in image units; RGB uses green.'},
   {label:'Transparency',key:'relativeTransparency',percentage:true,unboundedPercentage:true,direction:'Higher is better',definition:'Relative stellar throughput from ImageAnalysis RelativeExtinction: Transparency (%) = 100 × 10^(−0.4 × extinction in magnitudes). The most transparent measured subframe in the group is 100%. Measurements account for exposure time; RGB uses HSI intensity. This is not absolute atmospheric transmission. Missing native measurements remain unavailable. The master is compared separately with the same subframe reference using its recorded frame exposure; integration normalization affects its value. Select one sky KPI in Score weights; only that choice can contribute to scoring.'},
   {label:'Sky quality',key:'skyQuality',percentage:true,unboundedPercentage:true,direction:'Higher is better',definition:'Combines the existing Transparency and Sky brightness KPIs: Q = (T / Tref) × sqrt(Bref / B), shown as a percentage. B is Sky brightness minus any recorded pedestal, divided by exposure time. Higher transparency and a darker background improve Q. The transparency reference is 100%; values above 100% are allowed. This is an approximate relative quality indicator, not an absolute sky-brightness or transmission measurement. The master uses its recorded frame exposure and is affected by integration normalization; this value does not measure the SNR gain from stacking. No separate noise measurement is used. Select one sky KPI in Score weights; the combined Sky quality is the default.'},
   {label:'Cloud extinction (mag)',key:'cloudExtinction',noMaster:true,noAutofocus:true,comparisonOnly:true,direction:'Lower is better',definition:'ImageAnalysis CloudExtinction is the part of RelativeExtinction not explained by airmass: CloudExtinction = RelativeExtinction − (a + k × airmass), in magnitudes. ImageAnalysis fits this atmospheric baseline robustly, downweighting unusually dim frames. Near zero means little additional dimming; positive values can indicate clouds, haze or dew. Negative residuals can occur and are retained. At least five comparable frames with known airmass and usable stellar measurements are required. If the airmass span is below 0.05, only a constant baseline is fitted. This is a relative estimate, not an absolute cloud measurement. Integrated masters are not applicable. Comparison only; excluded from Score and R1–R4.'}
];
// One shared scoring slot prevents counting all three related sky indicators.
// Keep backgroundWeight as the saved weight key so existing process settings
// retain their chosen numeric weight. A missing/invalid selection uses combined Q.
const SQR_SKY_SCORE_CHOICES=[
   {key:'skyQuality',label:'Sky quality',name:'Sky quality',higher:true,issue:'Low sky quality'},
   {key:'relativeTransparency',label:'Transparency',name:'Transparency',higher:true,issue:'Low transparency'},
   {key:'skyBackground',label:'Sky brightness',name:'Sky brightness',higher:false,issue:'High sky brightness'}
];
function sqrSkyScoreChoice(o){return SQR_SKY_SCORE_CHOICES.find(c=>c.key===o?.skyScoreKPI)||SQR_SKY_SCORE_CHOICES[0];}
function sqrSkyScoreValue(row,o,withCorners){
   let key=sqrSkyScoreChoice(o).key,value=key==='skyBackground'?sqrSkyBackground(row,withCorners):key==='skyQuality'?row.skyQualityModes?.[withCorners?'corners':'field']?.value:row.relativeTransparency;
   return Number.isFinite(value)?value:null;
}
// Stable component identities connect manual weights, automatic selection and
// the public KPI descriptors. Manual scoring uses the corner-quality composite.
const SQR_SCORE_COMPONENTS=[
   {weight:'signalWeight',kpi:'0:signal',label:'PSF signal weight'},
   {weight:'starsWeight',kpi:'0:stars',label:'Star count'},
   {weight:'fwhmWeight',kpi:'0:fwhm',label:'Field FWHM'},
   {weight:'eccentricityWeight',kpi:'0:eccentricity',label:'Field eccentricity'},
   {weight:'cornerWeight',kpi:'cornerSeverity',label:'Corner quality'},
   {weight:'guideWeight',kpi:'guideQuality',label:'Guiding quality'},
   {weight:'backgroundWeight',kpi:'skyQuality',label:'Sky quality'},
   {weight:'belowMeanWeight',kpi:'belowMeanFraction',label:'Below-mean Quality'}
];
function sqrScoreComponents(o){let sky=sqrSkyScoreChoice(o);return SQR_SCORE_COMPONENTS.map(c=>c.weight==='backgroundWeight'?{...c,kpi:sky.key,label:sky.name}:c);}
// Automatic-only components: assess each measured corner independently. Their
// effective 0/1 weights are derived per group, never saved as manual settings.
const SQR_CORNER_COMPONENTS=[2,3,4,5].flatMap(region=>['fwhm','eccentricity'].map(metric=>({
   weight:'corner'+region+'_'+metric,kpi:region+':'+metric,region,metric,corner:true,
   label:SQR_REGIONS[region]+(metric==='fwhm'?' FWHM':' eccentricity')
})));
function sqrEccentricityValid(m){return !!m?.valid&&Number.isFinite(m.eccentricity)&&m.eccentricity>=0&&m.eccentricity<1;}
// null means unavailable, while zero is a real value. Stored corner quality
// stays inspectable even when corner scoring is temporarily disabled.
function sqrKPIValue(row,kpi){
   if(!row||kpi.noMaster&&row.isMaster)return null;
   if(kpi.metric==='eccentricity'&&!sqrEccentricityValid(row.metrics[kpi.region]))return null;
   let value=kpi.key==='cornerSeverity'?row.measuredCornerSeverity??row.cornerSeverity:kpi.key?row[kpi.key]:row.metrics[kpi.region]?.valid?row.metrics[kpi.region][kpi.metric]:null;
   return Number.isFinite(value)?value:null;
}
function sqrAvailableKPIs(group,includeMaster=true){
   let rows=group?(includeMaster?sqrGroupRows(group):group.rows.filter(row=>!row.isMaster)):[];
   return SQR_KPIS.filter(kpi=>!kpi.corners||rows.some(row=>sqrKPIValue(row,kpi)!==null));
}
// Describe the current scoring configuration, independently of plot availability.
// Automatic scoring can include a corner metric directly; manual scoring and
// the center/individual guiding values retain their composite contribution.
function sqrKPIScoreInfo(kpi,o,guidingEnabled=false,correlation=null){
   if(kpi.comparisonOnly)return 'Excluded from Score (comparison only)';
   let sky=SQR_SKY_SCORE_CHOICES.some(c=>c.key===kpi.key);
   if(sky&&kpi.key!==sqrSkyScoreChoice(o).key)return 'Excluded from Score (sky KPI not selected)';
   if(kpi.key==='score')return 'Combined Score';
   if(o.rankOfRanks){
      let manual=sqrKPIScoreInfo(kpi,{...o,rankOfRanks:false,correlationOnly:false},guidingEnabled,correlation);
      let automatic=correlation?.available===false?'Excluded from R3':sqrKPIScoreInfo(kpi,{...o,rankOfRanks:false,correlationOnly:true},guidingEnabled,correlation);
      let via=[];if(manual.startsWith('Included'))via.push(kpi.corners?'R2':o.measureCorners?'R1/R2':'R1');
      if(automatic.startsWith('Included')||automatic.includes('; included via'))via.push('R3');
      return via.length?'Included via '+via.join(' and ')+' in R4; available ranks have equal weight':'Excluded from R4';
   }
   if(o.correlationOnly){
      if(correlation?.available===false)return sqrKPIScoreInfo(kpi,{...o,correlationOnly:false},guidingEnabled,correlation)+' (manual score; R3 unavailable)';
      let key=kpi.corners&&!(kpi.region>=2)?'cornerSeverity':kpi.guiding?'guideQuality':sqrKPIKey(kpi),component=correlation?.components.find(c=>c.kpi===key);
      if(!component)return 'Correlation selection pending';
      let viaComposite=kpi.region>=2&&correlation.weights.cornerWeight>0;
      if(!component.included)return viaComposite?'Excluded as an individual KPI ('+component.reason+'); included via corner quality':'Excluded from Score ('+component.reason+')';
      return (sqrKPIKey(kpi)===key?'Included in Score':kpi.corners?'Included via corner quality':'Included via guiding quality')+' (equal weight)';
   }
   if(kpi.corners){
      if(!o.measureCorners)return 'Excluded from Score (corner scoring off)';
      if(!(o.cornerWeight>0))return 'Excluded from Score (corner weight 0)';
      return kpi.region===1?'Included via corner / center FWHM ratios':kpi.key==='cornerSeverity'?'Included in Score':'Included via corner quality';
   }
   if(kpi.guiding){
      if(o.guidingMode==='ignore')return 'Excluded from Score (guiding ignored)';
      if(!(o.guideWeight>0))return 'Excluded from Score (guiding weight 0)';
      if(!guidingEnabled)return 'Excluded from Score (no guiding logs)';
      return kpi.key==='guideQuality'?'Included in Score':'Included via guiding quality';
   }
   let weight=sky?o.backgroundWeight:kpi.key==='belowMeanFraction'?o.belowMeanWeight:o[({signal:'signalWeight',stars:'starsWeight',fwhm:'fwhmWeight',eccentricity:'eccentricityWeight'})[kpi.metric]];
   return weight>0?'Included in Score':'Excluded from Score (weight 0)';
}
/** Build a plot model independent of the review-table filter and sort order.
 * One slot represents one image; this is a WBPP-style metric plot, not frequency
 * binning. The visible mean excludes rejected rows, unlike scoring baselines. */
function sqrMetricPlot(group,kpi,measureCorners,selectedRow=null,order='value',autofocusRuns=[],guideScale=null,fwhmModel=null,skyModel=null){
   let chronological=order==='time',includeMaster=kpi.key!=='belowMeanFraction'&&!kpi.noMaster;
   let data={kpi,order:chronological?'time':'value',showAutofocus:chronological&&!kpi.guiding&&!kpi.noAutofocus,items:[],autofocus:[],guideScale,master:null,hasMaster:includeMaster&&!!group?.master,missing:0,message:'',average:null};
   if(kpi.metric==='fwhm'&&fwhmModel){data.fwhmModel=fwhmModel;data.detail=sqrFWHMDescription(fwhmModel,false);}
   if(kpi.key==='skyBackground'&&skyModel){data.skyModel=skyModel;data.detail=sqrSkyPlotDetails(skyModel);}
   if(kpi.key==='relativeTransparency')data.detail=group?.transparencySummary||'Measure the subframes to establish a transparency reference.';
   if(kpi.key==='cloudExtinction')data.detail=group?.cloudExtinctionSummary||'Measure at least five subframes with observation metadata to estimate cloud extinction.';
   if(kpi.key==='skyQuality')data.detail=group?.skyQualitySummary||'Measure sky background and relative transparency to calculate Sky quality.';
   if(!group){data.message='Measure a group to view its quality indicators.';return data;}
   // WBPP's metric plots use one slot per frame, ascending metric order and
   // 10% vertical padding. They do not aggregate values into frequency bins.
   // Score and Below-mean Quality describe subframe comparisons only: remove the master
   // before ordering and spacing, so it leaves neither a bar nor an empty slot.
   data.items=(includeMaster?sqrGroupRows(group):group.rows.filter(row=>!row.isMaster)).map(row=>({row,value:sqrKPIValue(row,kpi),time:sqrAcquisitionTime(row),master:!!row.isMaster,selected:row===selectedRow,review:!row.isMaster&&sqrNeedsReview(row),rejected:!row.isMaster&&!!(row.reject||row.moved)}))
      .sort((a,b)=>chronological?Number(b.master)-Number(a.master)||(a.time===null)-(b.time===null)||(a.time??0)-(b.time??0):
         (a.value===null)-(b.value===null)||(a.value??0)-(b.value??0)||a.row.registered.path.localeCompare(b.row.registered.path));
   if(data.showAutofocus)data.autofocus=sqrAutofocusMarkers(data.items,autofocusRuns);
   let valid=data.items.filter(item=>item.value!==null);
   data.master=includeMaster?sqrKPIValue(sqrMasterRow(group),kpi):null;data.missing=data.items.filter(item=>!item.master&&item.value===null).length;
   data.count=valid.filter(item=>!item.master).length;
   if(!valid.length){data.message='No valid measurements for '+kpi.label+'. Use the magnifier to measure.';return data;}
   // Keep subframe differences readable when the integration has much higher signal.
   let subframes=valid.filter(item=>!item.master),values=(subframes.length?subframes:valid).map(item=>item.value),min=Math.min(...values),max=Math.max(...values);
   let padding=(max-min||Math.abs(max)*.1||1)*.1;data.low=min-padding;data.high=max+padding;
   if(data.low<0&&min>=0)data.low=0;
   if(kpi.percentage&&!kpi.unboundedPercentage||kpi.key==='score')data.high=Math.min(1,data.high);
   // Apply absolute categories to the measured min/average/max errors. The
   // combined guiding quality is a derived indicator with a separate definition.
   // Only a validated imaging scale can define these limits.
   if(['guideMin','guideAvg','guideMax'].includes(kpi.key)&&Number.isFinite(guideScale)&&guideScale>0){
      // Minimum and average errors can occupy a small range below the thresholds.
      // Keep their measured range and headroom; clip grading bands to the axis.
      // Maximum errors retain the overview of all three guiding categories.
      if(kpi.key==='guideMax'){data.low=0;data.high=Math.max(data.high,2*guideScale);}
      data.guideBands=[
         {label:'Good',low:0,high:guideScale,color:SQR_GRADE_COLORS.Good},
         {label:'Medium',low:guideScale,high:1.75*guideScale,color:SQR_GRADE_COLORS.Medium},
         {label:'Bad',low:1.75*guideScale,high:null,color:SQR_GRADE_COLORS.Bad}];
   }
   // Fit all eccentricity regions to the actual bars, including the master. Keep
   // category thresholds fixed; off-axis bands are clipped by the renderer.
   if(kpi.metric==='eccentricity'){
      let plotted=valid.map(item=>item.value),bottom=Math.min(...plotted),top=Math.max(...plotted),pad=(top-bottom||top*.1||.01)*.1;
      data.low=Math.max(0,bottom-pad);data.high=Math.min(1,top+pad);
      data.eccentricityBands=[
         {label:'Good',low:0,high:SQR_ECCENTRICITY_LIMITS.good,color:SQR_GRADE_COLORS.Good},
         {label:'Medium',low:SQR_ECCENTRICITY_LIMITS.good,high:SQR_ECCENTRICITY_LIMITS.medium,color:SQR_GRADE_COLORS.Medium},
         {label:'Bad',low:SQR_ECCENTRICITY_LIMITS.medium,high:1,color:SQR_GRADE_COLORS.Bad}];
   }
   // All FWHM regions use the same reference model. The bands never alter
   // measurements, score penalties, rejection choices or the REVIEW quota.
   if(kpi.metric==='fwhm'&&fwhmModel?.valid&&fwhmModel.enabled){
      data.low=0;data.high=Math.max(data.high,1.15*fwhmModel.medium);
      data.fwhmBands=[
         {label:'Good',low:0,high:fwhmModel.good,color:SQR_GRADE_COLORS.Good},
         {label:'Medium',low:fwhmModel.good,high:fwhmModel.medium,color:SQR_GRADE_COLORS.Medium},
         {label:'Bad',low:fwhmModel.medium,high:data.high,color:SQR_GRADE_COLORS.Bad}];
   }
   if(kpi.metric==='fwhm'){
      data.low=Math.floor(data.low*10)/10;data.high=Math.ceil(data.high*10)/10;if(data.high<=data.low)data.high=data.low+.1;
      if(data.fwhmBands)data.fwhmBands[data.fwhmBands.length-1].high=data.high;
   }
   if(kpi.key==='skyBackground'){
      // Fit the actual histogram bars, including a plotted master. Neither
      // Bortle limits nor SQM may stretch the axis into an empty bright range.
      let plotted=valid.map(item=>item.value),bottom=Math.min(...plotted),top=Math.max(...plotted),pad=(top-bottom||Math.abs(top)*.1||.00001)*.1;
      data.low=bottom-pad;if(bottom>=0)data.low=Math.max(0,data.low);data.high=top+pad;
      if(!(data.high>data.low))data.high=data.low+.000001;
   }
   if(kpi.key==='skyBackground'&&skyModel?.valid&&skyModel.bortleClass)
      data.skyBands=sqrBortleShading(skyModel);
   data.masterClipped=data.master===null?'':data.master>data.high?'above':data.master<data.low?'below':'';
   let kept=valid.filter(item=>!item.master&&!item.rejected);
   if(kept.length)data.average=kept.reduce((sum,item)=>sum+item.value,0)/kept.length;
   return data;
}
function sqrPlotNumber(value){if(!Number.isFinite(value))return 'unavailable';let a=Math.abs(value);return value.toFixed(a>=1000?0:a>=100?1:a>=10?2:a>=1?3:4);}
function sqrPercent(value){return Number.isFinite(value)?(100*value).toFixed(1).replace(/\.0$/,'')+'%':'unavailable';}
function sqrKPIPlotNumber(value,kpi){return kpi?.percentage?sqrPercent(value):Number.isFinite(value)&&kpi?.guiding?sqrGuideNumber(value):Number.isFinite(value)&&kpi?.metric==='fwhm'?value.toFixed(1):kpi?.key==='score'&&Number.isFinite(value)?value.toFixed(3):sqrPlotNumber(value);}
// Use tenths of a pixel or larger steps so rounded FWHM ticks stay distinct.
function sqrHistogramTicks(data){
   if(data.kpi.metric!=='fwhm')return Array.from({length:6},(_,i)=>data.low+(data.high-data.low)*i/5);
   let step=Math.max(1,Math.ceil((data.high-data.low)*2)),first=Math.ceil(data.low*10/step)*step,values=[];
   for(let value=first;value<=data.high*10+1e-9;value+=step)values.push(value/10);return values;
}
function sqrHTML(text){return String(text).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');}
// Save metric identities, not menu positions, so new indicators do not change
// the axes in an existing process instance. Regional choices require measurements.
function sqrKPIKey(kpi){return kpi.key||kpi.region+':'+kpi.metric;}
function sqrScatterAxis(values,kpi){
   let min=Math.min(...values),max=Math.max(...values),padding=(max-min||Math.abs(min)||1)*.08;
   return {low:min>=0?Math.max(0,min-padding):min-padding,high:kpi.percentage&&!kpi.unboundedPercentage||kpi.key==='score'?Math.min(1,max+padding):max+padding};
}
/** Pearson correlation of the exact paired sample used for the plot. Rescaling
 * each axis before centering preserves r while avoiding cancellation from a
 * large common offset and squared overflow/underflow for different KPI units.
 * A constant axis makes r undefined, not zero. No row weights are applied. */
function sqrPearson(items){
   let count=items.length,result={r:null,count,reason:''};
   if(count<2){result.reason='At least two paired subframes are needed.';return result;}
   let ranges=['x','y'].map(key=>{
      let values=items.map(item=>item[key]),low=Math.min(...values),high=Math.max(...values);
      return {low,high,span:high-low,scale:Math.max(Math.abs(low),Math.abs(high))};
   });
   let constant=ranges.map(range=>range.high===range.low);
   if(constant[0]||constant[1]){result.reason=(constant[0]&&constant[1]?'X and Y have':constant[0]?'X has':'Y has')+' no variation.';return result;}
   let normalize=(value,range)=>Number.isFinite(range.span)?(value-range.low)/range.span:value/range.scale;
   // Score changes reorder rows. Keep summation order fixed so even the full
   // precision tooltip remains unchanged for the same paired measurements.
   let pairs=items.map(item=>[normalize(item.x,ranges[0]),normalize(item.y,ranges[1])]).sort((a,b)=>a[0]-b[0]||a[1]-b[1]);
   let meanX=pairs.reduce((sum,pair)=>sum+pair[0],0)/count,meanY=pairs.reduce((sum,pair)=>sum+pair[1],0)/count;
   let xx=0,yy=0,xy=0;for(let pair of pairs){let x=pair[0]-meanX,y=pair[1]-meanY;xx+=x*x;yy+=y*y;xy+=x*y;}
   let r=Math.max(-1,Math.min(1,(xy/Math.sqrt(xx))/Math.sqrt(yy)));
   // Remove only floating-point roundoff at the mathematical endpoints/zero.
   if(Math.abs(r)>=1-8*Number.EPSILON)r=r<0?-1:1;else if(Math.abs(r)<=8*Number.EPSILON)r=0;
   result.r=r;return result;
}
function sqrCorrelationStrength(r){let a=Math.abs(r);return a===1?'Perfect':a>=.7?'Strong':a>=.3?'Moderate':a>0?'Weak':'None';}
function sqrCorrelationText(correlation){
   let r=correlation.r;if(r===null)return 'Correlation (Pearson): unavailable · '+correlation.reason;
   // Round only the visible coefficient; interpretation retains full precision.
   let value=(r>0?'+':r<0?'-':'')+Math.abs(r).toFixed(4);
   if(r===0)return 'Correlation (Pearson) = '+value+' · None · No linear relationship';
   return 'Correlation (Pearson) = '+value+' · '+sqrCorrelationStrength(r)+' · '+(r>0?'Positive (both increase together)':'Negative (as X increases, Y decreases)');
}
/** Pair only finite measurements from the same subframe. Table filtering and
 * sort order never change the sample; rejection only changes point color.
 * Masters never enter the points, axes, counts, or correlation calculation. */
function sqrScatterPlot(group,xKPI,yKPI,selectedRow=null){
   let rows=(group?.rows||[]).filter(row=>!row.isMaster);
   let data={xKPI,yKPI,items:[],count:0,missing:0,total:rows.length,correlation:sqrPearson([]),message:''};
   if(!group){data.message='Measure a group to compare two quality indicators.';return data;}
   for(let row of rows){
      let x=sqrKPIValue(row,xKPI),y=sqrKPIValue(row,yKPI),paired=x!==null&&y!==null;
      if(paired)++data.count;else ++data.missing;
      if(paired)data.items.push({row,x,y,selected:row===selectedRow,review:sqrNeedsReview(row),rejected:!!(row.reject||row.moved)});
   }
   data.correlation=sqrPearson(data.items);
   if(!data.items.length){data.message='No images have both selected measurements. Measure the images, click Measure corners for regional indicators, or load guiding logs as needed.';return data;}
   data.xAxis=sqrScatterAxis(data.items.map(item=>item.x),xKPI);data.yAxis=sqrScatterAxis(data.items.map(item=>item.y),yKPI);
   return data;
}
// Retain meaningful digits for small signal weights as well as ordinary values.
function sqrScatterNumber(value,kpi){return kpi.metric==='fwhm'?sqrFmt(value,1):kpi.guiding?sqrGuideNumber(value):kpi.key==='score'?sqrFmt(value,3):kpi.percentage?sqrPercent(value):value!==0&&(Math.abs(value)<.001||Math.abs(value)>=1e6)?value.toExponential(2):sqrPlotNumber(value);}
/** Scatter coordinates remain numeric and unmodified, including overlapping
 * measurements. Draw the selected point last; all points support keyboard
 * focus and tooltips. Click messages use the same generation guard as bars. */
function sqrScatterContent(data,generation=0){
   let body='';
   if(data.message)body='<div class="empty">'+sqrHTML(data.message)+'</div>';
   else{
      let svg=[],labels=[],yTickChars=0,lastXChars=0;
      // Percentage positions use the data rectangle as their viewport. Text,
      // circles and click targets use font units and stay legible at any aspect.
      function label(x,y,value,attributes){
         labels.push('<text x="'+x+'" y="'+y+'" '+attributes+'>'+sqrHTML(value)+'</text>');
      }
      const x=value=>100*(value-data.xAxis.low)/(data.xAxis.high-data.xAxis.low)+'%';
      const y=value=>100*(data.yAxis.high-value)/(data.yAxis.high-data.yAxis.low)+'%';
      svg.push('<rect width="100%" height="100%" rx="3" fill="'+SQR_UNGRADED_PLOT.background+'"/>',
         '<g stroke="'+SQR_UNGRADED_PLOT.grid+'" stroke-dasharray="4 4">');
      for(let i=0;i<=5;++i){
         const px=(i*20)+'%',py=(100-i*20)+'%';
         const xt=sqrScatterNumber(data.xAxis.low+(data.xAxis.high-data.xAxis.low)*i/5,data.xKPI);
         const yt=sqrScatterNumber(data.yAxis.low+(data.yAxis.high-data.yAxis.low)*i/5,data.yKPI);
         yTickChars=Math.max(yTickChars,yt.length);
         if(i===5)lastXChars=xt.length;
         svg.push('<line x1="'+px+'" x2="'+px+'" y2="100%"/><line y1="'+py+'" y2="'+py+'" x2="100%"/>');
         label(px,'100%',xt,'text-anchor="middle" dy="1.35em"');
         label('0',py,yt,'text-anchor="end" dx="-.55em" dy=".35em"');
      }
      svg.push('</g><g stroke="#9399b2" pointer-events="none"><line y2="100%"/><line y1="100%" x2="100%" y2="100%"/></g>');
      // Preserve model indices for asynchronous selection despite drawing order.
      data.items.map((item,index)=>({item,index})).sort((a,b)=>Number(a.item.selected)-Number(b.item.selected)).forEach(({item,index})=>{
         let color=item.selected?'#89dceb':item.rejected?'#e57373':item.review?'#cba6f7':'#2d6cb5';
         let tip=(item.selected?'SELECTED · ':'')+(item.review?'REVIEW · ':'')+(item.rejected?'REJECTED · ':'')+sqrFileName(item.row.registered.path)+'\n'+data.xKPI.label+': '+sqrScatterNumber(item.x,data.xKPI)+'\n'+data.yKPI.label+': '+sqrScatterNumber(item.y,data.yKPI);
         if((data.xKPI.guiding||data.yKPI.guiding)&&item.row.guiding&&!item.row.guiding.scorable)tip+='\nPartial guiding data: '+item.row.guiding.reason;
         tip+='\nClick to select in Review and measurements';
         svg.push('<g class="point" data-index="'+index+'" tabindex="0" role="button" aria-label="'+sqrHTML(tip)+'"><title>'+sqrHTML(tip)+'</title>');
         svg.push('<circle cx="'+x(item.x)+'" cy="'+y(item.y)+'" r=".65em" fill="transparent" pointer-events="all"/>');
         svg.push('<circle data-point="'+index+'" cx="'+x(item.x)+'" cy="'+y(item.y)+'" r="'+(item.selected?'.43em':'.34em')+'" fill="'+color+'" stroke="'+(item.rejected?'#e57373':item.selected?'#00566e':'#1e1e2e')+'" stroke-width="'+(item.selected?2:1)+'"/></g>');
      });
      label('50%','100%',data.xKPI.label,'class="axis" text-anchor="middle" dy="2.85em"');
      labels.push('<g class="y-title">');
      label('0','50%',data.yKPI.label,'class="axis vertical" text-anchor="middle" dominant-baseline="central"');
      labels.push('</g>');
      body='<div class="plot-field" style="--y-ticks:'+yTickChars+'ch;--x-end:'+(lastXChars/2)+'ch"><svg class="scatter-chart" role="img" aria-label="'+sqrHTML(data.yKPI.label+' versus '+data.xKPI.label)+'">'+svg.join('')+'<g pointer-events="none">'+labels.join('')+'</g></svg></div>';
   }
   const [title,...details]=sqrCorrelationText(data.correlation).split(' · ');
   const tip=data.correlation.r===null?'':' title="Unrounded r = '+data.correlation.r+'"';
   const header='<header'+tip+'><h1 class="title">'+sqrHTML(title)+'</h1><div class="interpretation">'+sqrHTML(details.join(' · '))+'</div></header>';
   let style=SQR_CHART_CSS+'.scatter-chart{fill:currentColor}.axis{font-weight:600}.y-title{transform:translateX(calc(0px - var(--y-ticks) - 1.55em))}.vertical{transform-box:fill-box;transform-origin:center;transform:rotate(-90deg)}.point{cursor:pointer}.point:hover>[data-point],.point:focus>[data-point]{stroke:'+SQR_UNGRADED_PLOT.hover+';stroke-width:2}';
   return {body:'<div class="container">'+header+'<div class="plot-region">'+body+'</div></div>',style,generation};
}
/** Render the model as SVG inside a WebView. Escape image names and labels.
 * Clicks carry a plot-generation id so delayed browser callbacks cannot select
 * a row from an outdated group or indicator after the plot has been rebuilt. */
function sqrHistogramContent(data,generation=0){
   // SVG renderer for the per-image KPI measurements.
   let body='',legend='',message=data?.message||'',title=data?.kpi.label||'Quality indicators',palette=SQR_UNGRADED_PLOT;
   if(message)body='<div class="empty">'+sqrHTML(message)+'</div>';
   else if(data){
      let svg=[],y=value=>175-(value-data.low)/(data.high-data.low)*140,number=value=>sqrKPIPlotNumber(value,data.kpi);
      // Map the bar coordinates (55..385, 35..175) onto the shared data field.
      // Text follows the same anchors in an unscaled layer, including on resize.
      let labels=[],yTickChars=0;
      function addLabel(x,y,value,attributes){
         labels.push('<text x="'+((x-55)/330*100)+'%" y="'+((y-35)/140*100)+'%" '+attributes+'>'+sqrHTML(value)+'</text>');
      }
      let bands=sqrPlotBands(data),bandClass=data.skyBands?'sky':data.guideBands?'guide':data.fwhmBands?'fwhm':'eccentricity';
      palette=sqrPlotPalette(data,bands);
      svg.push('<defs><filter id="shadow" x="-20%" y="-20%" width="140%" height="140%"><feDropShadow dx="1" dy="2" stdDeviation="2" flood-color="#000" flood-opacity=".2"/></filter></defs><rect x="55" y="35" width="330" height="140" rx="3" fill="'+palette.background+'"/>');
      
      // Clip overlays to the data axis. A class can be wholly outside the
      // visible range; do not draw reversed rectangles or rescale the data.
      for(let band of bands){let low=Math.max(data.low,band.low??data.low),high=Math.min(data.high,band.high??data.high);
         if(high>low)svg.push('<rect class="'+bandClass+'-band" data-category="'+band.label+'" x="55" y="'+y(high)+'" width="330" height="'+(y(low)-y(high))+'" fill="'+band.color+'" fill-opacity="'+SQR_GRADE_OPACITY+'" pointer-events="none"/>');}
      for(let value of sqrHistogramTicks(data)){let py=y(value),tick=number(value);
         yTickChars=Math.max(yTickChars,tick.length);
         svg.push('<path d="M55 '+py+'H385" stroke="'+palette.grid+'" stroke-width=".5" stroke-dasharray="3,3"/>');
         const tickY=((py-35)/140*100)+'%';
         labels.push('<line x1="-.45em" x2="0" y1="'+tickY+'" y2="'+tickY+'" stroke="#585b70" stroke-width="2"/>');
         addLabel(55,py,tick,'class="tick" text-anchor="end" dx="-.65em" dy=".35em" fill="currentColor"');}
      let spacing=330/data.items.length,width=Math.min(spacing,Math.max(2,spacing-1));
      // Mark the whole slot, even for zero or missing measurements. Draw below
      // the bars so a selected frame can still show its own status outline.
      let selectedIndex=data.items.findIndex(item=>item.selected);
      if(selectedIndex>=0)svg.push('<rect class="selected-bin" x="'+(55+selectedIndex*spacing)+'" y="35" width="'+spacing+'" height="140" fill="#00566e" fill-opacity=".22" stroke="#00566e" stroke-width="2" vector-effect="non-scaling-stroke" pointer-events="none"/>');
      data.items.forEach((item,i)=>{if(item.value===null)return;let x=55+i*spacing+(spacing-width)/2,py=y(Math.max(data.low,Math.min(data.high,item.value))),cx=x+width/2;
         let color=item.selected?SQR_SELECTED_BAR:item.master?'#f9a825':item.rejected?'#e57373':item.review?'#cba6f7':'#2d6cb5';
         let outline=item.selected&&item.rejected?'#e57373':item.review?'#cba6f7':item.selected&&item.master?'#f9a825':'';
         let tip=(item.selected?'SELECTED · ':'')+(item.master?'MASTER: ':item.review?'REVIEW: ':'')+(item.rejected?'REJECTED · ':'')+sqrFileName(item.row.registered.path)+' — '+title+': '+number(item.value)+(data.kpi.key==='belowMeanFraction'?' ('+item.row.belowMeanCount+' worse; '+item.row.belowMeanAvailable+' assessed of '+item.row.belowMeanTotal+' enabled'+(item.row.belowMeanComplete?'':'; incomplete')+')':'')+(item.master&&data.masterClipped?' (clipped '+data.masterClipped+' axis range)':'')+(item.master?'':' — '+sqrAcquisitionLabel(item.row));
         if(data.skyModel?.valid&&!item.master){let m=data.skyModel,mu=sqrImageToSky(item.value,m.calibration);
            if(mu!==null)tip+=' — '+(m.calibration.transfer?'Green-relative estimate ':m.calibration.method==='sqm'?'SQM-based estimate ':'Approx. V-equivalent ')+mu.toFixed(2)+' mag/arcsec²'+(m.bortleClass?' — '+sqrBortleGrade(item.value,m)+' relative to Bortle '+sqrSkyBortleLabel(m):'')+
               (m.sqmValue!==null?' — '+(item.value<m.sqmValue?'Darker than':item.value>m.sqmValue?'Brighter than':'Equal to')+' session SQM':'');}
         if(data.eccentricityBands)tip+=' — '+sqrEccentricityCategory(item.value)+' eccentricity';
         if(data.fwhmBands)tip+=' — '+sqrFWHMCategory(item.value,data.fwhmModel)+' FWHM';
         svg.push('<g class="frame" data-index="'+i+'" tabindex="0" role="button"'+(item.selected?' aria-current="true"':'')+' aria-label="'+sqrHTML(tip)+'"><title>'+sqrHTML(tip)+'</title>');
         // A full-height hit area also makes zero-valued bars selectable.
         svg.push('<rect x="'+(55+i*spacing)+'" y="35" width="'+spacing+'" height="140" fill="transparent" pointer-events="all"/>');
         svg.push('<rect data-frame="'+i+'" x="'+x.toFixed(1)+'" y="'+py.toFixed(1)+'" width="'+width.toFixed(1)+'" height="'+(175-py).toFixed(1)+'" rx="3" fill="'+color+'" opacity="'+(item.rejected&&!item.selected ? .6 : 1)+'"'+(outline?' stroke="'+outline+'" stroke-width=".8"':'')+' filter="url(#shadow)"/>');
         if(item.selected)svg.push('<path data-selected="true" d="M'+(cx-3)+' 183L'+cx+' 178L'+(cx+3)+' 183Z" fill="#89dceb"/>');
         if(item.master){
            if(data.masterClipped){let top=data.masterClipped==='above',edge=top?35:175,tipY=top?edge-5:edge+5;
               svg.push('<path d="M'+(cx-3)+' '+edge+'L'+cx+' '+tipY+'L'+(cx+3)+' '+edge+'" fill="none" stroke="#f9a825" stroke-width="1.5"/>');}
            else svg.push('<circle cx="'+cx.toFixed(1)+'" cy="'+(py-5).toFixed(1)+'" r="3" fill="#f9a825"/>');
         }
         svg.push('</g>');});
      for(let band of bands.slice(0,2))if(band.high!==null&&band.high>=data.low&&band.high<=data.high)
         svg.push('<path class="'+bandClass+'-limit" d="M55 '+y(band.high)+'H385" stroke="'+band.color+'" stroke-width="1" stroke-dasharray="2,3" pointer-events="none"/>');
      if(data.average!==null){let py=y(data.average);
         svg.push('<path class="mean-reference" pointer-events="none" d="M55 '+py+'H385" stroke="'+palette.mean+'" stroke-width="1.5" stroke-dasharray="5,3"/>');
         addLabel(60,py,number(data.average),'class="mean-value" dy="-.4em" fill="'+palette.mean+'" font-weight="bold"');}
      if(data.skyModel?.valid&&data.skyModel.sqmValue!==null&&data.skyModel.sqmValue>=data.low&&data.skyModel.sqmValue<=data.high){let m=data.skyModel,py=y(m.sqmValue);
         svg.push('<path class="sqm-reference" pointer-events="none" d="M55 '+py+'H385" stroke="'+palette.sqm+'" stroke-width="2" stroke-dasharray="7,3"/>');
         addLabel(382,Math.max(48,py),'SQM '+m.sqmReading.toFixed(2),'class="sqm-value" text-anchor="end" dy="-.4em" fill="'+palette.sqm+'"');}
      for(let run of data.autofocus||[]){
         let start=55+run.startSlot*spacing;
         let label='AF'+(run.focusPosition==null?'':' '+run.focusPosition);
         let tip='Autofocus start: '+run.startText+' (log time)\nUTC: '+new Date(run.start).toISOString()+'\nFocus position: '+sqrFocusPositionText(run)+'\n'+run.reason+(run.sourcePaths?.length?'\nLogs: '+run.sourcePaths.map(sqrFileName).join(', '):'');
         svg.push('<g class="autofocus" pointer-events="none"><path d="M'+start+' 35V175" stroke="'+palette.focus+'" stroke-width="1" stroke-dasharray="2,2"/></g>');
         // Hover the AF tag below the axis; overlays leave all frame bars clickable.
         labels.push('<g class="af-tag" pointer-events="bounding-box"><title>'+sqrHTML(tip)+'</title>');
         addLabel(start,175,label,'class="af-value" text-anchor="middle" dy="2.9em" fill="#fab387" font-weight="bold"');
         labels.push('</g>');
      }
      svg.push('<path d="M55 35V175H385" fill="none" stroke="#585b70"/>');
      if(data.master!==null)addLabel(385,35,'Master: '+number(data.master)+(data.masterClipped?' '+(data.masterClipped==='above'?'↑':'↓')+' clipped':''),'class="master-value" text-anchor="end" dy="-.65em" fill="#f9a825"');
      let limit=value=>data.eccentricityBands?value.toFixed(2):number(value),unit=data.guideBands?'″':data.fwhmBands?' px':'';
      legend=bands.length?'<div class="category-legend">'+bands.map((band,i)=>{
         let range=data.skyBands?(band.label==='Good'?'< '+limit(band.high):band.label==='Bad'?'> '+limit(band.low):band.low===null?'≤ '+limit(band.high):band.high===null?'≥ '+limit(band.low):limit(band.low)+'–'+limit(band.high)):
            i===0?'≤ '+limit(band.high):i===1?'> '+limit(band.low)+' to '+limit(band.high):'> '+limit(band.low);
         let swatch='<i aria-hidden="true" style="display:inline-block;width:.85em;height:.85em;background:'+sqrGradeSwatch(band.color)+';border:1px solid #4e5862"></i>';
         return '<span style="color:'+SQR_GRADE_TEXT[band.label]+'">'+swatch+' '+band.label+' '+range+unit+'</span>';}).join(' &nbsp;·&nbsp; ')+'</div>':'';
      if(data.skyModel?.valid){let m=data.skyModel;
         legend+='<div class="bortle-legend'+(m.sqmValue!==null?' sqm-legend':'')+'">Bortle '+sqrSkyBortleLabel(m)+' · '+(m.sqmValue!==null?'SQM '+m.sqmReading.toFixed(2)+' mag/arcsec²':'Gaia calibration')+(m.calibration.transfer?' · relative to green':'')+'</div>';}
      body='<div class="plot-field" style="--y-ticks:'+yTickChars+'ch"><svg><svg viewBox="55 35 330 140" preserveAspectRatio="none">'+svg.join('')+'</svg><g class="plot-labels" pointer-events="none">'+labels.join('')+'</g></svg></div>';
   }
   let style=SQR_CHART_CSS+'.category-legend span{white-space:nowrap}.af-value{font-size:.95em}'+
      '.tick{fill:#a6adc8}.mean-value,.sqm-value{paint-order:stroke;stroke:'+palette.background+';stroke-width:2;stroke-linejoin:round}.frame{cursor:pointer}.frame:not([aria-current]):hover>[data-frame],.frame:not([aria-current]):focus>[data-frame]{stroke:'+palette.hover+';stroke-width:1.2}';
   return {body:'<div class="container"><header><h1 class="title">'+sqrHTML(title)+'</h1>'+legend+'</header><div class="plot-region">'+body+'</div></div>',style,generation};
}
function sqrChartDocument(plot){
   // The document and its listeners outlive individual charts. Replace the
   // markup in one browser task so the previous plot stays painted until then.
   const script=`
      window.sqrSelection=null;
      function select(event){
         const item=event.target.closest('[data-index]');
         if(!item)return;
         if(event.type==='keydown'){
            if(event.key!=='Enter'&&event.key!==' ')return;
            event.preventDefault();
         }
         window.sqrSelection={generation:Number(document.body.dataset.generation),index:Number(item.dataset.index)};
      }
      document.addEventListener('click',select);
      document.addEventListener('keydown',select);
      window.sqrReplacePlot=function(plot){
         const sheet=document.querySelector('style');
         if(sheet.textContent!==plot.style)sheet.textContent=plot.style;
         document.body.innerHTML=plot.body;
         document.body.dataset.generation=plot.generation;
         window.sqrSelection=null;
         return 'drawn:'+plot.generation;
      };`;
   return '<!doctype html><html><head><meta charset="UTF-8"><style>'+plot.style+'</style><script>'+script+'</script></head><body data-generation="'+plot.generation+'">'+plot.body+'</body></html>';
}
// Standalone documents are also used by the native plot inspection tools.
function sqrPlotHTML(data,generation=0){return sqrChartDocument(sqrHistogramContent(data,generation));}
function sqrScatterHTML(data,generation=0){return sqrChartDocument(sqrScatterContent(data,generation));}
class SQRChartView extends WebView {
   constructor(parent,ready,polled){
      super(parent);this.documentLoaded=false;this.drawing=null;this.queuedPlot=null;
      this.selectionPending=false;this.discardPendingSelection=false;
      const finish=generation=>{
         this.drawing=null;
         if(this.queuedPlot){let next=this.queuedPlot;this.queuedPlot=null;this.displayPlot(next);}
         else ready(generation);
      };
      this.onLoadFinished=ok=>{this.documentLoaded=ok;finish(ok?this.drawing:-1);};
      this.onScriptResultAvailable=value=>{
         if(typeof value==='string'&&value.startsWith('drawn:'))finish(Number(value.slice(6)));
         else if(value!=='cleared'){
            this.selectionPending=false;
            if(!this.discardPendingSelection)polled(value);
            this.discardPendingSelection=false;
         }
      };
   }
   displayPlot(plot){
      // While the first page or a replacement is pending, keep the latest request.
      if(this.drawing!==null){this.queuedPlot=plot;return;}
      this.drawing=plot.generation;
      if(this.documentLoaded)this.evaluateScript('window.sqrReplacePlot('+JSON.stringify(plot)+')');
      else this.setHTML(sqrChartDocument(plot));
   }
   pollSelection(){
      if(this.selectionPending)return;
      this.selectionPending=true;
      this.evaluateScript('(function(){var s=window.sqrSelection;window.sqrSelection=null;return s?JSON.stringify(s):null;})()');
   }
   discardSelection(){
      // A cached document survives tab changes. Drop both a stored click and
      // any poll reply still in flight when the user leaves this chart.
      this.discardPendingSelection=this.selectionPending;
      if(this.documentLoaded)this.evaluateScript("window.sqrSelection=null;'cleared'");
   }
}
/** Build an in-memory session from header reads. Group registered lights by
 * WBPP directory, exposure and geometry, then attach uniquely verified originals
 * and masters. The destination is excluded so previously moved lights stay out.
 * This stage does not load image pixels or move any files. */
/** Read WBPP data only: never execute the imported script or its process icons.
 * Native Script parameters are [id,value] pairs; XPSM uses the same table.
 * Only the fields needed to locate the run and its images are retained. */
function sqrWBPPRecord(id,filePath,pairs){
   let parameters=Object.create(null),wanted=['VERSION','DATA_VERSION','PRODUCT','outputDirectory','groups','frameGroups'],seen=new Set;
   for(let pair of pairs){let key=String(pair[0]),value=String(pair[1]);
      if(seen.has(key))throw new Error('Duplicate WBPP parameter: '+key);seen.add(key);
      if(wanted.includes(key))parameters[key]=value;}
   return {id:String(id),filePath:String(filePath),parameters};
}
function sqrWBPPIdentity(record){let p=record.parameters;
   return p.PRODUCT==='WBPP'||(!p.PRODUCT&&/(?:^|[/\\])(?:WBPP|WeightedBatchPreprocessing)\.js$/i.test(record.filePath));}
function sqrWBPPFromIcon(id){let instance=ProcessInstance.fromIcon(id);
   if(!instance||instance.processId()!=='Script')throw new Error('Select a WBPP script instance.');
   return sqrWBPPRecord(id,instance.filePath,instance.parameters);}
function sqrWBPPIcons(){let records=[];
   for(let id of ProcessInstance.iconsByProcessId('Script')){let r=sqrWBPPFromIcon(id);if(sqrWBPPIdentity(r))records.push(r);}
   return records;}
function sqrWBPPFromXML(text){
   if(text.length>64*1024*1024)throw new Error('The process-icon file exceeds the 64 MiB import limit. Save just the WBPP icon.');
   if(/<!DOCTYPE|<!ENTITY/i.test(text))throw new Error('Document type and entity declarations are not supported in process-icon files.');
   let doc=new XMLDocument;doc.parse(text);let root=doc.rootElement;
   if(!root||!['xpsm','instance'].includes(root.name))throw new Error('Select a PixInsight .xpsm process-icon file.');
   let instances=root.name==='instance'?[root,...root.childElementsByName('instance',true)]:root.childElementsByName('instance',true),records=[];
   for(let instance of instances)if(instance.attributeValue('class')==='Script'){
      let path=instance.childElementsByName('parameter').find(p=>p.attributeValue('id')==='filePath')?.text||'';
      let table=instance.childElementsByName('table').find(p=>p.attributeValue('id')==='parameters'),pairs=[];
      if(table)for(let row of table.childElementsByName('tr')){
         let cells=row.childElementsByName('td'),cell=id=>{let c=cells.find(c=>c.attributeValue('id')===id);return c?(c.text||c.attributeValue('value')):'';};
         pairs.push([cell('id'),cell('value')]);}
      let id=instance.attributeValue('id'),icon=root.childElementsByName('icon').find(e=>e.attributeValue('instance')===id);
      let r=sqrWBPPRecord(icon?.attributeValue('id')||id||'WBPP',path,pairs);if(sqrWBPPIdentity(r))records.push(r);
   }
   if(!records.length)throw new Error('No WBPP setup found. Choose a saved WBPP script icon, not the processing-history ProcessContainer.');
   return records;
}
function sqrWBPPFile(path){let info=new FileInfo(path);
   if(!info.exists||!info.isFile)throw new Error('Process-icon file not found: '+path);
   if(info.size>64*1024*1024)throw new Error('Save the WBPP icon separately; this file exceeds 64 MiB.');
   return sqrWBPPFromXML(File.readTextFile(path));}
function sqrWBPPDecode(text){return ByteArray.fromBase64(text).utf8ToString();}
function sqrWBPPAbsolute(path){
   if(typeof path!=='string'||!path.trim()||/[\x00-\x1f]/.test(path)||!(/^[A-Za-z]:[/\\]/.test(path)||/^[/\\]/.test(path)))
      throw new Error('WBPP contains an empty or relative file path. Save the setup with absolute paths.');
   return sqrPath(path);
}
function sqrWBPPCommonRoot(paths){let parts=sqrDir(paths[0]).replace(/\\/g,'/').replace(/\/$/,'').split('/');
   for(let path of paths){let next=sqrDir(path).replace(/\\/g,'/').split('/');while(parts.length&&parts.some((p,i)=>sqrKey(p)!==sqrKey(next[i]||'')))parts.pop();}
   let root=parts.join('/');if(!root||/^[A-Za-z]:$/.test(root)||/^\/\/[^/]+$/.test(root))
      throw new Error('The imported lights need a common original-light folder below the drive root. Import one acquisition setup at a time.');
   return root;}
/** WBPP switched image-type numbering and UTF-8 storage in 3.0.1. The
 * WBPP 3.1/3.2 schema 1 uses registration step 5 and regular master 0_0.
 * For older instances use the input list, then discover outputs normally. */
function sqrWBPPDecodeRecord(record){
   if(!sqrWBPPIdentity(record))throw new Error('This is not a WBPP setup.');
   let p=record.parameters,v=/^(\d+)\.(\d+)\.(\d+)/.exec(p.VERSION||'');
   if(!v||+v[1]<2||+v[1]>3||(+v[1]===3&&+v[2]>2)||Number(p.DATA_VERSION||0)>1)
      throw new Error('Unsupported WBPP data version. Supported setups: WBPP 2.x through 3.2.x.');
   let modern=+v[1]===3&&(+v[2]>0||+v[3]>=1),current=+v[1]===3&&+v[2]>=1;
   let output=p.outputDirectory||'',data=p.groups||p.frameGroups||'';
   if(!data)throw new Error('The WBPP instance has no saved frame list. Save it with the light frames included.');
   if(!/^\s*\[/.test(data))data=sqrWBPPDecode(data);
   let groups=JSON.parse(data);if(!Array.isArray(groups)||!groups.length)throw new Error('No WBPP frame groups were saved.');
   if(modern&&output&&!/^(?:[A-Za-z]:[/\\]|[/\\])/.test(output))output=sqrWBPPDecode(output);
   output=sqrWBPPAbsolute(output);
   let lights=new Map,disabled=new Set,masters=new Set;
   for(let group of groups)if(group&&Number(group.imageType)===(modern?4:3)&&!group.isMaster){
      if(!Array.isArray(group.fileItems))throw new Error('Invalid WBPP light-frame list.');
      for(let item of group.fileItems){
         if(!item||typeof item.filePath!=='string')throw new Error('Invalid WBPP light-frame path.');
         let path=sqrWBPPAbsolute(item.filePath),key=sqrKey(path);
         if(item.enabled===false){disabled.add(key);continue;}
         if(item.isMaster)continue;
         let light=lights.get(key);if(!light){light={path,registered:[]};lights.set(key,light);}
         if(current&&item.processed)for(let associated of Object.values(item.processed)){
            let path=associated?.['5'];if(typeof path==='string'&&path){path=sqrWBPPAbsolute(path);
               if(sqrUnder(path,output+'/registered')&&sqrImageFile(path)&&!light.registered.some(p=>sqrKey(p)===sqrKey(path)))light.registered.push(path);}}
      }
      let master=current&&group.masterFiles?.['0_0'];if(typeof master==='string'&&master){master=sqrWBPPAbsolute(master);if(sqrUnder(master,output+'/master')&&sqrImageFile(master))masters.add(master);}
   }
   if(!lights.size)throw new Error('The WBPP instance has no enabled original light frames.');
   if(lights.size>100000)throw new Error('Too many imported light frames. Import one acquisition setup at a time.');
   let list=Array.from(lights.values()),originals=sqrWBPPCommonRoot(list.map(l=>l.path));
   if(list.some(l=>sqrUnder(l.path,output)))throw new Error('WBPP light inputs include files inside its output directory. Import a setup containing original lights.');
   return {schema:1,source:record.id,version:p.VERSION,wbpp:output,originals,lights:list,masters:Array.from(masters),disabled:[...disabled].filter(k=>!lights.has(k)).length};
}
// Exclude a constant-width band with rounded ends on the registered pixel grid.
function sqrMaskTrail(image,start,end,width,region,ox,oy){
   let dx=end.x-start.x,dy=end.y-start.y,horizontal=Math.abs(dx)>=Math.abs(dy);
   if(!Number.isFinite(dx+dy+width)||Math.max(Math.abs(dx),Math.abs(dy))<1||width<1||width>200)throw Error('Choose two different pixels and a mask width of 1–200 pixels.');
   let major=p=>horizontal?p.x:p.y,minor=p=>horizontal?p.y:p.x;
   if(major(start)>major(end))[start,end]=[end,start];
   let u0=major(start),v0=minor(start),du=major(end)-u0,dv=minor(end)-v0,length2=du*du+dv*dv;
   let radius=width/2,slope=dv/du,extent=radius*Math.sqrt(1+slope*slope);
   let [x0,y0,x1,y1]=region;
   for(let u=Math.max(horizontal?x0:y0,Math.ceil(u0-radius));u<=Math.min((horizontal?x1:y1)-1,Math.floor(u0+du+radius));++u){
      let center=v0+slope*(u-u0),lo=Math.max(horizontal?y0:x0,Math.ceil(center-extent)),hi=Math.min((horizontal?y1:x1)-1,Math.floor(center+extent));
      const inside=v=>{let t=Math.max(0,Math.min(1,((u-u0)*du+(v-v0)*dv)/length2));
         return (u-u0-t*du)**2+(v-v0-t*dv)**2<=radius*radius;};
      while(lo<=hi&&!inside(lo))++lo;
      while(hi>=lo&&!inside(hi))--hi;
      if(lo>hi)continue;
      let x=(horizontal?u:lo)+ox-x0,y=(horizontal?lo:u)+oy-y0,n=hi-lo+1;
      let rect=new Rect(x,y,x+(horizontal?1:n),y+(horizontal?n:1)),zeros=new Float32Array(n);
      for(let c=0;c<image.numberOfNominalChannels;++c)image.setSamples(zeros,rect,c);
   }
}
// Find straight ridges on a bounded analysis grid. The saved mask always uses
// registered-image coordinates and the width chosen by the observer.
function sqrTrailField(source){
   const bin=Math.max(1,Math.ceil(Math.max(source.width,source.height)/1024)),small=new Image;
   let w,h,pixels;
   try{
      small.assign(source);if(bin>1)small.integerResample(-bin);
      w=small.width;h=small.height;pixels=new Float32Array(w*h);small.getSamples(pixels,new Rect(0,0,w,h),0);
      if(small.numberOfNominalChannels>1){
         let channel=new Float32Array(w*h);
         for(let c=1;c<small.numberOfNominalChannels;++c){small.getSamples(channel,new Rect(0,0,w,h),c);for(let i=0;i<pixels.length;++i)pixels[i]+=channel[i];}
         for(let i=0;i<pixels.length;++i)pixels[i]/=small.numberOfNominalChannels;
      }
   }finally{small.free();}
   let points=[],raw=new Float32Array(pixels),tileColumns=Math.ceil(w/32),tileNoise=new Float32Array(tileColumns*Math.ceil(h/32));
   // Normalize against the local sky and its MAD to allow for gradients.
   for(let y0=0;y0<h;y0+=32)for(let x0=0;x0<w;x0+=32){
      let x1=Math.min(w,x0+32),y1=Math.min(h,y0+32),sky=[],differences=[];
      for(let y=y0;y<y1;y+=2)for(let x=x0;x<x1;x+=2){let v=pixels[y*w+x];if(v>0&&Number.isFinite(v)){
         sky.push(v);if(x+1<x1&&pixels[y*w+x+1]>0)differences.push(Math.abs(pixels[y*w+x+1]-v));}}
      let median=sqrMedian(sky),mad=1.4826*sqrMedian(sky.map(v=>Math.abs(v-median)));
      let noise=Math.max(1e-7,Math.min(mad,differences.length?sqrMedian(differences)/.954:mad));
      tileNoise[(y0/32)*tileColumns+x0/32]=noise;
      for(let y=y0;y<y1;++y)for(let x=x0;x<x1;++x){let i=y*w+x,v=pixels[i];
         pixels[i]=v>0&&Number.isFinite(median+noise+v)?Math.max(-8,Math.min(24,(v-median)/noise)):NaN;
         if(pixels[i]>2.5)points.push(i);
      }
   }
   return {bin,w,h,pixels,points,raw,tileNoise,tileColumns};
}
function sqrTrailCandidates(field){
   let {w,h,points}=field,step=Math.max(1,points.length/24000),xs=[],ys=[];
   for(let i=0;i<points.length;i+=step){let p=points[Math.floor(i)];xs.push(p%w-(w-1)/2);ys.push(Math.floor(p/w)-(h-1)/2);}
   let radius=Math.ceil(Math.hypot(w,h)/2)+3,votes=new Uint32Array(2*radius+1),peaks=[];
   for(let a=0;a<360;++a){
      let angle=a*Math.PI/360,c=Math.cos(angle),s=Math.sin(angle);votes.fill(0);
      for(let i=0;i<xs.length;++i)++votes[radius+Math.round(xs[i]*c+ys[i]*s)];
      let local=[];
      for(let k=1;k<votes.length-1;++k){
         if(votes[k]<6||votes[k]<votes[k-1]||votes[k]<=votes[k+1])continue;
         local.push({angle,rho:k-radius,votes:votes[k]+.5*(votes[k-1]+votes[k+1])});
      }
      local.sort((a,b)=>b.votes-a.votes);peaks.push(...local.slice(0,6));
   }
   let candidates=[];
   for(let p of peaks.sort((a,b)=>b.votes-a.votes)){
      if(candidates.some(q=>{let d=Math.abs(p.angle-q.angle);return Math.min(d,Math.PI-d)<Math.PI/90&&Math.abs(p.rho-(d>Math.PI/2?-q.rho:q.rho))<4;}))continue;
      candidates.push(p);if(candidates.length===64)break;
   }
   return candidates;
}
// Test continuous support against sky on BOTH sides. A bright star or a step
// in the background cannot by itself supply a long, narrow, two-sided ridge.
function sqrTrailRun(field,angle,rho,side,minLength){
   let {w,h,pixels,raw,tileNoise,tileColumns}=field,nx=Math.cos(angle),ny=Math.sin(angle),horizontal=Math.abs(ny)>=Math.abs(nx);
   let major=horizontal?w:h,minor=horizontal?h:w,slope=horizontal?-nx/ny:-ny/nx;
   let intercept=(minor-1)/2-slope*(major-1)/2+rho/(horizontal?ny:nx),offset=Math.ceil(side*Math.hypot(1,slope));
   let best=null,first=-1,last=-1,mass=0,hits=0;
   for(let u0=0;u0<major;u0+=8){
      let count=0,sum=0,start=-1,end=-1,n=Math.min(8,major-u0);
      for(let u=u0;u<u0+n;++u){let v=Math.round(intercept+slope*u);if(v-offset<0||v+offset>=minor)continue;
         let i=horizontal?v*w+u:u*w+v,d=horizontal?offset*w:offset;
         if(!(raw[i-d]>0&&raw[i+d]>0))continue;
         let tile=(horizontal?(v>>5):(u>>5))*tileColumns+(horizontal?(u>>5):(v>>5));
         let signal=(raw[i]-Math.max(raw[i-d],raw[i+d]))/tileNoise[tile];
         if(pixels[i]>1.7&&signal>1.4){if(start<0)start=u;end=u;++count;sum+=Math.min(6,signal);}
      }
      if(count>=Math.max(1,Math.ceil(n*.5))){
         if(first<0||start-last>17){first=start;mass=hits=0;}
         last=end;mass+=sum;hits+=count;
         let span=last-first+1;
         if(span*Math.hypot(1,slope)>=minLength&&hits>=.58*span&&(!best||mass>best.score))
            best={horizontal,slope,intercept,first,last,score:mass};
      }
   }
   return best;
}
// Estimate the center at native resolution. Median residual clipping keeps
// occasional stars crossing the line out of the fitted slope and intercept.
function sqrRefineTrail(source,run,field,width,side,extent){
   let {bin}=field;
   let {horizontal,slope}=run,major=horizontal?source.width:source.height,minor=horizontal?source.height:source.width;
   let mid=(bin-1)/2,intercept=run.intercept*bin+mid*(1-slope);
   let first=Math.max(0,run.first*bin),last=Math.min(major-1,(run.last+1)*bin-1),samples=[],profileWidths=[],contrasts=[];
   let radius=Math.min(96,Math.max(20,5*bin,Math.ceil(width*.8))),channels=source.numberOfNominalChannels;
   for(let u=first;u<=last;u+=Math.max(1,Math.floor((last-first)/80))){
      let center=Math.round(intercept+slope*u);if(center-radius<0||center+radius>=minor)continue;
      let profile=[];for(let v=center-radius;v<=center+radius;++v){let value=0;
         for(let c=0;c<channels;++c)value+=horizontal?source.sample(u,v,c):source.sample(v,u,c);profile.push(value/channels);}
      let sky=Math.max((profile[0]+profile[1])/2,(profile[2*radius]+profile[2*radius-1])/2);
      let peak=Math.max(...profile)-sky,weight=0,moment=0;if(!(peak>0))continue;
      // Bright aircraft lights can have a narrow core and wide shoulders.
      let smooth=profile.map((v,i)=>(profile[Math.max(0,i-1)]+2*v+profile[Math.min(i+1,2*radius)])/4);
      let top=Math.max(...smooth),k=smooth.indexOf(top),lo=k,hi=k,shoulder=sky+.2*(top-sky);
      while(lo>0&&smooth[lo-1]>=shoulder)--lo;
      while(hi+1<profile.length&&smooth[hi+1]>=shoulder)++hi;
      let flank=profile.slice(0,5).concat(profile.slice(-5)),base=sqrMedian(flank);
      let noise=Math.max(1e-7,1.4826*sqrMedian(flank.map(v=>Math.abs(v-base))));
      if(noise>0){
         profileWidths.push((hi-lo+1)/Math.hypot(1,slope));
         contrasts.push(peak/noise);
      }
      for(let j=1;j<2*radius;++j){let excess=Math.max(0,profile[j]-sky-peak*.35);weight+=excess;moment+=excess*(center+j-radius);}
      if(weight>0)samples.push({u,v:moment/weight});
   }
   for(let pass=0;pass<2&&samples.length>=8;++pass){
      let residual=samples.map(p=>p.v-intercept-slope*p.u),center=sqrMedian(residual);
      let limit=Math.max(1.2,2.5*1.4826*sqrMedian(residual.map(v=>Math.abs(v-center))));
      samples=samples.filter((_,i)=>Math.abs(residual[i]-center)<=limit);
      if(samples.length<8)break;
      let u0=samples.reduce((s,p)=>s+p.u,0)/samples.length,v0=samples.reduce((s,p)=>s+p.v,0)/samples.length,uv=0,uu=0;
      for(let p of samples){uv+=(p.u-u0)*(p.v-v0);uu+=(p.u-u0)**2;}
      if(uu){slope=uv/uu;intercept=v0-slope*u0;}
   }
   // A confirmed diagonal may meet the frame edge where one comparison flank
   // falls outside the image. Follow its fitted center to the last lit sample.
   const extend=(u0,direction)=>{
      let limit=horizontal?field.w:field.h,cross=horizontal?field.h:field.w,edge=u0,misses=0;
      let offset=Math.ceil(side*Math.hypot(1,slope));
      for(let u=u0+direction;u>=0&&u<limit&&misses<3;u+=direction){
         let v=Math.round((intercept+slope*(u*bin+mid)-mid)/bin);if(v<0||v>=cross)break;
         let i=horizontal?v*field.w+u:u*field.w+v,stride=horizontal?field.w:1;
         let a=v>=offset?field.raw[i-stride*offset]:0,b=v+offset<cross?field.raw[i+stride*offset]:0;
         let sky=Math.max(a,b),tile=Math.floor(i/field.w/32)*field.tileColumns+Math.floor(i%field.w/32);
         if(sky>0&&field.pixels[i]>1.7&&field.raw[i]-sky>1.4*field.tileNoise[tile]){edge=u;misses=0;}else ++misses;
      }
      return edge;
   };
   first=extend(run.first,-1)*bin;last=Math.min(major-1,(extend(run.last,1)+1)*bin-1);
   // Thin tracks often fade or pass through stars. Intersect the fitted line
   // with the rectangle, rather than clamping two extrapolated endpoints.
   // Bright, resolved broad tracks keep the measured run in automatic mode.
   const broadBright=sqrMedian(profileWidths)>=7&&sqrMedian(contrasts)>=8;
   if(extent==='full'||(extent==='auto'&&!broadBright)){
      let lo=0,hi=major-1;
      if(Math.abs(slope)>1e-10){let a=-intercept/slope,b=(minor-1-intercept)/slope;
         lo=Math.max(lo,Math.min(a,b));hi=Math.min(hi,Math.max(a,b));}
      if(hi>lo){first=Math.round(lo);last=Math.round(hi);}
   }
   const point=u=>{let v=Math.max(0,Math.min(minor-1,Math.round(intercept+slope*u)));return horizontal?{x:u,y:v}:{x:v,y:u};};
   return {start:point(first),end:point(last),width,broadBright};
}
// Follow bright aircraft lights at native resolution. Several parallel lights
// can blend into one ridge on the detection grid. Median cross-sections resolve
// them and prevent an isolated star from starting or extending a track.
function sqrTraceAircraft(source,seed,bin,extent){
   let dx=seed.end.x-seed.start.x,dy=seed.end.y-seed.start.y,horizontal=Math.abs(dx)>=Math.abs(dy);
   let slope=horizontal?dy/dx:dx/dy,major=horizontal?source.width:source.height,minor=horizontal?source.height:source.width;
   let intercept=horizontal?seed.start.y-slope*seed.start.x:seed.start.x-slope*seed.start.y;
   let radius=Math.max(24,Math.min(96,6*bin)),step=Math.max(4,Math.min(24,Math.ceil(major/260))),tracks=[],active=[];
   const point=(u,v)=>horizontal?{x:u,y:v}:{x:v,y:u};
   for(let u=0;u<major;u+=step){
      let center=Math.round(intercept+slope*u);if(center+radius<0||center-radius>=minor)continue;
      let slices=[];
      for(let t=-3;t<=3;++t){
         let a=Math.max(0,Math.min(major-1,u+t)),v0=Math.round(intercept+slope*a)-radius;
         let v1=Math.max(0,v0),v2=Math.min(minor,v0+2*radius+1);if(v2<=v1)continue;
         let data=new Float32Array(v2-v1),rect=horizontal?new Rect(a,v1,a+1,v2):new Rect(v1,a,v2,a+1);
         source.getSamples(data,rect,0);
         if(source.numberOfNominalChannels>1){let ch=new Float32Array(data.length);
            for(let c=1;c<source.numberOfNominalChannels;++c){source.getSamples(ch,rect,c);for(let j=0;j<data.length;++j)data[j]+=ch[j];}}
         slices.push({data,offset:v1-v0});
      }
      let profile=[];
      for(let i=0;i<=2*radius;++i){let samples=[];for(let s of slices){let v=s.data[i-s.offset];if(v>0)samples.push(v);}
         profile.push(samples.length>=4?sqrMedian(samples):NaN);}
      let valid=profile.filter(Number.isFinite).sort((a,b)=>a-b);if(valid.length<12)continue;
      let sky=valid[Math.floor(valid.length*.25)],noise=Math.max(1e-7,sky-valid[Math.floor(valid.length*.08)]);
      let peaks=[];
      for(let i=2;i<profile.length-2;++i){let v=profile[i];if(!(v>=profile[i-1]&&v>profile[i+1]&&v>sky+8*noise))continue;
         let half=sky+(v-sky)/2,lo=i,hi=i;
         while(lo>0&&profile[lo-1]>=half)--lo;
         while(hi+1<profile.length&&profile[hi+1]>=half)++hi;
         if(hi-lo+1>=3)peaks.push({i,lo,hi,v});
      }
      peaks.sort((a,b)=>b.v-a.v);
      let resolved=[];
      for(let p of peaks){
         if(p.v-sky<(peaks[0].v-sky)*.22||resolved.some(q=>p.lo<=q.hi+1&&p.hi>=q.lo-1))continue;
         resolved.push(p);
      }
      active=active.filter(t=>u-t.last.u<=2*step);
      for(let p of resolved){
         let offset=(p.lo+p.hi)/2-radius,best=null,distance=Math.max(3,step*.22);
         for(let t of active){let d=Math.abs(t.last.offset-offset);if(t.last.u!==u&&d<distance){best=t;distance=d;}}
         if(!best){best={samples:[]};active.push(best);tracks.push(best);}
         best.last={u,offset,v:center+offset,sky,peak:p.v};best.samples.push(best.last);
      }
   }
   let result=[];
   for(let t of tracks){
      let s=t.samples,first=s[0],last=s[s.length-1],span=last.u-first.u;
      if(span<Math.max(36,major*.035)||s.length*step<span*.78)continue;
      // Sparse knots retain a gently curving aircraft path. Median offsets
      // smooth local centroid jitter without joining separate flashes.
      let pts=[];for(let i=0;i<s.length;i+=3){let a=s.slice(i,i+3),p=a[Math.floor(a.length/2)];
         pts.push(point(p.u,Math.round(intercept+slope*p.u+sqrMedian(a.map(q=>q.offset)))));}
      // Locate each endpoint between the sampled cross-sections. Immediately
      // outside a short aircraft trail its nearby brighter neighbor may persist.
      const endpoint=(q,dir)=>{
         let lastLit=q.u,misses=0;
         for(let d=1;d<=2*step&&misses<3;++d){
            let u=q.u+dir*d,v=Math.round(q.v+dir*d*slope);if(u<0||u>=major||v<0||v>=minor)break;
            let top=0;for(let j=Math.max(0,v-2);j<=Math.min(minor-1,v+2);++j){
               let value=0;for(let c=0;c<source.numberOfNominalChannels;++c)value+=horizontal?source.sample(u,j,c):source.sample(j,u,c);
               top=Math.max(top,value);
            }
            if(top>q.sky+.25*(q.peak-q.sky)){lastLit=u;misses=0;}else ++misses;
         }
         return lastLit;
      };
      let u0=endpoint(first,-1),u1=endpoint(last,1);
      if(extent==='full'){
         let lo=0,hi=major-1,b=intercept+sqrMedian(s.map(p=>p.offset));
         if(Math.abs(slope)>1e-10){let a=-b/slope,z=(minor-1-b)/slope;lo=Math.max(lo,Math.min(a,z));hi=Math.min(hi,Math.max(a,z));}
         u0=Math.round(lo);u1=Math.round(hi);
      }
      const endPoint=(u,q)=>point(u,Math.max(0,Math.min(minor-1,Math.round(q.v+slope*(u-q.u)))));
      let start=endPoint(u0,first),end=endPoint(u1,last);
      let via=pts.filter(p=>(horizontal?p.x:p.y)>u0&&(horizontal?p.x:p.y)<u1&&p.x>=0&&p.x<source.width&&p.y>=0&&p.y<source.height);
      result.push({start,end,width:seed.width,via});
   }
   return result;
}
function sqrDetectTrailBands(source,width,extent='auto'){
   if(Math.min(source.width,source.height)<3*Math.ceil(Math.max(source.width,source.height)/1024))return [];
   const field=sqrTrailField(source),minLength=Math.max(32,Math.min(field.w,field.h)*.22);
   if(field.points.length<minLength*.5)return [];
   let runs=[],side=Math.max(5,Math.min(24,Math.ceil(.65*width/field.bin)+2));
   for(let candidate of sqrTrailCandidates(field)){
      let best=null;
      for(let da of [-.25,0,.25])for(let dr of [-1.5,0,1.5]){
         let run=sqrTrailRun(field,candidate.angle+da*Math.PI/180,candidate.rho+dr,side,minLength);
         if(run&&(!best||run.score>best.score))best=run;
      }
      if(best)runs.push(best);
   }
   let bands=[],seeds=[];
   for(let run of runs.sort((a,b)=>b.score-a.score)){
      let band=sqrRefineTrail(source,run,field,width,side,extent);
      if(seeds.some(b=>{
         let dx=b.end.x-b.start.x,dy=b.end.y-b.start.y,length=Math.hypot(dx,dy);
         let near=p=>Math.abs((p.x-b.start.x)*dy-(p.y-b.start.y)*dx)/length<=Math.max(3,(b.broadBright?4:2)*field.bin);
         let along=p=>((p.x-b.start.x)*dx+(p.y-b.start.y)*dy)/length;
         let a=along(band.start),z=along(band.end);
         return near(band.start)&&near(band.end)&&Math.max(a,z)>=0&&Math.min(a,z)<=length;
      }))continue;
      seeds.push(band);
      let traced=band.broadBright?sqrTraceAircraft(source,band,field.bin,extent):[];
      if(traced.length)bands.push(...traced);
      else bands.push({start:band.start,end:band.end,width});
      if(bands.length>=16)break;
   }
   return bands.slice(0,16);
}
function sqrRetainedRegistered(row){return !!row?.registered?.path&&!row.isMaster&&!row.moved&&!row.reject;}
// Measure one native row or column across the traced center. Projection onto
// the local normal makes the result independent of the trail's angle.
function sqrTrailProfileWidth(source,x,y,dx,dy){
   const horizontal=Math.abs(dx)>=Math.abs(dy),normal=Math.max(Math.abs(dx),Math.abs(dy))/Math.hypot(dx,dy);
   const u=Math.round(horizontal?x:y),v=horizontal?y:x;
   const cross=horizontal?source.height:source.width,radius=Math.ceil(120/normal);
   const lo=Math.max(0,Math.floor(v)-radius),hi=Math.min(cross-1,Math.ceil(v)+radius),center=v-lo;
   if(u<0||u>=(horizontal?source.width:source.height)||v-lo<12||hi-v<12)return null;
   let profile=new Float32Array(hi-lo+1),rect=horizontal?new Rect(u,lo,u+1,hi+1):new Rect(lo,u,hi+1,u+1);
   source.getSamples(profile,rect,0);
   if(source.numberOfNominalChannels>1){let ch=new Float32Array(profile.length);
      for(let c=1;c<source.numberOfNominalChannels;++c){source.getSamples(ch,rect,c);for(let j=0;j<ch.length;++j)profile[j]+=ch[j];}}
   const flank=Math.min(16,Math.floor(Math.min(v-lo,hi-v)/3)),n=profile.length;
   const positive=a=>Array.from(a).filter(t=>Number.isFinite(t)&&t>0);
   let left=positive(profile.subarray(0,flank)),right=positive(profile.subarray(n-flank));
   if(Math.min(left.length,right.length)<Math.ceil(.7*flank))return null;
   let a=sqrMedian(left),b=sqrMedian(right),gradient=(b-a)/(n-flank);
   let noise=Math.max(1e-7,1.4826*sqrMedian(left.map(t=>Math.abs(t-a)).concat(right.map(t=>Math.abs(t-b)))));
   let smooth=new Float64Array(n);
   for(let i=1;i<n-1;++i)smooth[i]=(profile[i-1]+2*profile[i]+profile[i+1])/4-a-gradient*(i-(flank-1)/2);
   let k=Math.round(center),reach=Math.ceil(2/normal),peak=k;
   for(let i=k-reach;i<=k+reach;++i)if(smooth[i]>smooth[peak])peak=i;
   if(!(smooth[peak]>4*noise&&smooth[k]>Math.max(2*noise,.15*smooth[peak])))return null;
   // Stop in sky noise, or at the valley before a separate parallel ridge.
   const limit=Math.max(2.5*noise,.025*smooth[peak]);
   function edge(direction){
      let valley=peak;
      for(let i=peak+direction;i>1&&i<n-2;i+=direction){
         if(smooth[i]<limit&&smooth[i+direction]<limit){
            let inner=i-direction;
            return smooth[inner]>limit?inner+direction*(smooth[inner]-limit)/(smooth[inner]-smooth[i]):i;
         }
         if(smooth[i]<smooth[valley])valley=i;
         if(smooth[valley]<.4*smooth[peak]&&smooth[i]-smooth[valley]>Math.max(4*noise,.22*smooth[peak]))return valley;
      }
      return null;
   }
   let l=edge(-1),r=edge(1);
   return l===null||r===null?null:2*Math.max(center-l,r-center)*normal;
}
function sqrEstimateTrailWidth(source,band){
   let path=[band.start,...(band.via||[]),band.end],lengths=[],total=0;
   for(let i=1;i<path.length;++i){total+=Math.hypot(path[i].x-path[i-1].x,path[i].y-path[i-1].y);lengths.push(total);}
   let count=Math.min(64,Math.floor(total/3)),widths=[],j=0;
   for(let i=0;i<count;++i){
      let distance=total*(i+.5)/count;
      while(j<lengths.length-1&&distance>=lengths[j])++j;
      let p=path[j],dx=path[j+1].x-p.x,dy=path[j+1].y-p.y,base=j?lengths[j-1]:0,t=(distance-base)/(lengths[j]-base);
      let width=sqrTrailProfileWidth(source,p.x+t*dx,p.y+t*dy,dx,dy);
      if(width!==null)widths.push(width);
   }
   if(widths.length<Math.max(6,Math.ceil(count/4)))return null;
   widths.sort((a,b)=>a-b);
   // Cover typical wider sections and allow half a pixel per edge for rounding.
   return Math.min(200,Math.max(1,Math.ceil(widths[Math.floor(.8*(widths.length-1))]+1)));
}
function sqrBlinkBands(row){
   if(row?.trailBands?.length&&sqrFingerprint(row.registered.path)!==row.registered.fingerprint)
      throw Error('The registered light changed. Refresh the file list before displaying its trail mask.');
   return row?.trailBands;
}
function sqrTrailPlanPath(wbpp,row){
   let root=sqrPath(wbpp)+'/registered',source=sqrPath(row.registered.path);
   if(!sqrUnder(source,root))throw Error('The light is outside this run’s registered folder: '+source);
   return sqrPath(wbpp)+'/SQR-trail-masks/'+source.slice(root.length+1)+'.json';
}
function sqrValidateTrailBands(bands,m){
   const point=p=>p&&Number.isInteger(p.x)&&Number.isInteger(p.y)&&p.x>=0&&p.x<m.width&&p.y>=0&&p.y<m.height;
   if(!Array.isArray(bands)||bands.length>1024||bands.some(b=>!b||!point(b.start)||!point(b.end)||
      (b.start.x===b.end.x&&b.start.y===b.end.y)||!Number.isInteger(b.width)||b.width<1||b.width>200||
      (b.via!==undefined&&(!Array.isArray(b.via)||b.via.length>4096||!b.via.every(point)))))
      throw Error('Invalid trail mask coordinates for '+m.path);
   return bands;
}
function sqrReadTrailState(wbpp,row){
   let path=sqrTrailPlanPath(wbpp,row),empty={trailBands:[],trailCopy:'',trailCopyFingerprint:''};
   if(!File.exists(path))return empty;
   if(new FileInfo(path).size>1024*1024)throw Error('Unexpected trail mask file size: '+path);
   let saved=JSON.parse(File.readTextFile(path));
   if(saved?.version!==1&&saved?.version!==2)throw Error('Unsupported trail mask file: '+path);
   if(saved.sourceFingerprint!==row.registered.fingerprint)return empty;
   let trailBands=sqrValidateTrailBands(saved.bands,row.registered);
   if(saved.version===1||!trailBands.length)return {...empty,trailBands};
   if(!/^SQR-repair-[A-Za-z0-9_-]+$/.test(saved.folder)||!saved.copyFingerprint)
      throw Error('Invalid repaired image record: '+path);
   return {trailBands,trailCopy:sqrDir(path)+'/'+saved.folder+'/'+sqrBase(row.registered.path)+'.xisf',trailCopyFingerprint:saved.copyFingerprint};
}
function sqrLoadTrailBands(wbpp,row){return sqrReadTrailState(wbpp,row).trailBands;}
function sqrSaveTrailBands(wbpp,row,bands){
   let path=sqrTrailPlanPath(wbpp,row),dir=sqrDir(path),m=row.registered;
   function checkCurrent(){
      let previous=sqrReadTrailState(wbpp,row);
      if(sqrFingerprint(m.path)!==m.fingerprint||previous.trailCopy!==(row.trailCopy||'')||
         JSON.stringify(previous.trailBands)!==JSON.stringify(row.trailBands||[]))
         throw Error('The registered light or saved repair changed. Refresh the file list before editing.');
      return previous;
   }
   let previous=checkCurrent();
   sqrValidateTrailBands(bands,m);TGFileProtection.assertOutsideInstallation(path,'Trail repair');
   if(!File.directoryExists(dir))File.createDirectory(dir,true);
   let folder='',copy='',id='',fingerprint='',created=false;
   // The previous copy remains usable until both the new XISF and its small
   // manifest have been written. Keep the WBPP basename for local normalization.
   try{
      if(bands.length){
         folder=File.uniqueFileName(dir,20,'SQR-repair-','');TGFileProtection.assertOutsideInstallation(folder,'Trail repair folder');File.createDirectory(folder);created=true;
         id=sqrFileName(folder);copy=folder+'/'+sqrBase(m.path)+'.xisf';
         sqrWriteMaskedLight(row,bands,copy);fingerprint=sqrFingerprint(copy);
      }
      checkCurrent();
      TGFileProtection.writeTextFile(path,JSON.stringify({version:2,sourceFingerprint:m.fingerprint,bands,folder:id,copyFingerprint:fingerprint}),'Registered trail repair');
   }catch(e){
      if(copy&&File.exists(copy))TGFileProtection.removeFile(copy,'Incomplete repaired image');
      if(created&&File.directoryExists(folder))TGFileProtection.removeDirectory(folder,'Incomplete repair folder');
      throw e;
   }
   Object.assign(row,{trailBands:bands,trailCopy:copy,trailCopyFingerprint:fingerprint});delete row.trailError;
   if(previous.trailCopy&&File.exists(previous.trailCopy))try{
      if(sqrFingerprint(previous.trailCopy)===previous.trailCopyFingerprint){
         TGFileProtection.removeFile(previous.trailCopy,'Superseded repaired image');
         TGFileProtection.removeDirectory(sqrDir(previous.trailCopy),'Empty repair folder');
      }
   }catch(e){console.warningln('Could not clean up the previous repair: '+e);}
}
function sqrApplyTrailBands(image,bands,rect=null){
   if(!bands?.length)return;
   let tiles=Array.isArray(rect?.[0])?rect:[rect||[0,0,image.width,image.height]];
   for(let i=0;i<tiles.length;++i){
      let t=tiles[i],ox=(i%2)*(t[2]-t[0]),oy=Math.floor(i/2)*(t[3]-t[1]);
      for(let b of bands){let from=b.start;for(let to of [...(b.via||[]),b.end]){
         if(from.x!==to.x||from.y!==to.y)sqrMaskTrail(image,from,to,b.width,t,ox,oy);from=to;}}
   }
}
// Only repaired inputs need temporary files. Open a private copy to avoid
// changing an existing image window. Saving as XISF preserves image metadata.
function sqrWriteMaskedLight(row,bands,output){
   let m=row.registered,copy=File.uniqueFileName(File.systemTempDirectory,20,'SQR-trail-source-',File.extractExtension(m.path)),windows=[];
   try{
      TGFileProtection.assertOutsideInstallation(copy,'Temporary registered light');File.copyFile(copy,m.path);
      windows=ImageWindow.open(copy);if(windows.length!==1)throw Error('Expected one registered light: '+m.path);
      let win=windows[0],v=win.mainView;v.beginProcess();
      try{sqrApplyTrailBands(v.image,bands);}finally{v.endProcess();}
      TGFileProtection.assertOutsideInstallation(output,'Repaired registered light');
      if(!win.saveAs(output,false,false,false,false))throw Error('Cannot write repaired integration input: '+m.path);
      return output;
   }finally{for(let win of windows)win.forceClose();if(File.exists(copy))TGFileProtection.removeFile(copy,'Temporary registered light');}
}
function sqrPreparedRegisteredLight(row,scratch,index,files){
   if(row.trailCopy){
      if(sqrFingerprint(row.trailCopy)!==row.trailCopyFingerprint)throw Error('Saved repaired image changed: '+row.trailCopy);
      return row.trailCopy;
   }
   // Coordinate-only repairs from older runs can still be integrated.
   let dir=scratch+'/input-'+index,output=dir+'/'+sqrBase(row.registered.path)+'.xisf';
   TGFileProtection.assertOutsideInstallation(dir,'Temporary masked light folder');File.createDirectory(dir);files.push(dir,output);
   return sqrWriteMaskedLight(row,row.trailBands,output);
}
function sqrImportedRun(o){return o?.wbppImport?.schema===1&&sqrSameRunFolders(o.wbppImport,o);}
// Inspect XML as data. Only the matching ImageIntegration element enters
// native deserialization, never the surrounding container or script processes.
function sqrIntegrationElement(xml,group,container=false){
   if(!xml||xml.length>64*1024*1024||/<!DOCTYPE|<!ENTITY/i.test(xml))return null;
   let doc=new XMLDocument;doc.parse(xml);
   let candidates=[],paths=new Set(group.rows.map(r=>sqrKey(r.registered.path)));
   function visit(e){
      if(e.name==='instance'&&e.attributeValue('class')==='ImageIntegration'){
         let table=e.childElementsByName('table').find(t=>t.attributeValue('id')==='images');if(!table)return;
         let count=0;
         for(let tr of table.childElementsByName('tr')){
            let cells=tr.childElementsByName('td'),cell=k=>cells.find(c=>c.attributeValue('id')===k)?.text||'';
            if(container&&sqrKey(cell('localNormalizationDataPath')).includes('/ln_reference_frame_data/'))return;
            if(paths.has(sqrKey(cell('path'))))++count;
         }
         if(count)candidates.push({element:e,count});return;
      }
      // Other tables (including large frame lists) cannot contain processes.
      if(e.name==='table'||e.name==='parameter')return;
      for(let child of e.childElements())visit(child);
   }
   visit(doc.rootElement);candidates.sort((a,b)=>b.count-a.count);
   if(!candidates.length)return null;
   if(candidates.length>1&&candidates[0].count===candidates[1].count)throw Error('Several WBPP integrations match this group equally. A matching filter master with its processing history is needed.');
   return candidates[0].element;
}
function sqrWBPPIntegrationElement(o,group){
   if(!sqrImportedRun(o))throw Error('Import the WBPP setup for this run before creating a reviewed master.');
   if(group.master&&File.exists(group.master)){
      let reader=new FileFormatInstance(new FileFormat(File.extractExtension(group.master),true,false));
      try{if(reader.open(group.master,'verbosity 0')&&reader.format.canStoreImageProperties&&reader.imageProperties.some(p=>(p.id||p[0])==='PixInsight:ProcessingHistory')){
         let e=sqrIntegrationElement(reader.readImageProperty('PixInsight:ProcessingHistory'),group);
         if(e)return {element:e,source:group.master};
      }}finally{reader.close();}
   }
   let logs=sqrPath(o.wbpp)+'/logs',find=new FileFind,names=[];
   if(File.directoryExists(logs)&&find.begin(logs+'/*'))try{do{
      if(find.isFile&&!find.isSymbolicLink&&/^\d{14}_ProcessContainer\.xpsm$/i.test(find.name))names.push(find.name);
   }while(find.next());}finally{find.end();}
   // Use the latest run in this folder. An older container could use obsolete settings.
   if(names.length){let path=logs+'/'+names.sort().pop(),log=sqrWBPPLogReport(sqrPath(o.wbpp));
      if((!log?.path||sqrFileName(log.path).slice(0,14)===sqrFileName(path).slice(0,14))&&new FileInfo(path).size<=64*1024*1024){
         let e=sqrIntegrationElement(File.readTextFile(path),group,true);if(e)return {element:e,source:path};
      }}
   throw Error('Cannot find the final ImageIntegration settings for this group. Restore the matching WBPP master with its processing history or the run’s ProcessContainer.xpsm in logs/.');
}
// Let PixInsight decode its own process parameters and enumerations. A tiny
// temporary XISF carries the single history entry, avoiding a full master read.
function sqrRestoreIntegration(element,path){
   let history=new XMLDocument,root=new XMLElement('ProcessingHistory');root.setAttribute('version','1.0');root.addChildNode(element);history.rootElement=root;
   let f=new FileFormatInstance(new FileFormat('.xisf',false,true)),im=new Image,windows=[];
   try{TGFileProtection.assertOutsideInstallation(path,'Temporary integration settings');im.allocate(1,1,1);
      if(!f.create(path,'verbosity 0'))throw Error('Could not stage WBPP settings.');
      f.writeImageProperty('PixInsight:ProcessingHistory',history.serialize());if(!f.writeImage(im)||!f.close())throw Error('Could not write WBPP settings.');
      windows=ImageWindow.open(path);let p=windows[0]?.mainView.initialProcessing[0];
      if(!p||p.processId()!=='ImageIntegration')throw Error('PixInsight could not restore the saved ImageIntegration settings.');
      return p;
   }finally{if(f.isOpen)f.close();im.free();for(let w of windows)w.forceClose();}
}
function sqrIntegrationMembership(images,rows){
   let retained=new Map,enabled=[],disabled=0;
   for(let row of rows){
      let key=sqrKey(row.registered.path);
      if(retained.has(key))throw Error('Ambiguous registered light path: '+row.registered.path);
      retained.set(key,row);
   }
   // Consume disabled entries too. Only paths absent from the saved table
   // can be offered as additional inputs, after the saved reference and inputs.
   let seen=new Set;
   for(let [on,path,,ln] of images){
      let key=sqrKey(path),row=retained.get(key);if(!row)continue;
      if(seen.has(key))throw Error('Duplicate image in the WBPP integration: '+path);
      seen.add(key);
      if(on)enabled.push({row,ln});else ++disabled;
   }
   return {enabled,disabled,extra:rows.filter(row=>!seen.has(sqrKey(row.registered.path))).map(row=>({row,ln:''}))};
}
function sqrReviewedIntegrationInputs(p,rows,scratch,files,useMasks=true,entries=sqrIntegrationMembership(p.images,rows).enabled){
   let inputs=[],csv=new Map;
   let local=p.normalization===ImageIntegration.LocalNormalization||p.rejectionNormalization===ImageIntegration.LocalRejectionNormalization;
   for(let {row,ln} of entries){
      let original=row.registered.path;
      if(local){ln=ln||File.changeExtension(original,'.xnml');if(!File.exists(ln))throw Error('Missing WBPP local normalization data for '+original+': '+ln);}
      let path=useMasks&&row.trailBands?.length?sqrPreparedRegisteredLight(row,scratch,inputs.length,files):original;
      inputs.push([true,path,'',ln||'']);csv.set(sqrKey(original),path);
   }
   if(p.weightMode===ImageIntegration.CSVWeightsFile){
      if(!File.exists(p.csvWeightsFilePath))throw Error('Missing WBPP weights file: '+p.csvWeightsFilePath);
      let weights=[],found=new Set;
      for(let line of File.readTextFile(p.csvWeightsFilePath).split(/\r?\n/)){
         // WBPP writes an absolute path followed by one or three numeric weights.
         let m=/^(.+?),\s*([+\-\d.eE]+(?:\s*,\s*[+\-\d.eE]+){0,2})\s*$/.exec(line);if(!m)continue;
         let k=sqrKey(m[1].trim().replace(/^"|"$/g,''));if(!csv.has(k))continue;
         if(found.has(k))throw Error('Duplicate WBPP CSV weight: '+m[1]);found.add(k);weights.push(csv.get(k)+', '+m[2]);
      }
      if(found.size!==csv.size)throw Error('The WBPP weights file has no weight for one or more retained inputs.');
      let path=scratch+'/weights.csv';files.push(path);TGFileProtection.writeTextFile(path,weights.join('\n'),'Temporary integration weights');p.csvWeightsFilePath=path;
   }
   p.images=inputs;
}
// A run-relative identity keeps versions together even if the WBPP tree moves.
function sqrMasterGroupKey(wbpp,g){
   let dir=sqrPath(g.directory||sqrDir(g.rows[0].registered.path)),base=sqrPath(wbpp)+'/';
   let directory=sqrUnder(dir,wbpp)?dir.slice(base.length):dir;
   return JSON.stringify([directory,g.exposure,g.width,g.height,g.channels,g.filter||'']);
}
function sqrReviewedMasterVersions(wbpp,group,groups){
   let versions=[],dir=sqrPath(wbpp)+'/master',find=new FileFind,key=sqrMasterGroupKey(wbpp,group),unreadable=0;
   if(File.directoryExists(dir)&&find.begin(dir+'/SQR_masterLight_*.xisf'))try{do{
      if(!find.isFile||find.isSymbolicLink)continue;
      let path=dir+'/'+find.name,stamp=/(\d{4}-\d\d-\d\d)T(\d\d)-(\d\d)-(\d\d)-(\d{3})Z\.xisf$/i.exec(find.name);
      try{
         let m=sqrMetadata(path,true),saved=m.properties[SQR_MASTER_GROUP_PROPERTY];
         if(saved!==undefined){if(saved!==key)continue;}
         else{
            // Older files identify their group through the filter and geometry.
            // Use the saved integration inputs to disambiguate overlapping groups.
            let possible=groups.filter(g=>g.filter===m.filter&&g.width===m.width&&g.height===m.height&&g.channels===m.channels);
            if(possible.length>1&&possible.includes(group)){
               let reader=new FileFormatInstance(new FileFormat('.xisf',true,false));
               try{reader.open(path,'verbosity 0');let history=reader.readImageProperty('PixInsight:ProcessingHistory');
                  possible=history?possible.filter(g=>sqrIntegrationElement(history,g)):[];}finally{reader.close();}
            }
            if(possible.length!==1||possible[0]!==group)continue;
         }
         let when=stamp?stamp[1]+' '+stamp[2]+':'+stamp[3]+':'+stamp[4]+'.'+stamp[5]+' UTC':find.name;
         let counts=[['NCOMBINE',' kept'],['SQRREJ',' excluded'],['SQRTRAIL',' masked']]
            .filter(([id])=>m.keywords[id]!==undefined).map(([id,label])=>m.keywords[id]+label);
         versions.push({path,width:m.width,height:m.height,fingerprint:m.fingerprint,when,label:counts.concat(when).join(' · ')});
      }catch(e){++unreadable;console.warningln('Cannot list reviewed master '+path+': '+e);}
   }while(find.next());}finally{find.end();}
   versions.sort((a,b)=>b.when.localeCompare(a.when));return {versions,unreadable};
}
function sqrWriteReviewedMaster(path,windows,ids,groupKey){
   let f=new FileFormatInstance(new FileFormat('.xisf',false,true));
   try{if(!f.create(path,'verbosity 0',windows.length))throw Error('Cannot create reviewed master light.');
      windows.forEach((w,i)=>{let d=new ImageDescription;d.bitsPerSample=w.bitsPerSample;d.ieeefpSampleFormat=w.isFloatSample;d.imageType=i===0?ImageType.MasterLight:w.imageType;
         if(!f.setOptions(d))throw Error('Unsupported output image options.');
         f.keywords=w.keywords;w.mainView.exportProperties(f);f.setImageId(ids[i]);
         if(i===0&&groupKey)f.writeImageProperty(SQR_MASTER_GROUP_PROPERTY,groupKey);
         let pc=w.mainView.initialProcessing;if(pc.length){let entries='';for(let j=0;j<pc.length;++j)entries+=pc[j].toSource('XPSM 1.0');
            f.writeImageProperty('PixInsight:ProcessingHistory','<ProcessingHistory version="1.0">'+entries+'</ProcessingHistory>');}
         if(!f.writeImage(w.mainView.image))throw Error('Cannot write '+ids[i]+' to the reviewed master.');
      });
      if(!f.close())throw Error('Cannot finish writing the reviewed master.');
   }finally{if(f.isOpen)f.close();}
}
function sqrIntegrateReviewedGroup(options,group,notify,useMasks=true,confirmInputs=null){
   if(!sqrImportedRun(options))throw Error('Import WBPP before creating the reviewed master.');
   let wbpp=options.wbpp;
   let rows=group.rows.filter(sqrRetainedRegistered);if(rows.length<3)throw Error('ImageIntegration needs at least three retained registered lights in this group.');
   let dir=sqrPath(wbpp)+'/master',tag=String(group.filter||group.directoryName||'group').replace(/[^a-zA-Z0-9._-]+/g,'_').slice(0,64);
   let recipe=sqrWBPPIntegrationElement(options,group),scratch='',files=[],owned=[],ids=[];
   try{
      scratch=File.uniqueFileName(File.systemTempDirectory,20,'SQR-integrate-','');TGFileProtection.assertOutsideInstallation(scratch,'Temporary integration folder');File.createDirectory(scratch);
      let settings=scratch+'/settings.xisf';files.push(settings);let p=sqrRestoreIntegration(recipe.element,settings);
      const plan=sqrIntegrationMembership(p.images,rows);
      let entries=plan.enabled;
      if(confirmInputs){
         const choice=confirmInputs(plan);
         if(!choice)return null;
         if(choice.includeExtra===true)entries=entries.concat(plan.extra);
         useMasks=choice.useMasks;
      }
      const count=entries.length;
      if(count<3)throw Error('ImageIntegration needs at least three eligible lights. Selected inputs: '+count+'.');
      let repairs=0;
      for(let {row} of entries){
         let m=row.registered;if(m.width!==group.width||m.height!==group.height||m.channels!==group.channels)throw Error('Incompatible registered light: '+m.path);
         if(sqrFingerprint(m.path)!==m.fingerprint)throw Error('Registered light changed. Refresh the file list: '+m.path);
         if(useMasks){let saved=sqrReadTrailState(wbpp,row);
            if(saved.trailCopy!==(row.trailCopy||'')||JSON.stringify(saved.trailBands)!==JSON.stringify(row.trailBands||[]))throw Error('Trail mask changed. Refresh the file list: '+m.path);
            if(row.trailBands?.length)++repairs;}
      }
      let target=dir+'/SQR_masterLight_'+tag+'_'+count+'x_'+sqrStamp()+'.xisf';
      TGFileProtection.assertOutsideInstallation(target,'Reviewed master light');if(!File.directoryExists(dir))File.createDirectory(dir,true);
      if(File.exists(target))throw Error('Master light already exists: '+target);
      sqrReviewedIntegrationInputs(p,rows,scratch,files,useMasks,entries);
      if(repairs){p.rangeLow=p.rangeClipLow?Math.max(0,p.rangeLow):0;p.rangeClipLow=true;}
      p.generateDrizzleData=false;p.closePreviousImages=false;p.showImages=false;p.noGUIMessages=true;p.generateIntegratedImage=true;
      sqrTick(notify,'Integrating '+count+' retained registered lights');
      if(!p.executeGlobal())throw Error('ImageIntegration failed. See the PixInsight console.');
      let win=ImageWindow.windowById(p.integrationImageId);if(win.isNull)throw Error('ImageIntegration returned no master light.');
      owned.push(win);ids.push('integration');
      for(let [key,id] of [['lowRejectionMapImageId','rejection_low'],['highRejectionMapImageId','rejection_high'],['slopeMapImageId','slope_map'],
         ['lowBiweightRejectionMapImageId','biweight_rejection_low'],['highBiweightRejectionMapImageId','biweight_rejection_high']]){
         if(typeof p[key]==='string'&&p[key]){let w=ImageWindow.windowById(p[key]);if(!w.isNull){owned.push(w);ids.push(id);}}
      }
      if(p.numberOfImages!==count)throw Error('ImageIntegration used '+p.numberOfImages+' of '+count+' selected lights. See the PixInsight console before saving a reviewed master.');
      let keys=win.keywords.filter(k=>!['IMAGETYP','NCOMBINE','SQRREJ','SQRTRAIL','FILTER'].includes(k.name));
      keys.push(new FITSKeyword('IMAGETYP',"'Master Light'",''),new FITSKeyword('NCOMBINE',String(count),'Integrated registered exposures'),
         new FITSKeyword('SQRREJ',String(group.rows.length-count),'Excluded registered exposures'),
         new FITSKeyword('SQRTRAIL',String(repairs),'Inputs with reviewed trail masks'));
      if(group.filter)keys.push(new FITSKeyword('FILTER',"'"+group.filter.replace(/'/g,"''")+"'",''));win.keywords=keys;
      let staged=File.uniqueFileName(dir,20,'.sqr-master-','.xisf');files.push(staged);TGFileProtection.assertOutsideInstallation(staged,'Staged master light');
      sqrWriteReviewedMaster(staged,owned,ids,sqrMasterGroupKey(wbpp,group));
      if(File.exists(target))throw Error('Master light already exists: '+target);
      TGFileProtection.assertOutsideInstallation(target,'Reviewed master light');File.moveFile(target,staged);return target;
   }finally{
      for(let w of owned)w.forceClose();
      for(let f of files.reverse())try{if(File.directoryExists(f))TGFileProtection.removeDirectory(f,'Temporary integration folder');
         else if(File.exists(f))TGFileProtection.removeFile(f,'Temporary integration file');}catch(e){console.warningln(String(e));}
      if(scratch&&File.directoryExists(scratch))try{TGFileProtection.removeDirectory(scratch,'Temporary integration folder');}catch(e){console.warningln(String(e));}
   }
}
/** Validate saved import settings again and recheck output existence on every
 * scan. A configuration alone is never evidence of a successful WBPP run. */
function sqrWBPPScanInputs(o){let data=o.wbppImport;if(!data)return null;
   if(data.schema!==1||!Array.isArray(data.lights)||!data.lights.length||!Array.isArray(data.masters)||!sqrSameRunFolders(data,o))
      throw new Error('The imported WBPP list does not match the selected folders. Import it again or change the folders to scan normally.');
   let wbpp=sqrPath(o.wbpp),rawRoot=sqrPath(o.originals),originals=[],links=new Map,outputPaths=new Map,complete=true;
   for(let light of data.lights){let path=sqrWBPPAbsolute(light.path);
      if(!sqrUnder(path,rawRoot)||sqrUnder(path,wbpp)||!sqrImageFile(path))throw new Error('Invalid imported original-light path: '+path);
      if(o.destination&&sqrUnder(path,sqrPath(o.destination)))throw new Error('An imported light is inside the rejected-originals folder. Choose a separate destination.');
      originals.push(path);let valid=0;
      for(let output of light.registered||[]){output=sqrWBPPAbsolute(output);if(!sqrUnder(output,wbpp+'/registered')||!sqrImageFile(output))continue;
         if(File.exists(output)){let key=sqrKey(output);if(links.has(key)&&sqrKey(links.get(key))!==sqrKey(path))throw new Error('Several WBPP inputs claim the same registered image.');links.set(key,path);outputPaths.set(key,output);++valid;}}
      if(!valid||valid!==(light.registered||[]).length)complete=false;
   }
   // Verify saved links before considering discovered copies. Preserve them
   // even when the directory walker cannot enumerate their parent folder.
   let registered=[...outputPaths.values()];
   if(!complete)registered=registered.concat(sqrWalk(wbpp+'/registered').filter(p=>!outputPaths.has(sqrKey(p))));
   return {originals:[...new Set(originals)],registered:registered.filter(p=>!p.toLowerCase().includes('/ln_reference_frame_data/')),links,complete};
}
// WBPP runs may share an output directory. Read only the newest timestamp;
// the paired SmartReport repeats the console report rather than adding a run.
function sqrWBPPLogReport(wbpp){
   const dir=wbpp+'/logs',find=new FileFind,names=[];
   if(File.directoryExists(dir)&&find.begin(dir+'/*'))try{do{
      if(find.isFile&&!find.isSymbolicLink&&/^\d{14}(?:\.log|_SmartReport\.txt)$/i.test(find.name))names.push(find.name);
   }while(find.next());}finally{find.end();}
   if(!names.length)return null;
   names.sort();const stamp=names[names.length-1].slice(0,14);
   const name=names.find(n=>n.slice(0,14)===stamp&&/\.log$/i.test(n))||names[names.length-1];
   const path=dir+'/'+name;
   try{return {...sqrParseWBPPLog(File.readTextFile(path),/\.txt$/i.test(name)),path};}
   catch(e){return {path,entries:[],note:'Could not read WBPP run log: '+String(e)};}
}
function sqrParseWBPPLog(text,smartReport=false){
   const summary=[],details=[],scales=new Map,calibrated=new Map,byName=new Map,weights=new Map;
   const unique=(map,path,value)=>{let key=sqrKey(path);
      if(!map.has(key))map.set(key,value);
      else if(map.get(key)!==null&&sqrKey(map.get(key))!==sqrKey(value))map.set(key,null);};
   let remaining=0,declared=null,hasFooter=false,hasHeader=false,interrupted=false;
   let psfScale=false,target='',scaleError='',output='';
   for(let raw of text.split(/\r?\n/)){
      let line=raw.replace(/^\[\d{4}-\d\d-\d\d [\d:.]+\]\s*/,'').trim(),m;
      if(/^Weighted Batch Preprocessing\s+\d/i.test(line))hasHeader=true;
      if(/^\* Weighted Batch Preprocessing:\s*\d/.test(line))hasFooter=true;
      if(/^\*+ Warning: The execution was interrupted/i.test(line))interrupted=true;
      if((m=/^\*+ (\d+) frame\(s\) excluded from the execution:/i.exec(line))){remaining=declared=Number(m[1]);continue;}
      if(/^No frames have been excluded from the execution\./i.test(line)){declared=remaining=0;continue;}
      if(remaining){
         m=/^(.+\.(?:xisf|fits?|fts))(?: -- (.+))?$/i.exec(line);
         if(m){summary.push({path:m[1],reason:m[2]||'Excluded by WBPP'});--remaining;continue;}
         remaining=0;
      }
      if((m=/^Calibration frame \d+:\s*(.+?)\s+--->\s+(.+)$/i.exec(line))){
         const outputPath=m[2].replace(/\\/g,'/'),original=m[1].replace(/\\/g,'/');
         unique(calibrated,outputPath,original);unique(byName,sqrFileName(outputPath),outputPath);continue;
      }
      // Attribute an unnamed scale error only when the same target writes its
      // own invalid .xnml. Concurrent output or an LN reference subset is insufficient.
      if((m=/^LN\.scaleEvaluationMethod\s*=\s*(.+);/.exec(line)))psfScale=/PSF/i.test(m[1]);
      if((m=/^Loading target file:\s*(.+)$/i.exec(line))){target=m[1].replace(/\\/g,'/');scaleError=output='';continue;}
      if(!line||/^\*{4,}/.test(line)){target=scaleError=output='';continue;}
      if(target&&/^\*+ Error: Unable to compute a valid scale estimate/i.test(line))
         scaleError=psfScale?'PSF flux scale evaluation failed':'Flux scale evaluation failed';
      if((m=/^Writing output file:\s*(.+)$/i.exec(line))){
         output=m[1].replace(/\\/g,'/');
         if(target&&sqrKey(output)===sqrKey(target.replace(/\.[^./]+$/,'.xnml')))scales.delete(sqrKey(target));
      }
      if(target&&/^(\*+ Warning: )?Writing a local normalization data file tagged as invalid/i.test(line)){
         if(sqrKey(output)===sqrKey(target.replace(/\.[^./]+$/,'.xnml')))scales.set(sqrKey(target),{path:target,reason:scaleError||'Invalid local normalization data'});
         target=scaleError=output='';continue;
      }
      const msg=line.replace(/^\*+\s*(?:Warning|Error):\s*/i,'');
      if((m=/^(Invalid local normalization data generated for file|Local normalization (?:generation )?failed for file|Registration failed for image|PSF flux evaluation failed(?: for(?: file| image)?)?|(?:Unable|Failed) to (?:evaluate|compute) PSF flux(?: for (?:file|image))?):\s*(.+)$/i.exec(msg))&&sqrImageFile(m[2]))
         details.push({path:m[2],reason:m[1].replace(/ (?:generated )?for(?: file| image)?$/i,''),quality:true});
      else if((m=/^frame rejected \[.*?\]:\s*(.+)$/i.exec(msg)))details.push({path:m[1],reason:'Weight below the WBPP minimum',quality:true});
      else if((m=/^\[Frames rejection\] (.+\.(?:xisf|fits?|fts)) - .*?\|\s*(rejected|accepted)$/i.exec(msg)))
         weights.set(sqrKey(m[1]),{path:m[1],rejected:m[2].toLowerCase()==='rejected'});
   }
   const complete=smartReport?/\bExecution summary: \d+ operation\(s\) failed, 0 canceled or not executed, \d+ frame\(s\) excluded;[^\n]*\s*$/i.test(text):hasHeader&&hasFooter&&!interrupted;
   const authoritative=declared!==null;
   if(!authoritative){
      for(const {path,rejected} of weights.values())if(rejected)details.push({path,reason:'Weight below the WBPP minimum',quality:true});
      for(const {path} of scales.values())details.push({path,reason:'Invalid local normalization data',quality:true});
   }
   const entries=authoritative?summary:details;
   for(const e of entries){
      e.path=e.path.replace(/\\/g,'/');
      if(!authoritative){const output=e.path.includes('/')?e.path:byName.get(sqrKey(e.path));if(output)e.path=calibrated.get(sqrKey(output))||e.path;}
      if(authoritative){
         const cause=e.reason.slice(e.reason.indexOf(':')+1).trim();
         e.quality=/^(?:invalid local normalization data|local normalization failed|registration failed|not aligned with the reference frame|measurement failed|no valid weight available|rejected by frame selection)$/i.test(cause)||
            /^(?:weight below the minimum|abnormal weight|(?:failed|unable) to (?:evaluate|compute) PSF flux|PSF flux evaluation failed|unable to compute a valid scale estimate)\b/i.test(cause)||
            /^PSF flux evaluation:\s*(?:failed|no (?:valid )?(?:stars|PSF fits))\b/i.test(e.reason);
      }
   }
   const usable=complete&&(!authoritative||summary.length===declared);
   return {entries,scales,usable,note:usable?'':'Incomplete WBPP run or exclusion list. Findings are informational.'};
}
// Original-only failures stay outside measurement, ranking, Blink and trial stacks.
// Confirmed moves also handle verified exclusions without a registered counterpart.
function sqrDecisionRows(session){return (session?.groups||[]).flatMap(g=>g.rows).concat(session?.logOnly||[]);}
function sqrRejectTip(row){
   const action=row.isMaster?'The master cannot be rejected.':row.moved?'Original moved to: '+row.movedTo+'\nSelect Undo moved originals to restore it.':
      'Click to '+(row.reject?'keep':'reject')+' this original, or select the row and press Space.';
   return action+(row.wbppReason?'\nWBPP run log: '+row.wbppReason:'');
}
function sqrAttachWBPPLog(session,raws,moves,previous){
   const report=session.wbppLog=sqrWBPPLogReport(sqrPath(session.options.wbpp));
   const rows=session.groups.flatMap(g=>g.rows),byPath=new Map,origins=new Map;
   const ambiguous=rows.filter(r=>!r.original),byFinding=new Map,unmatched=new Map;
   // Retain the real paths on records. A normalized key claimed by two
   // different records stays ambiguous and must never auto-reject a light.
   const index=(map,path,record)=>{const key=sqrKey(path);map.set(key,map.has(key)&&map.get(key)!==record?null:record);};
   for(const m of raws)index(origins,m.path,m);
   for(const row of rows)for(const p of [row.original?.path,row.registered.path].filter(Boolean))index(byPath,p,row);
   session.logOnly=[];
   // Also recover log-only moves after a refresh, for Undo.
   for(const move of moves.values())if(move&&!byPath.has(sqrKey(move.original.path))&&move.logOnly){
      const row={original:move.original,match:'Verified',reject:true,moved:true,movedTo:move.target,moveJournal:move.journal};
      session.logOnly.push(row);index(byPath,row.original.path,row);
   }
   if(!report)return;
   for(const e of report.entries){
      const key=sqrKey(e.path),meta=origins.get(key);
      let row=origins.has(key)&&!meta?null:byPath.get(key);
      if(row===undefined&&meta){
         if(!ambiguous.some(r=>sqrCompatible(r.registered,meta)&&(r.registered.date&&r.registered.date===meta.date||sqrSourceStem(r.registered.path)===sqrBase(meta.path).toLowerCase()))){
            row={original:meta,match:'Verified',reject:false,moved:false};session.logOnly.push(row);byPath.set(key,row);
         }
      }
      if(!row){const reasonKey=key+'\n'+e.reason;if(!unmatched.has(reasonKey))unmatched.set(reasonKey,e);continue;}
      let finding=byFinding.get(row);
      if(!finding){finding={row,path:row.original?.path||row.registered.path,reasons:new Set,eligible:false};byFinding.set(row,finding);}
      const reason=row.registered&&report.scales?.get(sqrKey(row.registered.path))?.reason;
      finding.reasons.add(reason&&reason!=='Invalid local normalization data'&&/normalization/i.test(e.reason)?e.reason+' ('+reason+')':e.reason);
      if(report.usable&&e.quality&&row.original&&row.match==='Verified')finding.eligible=true;
   }
   const prior=new Map;
   if(previous?.wbppLog?.path&&sqrKey(previous.wbppLog.path)===sqrKey(report.path)&&sqrSameRunFolders(previous.options,session.options))
      for(const f of previous.wbppLog.findings||[])if(f.row?.original)prior.set(sqrKey(f.path),f);
   report.findings=[];
   for(const f of byFinding.values()){
      const row=f.row;f.reason=[...f.reasons].join(' · ');delete f.reasons;row.wbppReason=f.reason;
      const old=prior.get(sqrKey(f.path));
      if(f.eligible&&!row.moved)row.reject=old?.eligible&&old.reason===f.reason&&old.row.original.fingerprint===row.original.fingerprint?old.row.reject:true;
      report.findings.push(f);
   }
   for(const e of unmatched.values())report.findings.push({path:e.path,reason:e.reason,eligible:false,row:null});
   delete report.scales;delete report.entries;
}
function sqrScan(o,notify,previous=null){
   let wbpp=sqrPath(o.wbpp),rawRoot=sqrPath(o.originals);
   if(!File.directoryExists(wbpp+'/registered'))throw new Error('Select a WBPP output folder containing registered/.');
   if(!File.directoryExists(rawRoot))throw new Error('Select the folder containing original lights.');
   if(sqrUnder(rawRoot,wbpp))throw new Error('The originals folder must be outside the WBPP output folder.');
   let imported=sqrWBPPScanInputs(o);
   let registered=imported?imported.registered:sqrWalk(wbpp+'/registered').filter(p=>!p.toLowerCase().includes('/ln_reference_frame_data/'));
   let discoverMasters=()=>File.directoryExists(wbpp+'/master')?sqrWalk(wbpp+'/master').filter(p=>/^masterLight_/i.test(sqrBase(p))):[];
   let savedMasters=imported?o.wbppImport.masters.filter(p=>sqrUnder(p,wbpp+'/master')&&File.exists(p)):[];
   let masterFiles=imported?null:discoverMasters();
   let rawFiles=imported?imported.originals:sqrWalk(rawRoot,[wbpp,o.destination? sqrPath(o.destination):''],true).filter(p=>!/^master/i.test(sqrBase(p)));
   let raws=[],warnings=[],missingOriginals=[];
   const hasTrailMasks=File.directoryExists(wbpp+'/SQR-trail-masks');
   const moved=sqrScanMovedOriginals(o,registered,imported,warnings,notify);
   for(let i=0;i<rawFiles.length;++i){
      sqrTick(notify,'Reading original headers '+(i+1)+' / '+rawFiles.length);
      // A saved WBPP list can still name an original already moved by this
      // review. Keep its registered row available for journal-based Undo.
      if(imported&&!File.exists(rawFiles[i])){missingOriginals.push(rawFiles[i]);continue;}
      try{let m=sqrMetadata(rawFiles[i]);if(sqrIsLight(m))raws.push(m);}catch(e){warnings.push(rawFiles[i]+': '+String(e));}
   }
   let groups=[],byGroup={},originalIndex=sqrIndexOriginals(raws),originalByPath=new Map(raws.map(r=>[sqrKey(r.path),r])),verifiedLinks=new Set,fallbackNames=null,skipped=0;
   for(let i=0;i<registered.length;++i){
      sqrTick(notify,'Matching registered lights '+(i+1)+' / '+registered.length);
      let linked=imported?.links.get(sqrKey(registered[i]));
      let m=sqrMetadata(registered[i]);if(!sqrIsLight(m))continue;
      let move=moved.get(sqrKey(m.path));
      if(move&&!sqrCompatible(m,move.original))move=null;
      let found=move?{raw:move.original,state:'Verified'}:linked?sqrFindOriginal(m,[originalByPath.get(sqrKey(linked))].filter(Boolean)):sqrFindOriginal(m,raws,originalIndex);
      if(linked&&found.raw)verifiedLinks.add(sqrKey(found.raw.path));
      // Renamed or channel-separated outputs can still have a unique header
      // match. Fallback must not add stale copies of an already verified link.
      // Keep the full original index for matching so exclusion cannot turn an
      // ambiguous header match into a falsely unique association.
      if(imported&&!linked&&!move){
         fallbackNames??=new Set(rawFiles.filter(p=>!verifiedLinks.has(sqrKey(p))).map(p=>sqrBase(p).toLowerCase()));
         if((found.raw&&verifiedLinks.has(sqrKey(found.raw.path)))||(!found.raw&&!fallbackNames.has(sqrSourceStem(registered[i])))){++skipped;continue;}
      }
      let dir=sqrDir(m.path),directoryName=dir.split('/').pop(),key=dir+'|'+m.exposure+'|'+m.width+'x'+m.height+'|'+m.channels;
      let g=byGroup[key];if(!g){g={id:key,directory:dir,directoryName:directoryName,
         label:directoryName,width:m.width,height:m.height,channels:m.channels,exposure:m.exposure,
         filter:m.filter||sqrFilterFromName(directoryName),
         master:'',rows:[],roi:null,regions:null};groups.push(g);byGroup[key]=g;}
      const row={registered:m,original:found.raw,match:found.state,reject:!!move,moved:!!move,candidate:false,metrics:{}};
      if(move){row.movedTo=move.target;row.moveJournal=move.journal;}
      try{if(hasTrailMasks)Object.assign(row,sqrReadTrailState(wbpp,row));}catch(e){row.trailError=String(e);warnings.push(row.trailError);}
      g.rows.push(row);
   }
   if(!groups.length)throw new Error('No registered light images found. Supported formats: XISF and FITS.');
   for(let g of groups){g.master=sqrMasterFor(g,savedMasters);
      // Each group gets its own saved-path preference. Discover at most once,
      // without replacing the preferred list for groups processed later.
      if(!g.master){masterFiles??=discoverMasters();g.master=sqrMasterFor(g,masterFiles);}
      sqrMasterRow(g);
      sqrMasterScale(g);
      if(!g.master)warnings.push('No unique integrated master for filter '+(g.filter||'(unknown)')+' in master/: '+g.directoryName);}
   // A source exposure must not be moved once for several processed products.
   let occurrences={};for(let g of groups)for(let r of g.rows)if(r.original){let k=sqrKey(r.original.path);(occurrences[k]??=[]).push(r);}
   for(let k of Object.keys(occurrences))if(occurrences[k].length>1)for(let r of occurrences[k])if(!r.moved){r.match='Original used more than once';r.original=null;}
   let session={schema:1,version:SQR_VERSION,created:new Date().toISOString(),options:{...o},groups:groups,warnings:warnings};
   sqrTick(notify,'Checking WBPP run log');
   sqrAttachWBPPLog(session,raws,moved,previous);
   if(imported){let matched=new Set(sqrDecisionRows(session).filter(r=>r.original).map(r=>sqrKey(r.original.path)));
      for(let path of missingOriginals)if(!matched.has(sqrKey(path)))warnings.push('Imported original is missing: '+path);
      let missing=imported.originals.filter(p=>!matched.has(sqrKey(p)));
      if(missing.length)warnings.push(missing.length+' imported light(s) have no verified registered match: '+missing.join('\n'));
      if(skipped)warnings.push(skipped+' registered file(s) outside the imported selection were excluded.');}
   sqrRunSite(session);
   if(imported)session.importSummary='WBPP '+o.wbppImport.version+' · '+imported.originals.length+' imported lights · '+o.wbppImport.disabled+' disabled lights omitted · '+(imported.complete?'saved registered paths used':'registered outputs located in WBPP folder');
   let setup=sqrSessionPixelScale(session);
   if(setup.cameras.length>1)throw new Error('The reviewed images must come from one camera. Found: '+setup.cameras.join(', ')+'. Select input folders for a single camera.');
   if(setup.missingCamera.length)warnings.push('Camera identity is missing in '+setup.missingCamera.length+' reviewed image header(s); the single-camera condition could not be fully verified.');
   return session;
}
/** Load owned floating-point image data. The caller must free the returned
 * Image; failed reads free it here, and the file reader closes in all cases. */
function sqrReadImage(path,allowMultiple=false){
   let f=new FileFormatInstance(new FileFormat(File.extractExtension(path),true,false)),im=new Image;
   try{let d=f.open(path,'verbosity 0');if(!d||!d.length||(!allowMultiple&&d.length!==1)||!f.readImage(im))throw new Error('Cannot read image: '+path);return im;}
   catch(e){im.free();throw e;}finally{f.close();}
}
/** Choose a preparation budget from this computer's CURRENT free RAM and the
 * largest image. Honor existing CPU/file-concurrency preferences, changing none.
 * Reserve at most one eighth of available RAM (up to 8 GiB), estimating source,
 * crop and scratch pixels at 16 bytes per nominal sample. Unknown geometry or
 * memory status uses the serial path. This is a conservative working-set
 * estimate, not a limit on memory allocated inside file-format modules. */
function sqrPreparationThreads(items){
   if(items.length<2||typeof Thread==='undefined')return 1;
   try{
      if(!Settings.readGlobal('Process/EnableParallelProcessing',DataType.Boolean)||
         !Settings.readGlobal('Process/EnableParallelModuleProcessing',DataType.Boolean))return 1;
      let pixels=Math.max(...items.map(item=>item.width*item.height*item.channels));
      if(!(pixels>0)||!Number.isFinite(pixels))return 1;
      let memory=typeof System!=='undefined'?System.physicalMemoryStatus():null;
      if(!memory||!(memory.availableBytes>0)||!Number.isFinite(memory.availableBytes))return 1;
      let budget=Math.min(8*1024*1024*1024,memory.availableBytes/8);
      let count=Math.max(1,Math.min(8,items.length,Thread.numberOfProcessors,
         Math.max(1,Settings.readGlobal('Process/MaxFileReadThreads',DataType.Int32)),
         Math.max(1,Settings.readGlobal('Process/MaxFileWriteThreads',DataType.Int32)),
         Math.floor(budget/(16*pixels))));
      return Number.isFinite(count)?Math.floor(count):1;
   }catch(e){return 1;}
}
// Workers own their Images and file handles. Only ordinary cloned data crosses
// the thread boundary; no GUI, row objects or Image pointers are shared.
function sqrPreparationAbort(){
   // Console abort state belongs to the root script; workers use their own flag.
   let current=typeof Thread!=='undefined'?Thread.current:null;
   if(current?current.isAborted:console.abortRequested)throw new Error('Operation aborted.');
}
/** Bounded queue with deterministic result order. Pump events on the main
 * thread, propagate worker errors, and ALWAYS join every started worker before
 * returning or removing temporary files, including on abort or startup failure. */
function sqrMapPreparation(items,worker,helpers,notify,label){
   let count=sqrPreparationThreads(items),results=new Array(items.length);
   if(count===1){for(let i=0;i<items.length;++i){sqrTick(notify,label+' '+(i+1)+' / '+items.length);results[i]=worker(items[i]);}return results;}
   let source='(function(item){\n'+helpers.map(fn=>fn.toString()).join('\n')+'\nreturn ('+worker.toString()+')(item);\n})';
   let active=[],next=0,done=0;
   try{
      while(next<items.length||active.length){
         sqrTick(notify,label+' '+done+' / '+items.length);
         while(active.length<count&&next<items.length){let index=next++,thread=new Thread(source,items[index],{pooled:true});
            thread.start();active.push({index,thread});}
         // One bounded wait avoids busy polling. Check every worker afterwards,
         // so a slow first file never prevents finished slots from being reused.
         active[0].thread.wait(25);
         // In the installed runtime wait(0) waits indefinitely. Use a positive
         // timeout here as well, keeping cancellation and slot reuse responsive.
         for(let i=active.length-1;i>=0;--i){let job=active[i];if(!job.thread.wait(1))continue;
            if(job.thread.error)throw new Error(job.thread.error);
            results[job.index]=job.thread.result;active.splice(i,1);++done;}
      }
      sqrTick(notify,label+' '+done+' / '+items.length);return results;
   }finally{
      for(let job of active)job.thread.abort();
      for(let job of active)while(!job.thread.wait(25))CoreApplication.processEvents();
   }
}
function sqrPrepareBounds(item){
   let im=null;
   try{sqrPreparationAbort();im=sqrReadImage(item.path);let bounds=sqrBounds(im,item.margin);sqrPreparationAbort();return {bounds};}
   catch(e){sqrPreparationAbort();return {error:String(e)};}
   finally{if(im)im.free();}
}
/** Estimate usable bounds as [left, top, right, bottom], right/bottom exclusive.
 * Sample edges for zero padding and shrink inward; reject very small fields.
 * sqrAnalyze intersects these bounds so every frame uses identical coordinates. */
function sqrBounds(im,margin){
   let w=im.width,h=im.height,step=Math.max(4,Math.round(Math.min(w,h)/500));
   let r=[Math.ceil(w*margin/100),Math.ceil(h*margin/100),Math.floor(w*(1-margin/100)),Math.floor(h*(1-margin/100))];
   let valid=(x,y)=>{for(let c=0;c<im.numberOfNominalChannels;++c)if(Math.abs(im.sample(x,y,c))>1e-12)return true;return false;};
   // Exact-zero padding is tested along each edge; the margin guards sampling gaps.
   let edge=(side)=>{for(let j=0;j<=128;++j){let x=Math.round(r[0]+(r[2]-r[0]-1)*j/128),y=Math.round(r[1]+(r[3]-r[1]-1)*j/128);
      if(!valid(side===0?r[0]:side===2?r[2]-1:x,side===1?r[1]:side===3?r[3]-1:y))return false;}return true;};
   for(let pass=0;pass<1000;++pass){let changed=false;
      sqrPreparationAbort();
      for(let side=0;side<4;++side)if(!edge(side)){r[side]+=(side<2?step:-step);changed=true;}
      if(r[2]-r[0]<w*.5||r[3]-r[1]<h*.5)throw new Error('Less than half the field is free of sampled registration padding. Review this frame manually.');
      if(!changed)return r;
   }throw new Error('Could not determine usable field.');
}
// Derive the field, center and four corner rectangles in SQR_REGIONS order.
// Corner/center dimensions are percentages of the common usable field.
function sqrRegions(roi,patch){let [x0,y0,x1,y1]=roi,w=x1-x0,h=y1-y0,pw=Math.max(1,Math.round(w*patch/100)),ph=Math.max(1,Math.round(h*patch/100)),cx=Math.round((x0+x1-pw)/2),cy=Math.round((y0+y1-ph)/2);
   return [roi,[cx,cy,cx+pw,cy+ph],[x0,y0,x0+pw,y0+ph],[x1-pw,y0,x1,y0+ph],[x0,y1-ph,x0+pw,y1],[x1-pw,y1-ph,x1,y1]];}
// Field scoring requires valid signal and PSF support. Regional shape checks
// can remain useful when a small crop has no independent signal/noise estimate.
function sqrMetricValid(m,minStars,requireSignal){return Number.isFinite(m.fwhm)&&m.fwhm>0&&m.stars>=minStars&&(!requireSignal||(Number.isFinite(m.signal)&&m.signal>0&&m.psfCount>=minStars));}
/** Decode native ImageAnalysis measurement columns into the existing metrics.
 * Use process-provided column constants; the schema differs from older engines.
 * FWHMpx preserves pixel units regardless of image scale metadata.
 * Missing or insufficient results remain explicit invalid metrics for REVIEW. */
function sqrMeasurement(row,minStars,requireSignal=true){
   const C=ImageAnalysis;
   if(!row||row.length<=Math.max(C.measurements_measurementFWHMpx,C.measurements_measurementEccentricity,
      C.measurements_measurementPSFSignalWeight,C.measurements_measurementStars,C.measurements_measurementPSFCount))
      return {valid:false,error:'No measurement returned'};
   let m={fwhm:row[C.measurements_measurementFWHMpx],eccentricity:row[C.measurements_measurementEccentricity],
      signal:row[C.measurements_measurementPSFSignalWeight],stars:row[C.measurements_measurementStars],
      psfCount:row[C.measurements_measurementPSFCount]};
   m.valid=sqrMetricValid(m,minStars,requireSignal);
   if(!m.valid)m.error='Insufficient valid PSF measurements';return m;
}
/** Undefined native extinction is stored as zero too: bit 0x20 distinguishes
 * a valid zero (the reference) from an unavailable measurement. The exposure
 * property on our clean field crops makes native comparisons use flux/second. */
function sqrNativeExtinction(row){
   const C=ImageAnalysis;
   let cloud=sqrNativeCloudExtinction(row);
   if(!row)return {cloud,error:'ImageAnalysis returned no relative extinction measurement.'};
   let value=row[C.measurements_measurementRelativeExtinction],flags=row[C.measurements_measurementFlags],
      exposure=row[C.measurements_measurementExposure];
   if(!Number.isFinite(exposure)||exposure<=0)return {cloud,error:'Exposure time is unavailable.'};
   if(!(flags&0x20)||!Number.isFinite(value))return {cloud,missingStellarFlux:true,error:'ImageAnalysis could not measure relative extinction for this frame in the group’s common stellar brightness range. Too few usable stars or too many saturated stars can cause this.'};
   return {value,exposure,cloud,error:''};
}
function sqrClearTransparency(row){delete row.nativeExtinction;row.relativeTransparency=null;row.transparencyInfo=null;
   row.skyQuality=null;row.skyQualityInfo=null;delete row.skyQualityModes;row.cloudExtinction=null;row.cloudExtinctionInfo=null;}
/** Cloud extinction is a signed magnitude residual. A zero is valid only when
 * native measurementFlags bit 0x40 is set. Keep the native estimator unchanged;
 * do not clamp negative residuals or substitute a manually chosen altitude. */
function sqrNativeCloudExtinction(row){
   const C=ImageAnalysis;
   let value=row?.[C.measurements_measurementCloudExtinction],flags=row?.[C.measurements_measurementFlags],
      airmass=row?.[C.measurements_measurementAirmass],altitude=row?.[C.measurements_measurementAltitude];
   let known=Number.isFinite(airmass)&&airmass>0;
   return {value:(flags&0x40)&&Number.isFinite(value)?value:null,airmass:known?airmass:null,
      altitude:known&&Number.isFinite(altitude)?altitude:null};
}
function sqrFinalizeCloudExtinction(group){
   let usable=group.rows.filter(r=>!r.nativeExtinction?.error&&Number.isFinite(r.nativeExtinction?.value)&&r.nativeExtinction?.cloud?.airmass>0).length;
   for(let r of sqrGroupRows(group)){
      let m=r.nativeExtinction,c=m?.cloud;r.cloudExtinction=null;
      let error=r.isMaster?'Cloud extinction describes individual exposures and is not applicable to an integrated master.':
         !m?'Measure the subframes to estimate cloud extinction.':
         !(sqrExposure(r)>0)?'A valid exposure time is required for cloud extinction.':
         !(c?.airmass>0)?'Airmass is unavailable. Check the observation time and target coordinates. If the headers lack a site, open the gear at the bottom (Review configuration), choose Edit sites, save the location, then click Measure.':
         m.error|| (usable<5?'At least five subframes with usable relative extinction and known airmass are required; this group has '+usable+'.':
            'ImageAnalysis could not determine cloud extinction for this frame.');
      r.cloudExtinctionInfo={airmass:c?.airmass??null,altitude:c?.altitude??null,usableFrames:usable,error};
      if(!r.isMaster&&Number.isFinite(c?.value)){r.cloudExtinction=c.value;r.cloudExtinctionInfo.error='';}
   }
   let available=group.rows.filter(r=>Number.isFinite(r.cloudExtinction)).length;
   group.cloudExtinctionSummary=available+' of '+group.rows.length+' subframes have CloudExtinction. '+usable+
      ' have usable relative extinction and known airmass; at least five are required. The atmospheric baseline is fitted separately for this filter group.';
}
function sqrCloudExtinctionDescription(row){
   let info=row.cloudExtinctionInfo;
   return Number.isFinite(row.cloudExtinction)&&!row.isMaster?'Cloud extinction: '+sqrFmt(row.cloudExtinction,4)+' mag.\nAirmass: '+sqrFmt(info?.airmass,4)+
      '; altitude: '+sqrFmt(info?.altitude,2)+'°.\nNative ImageAnalysis residual after removing the atmospheric baseline.':
      info?.error||(row.isMaster?'Not applicable to an integrated master.':'Measure the subframes to estimate cloud extinction.');
}
// Stable tie-breaking makes reference selection independent of Review order.
function sqrTransparencyReference(group){return group.rows.filter(r=>!r.nativeExtinction?.error&&
   Number.isFinite(r.nativeExtinction?.value)&&r.nativeExtinction?.exposure>0)
   .slice().sort((a,b)=>a.nativeExtinction.value-b.nativeExtinction.value||a.registered.path.localeCompare(b.registered.path))[0];}
/** Keep a ratio internally: the existing percentage formatter multiplies by
 * 100, and all scoring rules already consume ratios. Masters use a separate
 * native comparison with this same light reference and cannot affect its set. */
function sqrFinalizeTransparency(group){
   let reference=sqrTransparencyReference(group),path=reference?.registered.path;
   group.transparencySummary=reference?'Reference (100%): '+sqrFileName(path)+'. Most transparent measured subframe according to ImageAnalysis RelativeExtinction, independently of Score. Transparency (%) = 100 × 10^(−0.4 × extinction in magnitudes).':'No reliable subframe transparency reference is available.';
   for(let row of sqrGroupRows(group)){
      let m=row.nativeExtinction;row.relativeTransparency=null;
      row.transparencyInfo={error:m?.error||'No relative extinction measurement is available.'};
      if(!m||m.error||!Number.isFinite(m.value)||!(m.exposure>0))continue;
      if(!reference){row.transparencyInfo={error:group.transparencySummary};continue;}
      if(row.isMaster&&m.reference!==path){row.transparencyInfo={error:'The master has not been measured against the current subframe reference.'};continue;}
      let extinction=row.isMaster?m.value:m.value-reference.nativeExtinction.value,value=Math.pow(10,-.4*extinction);
      if(Number.isFinite(value)&&value>0){row.relativeTransparency=value;
         row.transparencyInfo={reference:path,extinction,exposure:m.exposure,sensitivity:group.extinctionSensitivity,error:''};}
      else row.transparencyInfo={error:'Relative extinction could not be converted to a finite positive transparency.'};
   }
   sqrFinalizeCloudExtinction(group);
}
function sqrMasterQualityNote(row){return row.isMaster?'\nMaster comparison: recorded frame exposure '+sqrFmt(sqrExposure(row),2)+' s, not total integration time. Integration normalization affects these values; they do not measure the session atmosphere or the SNR gain from stacking.':'';}
function sqrTransparencyDescription(row){
   let info=row.transparencyInfo;
   return Number.isFinite(row.relativeTransparency)?'Transparency: '+sqrPercent(row.relativeTransparency)+'\nReference (100%): '+sqrFileName(info.reference)+'\nImageAnalysis relative extinction: '+sqrFmt(info.extinction,4)+' mag.'+
      (info.sensitivity?'\nStellar detection sensitivity for this group: '+info.sensitivity+' (automatic retry).':'')+'\nExposure-corrected stellar flux; RGB uses HSI intensity.'+sqrMasterQualityNote(row):info?.error||'Measure the subframes to estimate relative transparency.';
}
/** Arithmetic pixel means are independent of star detection. Read all nominal
 * channels (green for RGB, no alpha), with no stretch, clipping or star rejection.
 * Cache during existing image reads; reranking and blinking never read pixels.
 * Whole-image really means the entire registered image, including its borders. */
function sqrBackgroundComplete(row,withCorners){
   let b=row.backgroundMeans;
   return !!b&&(row.registered?.channels!==3||b.channel===1)&&Object.prototype.hasOwnProperty.call(b,'whole')&&(!withCorners||[1,2,3,4,5].every(i=>Object.prototype.hasOwnProperty.call(b.previews||{},i)));
}
function sqrMeasureBackground(row,image,regions,withCorners){
   let channel=image.numberOfNominalChannels===3?1:0;
   if(row.backgroundMeans&&image.numberOfNominalChannels===3&&row.backgroundMeans.channel!==1)delete row.backgroundMeans;
   let b=row.backgroundMeans??={previews:{},channel};b.previews??={};
   const mean=rect=>{let value=image.mean(new Rect(...rect),channel,channel);return Number.isFinite(value)?value:null;};
   if(!Object.prototype.hasOwnProperty.call(b,'whole'))b.whole=mean([0,0,image.width,image.height]);
   if(withCorners)for(let i=1;i<=5;++i)if(!Object.prototype.hasOwnProperty.call(b.previews,i))b.previews[i]=mean(regions[i]);
}
// A partial set cannot establish the minimum of all five previews. Missing
// background values stay unavailable even if the corresponding PSF fit succeeds.
function sqrSkyBackground(row,withCorners){
   let b=row.backgroundMeans;if(!b||(row.registered?.channels===3&&b.channel!==1))return null;
   if(!withCorners)return Number.isFinite(b.whole)?b.whole:null;
   let means=[1,2,3,4,5].map(i=>b.previews?.[i]);
   return means.every(Number.isFinite)?Math.min(...means):null;
}
function sqrBackgroundDescription(row,withCorners){
   let b=row.backgroundMeans;
   return (withCorners?'Minimum of the center and four corner preview means.':'Mean of the whole registered image, including registration borders.')+
      ' In image units; RGB uses the green channel. Lower is better.'+
      (withCorners?'\nPreview means: '+[1,2,3,4,5].map(i=>SQR_REGIONS[i]+' '+sqrFmt(b?.previews?.[i],6)).join(' · '):'');
}
/** Combine existing brightness and transmission measurements only; no pixel
 * access and no new noise estimate. For a faint background-limited source,
 * relative SNR at equal exposure is proportional to transmission/sqrt(sky rate).
 * The reported pixel mean is a sky-brightness proxy, not a noise measurement.
 * Use the same transparency reference rather than choosing a score-dependent
 * optimum. Missing/nonpositive backgrounds are not clamped to an artificial
 * floor, which could incorrectly reward subtracted or invalid images. */
function sqrSkyQualityInputs(row,withCorners){
   let transparency=row.relativeTransparency;
   if(!Number.isFinite(transparency)||transparency<=0)return {error:'Transparency is unavailable.'};
   let brightness=sqrSkyBackground(row,withCorners),exposure=sqrExposure(row);
   if(brightness===null)return {error:'Sky brightness is unavailable'+(withCorners?'; all five preview means are required.':'.')};
   if(exposure===null)return {error:'Exposure time is unavailable.'};
   let pedestal;
   try{pedestal=sqrSkyPedestal(row.registered);}catch(e){return {error:String(e)};}
   let rate=(brightness-pedestal)/exposure;
   if(!Number.isFinite(rate)||rate<=0)return {error:'Sky brightness must be positive after removing the recorded pedestal.'};
   return {transparency,brightness,pedestal,exposure,rate,error:''};
}
function sqrUpdateSkyQuality(group,withCorners){
   let all=sqrGroupRows(group);
   let referenceKeys=new Set(group.rows.filter(r=>Number.isFinite(r.relativeTransparency)&&r.transparencyInfo?.reference).map(r=>sqrKey(r.transparencyInfo.reference)));
   let reference=referenceKeys.size===1?group.rows.find(r=>sqrKey(r.registered.path)===[...referenceKeys][0]):null;
   // R1 and R2 need independent background bases even when the other mode is
   // displayed. Compute both cheaply from cached means; never remeasure pixels.
   for(let row of all)row.skyQualityModes={};
   for(let corners of [false,true]){
      let inputs=new Map(all.map(r=>[r,sqrSkyQualityInputs(r,corners)])),ref=reference?inputs.get(reference):null;
      let reason=!ref?'A unique transparency reference is unavailable.':ref.error?'The transparency reference has no usable Sky brightness: '+ref.error:'';
      for(let row of all){let values=inputs.get(row),result={value:null,info:{error:values.error||reason}};
         if(!result.info.error){
            // Evaluate in log space to avoid overflowing intermediate ratios.
            let value=Math.exp(Math.log(values.transparency)-Math.log(ref.transparency)+.5*(Math.log(ref.rate)-Math.log(values.rate)));
            result=Number.isFinite(value)&&value>0?{value,info:{...values,reference:reference.registered.path,referenceTransparency:ref.transparency,referenceRate:ref.rate,withCorners:corners,error:''}}:
               {value:null,info:{error:'The combined quality ratio is outside the supported numeric range.'}};
         }
         row.skyQualityModes[corners?'corners':'field']=result;
         if(corners===!!withCorners){row.skyQuality=result.value;row.skyQualityInfo=result.info;}
      }
      if(corners===!!withCorners)group.skyQualitySummary='Background basis: '+(corners?'minimum of the five preview means.':'whole-image mean.')+' '+(reason||
         'Reference (100%): '+sqrFileName(reference.registered.path)+'. Uses the current Sky brightness KPI; changing corner scoring updates this combined indicator. Values above 100% indicate a better transparency/background balance than the reference.');
   }
}
function sqrSkyQualityDescription(row){
   let info=row.skyQualityInfo;
   return Number.isFinite(row.skyQuality)&&info?'Sky quality: '+sqrPercent(row.skyQuality)+'\nQ = (T / Tref) × sqrt(Bref / B).\nReference (100%): '+sqrFileName(info.reference)+
      '\nTransparency: '+sqrPercent(info.transparency)+'; reference: '+sqrPercent(info.referenceTransparency)+'.\nSky brightness rate: '+sqrPlotNumber(info.rate)+'; reference: '+sqrPlotNumber(info.referenceRate)+' image units/s.'+
      '\nBackground basis: '+(info.withCorners?'minimum of five preview means':'whole-image mean')+'.'+sqrMasterQualityNote(row):info?.error||'Measure Sky brightness and Transparency to calculate Sky quality.';
}
function sqrActiveRegions(o){return o.measureCorners?[0,1,2,3,4,5]:[0];}
// An attempted but invalid measurement is still a result. Do not repeatedly
// launch the same unsuccessful measurement when clicking Measure corners again.
function sqrMissingCornerMeasurements(session){return !session||session.groups.some(g=>sqrGroupRows(g).some(r=>[1,2,3,4,5].some(i=>!r.metrics[i])||!sqrBackgroundComplete(r,true)));}
// Corner inclusion is session data, never a saved preference. Partial results
// count too, so unavailable regions remain visible for review after an abort.
function sqrHasCornerMeasurements(session){return !!session?.groups.some(g=>sqrGroupRows(g).some(r=>[1,2,3,4,5].some(i=>!!r.metrics[i]||Object.prototype.hasOwnProperty.call(r.backgroundMeans?.previews||{},i))));}
/** Bound regional concurrency by this machine's permitted CPU count and current
 * free memory. Extra native workers hide scheduling waits for small crops; they
 * do not increase the application's CPU or file-I/O limits. Reserve at most a
 * half of free RAM / 64 GiB, estimating 64 bytes per sample plus 16 MiB per
 * job for native image/statistics scratch space. Limit the queue to eight workers
 * per permitted processor, at most 512, to avoid excessive thread overhead.
 * These are conservative estimates, not a hard memory limit. Unknown capacity
 * keeps the original native defaults. Respect PixInsight's file-I/O limits.
 * Full-field batches retain their original scheduling and measurement settings. */
function sqrMeasurementPlan(jobs){
   let unchanged={batchSize:Math.max(1,jobs.length),overload:1,fileThreads:true};
   if(jobs.length<2||jobs.some(j=>j.region===0))return unchanged;
   try{
      if(!Settings.readGlobal('Process/EnableParallelProcessing',DataType.Boolean)||
         !Settings.readGlobal('Process/EnableParallelModuleProcessing',DataType.Boolean))
         return {batchSize:1,overload:1,fileThreads:false};
      let processors=Math.min(Thread.numberOfProcessors,Settings.readGlobal('Process/MaxProcessors',DataType.Int32));
      let pixels=Math.max(...jobs.map(j=>j.pixels)),memory=System.physicalMemoryStatus();
      if(!Number.isFinite(processors)||processors<1||!Number.isFinite(pixels)||pixels<=0||
         !memory||!Number.isFinite(memory.availableBytes)||memory.availableBytes<=0)return unchanged;
      processors=Math.floor(processors);
      if(processors===1)return {batchSize:1,overload:1,fileThreads:false};
      let budget=Math.min(64*1024*1024*1024,memory.availableBytes/2);
      let capacity=Math.max(1,Math.floor(budget/(64*pixels+16*1024*1024)));
      let workers=Math.max(1,Math.min(jobs.length,512,8*processors,capacity));
      return {batchSize:workers,overload:Math.max(1,Math.min(8,Math.floor(100*workers/processors)/100)),fileThreads:workers>1};
   }catch(e){return unchanged;}
}
/** Measure every submitted job with native ImageAnalysis. Field crops have
 * unique paths per run; optionally cache them to recompute set-dependent native
 * extinction without repeating PSF fits. Corners do not need the file cache.
 * Cached comparison jobs must not overwrite the existing field metrics. */
function sqrMeasureBatch(jobs,o,useCache=false,extinctionSensitivity=null){
   let plan=sqrMeasurementPlan(jobs);
   for(let first=0;first<jobs.length;first+=plan.batchSize){
      if(console.abortRequested)throw new Error('Operation aborted.');
      let batch=jobs.slice(first,first+plan.batchSize);
      let p=new ImageAnalysis;p.task=ImageAnalysis.Task_Measure;p.fileCache=useCache&&extinctionSensitivity===null;
      if(extinctionSensitivity!==null)p.sensitivity=extinctionSensitivity;
      // Measure trails on the common field. Match the extended setting on cached
      // field comparisons; corner crops and the separate sensitivity retry skip it.
      p.extendedMeasurements=batch[0].region===0&&extinctionSensitivity===null;p.maxPSFFits=o.maxFits;p.psfFit=ImageAnalysis.PSF_Moffat4;
      p.useFileThreads=plan.fileThreads;p.fileThreadOverload=plan.overload;
      p.psfFitCircular=false;p.onError=ImageAnalysis.OnError_Continue;
      // Scoring and rejection remain owned by this script, not process expressions.
      p.approvalExpression='';p.weightingExpression='';
      p.frames=batch.map(j=>[true,j.path,'','']);
      let ok=p.executeGlobal();
      if(console.abortRequested)throw new Error('Operation aborted.');
      // Parallel processing and failed files can change output order and length.
      // Match the returned file path, never the result's row position.
      let results=new Map;for(let m of p.measurements)results.set(sqrKey(m[ImageAnalysis.measurements_measurementPath]),m);
      for(let j of batch){let m=results.get(sqrKey(j.path));
         if(j.measureMetrics!==false)j.row.metrics[j.region]=m?sqrMeasurement(m,o.minStars,j.region===0):
            {valid:false,error:ok?'No measurement returned':'Measurement failed'};
         if(j.region===0&&!j.row.isMaster&&j.measureMetrics!==false&&p.extendedMeasurements)
            j.row.metrics[0].trails=sqrNativeTrails(m);
         if(j.region===0)j.extinction=sqrNativeExtinction(m);}
   }
}
/** Native extinction is relative to the submitted set. Reevaluate cached field
 * results per filter using lights only. A separate cached master/reference pair
 * retains the master's comparison KPI without altering any light's estimator.
 * Never infer validity from a zero value: the process supplies a defined flag. */
function sqrMeasureTransparency(groups,jobs,o,notify){
   for(let g of groups){
      let fields=jobs.filter(j=>j.group===g),lights=fields.filter(j=>!j.row.isMaster&&!j.referenceOnly);
      if(lights.length)g.extinctionSensitivity=null;
      for(let j of lights)if(!(sqrExposure(j.row)>0))j.row.nativeExtinction={error:'Exposure time is unavailable.'};
      let compare=lights.filter(j=>sqrExposure(j.row)>0).map(j=>({...j,measureMetrics:false}));
      if(compare.length===1)compare[0].row.nativeExtinction={error:'At least two subframes with valid exposure times are required for relative extinction.'};
      else if(compare.length>1){
         sqrTick(notify,'Computing relative transparency — '+g.label);
         sqrMeasureBatch(compare,o,true);
         if(compare.some(j=>j.extinction?.missingStellarFlux)){
            sqrTick(notify,'Retrying relative transparency with fainter stars — '+g.label);
            // ImageAnalysis selects one brightness window per submitted set.
            // Keep results from one pass, including its cloud-extinction fit.
            let retry=compare.map(j=>({...j,extinction:null}));
            try{
               sqrMeasureBatch(retry,o,false,SQR_EXTINCTION_RETRY_SENSITIVITY);
               const valid=j=>Number.isFinite(j.extinction?.value);
               if(compare.every((j,i)=>!valid(j)||valid(retry[i]))&&compare.some((j,i)=>!valid(j)&&valid(retry[i]))){
                  compare=retry;g.extinctionSensitivity=SQR_EXTINCTION_RETRY_SENSITIVITY;
               }
            }catch(e){if(console.abortRequested)throw e;
               console.warningln('Transparency retry failed for '+g.label+'. Keeping the first measurement. '+String(e));}
         }
         for(let j of compare)j.row.nativeExtinction=j.extinction;
      }
      let master=fields.find(j=>j.row.isMaster),reference=sqrTransparencyReference(g);
      if(master){
         let ref=reference&&fields.find(j=>j.row===reference);
         if(ref&&sqrExposure(master.row)>0){
            let pair=[ref,master].map(j=>({...j,measureMetrics:false}));sqrMeasureBatch(pair,o,true,g.extinctionSensitivity??null);
            let a=pair[0].extinction,b=pair[1].extinction;
            master.row.nativeExtinction=a.error||b.error?{error:a.error||b.error}:
               {value:b.value-a.value,exposure:b.exposure,reference:reference.registered.path,error:''};
         }
         else master.row.nativeExtinction={error:!(sqrExposure(master.row)>0)?'Master frame exposure is unavailable; total integration time cannot replace it.':
            !reference?'No reliable subframe transparency reference is available.':'The reference crop is unavailable for the master comparison.'};
      }
      sqrFinalizeTransparency(g);
      if(lights.length){g.extinctionSiteKey=sqrExtinctionSiteKey(g,o.observingSite);g.refreshExtinction=false;}
   }
}
/** Prepare one image with independently owned handles. Read failures remain
 * per-image unavailable measurements; write failures stop the run. The caller
 * registers every output path before starting workers, so cleanup also covers
 * partially written files and workers interrupted before returning results. */
function sqrPrepareCrops(item){
   let im=null,row={backgroundMeans:item.backgroundMeans};
   try{sqrPreparationAbort();im=sqrReadImage(item.path,item.isMaster);
      if(im.width!==item.width||im.height!==item.height||im.numberOfNominalChannels!==item.channels)throw new Error('Image dimensions or channels do not match this group: '+item.path);
      sqrMeasureBackground(row,im,item.regions,item.withCorners);
   }catch(e){if(im)im.free();sqrPreparationAbort();
      let b=row.backgroundMeans??={previews:{}};if(!Object.prototype.hasOwnProperty.call(b,'whole'))b.whole=null;
      if(item.withCorners)for(let i=1;i<=5;++i)if(!Object.prototype.hasOwnProperty.call(b.previews,i))b.previews[i]=null;
      return {backgroundMeans:row.backgroundMeans,error:String(e)};
   }
   try{
   for(let job of item.jobs){sqrPreparationAbort();let crop=new Image,writer=null;
      try{crop.assign(im,new Rect(...item.regions[job.region]),0,im.numberOfNominalChannels-1);
         // Carry exposure and observation geometry/time only. Inherited signal,
         // noise and normalization metadata must not replace pixel measurements.
         writer=new FileFormatInstance(new FileFormat('.xisf',false,true));
         if(!writer.create(job.path,'compression-codec none'))throw new Error('Cannot create temporary measurement image.');
         let description=new ImageDescription;description.bitsPerSample=im.bitsPerSample;description.ieeefpSampleFormat=true;
         writer.setOptions(description);
         if(job.region===0&&item.exposure>0)writer.writeImageProperty('Instrument:ExposureTime',item.exposure);
         if(job.region===0&&item.observation){
            writer.keywords=item.observation.keywords.map(k=>new FITSKeyword(k[0],k[1],k[2]));
            for(let property of item.observation.properties)writer.writeImageProperty(property[0],property[1]);
         }
         if(!writer.writeImage(crop))throw new Error('Cannot write temporary measurement image.');
      }finally{if(writer)writer.close();crop.free();}
   }sqrPreparationAbort();return {backgroundMeans:row.backgroundMeans};}
   finally{im.free();}
}
/** Stage missing field/regional crops and means with bounded parallelism. Native
 * measurement batches retain the original field/region ordering regardless of
 * worker completion order. The UI/session is updated only on the main thread. */
function sqrMeasureGroups(groups,o,active,notify){
   let eligible=[],withField=active.includes(0);
   for(let g of groups){
      // Recover an interrupted set as a whole, never compare only its remainder.
      let needLights=withField&&(g.refreshExtinction||(g.extinctionSiteKey||'')!==sqrExtinctionSiteKey(g,o.observingSite)||
         g.rows.some(r=>!r.measureError&&(!r.metrics[0]||!r.nativeExtinction)));
      let master=sqrMasterRow(g),needMaster=withField&&master&&!master.measureError&&(needLights||!master.metrics[0]||!master.nativeExtinction);
      let reference=needMaster&&!needLights?sqrTransparencyReference(g):null;
      for(let r of sqrGroupRows(g)){
         if(r.measureError)continue;
         let needed=new Set(active.filter(i=>!r.metrics[i])),referenceOnly=r===reference;
         if((!r.isMaster&&needLights)||(r.isMaster&&needMaster)||referenceOnly)needed.add(0);
         if(needed.size||!sqrBackgroundComplete(r,o.measureCorners))eligible.push({r,g,needed:[...needed],referenceOnly});
         if((!r.isMaster&&needLights)||(r.isMaster&&needMaster))sqrClearTransparency(r);
      }
   }
   if(!eligible.length){if(withField)for(let g of groups)sqrFinalizeTransparency(g);return;}
   let scratch=sqrPath(File.systemTempDirectory)+'/.sqr-work-'+sqrStamp();
   TGFileProtection.assertOutsideInstallation(scratch,'Temporary measurements');
   if(File.exists(scratch)||File.directoryExists(scratch))throw Error('Temporary measurement directory is occupied.');
   File.createDirectory(scratch,true);
   let passes=[[],[]],files=new Set,completed=0;
   let total=eligible.reduce((n,item)=>n+item.needed.length,0);
   let clean=paths=>{for(let path of paths){if(File.exists(path))TGFileProtection.removeFile(path,"Temporary image");files.delete(path);}};
   let measurePass=jobs=>{if(!jobs.length)return;
      sqrTick(notify,'Measuring '+(jobs[0].region===0?'full fields':'center/corner regions')+' · '+jobs.length+' images · '+completed+' / '+total+' completed');
      let field=jobs[0].region===0;sqrMeasureBatch(jobs,o,field);
      if(field)sqrMeasureTransparency(groups,jobs,o,notify);
      completed+=jobs.length;clean(jobs.map(j=>j.path));
      sqrTick(notify,'Measured '+completed+' / '+total+' regions');
   };
   try{
      let items=eligible.map(({r,g,needed,referenceOnly},index)=>({path:r.registered.path,isMaster:!!r.isMaster,exposure:sqrExposure(r),
         observation:withField&&!r.isMaster?sqrRowObservation(r,o.observingSite):null,
         width:g.width,height:g.height,channels:g.channels,regions:g.regions,withCorners:o.measureCorners,backgroundMeans:r.backgroundMeans,
         jobs:needed.map(region=>{let path=scratch+'/frame-'+index+'-region-'+region+'.xisf',rect=g.regions[region];
            TGFileProtection.assertOutsideInstallation(path,'Temporary measurement image');
            if(File.exists(path)||File.directoryExists(path))throw Error('Temporary measurement image is occupied.');
            files.add(path);
            return {path,region,measureMetrics:!r.metrics[region],referenceOnly:region===0&&referenceOnly,pixels:(rect[2]-rect[0])*(rect[3]-rect[1])*g.channels};})}));
      let results=sqrMapPreparation(items,sqrPrepareCrops,[sqrReadImage,sqrPreparationAbort,sqrMeasureBackground],notify,'Preparing images');
      for(let index=0;index<items.length;++index){let {r,g}=eligible[index],result=results[index];r.backgroundMeans=result.backgroundMeans;
         for(let job of items[index].jobs){if(result.error){if(job.measureMetrics)r.metrics[job.region]={valid:false,error:result.error};
               if(job.region===0&&!job.referenceOnly)r.nativeExtinction={error:result.error};++completed;}
            else passes[job.region===0?0:1].push({...job,row:r,group:g});}}
      for(let jobs of passes)measurePass(jobs);
      if(withField)for(let g of groups)sqrFinalizeTransparency(g);
   }finally{clean(files);if(File.directoryExists(scratch))TGFileProtection.removeDirectory(scratch,"Temporary image directory");}
}

// A change of corner geometry leaves full-field measurements intact.
function sqrConfigureCornerSize(g,o,reset=false){
   if(!g.roi)return false;
   if(reset||o.autoCornerSize===false||g.cornerStart!==undefined&&g.cornerStart!==o.patch){
      delete g.cornerPatch;delete g.cornerRetryMinimum;
   }
   g.cornerStart=o.patch;
   let regions=sqrRegions(g.roi,g.cornerPatch??o.patch);
   if(JSON.stringify(g.regions)===JSON.stringify(regions))return false;
   g.regions=regions;
   for(let r of sqrGroupRows(g)){
      for(let i=1;i<=5;++i)delete r.metrics[i];
      if(r.backgroundMeans)r.backgroundMeans.previews={};
   }
   return true;
}
// A larger patch can lose a usable PSF fit. Compare complete regional sets
// first, and retain one geometry and its corresponding background means.
function sqrRetrySparseCorners(g,o,notify){
   if(o.autoCornerSize===false)return;
   const regions=[1,2,3,4,5],minimum=o.minStars;
   let size=g.cornerPatch??o.patch;
   if(size>=SQR_MAX_CORNER_PERCENT||g.cornerRetryMinimum===minimum)return;
   let fewest=Infinity;
   for(let r of g.rows)for(let i of regions){
      let stars=r.metrics[i]?.stars;if(Number.isFinite(stars))fewest=Math.min(fewest,stars);
   }
   if(fewest>=minimum)return;
   // Estimate the area needed at the observed stellar density. Round up to
   // five percentage points; use the largest supported patch for zero stars.
   let estimate=fewest>0?5*Math.ceil(size*Math.sqrt(minimum/fewest)/5):SQR_MAX_CORNER_PERCENT;
   let next=Math.min(SQR_MAX_CORNER_PERCENT,Math.max(size+1,estimate));
   const coverage=r=>regions.filter(i=>{let m=r.metrics[i];
      return m&&sqrMetricValid(m,minimum,false)&&(i===1||(Number.isFinite(m.eccentricity)&&m.eccentricity>=0&&m.eccentricity<1));}).length;
   const all=sqrGroupRows(g);
   for(;;){
      sqrTick(notify,'Retrying center and corners at '+next+'% — '+g.label);
      // Stage the retry separately so a failure or abort cannot leave a mix
      // of rectangle sizes, even for the master or a previously unreadable row.
      let copies=all.map(r=>({...r,metrics:{0:r.metrics[0]},backgroundMeans:{...r.backgroundMeans,previews:{}}}));
      for(let r of copies)if(r.measureError)for(let i of regions){r.metrics[i]={valid:false,error:r.measureError};r.backgroundMeans.previews[i]=null;}
      let trial={...g,regions:sqrRegions(g.roi,next),rows:copies.slice(0,g.rows.length),masterRow:g.master?copies[copies.length-1]:null};
      sqrMeasureGroups([trial],o,regions,notify);
      let before=g.rows.map(coverage),after=trial.rows.map(coverage);
      let complete=a=>a.filter(n=>n===5).length,sum=a=>a.reduce((n,k)=>n+k,0);
      let readable=all.every((r,j)=>regions.every(i=>!Number.isFinite(r.backgroundMeans?.previews?.[i])||
         Number.isFinite(copies[j].backgroundMeans.previews[i])));
      // Keep every previously complete light. A gain in complete lights takes
      // priority over partial coverage. A tie favours the smaller geometry.
      let improved=complete(after)>complete(before)||sum(after)>sum(before);
      if(readable&&improved&&before.every((n,i)=>n<5||after[i]===5)){
         for(let i=0;i<all.length;++i){all[i].metrics=copies[i].metrics;all[i].backgroundMeans=copies[i].backgroundMeans;}
         g.regions=trial.regions;g.cornerPatch=next;
      }
      if(next===SQR_MAX_CORNER_PERCENT||!g.rows.some(r=>regions.some(i=>Number.isFinite(r.metrics[i]?.stars)&&r.metrics[i].stars<minimum)))break;
      next=SQR_MAX_CORNER_PERCENT;
   }
   g.cornerRetryMinimum=minimum;
}
// Invalidate a master's measurement cache when the file or shared crop changes.
// Master failures are retained as invalid comparison data, not rejection flags.
function sqrPrepareMaster(g,o,active){
   let master=sqrMasterRow(g);if(!master)return;
   try{
      let fingerprint=sqrFingerprint(g.master);
      // Read the small header once per file revision. Keep header failures
      // diagnostic: PSF and pixel measurements can still be useful on their own.
      if(master.metadataFingerprint!==fingerprint){
         try{master.registered=sqrMetadata(g.master,true);}
         catch(e){if(console.abortRequested)throw e;master.registered={path:g.master};}
         master.metadataFingerprint=fingerprint;
      }
      let signature=JSON.stringify({version:SQR_VERSION,file:[g.master,fingerprint],roi:g.roi,
         maxFits:o.maxFits});
      if(master.measureSignature!==signature){master.metrics={};sqrClearTransparency(master);delete master.backgroundMeans;delete master.measureError;master.measureSignature=signature;}
   }catch(e){if(console.abortRequested)throw e;master.measureSignature='';delete master.backgroundMeans;sqrClearTransparency(master);master.nativeExtinction={error:String(e)};
      for(let i of active)master.metrics[i]={valid:false,error:String(e)};}
}
/** Coordinate border discovery, cache validation, measurement and ranking.
 * Signatures include file fingerprints and measurement settings. Weights and
 * the REVIEW percentage are excluded because they only affect derived scores.
 * Measuring corners fills missing regions without discarding valid field metrics. */
function sqrAnalyze(session,notify){
   let o=session.options,active=sqrActiveRegions(o);
   for(let g of session.groups){
      let signature=JSON.stringify({version:SQR_VERSION,method:'clean-crops-v1',margin:o.margin,maxFits:o.maxFits,
         files:g.rows.map(r=>[r.registered.path,sqrFingerprint(r.registered.path)]).sort((a,b)=>a[0].localeCompare(b[0]))});
      if(g.measureSignature===signature)sqrConfigureCornerSize(g,o);
      if(g.measureSignature===signature&&g.rows.every(r=>active.every(i=>r.metrics[i]))){
         sqrTick(notify,'Using existing subframe measurements: '+g.label);sqrPrepareMaster(g,o,active);
         continue;}
      if(g.measureSignature!==signature){
       let roi=[0,0,g.width,g.height];
       for(let r of g.rows){r.metrics={};sqrClearTransparency(r);delete r.backgroundMeans;delete r.measureError;}
       let items=g.rows.map(r=>({path:r.registered.path,width:g.width,height:g.height,channels:g.channels,margin:o.margin}));
       let bounds=sqrMapPreparation(items,sqrPrepareBounds,[sqrReadImage,sqrPreparationAbort,sqrBounds],notify,'Checking registered borders — '+g.label);
       for(let i=0;i<g.rows.length;++i){let result=bounds[i];if(result.error)g.rows[i].measureError=result.error;
          else{let b=result.bounds;roi=[Math.max(roi[0],b[0]),Math.max(roi[1],b[1]),Math.min(roi[2],b[2]),Math.min(roi[3],b[3])];}}
       if(roi[2]-roi[0]<g.width*.5||roi[3]-roi[1]<g.height*.5)throw new Error('Insufficient common field: '+g.label);
       g.roi=roi;sqrConfigureCornerSize(g,o,true);g.measureSignature=signature;
      }
      for(let r of g.rows)if(r.measureError){r.nativeExtinction={error:r.measureError};r.backgroundMeans={whole:null,previews:Object.fromEntries(active.filter(i=>i>0).map(i=>[i,null]))};for(let i of active)r.metrics[i]={valid:false,error:r.measureError};}
      sqrPrepareMaster(g,o,active);
   }
   sqrMeasureGroups(session.groups,{...o,observingSite:sqrRunSite(session).site||sqrFallbackSite(o)},active,notify);
   if(o.measureCorners)for(let g of session.groups)sqrRetrySparseCorners(g,o,notify);
   sqrRank(session);return session;
}
const SQR_MASTER_SCORE_INFO='Integrated master: measurements only; excluded from Score and R1–R4 ranks.';
// Clear legacy cached scores as well as current assessments, without touching
// measurements or their comparison diagnostics. A master is never a candidate.
function sqrExcludeMasterScore(row){
   for(let key of ['score','scoreWithoutCorners','scoreWithCorners','scoreCorrelated','scoreRankOfRanks',
      'rank','rankWithoutCorners','rankWithCorners','rankCorrelated','rankOfRanks'])row[key]=null;
   row.rankComponents=[];row.rankOfRanksDetail=SQR_MASTER_SCORE_INFO;
   row.reject=false;row.candidate=false;row.guidingIgnored=true;row.needsDataReview=false;row.insufficientCorners=0;
   row.scoreContributions=[];row.dataReviewReasons=[];row.reasons=[SQR_MASTER_SCORE_INFO];
   row.mainIssue='';row.mainIssueDetail=SQR_MASTER_SCORE_INFO;
}
// Rank 1 is the lowest (worst) finite subframe score. Missing scores and masters
// receive no rank. Table filtering happens after this complete population.
function sqrAssignRanks(rows,scoreKey,rankKey){
   for(let r of rows){r[rankKey]=null;if(r.isMaster)r[scoreKey]=null;}
   let ranked=rows.filter(r=>!r.isMaster&&Number.isFinite(r[scoreKey])).sort((a,b)=>a[scoreKey]-b[scoreKey]||a.registered.path.localeCompare(b.registered.path));
   for(let i=0;i<ranked.length;++i)ranked[i][rankKey]=i+1;
}
// R4 combines the displayed ranks, normalized separately for each available
// subframe population. The master contributes neither a rank nor a population slot.
// Missing ranks are omitted, never interpreted as best or worst measurements.
function sqrRankOfRanks(rows,withCorners){
   let sources=[['rankWithoutCorners','R1: field rank'],...(withCorners?[['rankWithCorners','R2: rank with corners']]:[]),['rankCorrelated','R3: correlation rank']]
      .map(([key,name])=>({key,name,count:rows.filter(r=>!r.isMaster&&Number.isFinite(r[key])).length}));
   for(let r of rows){
      if(r.isMaster){sqrExcludeMasterScore(r);continue;}
      r.rankComponents=sources.filter(c=>Number.isFinite(r[c.key])).map(c=>({...c,rank:r[c.key],value:c.count>1?(r[c.key]-1)/(c.count-1):.5}));
      r.scoreRankOfRanks=r.rankComponents.length?r.rankComponents.reduce((sum,c)=>sum+c.value,0)/r.rankComponents.length:null;
      r.rankOfRanksDetail='R4 averages normalized ranks with equal weight. For each rank: (rank − 1) / (ranked images − 1); a single ranked image uses 0.5. Higher is better.\n'+
         r.rankComponents.map(c=>c.name+': '+c.rank+' of '+c.count+' → '+sqrFmt(c.value)).join('\n');
      let omitted=sources.filter(c=>!Number.isFinite(r[c.key])).map(c=>c.name);
      if(!withCorners)omitted.push('R2 (corner scoring off)');
      if(omitted.length)r.rankOfRanksDetail+='\nOmitted: '+omitted.join(', ')+'.';
      r.rankOfRanksDetail+='\nCombined Score: '+sqrFmt(r.scoreRankOfRanks)+'. Ranks include subframes only; equal scores are ordered by filename.';
   }
   sqrAssignRanks(rows,'scoreRankOfRanks','rankOfRanks');
}
// Preserve manual evaluation while computing the independent R3 comparison.
// Arrays are replaced by scoring functions, so shallow snapshots retain them.
const SQR_ACTIVE_SCORE_FIELDS=['score','guidingIgnored','reasons','dataReviewReasons','needsDataReview','scoreContributions','mainIssue','mainIssueDetail','insufficientCorners'];
function sqrScoreState(row){return Object.fromEntries(SQR_ACTIVE_SCORE_FIELDS.map(key=>[key,row[key]]));}
function sqrApplyRankOfRanks(row,automatic){
   if(row.isMaster){sqrExcludeMasterScore(row);return;}
   row.score=row.scoreRankOfRanks;
   // Guiding can participate through R3 even when its manual R1/R2 weight is 0.
   row.guidingIgnored=row.guidingIgnored&&automatic.guidingIgnored;
   row.dataReviewReasons=[...new Set([...(row.dataReviewReasons||[]),...(automatic.dataReviewReasons||[])])];row.needsDataReview=row.dataReviewReasons.length>0;
   let count=row.rankComponents.length;
   row.scoreContributions=row.rankComponents.filter(c=>c.value<1).map(c=>({key:c.key,name:c.name,issue:'Low '+c.name.slice(0,2)+' rank',w:1,z:10*(1-c.value),contribution:(1-c.value)/count})).sort((a,b)=>b.contribution-a.contribution);
   row.mainIssue=row.scoreContributions[0]?.issue||(row.needsDataReview?'Missing data':'None');
   row.mainIssueDetail=row.rankOfRanksDetail+(row.needsDataReview?'\nSome component measurements require inspection.':'');
   row.reasons=row.scoreContributions.map(c=>c.name+' (−'+sqrFmt(c.contribution)+' from Score)');
   if(!row.reasons.length)row.reasons.push('No rank penalty');
   if(row.needsDataReview)row.reasons.unshift('Insufficient measurements: inspect manually');
}
/** Calculate the breadth of poor quality before Score, avoiding a dependency
 * cycle. Only underlying KPIs with positive manual weights count; R3's effective
 * weights never redefine this measurement. Score and this fraction itself never
 * count. A fraction uses available comparisons, while completeness
 * records missing ones so a partial percentage cannot look fully assessed.
 * Keep separate field-only and corner-inclusive fractions for independent R1/R2.
 * Baselines include rejected subframes but exclude the integrated master. */
function sqrMeanComparisons(group,o,guideEnabled=false){
   let sky=sqrSkyScoreChoice(o),components=[
      {label:'PSF signal weight',weight:o.signalWeight,lower:true,value:r=>sqrKPIValue(r,SQR_KPIS[1])},
      {label:'Star count',weight:o.starsWeight,lower:true,value:r=>sqrKPIValue(r,SQR_KPIS[2])},
      {label:'Field FWHM',weight:o.fwhmWeight,value:r=>sqrKPIValue(r,SQR_KPIS[3])},
      {label:'Field eccentricity',weight:o.eccentricityWeight,value:r=>sqrKPIValue(r,SQR_KPIS[5])},
      {label:sky.name,backgroundMode:'field',lower:sky.higher,weight:o.backgroundWeight,value:r=>sqrSkyScoreValue(r,o,false)},
      {label:sky.name,backgroundMode:'corners',lower:sky.higher,weight:o.backgroundWeight,value:r=>sqrSkyScoreValue(r,o,true)},
      {label:'Corner quality',corner:true,weight:o.cornerWeight,value:r=>r.metrics[0]?.valid&&r.metrics[1]?.valid&&[2,3,4,5].every(i=>sqrEccentricityValid(r.metrics[i]))?r.measuredCornerSeverity:null}
   ];if(guideEnabled)components.push({label:'Guiding quality (arcsec)',guiding:true,weight:o.guideWeight,value:r=>r.guideQuality});
   components=components.filter(c=>c.weight>0);
   // Ranking reorders rows; sum in a fixed order so displayed means stay stable.
   for(let c of components){let values=group.rows.map(c.value).filter(Number.isFinite).sort((a,b)=>a-b);c.mean=values.length?values.reduce((sum,v)=>sum+v,0)/values.length:null;}
   for(let r of sqrGroupRows(group)){
      let allComparisons=components.filter(c=>!c.guiding||!r.isMaster&&!r.guidingIgnored).map(c=>{let value=c.value(r),available=Number.isFinite(value)&&Number.isFinite(c.mean);
         // Ignore rounding noise at equality; the criterion is a strict worse-than-mean comparison.
         let delta=available?(c.lower?c.mean-value:value-c.mean):0,tolerance=available?1e-12*Math.max(1,Math.abs(value),Math.abs(c.mean)):0;
         return {label:c.label,corner:c.corner,backgroundMode:c.backgroundMode,lower:c.lower,value,mean:c.mean,available,worse:available&&delta>tolerance};});
      let fieldComparisons=allComparisons.filter(c=>!c.corner&&c.backgroundMode!=='corners');
      allComparisons=allComparisons.filter(c=>c.backgroundMode!=='field');
      let fraction=items=>{let available=items.filter(c=>c.available);return available.length?available.filter(c=>c.worse).length/available.length:null;};
      r.belowMeanFieldFraction=fraction(fieldComparisons);r.belowMeanCornerFraction=fraction(allComparisons);
      let comparisons=o.measureCorners?allComparisons:fieldComparisons;
      r.belowMeanAvailable=comparisons.filter(c=>c.available).length;r.belowMeanTotal=comparisons.length;
      r.belowMeanComplete=r.belowMeanAvailable===comparisons.length&&comparisons.length>0;
      r.belowMeanCount=r.belowMeanAvailable?comparisons.filter(c=>c.worse).length:null;
      r.belowMeanFraction=r.belowMeanAvailable?r.belowMeanCount/r.belowMeanAvailable:null;
      r.belowMeanDetail=(r.belowMeanFraction===null?'No comparable measurements.':'Below-mean Quality: '+sqrPercent(r.belowMeanFraction)+' ('+r.belowMeanCount+' of '+r.belowMeanAvailable+' assessed indicators have worse-than-mean quality). Lower percentages are better.')+
         '\nEnabled underlying indicators: '+r.belowMeanTotal+'. The manual KPI weights and corner/guiding settings define this comparison; selecting R3 or R4 does not change it. Score and Below-mean Quality itself are excluded. Arithmetic means use all supported subframes in this group, including rejects; the master is excluded.\n'+
         comparisons.map(c=>c.label+': '+(c.available?sqrFmt(c.value)+' vs mean '+sqrFmt(c.mean)+' — '+(c.worse?'worse':'at or better than mean'):'unavailable')+' ('+(c.lower?'below':'above')+' mean is worse)').join('\n')+
         (r.belowMeanComplete?'':'\nIncomplete comparison; unavailable KPIs are not counted as good.');
   }
}
function sqrMeanQualityLabel(row){return Number.isFinite(row.belowMeanFraction)?sqrPercent(row.belowMeanFraction)+(row.belowMeanComplete?'':'*'):'—';}
/** Convert the existing capped penalties to a quality score. Using a fixed cap
 * (not a group min/max) preserves relative manual weights and ranking ties. */
function sqrWeightedScore(parts){
   let weight=parts.reduce((sum,p)=>sum+p.w,0);
   return weight>0?Math.max(0,Math.min(1,1-parts.reduce((sum,p)=>sum+p.z*p.w,0)/(10*weight))):null;
}
// Compare other components with PSF signal weight using paired subframes only.
// Three pairs are the minimum: two points always give a spurious perfect r.
function sqrScoreCorrelation(group,component,o,guideAvailable){
   // The reference is not a candidate: its self-correlation is not evidence
   // for selection, even when no other KPI passes the threshold.
   if(component.weight==='signalWeight')return {...component,r:null,count:0,included:false,reason:'correlation reference only; self-correlation excluded'};
   let kpi=SQR_KPIS.find(k=>sqrKPIKey(k)===component.kpi),pairs=[];
   for(let r of group.rows.filter(r=>!r.isMaster)){
      let x=sqrKPIValue(r,SQR_KPIS[1]),y=sqrKPIValue(r,kpi);
      if(component.weight==='cornerWeight'&&(!r.metrics[1]?.valid||![2,3,4,5].every(i=>sqrEccentricityValid(r.metrics[i]))))y=null;
      if(component.weight==='guideWeight'&&!r.guiding?.scorable)y=null;
      if(Number.isFinite(x)&&Number.isFinite(y))pairs.push({x,y});
   }
   let result=sqrPearson(pairs),included=false,reason='';
   if((component.weight==='cornerWeight'||component.corner)&&!o.measureCorners)reason='corner scoring off';
   else if(component.weight==='guideWeight'&&o.guidingMode==='ignore')reason='guiding ignored';
   else if(component.weight==='guideWeight'&&!guideAvailable)reason='no guiding logs';
   else if(result.count<3)reason='fewer than 3 paired subframes';
   else if(!Number.isFinite(result.r))reason='constant or unavailable measurements';
   else if(Math.abs(result.r)<.7-1e-12)reason='|r| < 0.7';
   else {included=true;reason='|r| ≥ 0.7';}
   return {...component,...result,included,reason};
}
function sqrScoreCorrelationReport(selection){
   if(!selection)return 'Enable correlation scoring after measuring the group.';
   return (selection.available===false?'No strongly correlated KPIs. R3 unavailable; selecting R3 keeps the manual score. R4 omits R3.\n':'')+
      'Equal weights; |r| ≥ 0.7; at least 3 paired subframes. The master is excluded from correlation. PSF signal weight is the correlation reference only and is excluded from R3.\n'+
      selection.components.map(c=>c.weight==='signalWeight'?c.label+': reference only; self-correlation excluded':c.label+': '+(c.included?'included':'excluded')+'; r = '+sqrFmt(c.r)+', n = '+c.count+' ('+c.reason+')').join('\n');
}
// Build the same components for manual and correlation scoring. Missing values
// never become zero-quality measurements; the UI retains explicit review flags.
function sqrScoreParts(r,data,o,withCorners){
   let parts=data.parts.map(p=>({...p,w:o[p.key]}));
   let sky=withCorners?data.skyCorner:data.skyField;
   if(sky)parts.push({...sky,w:o.backgroundWeight});
   if(data.corner&&withCorners)parts.push({key:'cornerWeight',issue:data.corner.issue,name:data.corner.name,z:data.corner.value,w:o.cornerWeight});
   if(o.correlationOnly&&withCorners)for(let part of data.regionalParts||[])parts.push({...part,w:o[part.key]});
   let fraction=withCorners?r.belowMeanCornerFraction:r.belowMeanFieldFraction;
   if(Number.isFinite(fraction))parts.push({key:'belowMeanWeight',issue:'Below-mean Quality',name:'Below-mean Quality',z:fraction,w:o.belowMeanWeight,percentage:true});
   return parts;
}
function sqrApplyScore(r,data,o,guideEnabled){
   if(r.isMaster){sqrExcludeMasterScore(r);return;}
   let cornerRequired=o.measureCorners&&(!o.correlationOnly||o.cornerWeight>0),missingFieldShape=o.eccentricityWeight>0&&!sqrEccentricityValid(r.metrics[0]);
   r.guidingIgnored=sqrIgnoreGuiding(r,o);
   // Record the same checks that set the REVIEW flag so its tooltip explains
   // the active scoring mode, including equal-weight correlation selection.
   let reasons=[];
   if(!r.metrics[0]?.valid)reasons.push('Field PSF measurements are unavailable or insufficient.');
   if(missingFieldShape)reasons.push('Field eccentricity is unavailable.');
   if(cornerRequired){
      if(!r.metrics[1]?.valid)reasons.push('Center PSF measurements are unavailable or insufficient.');
      let missing=[2,3,4,5].filter(i=>!r.metrics[i]?.valid);
      if(missing.length)reasons.push('Corner PSF measurements are unavailable or insufficient: '+missing.map(i=>SQR_REGIONS[i]).join(', ')+'.');
      let shape=[2,3,4,5].filter(i=>r.metrics[i]?.valid&&!sqrEccentricityValid(r.metrics[i]));
      if(shape.length)reasons.push('Corner eccentricity is unavailable: '+shape.map(i=>SQR_REGIONS[i]).join(', ')+'.');
   }
   // A selected corner KPI requires only its own measurement. Missing unrelated
   // corners or eccentricities do not invalidate an independently usable FWHM.
   if(o.correlationOnly&&o.measureCorners){let missing=SQR_CORNER_COMPONENTS.filter(c=>o[c.weight]>0&&sqrKPIValue(r,c)===null);
      if(missing.length)reasons.push('Selected corner KPIs are unavailable: '+missing.map(c=>c.label).join(', ')+'.');}
   if(o.backgroundWeight>0&&sqrSkyScoreValue(r,o,o.measureCorners)===null){let sky=sqrSkyScoreChoice(o);
      reasons.push(sky.key==='skyBackground'?(o.measureCorners?
         'Sky brightness is unavailable; missing preview means: '+[1,2,3,4,5].filter(i=>!Number.isFinite(r.backgroundMeans?.previews?.[i])).map(i=>SQR_REGIONS[i]).join(', ')+'.':
         'Sky brightness is unavailable; the whole-image mean is missing.'):
         sky.name+' is unavailable: '+(sky.key==='skyQuality'?r.skyQualityInfo?.error:r.transparencyInfo?.error||'measure matching stars.'));
   }
   if(guideEnabled&&!r.isMaster&&!r.guidingIgnored){
      if(!r.guiding?.scorable)reasons.push('Guiding: '+(r.guiding?.reason||'usable guiding measurements are missing')+'.');
      if(r.guiding?.dropped>0)reasons.push('Guiding contains '+r.guiding.dropped+' rejected guide samples during this exposure.');
   }
   if(o.belowMeanWeight>0&&!r.belowMeanComplete)reasons.push('Below-mean Quality is incomplete: '+r.belowMeanAvailable+' of '+r.belowMeanTotal+' enabled indicators could be assessed.');
   r.dataReviewReasons=reasons;r.needsDataReview=reasons.length>0;
   let parts=sqrScoreParts(r,data,o,o.measureCorners),denominator=parts.reduce((sum,p)=>sum+p.w,0);
   r.score=sqrWeightedScore(parts);
   let impacts=parts.filter(p=>p.z>0&&p.w>0).sort((a,b)=>b.z*b.w-a.z*a.w);
   r.scoreContributions=impacts.map(p=>({...p,contribution:p.z*p.w/(10*denominator)}));
   r.mainIssue=impacts.length?impacts[0].issue:r.needsDataReview?'Missing data':guideEnabled&&r.guiding?.scorable?r.guiding.category:'None';
   let penaltyText=p=>p.percentage?sqrPercent(p.z):p.z.toFixed(2)+(p.guiding?' guiding penalty':' robust deviations');
   r.mainIssueDetail='Score: '+sqrFmt(r.score)+' (higher is better, 0–1). '+(impacts.length?impacts[0].name+': '+penaltyText(impacts[0])+' × weight '+impacts[0].w+'; subtracts '+sqrFmt(r.scoreContributions[0].contribution)+' from Score.':'No enabled quality penalty.');
   if(r.guiding)r.mainIssueDetail+='\n'+sqrGuideReport(r);
   if(r.needsDataReview)r.mainIssueDetail+=' Some enabled measurements are unavailable; inspect manually.';
   if(missingFieldShape)r.mainIssueDetail+=' Field eccentricity is unavailable.';
   r.reasons=impacts.map(p=>p.name+' ('+penaltyText(p)+')');
   if(r.guiding&&!r.guidingIgnored&&!impacts.some(p=>p.guiding))r.reasons.push(r.guiding.scorable?r.guiding.category:r.guiding.reason);
   if(!r.reasons.length)r.reasons.push('No enabled quality penalty');
   r.insufficientCorners=cornerRequired?4-data.cornerCount:0;
   if(r.needsDataReview)r.reasons.unshift('Insufficient measurements: inspect manually');
   if(cornerRequired&&data.missingShape)r.reasons.unshift('Corner eccentricity unavailable: inspect manually');
   if(missingFieldShape)r.reasons.unshift('Field eccentricity unavailable: inspect manually');
}
/** Explain a missing regional result from the recorded measurements or error.
 * The regional validity rule uses detected stars and FWHM, not the field-only
 * PSF signal/count threshold. Never infer an optical cause from a failed fit. */
function sqrRegionMeasurementReason(row,region,minStars){
   let m=row.metrics[region];
   if(!m)return 'Not measured: no result is available.';
   if(m.error&&m.error!=='Insufficient valid PSF measurements'){
      if(m.error==='No measurement returned')return 'ImageAnalysis returned no measurement for this preview.';
      if(m.error==='Measurement failed')return 'ImageAnalysis failed to measure this preview; no detailed cause was returned.';
      return 'Measurement error: '+m.error;
   }
   let reasons=[];
   if(!Number.isFinite(m.stars))reasons.push('the detected-star count was not returned');
   else if(m.stars<minStars)reasons.push(sqrFmt(m.stars,0)+' detected stars; Minimum stars requires '+minStars);
   if(!Number.isFinite(m.fwhm)||m.fwhm<=0)reasons.push('no valid FWHM was returned'+(Number.isFinite(m.psfCount)?' ('+sqrFmt(m.psfCount,0)+' accepted PSF fits)':''));
   if(region>=2&&!reasons.length&&!sqrEccentricityValid(m)){
      if(!Number.isFinite(m.eccentricity))reasons.push('no eccentricity value was returned');
      else if(m.eccentricity<0||m.eccentricity>=1)reasons.push('eccentricity '+sqrFmt(m.eccentricity)+' is outside the usable range 0 ≤ e < 1');
   }
   if(!reasons.length&&!m.valid)reasons.push('no usable PSF measurement is available; no detailed cause was recorded');
   return reasons.length?reasons.join('; ')+'.':'';
}
function sqrNativeTrails(m){
   const C=ImageAnalysis,count=m?.[C.measurements_measurementTrails];
   // ImageAnalysis stores zero for undefined integers. Bit 0x08 validates Trails.
   return (m?.[C.measurements_measurementFlags]&0x08)&&Number.isInteger(count)&&count>=0?count:null;
}
function sqrTrailPending(row){return row.metrics?.[0]?.trails>0&&!row.metrics[0].trailReviewed;}
function sqrNeedsReview(row){return !!(row.candidate||row.trailReview);}
function sqrRefreshTrailReview(group){
   const kept=group.rows.filter(r=>!r.isMaster&&!r.moved&&!r.reject).length;
   let changed=false;
   for(const r of group.rows){
      const review=kept<SQR_TRAIL_REVIEW_LIMIT&&!r.isMaster&&!r.moved&&!r.reject&&sqrTrailPending(r);
      if(!!r.trailReview!==review)changed=true;
      r.trailReview=review;
   }
   return changed;
}
function sqrTrailNotice(retained){
   if(retained.length>=SQR_TRAIL_REVIEW_LIMIT)return '';
   const count=retained.filter(sqrTrailPending).length;
   const missing=retained.filter(r=>!Number.isInteger(r.metrics?.[0]?.trails)).length;
   return (count?' Inspect '+count+' retained subframe'+(count===1?'':'s')+' with detected trails in Blink.':'')+
      (missing?' Trail count unavailable for '+missing+' retained subframe'+(missing===1?'':'s')+'.':'');
}
/** Explain selection from its actual group rank and measurement checks, never
 * from the current table sort or visible row number. No image reads are needed. */
function sqrReviewToolTip(row,group,options){
   if(row.isMaster)return SQR_MASTER_SCORE_INFO;
   let trail=row.trailReview?'ImageAnalysis detected '+row.metrics[0].trails+' trail(s) in the common usable field. Fewer than '+SQR_TRAIL_REVIEW_LIMIT+' subframes are retained in this group. Inspect the frame in Blink, then choose Keep despite trail or mark it for rejection.':'';
   if(trail&&(group.reviewComplete||!row.candidate))return trail;
   if(group.reviewComplete)return 'Review completed by accepting the rejection recommendation for this group. Measurements and score details remain available.';
   if(!row.candidate)return '';
   let sections=['Marked REVIEW for the following reasons:'];
   if(trail)sections.push(trail);
   if(Number.isFinite(row.rank)&&row.rank<=group.shortlistCount){
      let text='Review worst ('+Number(options.percent.toFixed(1))+'%): rank '+row.rank+' of '+group.shortlistPopulation+
         ' subframes with valid field measurements; '+group.shortlistCount+' shortlisted (rounded up).';
      if(Number.isFinite(row.score))text+='\nScore: '+sqrFmt(row.score)+' (higher is better).';
      let penalties=(row.scoreContributions||[]).slice(0,3);
      if(penalties.length)text+='\nLargest score penalties: '+penalties.map(p=>p.name+' (−'+sqrFmt(p.contribution)+')').join('; ')+'.';
      else text+='\nNo measured score penalty. The percentage shortlist still applies.';
      text+='\nEqual scores are ordered by filename.';sections.push(text);
   }
   if(row.needsDataReview)sections.push('Measurements require inspection:\n'+(row.dataReviewReasons?.length?row.dataReviewReasons:['Required measurements are unavailable or insufficient.']).map(reason=>'• '+reason).join('\n'));
   if(options.measureCorners){
      let missing=[1,2,3,4,5].map(i=>({region:i,reason:sqrRegionMeasurementReason(row,i,options.minStars)})).filter(item=>item.reason);
      // Also explain missing regional data on a quota-selected row, even when
      // correlation scoring has excluded that particular regional indicator.
      if(missing.length)sections.push('Unavailable preview measurements:\n'+missing.map(item=>'• '+SQR_REGIONS[item.region]+': '+item.reason).join('\n'));
   }
   sections.push('Review this image before deciding whether to reject it.');return sections.join('\n\n');
}
/** Compact, aligned selected-image information. Keep long explanations and
 * full paths in tooltips so selection changes never stretch the dialog. All
 * filenames and measurement messages are escaped before rich-text rendering. */
function sqrReviewDetails(row){
   let headers=['Field','Center','Top left','Top right','Bottom left','Bottom right'];
   let metrics='<table width="100%" cellspacing="2" cellpadding="0"><tr><td></td>'+headers.map(h=>'<th>'+h+'</th>').join('')+'</tr>';
   for(let [label,key,digits] of [['FWHM (px)','fwhm',1],['Eccentricity','eccentricity',2],['Stars','stars',0]])
      metrics+='<tr><td><b>'+label+'</b></td>'+headers.map((h,i)=>{let m=row?.metrics[i],value=m?.[key];
         let valid=Number.isFinite(value)&&(key==='stars'||key==='eccentricity'&&sqrEccentricityValid(m)||key==='fwhm'&&m?.valid);
         return '<td align="center">'+(valid?sqrFmt(value,digits):'—')+'</td>';}).join('')+'</tr>';
   metrics+='</table>';
   if(!row)return {summary:'No image selected.',summaryTip:'Select an image in the table to see its assessment and regional measurements.',metrics,metricsTip:'No image selected.',source:'<b>File:</b> —',sourceTip:''};
   let state=row.isMaster?'Master · comparison only':row.moved?'Original moved':row.reject?'Reject original':'Keep original';
   if(!row.isMaster&&sqrNeedsReview(row))state+=' · REVIEW';
   let guide=row.isMaster?'':row.guiding?(row.guiding.scorable?row.guiding.category:'Unavailable')+(row.guidingIgnored?' (excluded)':''):'';
   let summary=row.isMaster?'<b>'+sqrHTML(state)+'</b><br/>Excluded from Score and R1–R4 ranks.':
      '<b>'+sqrHTML(state)+'</b> · Score: '+sqrFmt(row.score)+'<br/><b>Main issue:</b> '+sqrHTML(row.mainIssue||'Not measured')+(guide?' · <b>Guiding:</b> '+sqrHTML(guide):'');
   if(row.trailReview)summary+=' · <b>Inspect trail in Blink</b>';
   if(row.wbppReason)summary+='<br/><b>WBPP:</b> '+sqrHTML(row.wbppReason);
   let summaryTip=row.isMaster?SQR_MASTER_SCORE_INFO:[row.wbppReason,row.mainIssueDetail,...(row.reasons||[]),...(row.dataReviewReasons||[])].filter(Boolean).join('\n');
   if(row.guiding)summaryTip+='\n'+sqrGuideReport(row);
   let metricsTip='FWHM is in pixels. Eccentricity: 0 = round, toward 1 = elongated. Stars is the detected count. — = unavailable.\n'+headers.map((h,i)=>{
      let m=row.metrics[i];return h+': '+(m?.valid?'FWHM '+sqrFmt(m.fwhm,1)+' px; eccentricity '+sqrFmt(m.eccentricity,2)+'; '+sqrFmt(m.stars,0)+' stars.':m?(m.error||'Insufficient valid star measurements.'):'Not measured.');}).join('\n');
   let label=row.isMaster?'Master':row.moved?'Moved to':'Original',path=row.isMaster?row.registered.path:row.moved?row.movedTo:row.original?.path;
   let name=path?sqrFileName(path):row.match||'No associated original';if(name.length>90)name=name.slice(0,54)+'…'+name.slice(-30);
   return {summary,summaryTip,metrics,metricsTip,source:'<b>'+label+':</b> '+sqrHTML(name),
      sourceTip:label+': '+(path||row.match||'No associated original')+'\nRegistered: '+row.registered.path};
}
/** Recompute derived data from cached measurements. Manual weights always produce
 * R1/R2 first. R3 requires a qualifying KPI; R4 combines available ranks.
 * The chosen mode controls Score without changing weights or rereading pixels.
 * Below-mean Quality is computed once from the manual KPI selection. R3 assesses
 * and weights that same composite, keeping its values and plotted correlations
 * independent of the active scoring mode. */
function sqrRank(session){
   let o=session.options;
   o.skyScoreKPI=sqrSkyScoreChoice(o).key;
   for(let c of SQR_SCORE_COMPONENTS)o[c.weight]??=sqrDefaults()[c.weight];
   let guideAvailable=!!session.guiding?.enabled,guideEnabled=guideAvailable&&o.guideWeight>0&&o.guidingMode!=='ignore';
   if(!o.correlationOnly&&!o.rankOfRanks&&o.signalWeight+o.starsWeight+o.fwhmWeight+o.eccentricityWeight+o.backgroundWeight+(o.measureCorners?o.cornerWeight:0)+(guideEnabled?o.guideWeight:0)<=0)throw new Error('At least one underlying quality indicator must have a positive weight.');
   for(let g of session.groups){
      let all=sqrGroupRows(g);g.correlationScoring=null;
      for(let r of all)r.skyBackground=sqrSkyBackground(r,o.measureCorners);
      sqrUpdateSkyQuality(g,o.measureCorners);
      let sky=sqrSkyScoreChoice(o),skyField=sqrSummary(g.rows.map(r=>sqrSkyScoreValue(r,o,false)).filter(Number.isFinite)),skyCorner=sqrSummary(g.rows.map(r=>sqrSkyScoreValue(r,o,true)).filter(Number.isFinite));
      for(let r of all)for(let i=0;i<6;++i)if(r.metrics[i]){let m=r.metrics[i];m.valid=sqrMetricValid(m,o.minStars,i===0);if(m.valid)delete m.error;else if('fwhm' in m)m.error='Insufficient valid PSF measurements';}
      let valid=g.rows.filter(r=>r.metrics[0]?.valid);
      let signal=sqrSummary(valid.map(r=>r.metrics[0].signal)),stars=sqrSummary(valid.map(r=>r.metrics[0].stars)),fwhm=sqrSummary(valid.map(r=>r.metrics[0].fwhm));
      let eccentricity=sqrSummary(valid.filter(r=>sqrEccentricityValid(r.metrics[0])).map(r=>r.metrics[0].eccentricity));
      let corners=[2,3,4,5].map(i=>({width:sqrSummary(valid.filter(r=>r.metrics[i]?.valid).map(r=>r.metrics[i].fwhm)),
         ratio:sqrSummary(valid.filter(r=>r.metrics[i]?.valid&&r.metrics[1]?.valid).map(r=>r.metrics[i].fwhm/r.metrics[1].fwhm)),
         eccentricity:sqrSummary(valid.filter(r=>sqrEccentricityValid(r.metrics[i])).map(r=>r.metrics[i].eccentricity))}));
      let scoring=new Map;
      for(let r of all){r.candidate=false;r.score=null;r.scoreWithoutCorners=null;r.scoreWithCorners=null;r.scoreCorrelated=null;r.rankCorrelated=null;r.rank=null;r.reasons=[];r.cornerSeverity=null;r.measuredCornerSeverity=null;r.worstCorner='';
         r.mainIssue='Missing data';r.mainIssueDetail='Field measurement unavailable.';r.scoreContributions=[];r.dataReviewReasons=[];r.needsDataReview=true;r.insufficientCorners=0;
         r.guidingIgnored=sqrIgnoreGuiding(r,o);
         let cs=[];for(let i=2;i<6;++i)if(r.metrics[i]?.valid&&Number.isFinite(corners[i-2].width.median)){let c=corners[i-2],region=SQR_REGIONS[i],tests=[
            {issue:'Large corner stars',name:'Large '+region.toLowerCase()+' FWHM',value:sqrBad(r.metrics[i].fwhm,c.width,false)},
            {issue:'Large corner stars',name:'High '+region.toLowerCase()+' / center FWHM ratio',value:r.metrics[1]?.valid?sqrBad(r.metrics[i].fwhm/r.metrics[1].fwhm,c.ratio,false):0},
            {issue:'Elongated stars',name:'High '+region.toLowerCase()+' eccentricity',value:sqrEccentricityValid(r.metrics[i])?sqrBad(r.metrics[i].eccentricity,c.eccentricity,false):0}];
            tests.sort((a,b)=>b.value-a.value);cs.push({...tests[0],region});}
         cs.sort((a,b)=>b.value-a.value);let corner=cs.length?cs[0].value:null;
         r.measuredCornerSeverity=r.cornerSeverity=corner;r.worstCorner=cs.length?cs[0].region:'';
         let m=r.metrics[0];if(!m?.valid){r.candidate=!r.isMaster;r.reasons.push('Field measurement unavailable');
            r.dataReviewReasons=['Field PSF measurements are unavailable or insufficient'+(m?.error?': '+m.error:'.')];
            if(m&&(Number.isFinite(m.stars)||Number.isFinite(m.psfCount)))r.dataReviewReasons.push('Detected stars: '+sqrFmt(m.stars,0)+'; PSF fits: '+sqrFmt(m.psfCount,0)+'; required minimum for each: '+o.minStars+'.');
            if(r.guiding)r.reasons.push(r.guiding.scorable?r.guiding.category:r.guiding.reason);continue;}
         // Retain the master's corner diagnostic, but never build scoring parts for it.
         if(r.isMaster)continue;
         let parts=[{key:'signalWeight',issue:'Weak signal',name:'Low PSF signal weight',z:sqrBad(m.signal,signal,true)},
            {key:'starsWeight',issue:'Few stars',name:'Low star count',z:sqrBad(m.stars,stars,true)},
            {key:'fwhmWeight',issue:'Large stars',name:'Large field FWHM',z:sqrBad(m.fwhm,fwhm,false)}];
         if(sqrEccentricityValid(m))parts.push({key:'eccentricityWeight',issue:'Elongated stars',name:'High field eccentricity',z:sqrBad(m.eccentricity,eccentricity,false)});
         if(guideAvailable&&!r.isMaster&&r.guiding?.scorable)parts.push({key:'guideWeight',issue:r.guiding.category,name:r.guiding.category,z:r.guidePenalty,guiding:true});
         let skyPart=withCorners=>{let value=sqrSkyScoreValue(r,o,withCorners);return value===null?null:{key:'backgroundWeight',kpi:sky.key,issue:sky.issue,name:sky.issue,z:sqrBad(value,withCorners?skyCorner:skyField,sky.higher)};};
         scoring.set(r,{parts,skyField:skyPart(false),skyCorner:skyPart(true),corner:cs[0],cornerCount:cs.length,missingShape:[2,3,4,5].some(i=>!sqrEccentricityValid(r.metrics[i]))});
      }
      let manual={...o,correlationOnly:false,guideWeight:guideEnabled?o.guideWeight:0};
      sqrMeanComparisons(g,manual,guideEnabled);
      for(let r of all){let data=scoring.get(r);if(!data)continue;
         let missingFieldShape=o.eccentricityWeight>0&&!sqrEccentricityValid(r.metrics[0]);
         r.scoreWithoutCorners=missingFieldShape||o.backgroundWeight>0&&!data.skyField?null:sqrWeightedScore(sqrScoreParts(r,data,manual,false));
         if(data.cornerCount===4&&!data.missingShape&&!missingFieldShape&&r.metrics[1]?.valid&&(!(o.backgroundWeight>0)||data.skyCorner))r.scoreWithCorners=sqrWeightedScore(sqrScoreParts(r,data,manual,true));
         sqrApplyScore(r,data,manual,guideEnabled);
      }
      sqrAssignRanks(all,'scoreWithoutCorners','rankWithoutCorners');sqrAssignRanks(all,'scoreWithCorners','rankWithCorners');
      let manualStates=new Map(all.map(r=>[r,sqrScoreState(r)]));
      {
         let components=[...sqrScoreComponents(o).slice(0,-1),...SQR_CORNER_COMPONENTS].map(c=>sqrScoreCorrelation(g,c,o,guideAvailable));
         let auto={...o,correlationOnly:true,rankOfRanks:false};for(let c of [...SQR_SCORE_COMPONENTS,...SQR_CORNER_COMPONENTS])auto[c.weight]=0;
         for(let c of components)auto[c.weight]=c.included?1:0;
         let autoGuide=auto.guideWeight>0;
         // Select the already defined composite, just like every other KPI.
         // Recomputing it from R3's selected components would change its meaning.
         let breadth=sqrScoreCorrelation(g,SQR_SCORE_COMPONENTS[SQR_SCORE_COMPONENTS.length-1],o,guideAvailable);
         components.push(breadth);auto.belowMeanWeight=breadth.included?1:0;
         g.correlationScoring={components,available:components.some(c=>c.included),weights:Object.fromEntries([...SQR_SCORE_COMPONENTS,...SQR_CORNER_COMPONENTS].map(c=>[c.weight,auto[c.weight]]))};
         let selectedCorners=SQR_CORNER_COMPONENTS.filter(c=>auto[c.weight]>0);
         // With no eligible KPIs, preserve manual evaluation and leave the R3
         // score/rank null. R4 must omit R3 rather than count manual ranks twice.
         if(g.correlationScoring.available)for(let r of all){let data=scoring.get(r);if(data){
            data.regionalParts=[];
            for(let c of selectedCorners){let value=sqrKPIValue(r,c);if(value===null)continue;
               // Reuse the already computed per-corner robust baselines.
               let baseline=corners[c.region-2][c.metric==='fwhm'?'width':'eccentricity'];
               data.regionalParts.push({key:c.weight,kpi:c.kpi,issue:c.metric==='fwhm'?'Large corner stars':'Elongated stars',name:c.label,z:sqrBad(value,baseline,false)});
            }
            sqrApplyScore(r,data,auto,autoGuide);r.scoreCorrelated=r.score;
         }}
         sqrAssignRanks(all,'scoreCorrelated','rankCorrelated');
      }
      sqrRankOfRanks(all,o.measureCorners);
      // Restore every manual tooltip and missing-data flag when R3 is only a
      // comparison column. R4 combines the ranks and retains both data checks.
      for(let r of all){let automatic=sqrScoreState(r);
         // Also discard legacy scores/flags when a cached master has missing measurements.
         if(r.isMaster){sqrExcludeMasterScore(r);continue;}
         if(!o.correlationOnly||o.rankOfRanks||!g.correlationScoring.available)Object.assign(r,manualStates.get(r));
         if(o.rankOfRanks)sqrApplyRankOfRanks(r,automatic);
      }
      // Worst-first ranks and REVIEW quotas retain their meaning after inversion.
      let sorted=valid.slice().sort((a,b)=>(a.score??Infinity)-(b.score??Infinity)||a.registered.path.localeCompare(b.registered.path));
      let count=Math.ceil(sorted.length*o.percent/100);for(let i=0;i<sorted.length;++i){sorted[i].rank=i+1;sorted[i].candidate=i<count||sorted[i].needsDataReview;}
      if(sqrRecommendationReviewComplete(g,o,guideAvailable))for(let r of g.rows)r.candidate=false;
      sqrRefreshTrailReview(g);
      g.shortlistCount=count;g.shortlistPopulation=sorted.length;g.rows.sort((a,b)=>Number(sqrNeedsReview(b))-Number(sqrNeedsReview(a))||(a.score??-1)-(b.score??-1)||a.registered.path.localeCompare(b.registered.path));
   }
}
function sqrWriteJSON(path,value){TGFileProtection.writeTextFile(path,JSON.stringify(value,null,2),"Move/undo journal");}
// Choose the highest-scoring kept subframe. Signal strength and filename provide
// deterministic tie-breaks; the master can never become a "best subframe".
function sqrBestRow(group){return group.rows.filter(r=>!r.isMaster&&r.metrics[0]?.valid&&Number.isFinite(r.score)&&!r.reject&&!r.moved)
   .sort((a,b)=>b.score-a.score||b.metrics[0].signal-a.metrics[0].signal||a.registered.path.localeCompare(b.registered.path))[0]||null;}
function sqrReference(group,choice,row=null){
   if(choice==='trail')return {path:row?.trailBands?.length?row.registered.path:'',label:'UNMASKED'};
   if(choice==='best'||choice==='mosaic-best'){let best=sqrBestRow(group);return {path:best?.registered.path||'',label:'BEST SUBFRAME',row:best};}
   return {path:group.master||'',label:'MASTER'};
}
/** Preflight every marked original before any move begins.
 * Check source containment, light-frame identity, unchanged fingerprints and
 * destination collisions. Preserve relative paths and refuse overwrites.
 * Returned entries retain row references for updating the in-memory review. */
function sqrMovePlan(session){
   let o=session.options;if(!o.destination.trim())throw new Error('Choose a rejected-originals folder.');
   let root=sqrPath(o.originals),dest=sqrPath(o.destination);
   TGFileProtection.assertOutsideInstallation(root,"Original-light folder");
   TGFileProtection.assertOutsideInstallation(dest,"Rejected-originals folder");
   if(sqrKey(dest)===sqrKey(root))throw new Error('The destination must differ from the originals folder.');
   if(sqrUnder(dest,sqrPath(o.wbpp)))throw new Error('Choose a destination outside the WBPP output folder.');
   let plan=[],sources={},targets={};
   for(let r of sqrDecisionRows(session))if(r.reject&&!r.moved){
      if(r.isMaster)throw new Error('Integrated masters cannot be rejected or moved.');
      if(!r.original||!['Verified','Manually verified'].includes(r.match))throw new Error('Resolve the original-file association for '+sqrFileName(r.registered.path));
      let source=sqrPath(r.original.path);if(!sqrUnder(source,root)||sqrUnder(source,sqrPath(o.wbpp)))throw new Error('Original lies outside the selected original-light root.');
      if(sqrFingerprint(source)!==r.original.fingerprint)throw new Error('Original changed since scanning: '+source);
      let meta=sqrMetadata(source);if(!sqrIsLight(meta)||!sqrCompatible(r.registered||r.original,meta))throw new Error('Original metadata no longer matches: '+source);
      let relative=source.slice(root.length+1),target=dest+'/'+relative;
      TGFileProtection.assertOutsideInstallation(source,"Original light to move");
      TGFileProtection.assertOutsideInstallation(target,"Rejected original destination");
      if(!sqrUnder(target,dest)||sources[sqrKey(source)]||targets[sqrKey(target)]||File.exists(target))throw new Error('Duplicate source or occupied destination: '+target);
      sources[sqrKey(source)]=true;targets[sqrKey(target)]=true;plan.push({source:source,target:target,fingerprint:r.original.fingerprint,registered:r.registered?.path||'',status:'planned',row:r});
   }
   if(!plan.length)throw new Error('No rejected originals are selected.');return plan;
}
/** Execute a validated plan with a journal written before the first file move.
 * Per-file rechecks catch changes since preflight. Journal states distinguish
 * planned, in-progress and completed files; failures do not imply a rollback.
 * Only verified original paths are moved; processed frames remain available. */
function sqrMove(session,notify){
   let plan=sqrMovePlan(session),dest=sqrPath(session.options.destination);
   TGFileProtection.assertOutsideInstallation(dest,"Rejected-originals folder");
   let journalPath=dest+'/SQR-moves-'+sqrStamp()+'.json';
   TGFileProtection.assertOutsideInstallation(journalPath,"Move journal");
   if(File.exists(journalPath)||File.directoryExists(journalPath))throw new Error('Move journal already exists: '+journalPath);
   if(!File.directoryExists(dest))File.createDirectory(dest,true);
   let journal={schema:1,created:new Date().toISOString(),originals:sqrPath(session.options.originals),destination:dest,wbpp:sqrPath(session.options.wbpp),
      moves:plan.map(p=>({source:p.source,target:p.target,fingerprint:p.fingerprint,registered:p.registered,status:'planned'}))};
   sqrWriteJSON(journalPath,journal);
   session.lastMoveJournal=journalPath;
   try{for(let i=0;i<plan.length;++i){
      let p=plan[i];sqrTick(notify,'Moving original '+(i+1)+' / '+plan.length);
      if(sqrFingerprint(p.source)!==p.fingerprint||File.exists(p.target))throw new Error('Files changed after move-plan validation.');
      TGFileProtection.assertOutsideInstallation(p.source,'Original light to move');
      TGFileProtection.assertOutsideInstallation(p.target,'Rejected original destination');
      let dir=sqrDir(p.target);if(!File.directoryExists(dir))File.createDirectory(dir,true);
      journal.moves[i].status='moving';sqrWriteJSON(journalPath,journal);
      TGFileProtection.assertOutsideInstallation(p.source,"Original light to move");
      TGFileProtection.assertOutsideInstallation(p.target,"Rejected original destination");
      File.moveFile(p.target,p.source);
      // Update memory before writing the completed entry, so reporting errors do not re-enable a moved source.
      p.row.moved=true;p.row.movedTo=p.target;p.row.moveJournal=journalPath;journal.moves[i].status='moved';
      journal.moves[i].destinationFingerprint=sqrFingerprint(p.target);sqrWriteJSON(journalPath,journal);
   }}catch(e){journal.error=String(e);sqrWriteJSON(journalPath,journal);throw new Error(String(e)+'\nMove journal: '+journalPath);}
   return {count:plan.length,journal:journalPath};
}

// Restore only paths recorded by a move journal. Resolve each path before
// containment checks, and refuse linked files/directories along either route.
function sqrRestorePath(value){
   if(typeof value!=='string'||!/^([a-z]:[\\/]|[\\/]{2}|\/)/i.test(value))throw new Error('Move journal contains a non-absolute path.');
   return sqrPath(value);
}
function sqrNoLinkedPath(path){
   TGFileProtection.assertOutsideInstallation(path,"Move/undo location");
   for(let p=path;p;){let info=new FileInfo(p);if(info.isSymbolicLink||info.isRedirectionPoint)throw new Error('Linked restore paths are not supported: '+p);
      let parent=sqrDir(p).replace(/\/$/,'');if(!parent||sqrKey(parent)===sqrKey(p)||/^[a-z]:$/i.test(parent))break;p=parent;}
}
function sqrRestoreAvailability(entry){
   try{
      sqrNoLinkedPath(entry.source);sqrNoLinkedPath(entry.target);
      if(!['moved','moving'].includes(entry.status))return 'No completed move recorded';
      if(File.exists(entry.source)||File.directoryExists(entry.source)){
         if(!File.exists(entry.target)&&!File.directoryExists(entry.target)&&sqrFingerprint(entry.source)===entry.fingerprint)return 'Already restored';
         return 'Original path is occupied; no overwrite';
      }
      if(sqrFingerprint(entry.target)!==(entry.destinationFingerprint||entry.fingerprint))return 'Moved file has changed';
      return '';
   }catch(e){return String(e).replace(/^Error: /,'');}
}
/** A journal is data, not an instruction to move arbitrary files. Require the
 * exact preserved relative path and reject duplicate/overlapping destinations.
 * Older journals without wbpp remain usable; image identity is checked below. */
function sqrReadMoveJournal(path,scan=null){
   path=sqrPath(path);let journal=JSON.parse(File.readTextFile(path));
   if(journal.schema!==1||!Array.isArray(journal.moves)||!journal.moves.length)throw new Error('Choose an SQR-moves journal containing original-light moves.');
   let root=sqrRestorePath(journal.originals),dest=sqrRestorePath(journal.destination),wbpp=journal.wbpp?sqrRestorePath(journal.wbpp):'',seen=new Set;
   if(scan&&(sqrKey(root)!==sqrKey(scan.originals)||sqrKey(dest)!==sqrKey(scan.destination)||(wbpp&&sqrKey(wbpp)!==sqrKey(scan.wbpp))))return null;
   TGFileProtection.assertOutsideInstallation(root,'Restore destination folder');
   TGFileProtection.assertOutsideInstallation(dest,'Rejected-originals folder');
   if(sqrKey(root)===sqrKey(dest)||sqrKey(sqrPath(sqrDir(path)))!==sqrKey(dest))throw new Error('The move journal must be in its recorded rejection folder.');
   let entries=journal.moves.map((move,index)=>{
      let source=sqrRestorePath(move.source),target=sqrRestorePath(move.target);
      if(!sqrUnder(source,root)||sqrKey(source)===sqrKey(root)||
         sqrKey(target)!==sqrKey(dest+'/'+source.slice(root.length+1))||!sqrImageFile(source)||
         (wbpp&&(sqrUnder(source,wbpp)||sqrUnder(target,wbpp)))||
         typeof move.fingerprint!=='string'||!/^\d+\|.+/.test(move.fingerprint))throw new Error('Invalid original-light path or fingerprint in move journal: '+source);
      for(let p of [source,target]){if(seen.has(sqrKey(p)))throw new Error('Duplicate path in move journal: '+p);seen.add(sqrKey(p));}
      let entry={...move,source,target,index};entry.problem=sqrRestoreAvailability(entry);return entry;
   });
   return {path,root,dest,entries};
}
/** Recover only moves backed by a live journal entry and an exact registered
 * path or saved WBPP association. Undo's availability check also handles a
 * move interrupted before the journal's final write, and ignores restorations. */
function sqrScanMovedOriginals(o,registered,imported,warnings,notify){
   const moves=new Map;
   if(!o.destination||!File.directoryExists(o.destination))return moves;
   const paths=[],dest=sqrPath(o.destination),find=new FileFind;
   const scope={originals:sqrPath(o.originals),destination:dest,wbpp:sqrPath(o.wbpp)};
   if(find.begin(dest+'/SQR-moves-*.json'))try{do{
      if(find.isFile&&!find.isSymbolicLink)paths.push(dest+'/'+find.name);
   }while(find.next());}finally{find.end();}
   if(!paths.length)return moves;
   const selected=new Set(registered.map(sqrKey)),sources=imported?new Set(imported.originals.map(sqrKey)):null,links=new Map;
   if(imported)for(const [reg,source] of imported.links){
      const key=sqrKey(source);
      if(!links.has(key))links.set(key,[]);
      links.get(key).push(reg);
   }
   // Prefer the most recent journal after Undo followed by another move.
   for(const path of paths.sort().reverse()){
      sqrTick(notify,'Checking moved originals: '+sqrFileName(path));
      try{
         sqrNoLinkedPath(path);
         const record=sqrReadMoveJournal(path,scope);
         for(const entry of record?.entries||[]){
            if(entry.problem)continue;
            const source=sqrKey(entry.source),reg=sqrKey(entry.registered||'');
            if(sources&&!sources.has(source))continue;
            const keys=new Set(links.get(source)||[]);
            if(selected.has(reg)&&!imported?.links.has(reg))keys.add(reg);
            const logOnly=entry.registered==='';
            if(logOnly)keys.add('original:'+entry.source);
            if(!keys.size)continue;
            let original;
            try{original={...sqrMetadata(entry.target),path:entry.source,fingerprint:entry.fingerprint};}
            catch(e){warnings.push(entry.target+': '+String(e));continue;}
            if(!sqrIsLight(original))continue;
            for(const key of keys){
               if(!moves.has(key))moves.set(key,{original,target:entry.target,journal:path,logOnly});
               else if(sqrKey(moves.get(key)?.original.path||'')!==source)moves.set(key,null);
            }
         }
      }catch(e){warnings.push('Could not read moved originals from '+path+': '+String(e));}
   }
   return moves;
}
/** Validate every selected file before restoring any. A changed file, occupied
 * original path or non-light image blocks the selected plan without data loss. */
function sqrRestorePlan(record,indices){
   if(!indices.length)throw new Error('Select at least one moved original to restore.');
   let seen=new Set;
   return indices.map(index=>{
      if(!Number.isInteger(index)||!record.entries[index]||seen.has(index))throw new Error('Invalid restore selection.');seen.add(index);
      let entry=record.entries[index],problem=sqrRestoreAvailability(entry);if(problem)throw new Error(problem+': '+entry.source);
      let metadata=sqrMetadata(entry.target);if(!sqrIsLight({...metadata,path:entry.source}))throw new Error('The moved file is not an original light: '+entry.target);
      return {...entry,metadata};
   });
}
function sqrRestoreIdentity(plan){return JSON.stringify(plan.map(p=>[p.source,p.target,p.fingerprint,p.destinationFingerprint||'',p.registered||'']));}
function sqrMarkRestored(session,entry){
   for(let row of sqrDecisionRows(session)){
      if(row.isMaster)continue;
      let sameOriginal=row.original&&sqrKey(row.original.path)===sqrKey(entry.source),sameRegistered=row.registered&&sqrKey(row.registered.path)===sqrKey(entry.registered||'');
      if((sameOriginal||sameRegistered)&&sqrCompatible(row.registered||row.original,entry.metadata)){
         row.original={...entry.metadata,path:entry.source,fingerprint:sqrFingerprint(entry.source)};row.match='Verified';
         row.moved=false;row.reject=false;delete row.movedTo;delete row.moveJournal;
      }
   }
}
/** Retain the original move journal. Each undo has its own progress journal,
 * so partial restores can be retried from the original journal after restart.
 * Actual source/target presence and fingerprints determine eligibility. */
function sqrRestore(journalPath,indices,session,notify,expectedPlan){
   let record=sqrReadMoveJournal(journalPath),plan=sqrRestorePlan(record,indices);
   if(expectedPlan&&sqrRestoreIdentity(plan)!==sqrRestoreIdentity(expectedPlan))throw new Error('The move journal changed. Review the restore plan again.');
   let path=record.dest+'/SQR-undo-'+sqrStamp()+'.json';
   if(File.exists(path))throw new Error('Undo journal already exists: '+path);
   let journal={schema:1,operation:'undo',created:new Date().toISOString(),moveJournal:record.path,
      restores:plan.map(p=>({source:p.target,target:p.source,fingerprint:p.destinationFingerprint||p.fingerprint,status:'planned'}))};
   sqrWriteJSON(path,journal);
   try{for(let i=0;i<plan.length;++i){
      let entry=plan[i];sqrTick(notify,'Restoring original '+(i+1)+' / '+plan.length);
      let problem=sqrRestoreAvailability(entry);if(problem)throw new Error(problem+': '+entry.source);
      TGFileProtection.assertOutsideInstallation(entry.source,"Restored original destination");
      TGFileProtection.assertOutsideInstallation(entry.target,"Rejected original to restore");
      let dir=sqrDir(entry.source);if(!File.directoryExists(dir))File.createDirectory(dir,true);
      journal.restores[i].status='restoring';sqrWriteJSON(path,journal);
      TGFileProtection.assertOutsideInstallation(entry.source,"Restored original destination");
      TGFileProtection.assertOutsideInstallation(entry.target,"Rejected original to restore");
      File.moveFile(entry.source,entry.target);
      // Reflect a successful move before journal/reporting failures can occur.
      journal.restores[i].status='restored';sqrMarkRestored(session,entry);
      journal.restores[i].restoredFingerprint=sqrFingerprint(entry.source);sqrWriteJSON(path,journal);
   }}catch(e){journal.error=String(e);try{sqrWriteJSON(path,journal);}catch(writeError){journal.error+='\nUnable to update undo journal: '+String(writeError);}
      throw new Error(journal.error+'\nUndo journal: '+path+'\nReopen the original move journal to check remaining files.');}
   return {count:plan.length,journal:path};
}

/* Recommendations use the current Review Score without changing Score/R1--R4.
 * Freeze its best-first ordering, then test nested sets against the SNR limit.
 * Nothing below moves files or changes rejection decisions implicitly. */
function sqrRecommendationOptions(o={}){
   let v=o.recommendation||{};
   return {snrPercent:Number.isFinite(v.snrPercent)?Math.max(50,Math.min(100,v.snrPercent)):95,
      minFrames:Number.isInteger(v.minFrames)?Math.max(7,Math.min(100000,v.minFrames)):20,
      includeRejected:v.includeRejected===true,useROI:!!v.useROI,roi:Array.isArray(v.roi)&&v.roi.length===4?v.roi.slice():null,
      geometry:Array.isArray(v.geometry)?v.geometry.slice():null,
      plotKPI:SQR_RECOMMENDATION_KPIS.some(k=>k.key===v.plotKPI)?v.plotKPI:'score'};
}
const SQR_RECOMMENDATION_KPIS=[
   {key:'fwhm',label:'FWHM (px)',digits:2,description:'Trial-stack FWHM measured over the common usable field. Lower is sharper. Shown for comparison; the recommendation is selected by mean retained Review Score.'},
   {key:'score',label:'Score (retained mean)',digits:3,unitInterval:true,description:'Arithmetic mean of the retained subframes’ Review scores at analysis time. The highest mean meeting the SNR and minimum-count limits is recommended. This is not a score assigned to the integrated image.'},
   {key:'signal',label:'PSF signal weight',digits:6,description:'PSF signal weight measured on each trial stack by ImageAnalysis. Higher indicates better signal quality.'},
   {key:'psfSNR',label:'PSF SNR',digits:2,description:'Measured trial-stack PSF SNR, converted from a power ratio to an amplitude ratio. Higher is better.'},
   {key:'stars',label:'Stars',digits:0,description:'Stars detected independently in each trial stack across the common usable field, regardless of the object ROI. The area stays fixed, but noise and star profiles can change which stars are detected. This is not a fixed matched-star sample.'},
   {key:'eccentricity',label:'Eccentricity',digits:3,unitInterval:true,description:'Measured trial-stack stellar eccentricity. Lower is rounder.'},
   {key:'noise',label:'Noise (sigma)',digits:6,description:'Noise measured in the trial stack by ImageAnalysis, in the common normalized test-image units. Lower is quieter.'},
   {key:'exposureHours',label:'Retained exposure (h)',digits:2,description:'Total exposure time of the retained subframes, in hours.'},
   {key:'effective',label:'Effective frame count',digits:1,description:'Effective count from the fixed integration weights: sum(weights) squared / sum(squared weights). Unequal weights reduce this count.'}
];
/** Display choices do not affect the result. Scores and scoring settings do:
 * they determine the candidate ordering and recommended cutoff. Fingerprints
 * catch changed files without reading image pixels. */
function sqrRecommendationKey(group,o,config,guideAvailable,fingerprint=sqrFingerprint,acceptedRejects=null){
   let guides=!!guideAvailable&&o.guidingMode!=='ignore',sky=sqrSkyScoreChoice(o).key;
   let rows=group.rows.filter(r=>!r.isMaster).map(r=>{
      let file;try{file=fingerprint(r.registered.path);}catch(e){file='unavailable';}
      let field=r.metrics[0]||{},regions=o.measureCorners?[2,3,4,5].map(i=>r.metrics[i]||null):null;
      // Moving a marked frame changes its eligibility when reconsidering it.
      // Moving a reject after accepting that result preserves its history.
      let decision=config.includeRejected&&r.moved&&!acceptedRejects?.has(r)?'moved':!!(r.reject||r.moved);
      return [r.registered.path,file,decision,r.score,field.valid,field.fwhm,field.eccentricity,field.signal,field.stars,field.psfCount,
         regions,r.relativeTransparency,sqrExposure(r),r[sky],guides?[r.guiding?.scorable,r.guideQuality]:null];
   }).sort((a,b)=>a[0].localeCompare(b[0]));
   return JSON.stringify([SQR_VERSION,group.width,group.height,group.channels,group.roi,
      config.snrPercent,config.minFrames,!!config.includeRejected,config.useROI?config.roi:null,
      o.minStars,o.maxFits,o.margin,o.measureCorners?(group.cornerPatch??o.patch):null,!!o.measureCorners,guides,sky,
      !!o.correlationOnly,!!o.rankOfRanks,[...SQR_SCORE_COMPONENTS,...SQR_CORNER_COMPONENTS].map(c=>o[c.weight]),rows]);
}
function sqrRecommendationPlotValue(result,point,kpi){
   if(point.error)return null;
   let value=kpi.key==='exposureHours'?(point.exposure>0?point.exposure/3600:null):point[kpi.key];return Number.isFinite(value)?value:null;
}
function sqrRecommendationFormat(value,kpi){return !Number.isFinite(value)?'—':value!==0&&Math.abs(value)<.0001?value.toExponential(2):value.toFixed(kpi.digits);}
function sqrRecommendationHours(point){return point.exposure>0?(point.exposure/3600).toFixed(2):'—';}
/** Use the same score the user chose in Review, independent of table sorting.
 * R3 provides strongly correlated KPI selection when that score is selected. */
function sqrRecommendationRanking(group,o,includeRejected=false){
   let rows=group.rows.filter(r=>!r.isMaster&&!r.moved&&(includeRejected||!r.reject));
   if(rows.some(r=>!r.metrics[0]?.valid))throw Error(includeRejected?'Every included subframe needs a valid field measurement. Measure the frames again or turn off Include rejected subframes to exclude marked frames.':'Measure all remaining subframes first. Resolve or manually reject frames without valid field measurements.');
   if(rows.some(r=>!Number.isFinite(r.score)||r.score<0||r.score>1))throw Error('Every remaining subframe needs a valid Review Score. Check the score settings and measurements.');
   rows.sort((a,b)=>b.score-a.score||a.registered.path.localeCompare(b.registered.path));
   let scoreMode=o.rankOfRanks?'R4':o.correlationOnly&&group.correlationScoring?.available?'R3':o.measureCorners?'R2':'R1';
   return {rows,scoreMode};
}
function sqrRecommendationGeometry(group,options){
   let field=group.roi;if(!field)throw Error('Measure the group to establish its common usable field.');
   // Integration and ImageAnalysis always use the common field. Only object
   // photometry uses the smaller rectangle with a surrounding-sky margin.
   let crop=field.slice(),photometryCrop=null,aperture=null;
   if(options.useROI){let r=options.roi;
      if(!r||!r.every(Number.isInteger)||r[2]-r[0]<32||r[3]-r[1]<32)throw Error('Specify an object ROI at least 32 × 32 pixels.');
      if(options.geometry&&(options.geometry[0]!==group.width||options.geometry[1]!==group.height))throw Error('The saved ROI belongs to another image size. Select a matching preview or enter its coordinates again.');
      if(r[0]<field[0]||r[1]<field[1]||r[2]>field[2]||r[3]>field[3])throw Error('The object ROI must lie inside the common usable field.');
      let pad=Math.max(64,Math.ceil(Math.max(r[2]-r[0],r[3]-r[1])*.3));
      let sky=[Math.max(field[0],r[0]-pad),Math.max(field[1],r[1]-pad),Math.min(field[2],r[2]+pad),Math.min(field[3],r[3]+pad)];
      let ring=(sky[2]-sky[0])*(sky[3]-sky[1])-(r[2]-r[0])*(r[3]-r[1]);
      if(ring<Math.max(2048,.2*(r[2]-r[0])*(r[3]-r[1])))throw Error('The ROI needs more surrounding sky inside the usable field. Make it smaller or move it away from the edge.');
      photometryCrop=[sky[0]-field[0],sky[1]-field[1],sky[2]-field[0],sky[3]-field[1]];
      aperture=[r[0]-sky[0],r[1]-sky[1],r[2]-sky[0],r[3]-sky[1]];
   }
   return {crop,photometryCrop,aperture};
}
/** Measure only Object SNR on a temporary local crop. Do not change the field
 * image or its selection: the same pixels must reach integration/ImageAnalysis
 * with and without an ROI. Freeze the sky-star mask on the first input frame. */
function sqrRecommendationPhotometry(image,geometry,maskRadius,requirePositive=true){
   if(!geometry.aperture)return null;
   let local=new Image;
   try{
      local.assign(image,new Rect(...geometry.photometryCrop));
      if(!geometry.skyMask)geometry.skyMask=sqrRecommendationSkyMask(local,maskRadius);
      return sqrRecommendationAperture(local,geometry.aperture,geometry.skyMask,requirePositive);
   }finally{local.free();}
}
function sqrRecommendationMedian(values){let a=values.slice().sort((a,b)=>a-b),n=a.length;return n?(a[(n-1)>>1]+a[n>>1])/2:NaN;}
/** Fixed-aperture photometry with a robust surrounding-sky plane. Approximate
 * the background-limited flux variance including short-range covariance (up
 * to three pixels) and uncertainty of the fitted background at the aperture.
 * Do not confuse this with absolute photometry or source-shot-noise modeling. */
function sqrRecommendationSkyMask(image,radius){
   let w=image.width,h=image.height,pixels=new Float32Array(w*h),mask=new Uint8Array(w*h);
   image.getSamples(pixels);let threshold=image.median()+8*sqrRecommendationNoise(image);
   // Freeze a mask beyond bright stellar cores. Clipping cores alone leaves
   // smooth wings that can be mistaken for correlated background noise.
   radius=Math.max(8,Math.min(40,Math.ceil(radius)));
   for(let y=1;y<h-1;++y)for(let x=1;x<w-1;++x){let i=y*w+x,v=pixels[i];
      if(!(v>threshold)||v<pixels[i-1]||v<pixels[i+1]||v<pixels[i-w]||v<pixels[i+w])continue;
      for(let yy=Math.max(0,y-radius);yy<=Math.min(h-1,y+radius);++yy){let dx=Math.floor(Math.sqrt(radius*radius-(yy-y)*(yy-y)));
         mask.fill(1,yy*w+Math.max(0,x-dx),yy*w+Math.min(w,x+dx+1));}
   }
   return mask;
}
function sqrRecommendationAperture(image,rect,skyMask=null,requirePositive=true){
   let w=image.width,h=image.height,pixels=new Float32Array(w*h);image.getSamples(pixels);
   // A sky guard band reduces contamination by the target's faint outskirts.
   // It changes only the background samples, never the fixed object aperture.
   let guard=Math.max(8,Math.round(.25*Math.min(rect[2]-rect[0],rect[3]-rect[1])));
   let inROI=(x,y)=>x>=rect[0]-guard&&x<rect[2]+guard&&y>=rect[1]-guard&&y<rect[3]+guard,samples=[];
   let stride=Math.max(1,Math.ceil(Math.sqrt(w*h/60000)));
   for(let y=0;y<h;y+=stride)for(let x=0;x<w;x+=stride)if(!inROI(x,y)&&!skyMask?.[y*w+x]){
      let v=pixels[y*w+x];if(Number.isFinite(v))samples.push({x:(x-w/2)/w,y:(y-h/2)/h,v});}
   if(samples.length<512)throw Error('Too few surrounding-sky samples for the object ROI.');
   let median=sqrRecommendationMedian(samples.map(p=>p.v)),sigma=1.4826*sqrRecommendationMedian(samples.map(p=>Math.abs(p.v-median)));
   if(!(sigma>0))throw Error('The surrounding sky has no measurable noise.');
   let plane=[median,0,0],inverse=null,used=[];
   for(let pass=0;pass<4;++pass){
      used=samples.filter(p=>Math.abs(p.v-plane[0]-plane[1]*p.x-plane[2]*p.y)<3*sigma);
      if(used.length<512||used.length<samples.length*.5)throw Error('Surrounding sky is contaminated or insufficient. Choose a cleaner object ROI.');
      let a=used.length,b=0,c=0,d=0,e=0,f=0,t=[0,0,0];
      for(let p of used){b+=p.x;c+=p.y;d+=p.x*p.x;e+=p.x*p.y;f+=p.y*p.y;t[0]+=p.v;t[1]+=p.x*p.v;t[2]+=p.y*p.v;}
      let det=a*(d*f-e*e)-b*(b*f-c*e)+c*(b*e-c*d);
      if(!(Math.abs(det)>1e-12))throw Error('Surrounding sky geometry cannot determine a background plane.');
      inverse=[[(d*f-e*e)/det,(c*e-b*f)/det,(b*e-c*d)/det],[(c*e-b*f)/det,(a*f-c*c)/det,(b*c-a*e)/det],[(b*e-c*d)/det,(b*c-a*e)/det,(a*d-b*b)/det]];
      plane=inverse.map(row=>row.reduce((s,v,i)=>s+v*t[i],0));
      sigma=1.4826*sqrRecommendationMedian(used.map(p=>Math.abs(p.v-plane[0]-plane[1]*p.x-plane[2]*p.y)));
      if(!(sigma>0))throw Error('The surrounding sky has no measurable noise.');
   }
   let covariance=1;
   // Sample pairs on the native grid: downsampling the image itself would hide
   // interpolation covariance. Reject bright residuals before accumulating.
   for(let dy=0;dy<=3;++dy)for(let dx=-3;dx<=3;++dx){if(dy===0&&dx<=0)continue;
      let sum=0,count=0;
      for(let p of used){let x=Math.round(p.x*w+w/2),y=Math.round(p.y*h+h/2),xx=x+dx,yy=y+dy;
         if(xx<0||xx>=w||yy>=h||inROI(xx,yy)||skyMask?.[yy*w+xx])continue;
         let a=p.v-plane[0]-plane[1]*p.x-plane[2]*p.y,
            b=pixels[yy*w+xx]-plane[0]-plane[1]*(xx-w/2)/w-plane[2]*(yy-h/2)/h;
         if(!Number.isFinite(b)||Math.abs(b)>3*sigma)continue;sum+=a*b;++count;}
      if(count>256)covariance+=2*sum/count/(sigma*sigma);
   }
   covariance=Math.max(1,covariance);
   let signal=0,area=0,vector=[0,0,0];
   for(let y=rect[1];y<rect[3];++y)for(let x=rect[0];x<rect[2];++x){let v=pixels[y*w+x];
      if(!Number.isFinite(v))throw Error('The object ROI contains invalid pixels.');
      let xx=(x-w/2)/w,yy=(y-h/2)/h;signal+=v-plane[0]-plane[1]*xx-plane[2]*yy;vector[0]++;vector[1]+=xx;vector[2]+=yy;++area;}
   let backgroundVariance=0;for(let i=0;i<3;++i)for(let j=0;j<3;++j)backgroundVariance+=vector[i]*inverse[i][j]*vector[j];
   let variance=sigma*sigma*covariance*(area+Math.max(0,backgroundVariance));
   if(!Number.isFinite(signal)||!Number.isFinite(variance)||!(variance>0))throw Error('Invalid object-aperture signal or noise variance. Check the ROI and its surrounding sky.');
   if(requirePositive&&!(signal>0))throw Error('No positive background-subtracted object signal was measured in the integrated image. Adjust the ROI and its surrounding sky.');
   return {signal,variance,snr:signal/Math.sqrt(variance),background:plane[0],sigma,covariance,skySamples:used.length};
}
function sqrRecommendationNoise(image){
   for(let n=4;n>=2;--n){let a=image.noiseMRS(n);if(a[0]>0&&a[1]>=.01*image.width*image.height)return a[0];}
   let a=image.noiseKSigma();if(!(a[0]>0))throw Error('No usable noise estimate.');return a[0];
}
function sqrRecommendationWrite(path,image,weight){
   TGFileProtection.assertOutsideInstallation(path,"Temporary recommendation image");
   if(File.exists(path)||File.directoryExists(path))throw Error("Temporary recommendation image is occupied.");
   let writer=new FileFormatInstance(new FileFormat('.xisf',false,true));
   try{if(!writer.create(path,'compression-codec none'))throw Error('Cannot create recommendation test image.');
      let description=new ImageDescription;description.bitsPerSample=32;description.ieeefpSampleFormat=true;writer.setOptions(description);
      writer.keywords=[new FITSKeyword('SQRWEIGHT',String(weight),'Fixed PSF signal integration weight')];
      if(!writer.writeImage(image))throw Error('Cannot write recommendation test image.');
   }finally{writer.close();}
}
function sqrRecommendationCrop(row,geometry){
   let image=sqrReadImage(row.registered.path),crop=new Image;
   try{let c=image.numberOfNominalChannels===3?1:0;crop.assign(image,new Rect(...geometry.crop),c,c);return crop;}
   catch(e){crop.free();throw e;}finally{image.free();}
}
// Use identical apertures on aligned pixels. Subtract a local sky annulus,
// and reject clipped peaks, off-center detections and noise-dominated fluxes.
function sqrRecommendationStarFlux(image,star,r){
   let x=Math.round(star.pos.x),y=Math.round(star.pos.y),outer=2*r,side=2*outer+1;
   let rect=new Rect(x-outer,y-outer,x+outer+1,y+outer+1);
   if(rect.x0<0||rect.y0<0||rect.x1>image.width||rect.y1>image.height)return null;
   let pixels=new Float32Array(side*side);image.getSamples(pixels,rect,0);
   let sky=[],sum=0,n=0,mx=0,my=0,peak=0;
   for(let dy=-outer;dy<=outer;++dy)for(let dx=-outer;dx<=outer;++dx){
      let d2=dx*dx+dy*dy,v=pixels[(dy+outer)*side+dx+outer];
      if(d2<=r*r){if(!Number.isFinite(v))return null;sum+=v;++n;mx+=dx*v;my+=dy*v;peak=Math.max(peak,v);}
      else if(d2>=2.25*r*r&&d2<=outer*outer&&Number.isFinite(v))sky.push(v);
   }
   if(peak>=.95||sky.length<30)return null;
   let background=sqrMedian(sky),sigma=1.4826*sqrMedian(sky.map(v=>Math.abs(v-background)));
   let flux=sum-n*background,uncertainty=Math.max(sigma,1e-10)*Math.sqrt(n*(1+n/sky.length));
   return flux>10*uncertainty&&Math.hypot(mx,my)<=flux*Math.max(2,r*.25)?flux:null;
}
// Only needed for incomplete ImageAnalysis throughput. Anchor flux ratios to
// a frame on the known scale if possible; otherwise use a common relative unit.
function sqrRecommendationReferenceStars(row,geometry,radius){
   let image=sqrRecommendationCrop(row,geometry);
   try{
      let detector=new StarDetector;detector.fitPSF=false;detector.upperLimit=.9;detector.allowClusteredSources=false;
      let cells=new Map,stars=[];
      for(let star of detector.stars(image)){
         let cell=Math.floor(6*star.pos.x/image.width)+6*Math.floor(6*star.pos.y/image.height),count=cells.get(cell)||0;
         if(count>=4)continue;
         let flux=sqrRecommendationStarFlux(image,star,radius);
         if(flux!==null){stars.push({pos:star.pos,flux});cells.set(cell,count+1);}
      }
      return stars;
   }finally{image.free();}
}
function sqrRecommendationFluxMatch(crop,stars,radius){
   let ratios=[];
   for(let star of stars){
      let flux=sqrRecommendationStarFlux(crop,star,radius);
      if(flux!==null)ratios.push(Math.log(flux/star.flux));
   }
   let center=sqrMedian(ratios),scatter=1.4826*sqrMedian(ratios.map(v=>Math.abs(v-center)));
   let kept=ratios.filter(v=>Math.abs(v-center)<=Math.max(.03,3*scatter));
   return {count:kept.length,ratio:kept.length>=5&&scatter<=.20?Math.exp(sqrMedian(kept)):null};
}
function sqrRecommendationFluxLevels(rows,levels,geometry){
   let known=i=>Number.isFinite(levels[i])&&levels[i]>0;
   let indices=rows.map((_,i)=>i),anchors=indices.filter(known),missing=indices.filter(i=>!known(i));
   let candidates=(anchors.length?anchors:indices).sort((i,j)=>rows[j].metrics[0].psfCount-rows[i].metrics[0].psfCount);
   let radius=Math.max(6,Math.min(28,Math.ceil(2.5*sqrMedian(rows.map(r=>r.metrics[0].fwhm)))));
   let resolved=levels.slice(),failed=null,matchCounts=new Map;
   for(let index of candidates){
      sqrPreparationAbort();
      let stars=sqrRecommendationReferenceStars(rows[index],geometry,radius);
      if(stars.length<5)continue;
      // Known anchors already share physical units. With no known anchor,
      // accept only a complete set relative to a single reference.
      let trial=anchors.length?resolved:levels.slice(),anchor=anchors.length?levels[index]:1;
      trial[index]=anchor;
      let complete=true;
      for(let i of missing){
         if(Number.isFinite(trial[i])&&trial[i]>0)continue;
         sqrPreparationAbort();let crop=sqrRecommendationCrop(rows[i],geometry),match;
         try{match=sqrRecommendationFluxMatch(crop,stars,radius);}finally{crop.free();}
         if(match.ratio!==null){trial[i]=anchor*match.ratio;continue;}
         matchCounts.set(i,Math.max(matchCounts.get(i)||0,match.count));failed=i;complete=false;
         if(!anchors.length)break;
      }
      if(complete)return trial;
   }
   if(failed===null)throw Error('Could not normalize the test stacks: no candidate reference frame has five usable stars in the common field.');
   throw Error('Cannot establish a reliable stellar scale for '+sqrFileName(rows[failed].registered.path)+' after trying '+candidates.length+' reference frame(s) ('+matchCounts.get(failed)+' matched stars). Inspect this frame in Blink before including it in a recommendation.');
}
/** Temporary, photometrically normalized crops
 * are reused for all trials. All candidates use exactly the same coordinates,
 * scaling, fixed PSF weights and Winsorized pixel-rejection settings. */
function sqrRecommendationPrepare(ranking,geometry,scratch,notify){
   let frames=[],levels=ranking.rows.map(r=>r.relativeTransparency*sqrExposure(r));
   let known=levels.filter(v=>Number.isFinite(v)&&v>0),reference=known.length?sqrRecommendationMedian(known):1;
   let normalizedLevels=levels;
   if(known.length!==levels.length){
      sqrTick(notify,'Measuring reference stars for test-stack normalization');
      normalizedLevels=sqrRecommendationFluxLevels(ranking.rows,levels,geometry);
   }
   let low=Infinity,high=-Infinity,maskRadius=geometry.aperture?6*Math.max(...ranking.rows.map(r=>r.metrics[0].fwhm)):0;
   for(let i=0;i<ranking.rows.length;++i){sqrTick(notify,'Preparing recommendation '+(i+1)+' / '+ranking.rows.length);
      let row=ranking.rows[i],crop=sqrRecommendationCrop(row,geometry);
      try{
         // Zero padding must never improve estimated noise. Edge checking was
         // done during measurement; test the cropped pixels again before use.
         let zeros=0,samples=0,step=Math.max(1,Math.floor(Math.sqrt(crop.width*crop.height/4096)));
         for(let y=0;y<crop.height;y+=step)for(let x=0;x<crop.width;x+=step){let v=crop.sample(x,y,0);
            if(!Number.isFinite(v))throw Error('Invalid pixels in '+sqrFileName(row.registered.path));if(v===0)++zeros;++samples;}
         if(zeros>.01*samples)throw Error('Registration padding or clipped black pixels in the test area: '+sqrFileName(row.registered.path));
         // Faint objects can have signed, noisy single-frame flux. Keep every
         // valid noise measurement; only integrated object SNR must be positive.
         let stats=sqrRecommendationPhotometry(crop,geometry,maskRadius,false);
         // Normalization must also be ROI-independent; a local sky estimate
         // would change the integrated field and all of its quality metrics.
         let matched=!(Number.isFinite(levels[i])&&levels[i]>0);
         let scale=normalizedLevels[i]/reference,background=crop.median();
         let sigma=stats?stats.sigma:sqrRecommendationNoise(crop);
         let minimum=crop.minimum(),maximum=crop.maximum(),range=maximum-minimum;
         if(!(range>0)||!Number.isFinite(minimum)||!Number.isFinite(maximum))throw Error('Invalid image range.');
         let normalizedLow=(minimum-background)/scale,normalizedHigh=(maximum-background)/scale;
         low=Math.min(low,normalizedLow);high=Math.max(high,normalizedHigh);
         // Never serialize negative intermediates: file-format out-of-range
         // policies may alter them on read. Encode each crop reversibly first;
         // the second pass converts it to ONE common affine scale for all sets.
         crop.apply(minimum,ImageOp_Sub);crop.apply(.9/range,ImageOp_Mul);crop.apply(.05,ImageOp_Add);
         let weight=row.metrics[0].signal,path=scratch+'/crop-'+i+'.xisf';
         sqrRecommendationWrite(path,crop,weight);
         frames.push({row,path,weight,matched,variance:(stats?stats.variance:sigma*sigma)/(scale*scale),
            signal:stats?stats.signal/scale:1,score:row.score,fwhm:row.metrics[0].fwhm,exposure:sqrExposure(row),normalizedLow,normalizedRange:range/scale});
      }finally{crop.free();}
   }
   // A single affine transform keeps every temporary image inside [0.05,.95].
   // Never clip peaks or rescale frames separately: SNR and relative weights
   // must survive this display-safe range conversion unchanged.
   if(!Number.isFinite(low)||!(high>low))throw Error('Invalid pixel range in recommendation images.');
   let range=high-low;
   for(let i=0;i<frames.length;++i){
      sqrTick(notify,'Normalizing test crop '+(i+1)+' / '+frames.length);
      let f=frames[i],cropPath=f.path,inputPath=scratch+'/input-'+i+'.xisf',im=sqrReadImage(cropPath);
      try{
         let gain=f.normalizedRange/range,offset=.05+.9*(f.normalizedLow-low)/range-.05*gain;
         im.apply(gain,ImageOp_Mul);im.apply(offset,ImageOp_Add);
         sqrRecommendationWrite(inputPath,im,f.weight);
      }finally{im.free();}
      // Integration reads the common-scale input. Release this frame's
      // first-pass crop as soon as that input has been written successfully.
      f.path=inputPath;TGFileProtection.removeFile(cropPath,'Temporary recommendation crop');
   }
   return frames;
}
/** Cumulative estimates are O(N), with signal fixed across cutoffs to avoid
 * rewarding positive noise fluctuations in individual aperture measurements. */
function sqrRecommendationCurve(frames,minFrames){
   let signal=sqrRecommendationMedian(frames.map(f=>f.signal)),sumW=0,sumW2=0,sumV=0,sumScore=0,exposure=0,curve=[];
   // The shared flux cancels in modeled SNR retention ratios. If its noisy
   // estimate is nonpositive, use unit flux to propose counts for native tests.
   if(!(signal>0))signal=1;
   for(let i=0;i<frames.length;++i){let f=frames[i];sumW+=f.weight;sumW2+=f.weight*f.weight;sumV+=f.weight*f.weight*f.variance;sumScore+=f.score;
      exposure=exposure!==null&&f.exposure>0?exposure+f.exposure:null;
      if(i+1>=minFrames)curve.push({keep:i+1,snr:signal*sumW/Math.sqrt(sumV),score:sumScore/(i+1),exposure,effective:sumW*sumW/sumW2});}
   return curve;
}
function sqrRecommendationBest(points,percent){
   let valid=points.filter(p=>p.snr>0&&Number.isFinite(p.score)&&!p.error);if(!valid.length)return null;
   let peak=Math.max(...valid.map(p=>p.snr)),eligible=valid.filter(p=>p.snr+1e-12>=peak*percent/100);
   let highest=Math.max(...eligible.map(p=>p.score));
   // Only numerical ties prefer more frames; FWHM is not a decision input.
   return eligible.filter(p=>highest-p.score<=1e-12).sort((a,b)=>b.keep-a.keep)[0];
}
function sqrRecommendationTrialCounts(curve,percent){
   let counts=new Set,first=curve[0].keep,last=curve[curve.length-1].keep;
   for(let i=0;i<5;++i)counts.add(Math.round(first+(last-first)*i/4));
   let best=sqrRecommendationBest(curve,percent),peak=curve.slice().sort((a,b)=>b.snr-a.snr)[0];
   for(let n of [best?.keep,peak?.keep])if(n>=first&&n<=last)counts.add(n);
   return [...counts].sort((a,b)=>b-a);
}
function sqrRecommendationTrial(frames,keep,geometry,scratch,o){
   let p=new ImageIntegration,window=null,path=scratch+'/trial-'+keep+'.xisf';
   try{
      p.images=frames.slice(0,keep).map(f=>[true,f.path,'','']);p.combination=ImageIntegration.Average;
      p.weightMode=ImageIntegration.KeywordWeight;p.weightKeyword='SQRWEIGHT';p.minWeight=0;
      p.normalization=ImageIntegration.NoNormalization;p.rejectionNormalization=ImageIntegration.NoRejectionNormalization;
      p.rejection=ImageIntegration.WinsorizedSigmaClip;p.sigmaLow=4;p.sigmaHigh=3;
      p.rangeClipLow=false;p.rangeClipHigh=false;p.generateRejectionMaps=false;p.generateDrizzleData=false;
      p.generateIntegratedImage=true;p.closePreviousImages=false;p.showImages=false;p.noGUIMessages=true;
      p.evaluateSNR=false;p.useCache=true;p.autoMemorySize=true;p.autoMemoryLimit=.35;
      if(!p.executeGlobal())throw Error('Test integration failed.');
      window=ImageWindow.windowById(p.integrationImageId);if(window.isNull)throw Error('Test integration returned no image.');
      if(console.abortRequested)throw Error('Operation aborted.');
      let aperture=sqrRecommendationPhotometry(window.mainView.image,geometry);
      sqrRecommendationWrite(path,window.mainView.image,1);
      let ia=new ImageAnalysis;ia.task=ImageAnalysis.Task_Measure;ia.frames=[[true,path,'','']];ia.fileCache=false;
      ia.extendedMeasurements=false;ia.psfFit=ImageAnalysis.PSF_Moffat4;ia.psfFitCircular=false;ia.maxPSFFits=o.maxFits;
      ia.approvalExpression='';ia.weightingExpression='';ia.onError=ImageAnalysis.OnError_Continue;
      if(!ia.executeGlobal()||!ia.measurements.length)throw Error('No PSF measurement for test integration.');
      // ImageAnalysis PSFSNR is a ratio of powers. Convert to amplitude SNR so
      // that a 95% limit has the same meaning as the object-aperture ratio.
      let m=ia.measurements[0],metric=sqrMeasurement(m,o.minStars,false),snr=aperture?aperture.snr:Math.sqrt(m[ImageAnalysis.measurements_measurementPSFSNR]);
      if(!metric.valid)throw Error('Insufficient valid PSF stars in the common usable field. Check the field measurements and Minimum stars setting.');
      if(!(snr>0))throw Error('No positive SNR in the test stack. Check the object ROI or field signal.');
      return {keep,snr,fwhm:metric.fwhm,stars:metric.stars,signal:metric.signal,eccentricity:metric.eccentricity,
         psfSNR:Math.sqrt(m[ImageAnalysis.measurements_measurementPSFSNR]),noise:m[ImageAnalysis.measurements_measurementNoise],aperture};
   }finally{if(window&&!window.isNull)window.forceClose();if(File.exists(path))TGFileProtection.removeFile(path,"Temporary image");}
}
function sqrRecommendationAnalyze(group,o,options,guideAvailable,notify){
   let ranking=sqrRecommendationRanking(group,o,options.includeRejected),geometry=sqrRecommendationGeometry(group,options);
   if(ranking.rows.length<options.minFrames)throw Error('Only '+ranking.rows.length+' eligible frames remain; the minimum is '+options.minFrames+'.');
   let scratch=sqrPath(File.systemTempDirectory)+'/.sqr-recommendation-'+sqrStamp();
   TGFileProtection.assertOutsideInstallation(scratch,'Temporary recommendations');
   if(File.exists(scratch)||File.directoryExists(scratch))throw Error('Temporary recommendation directory is occupied.');
   File.createDirectory(scratch,true);
   try{
      let frames=sqrRecommendationPrepare(ranking,geometry,scratch,notify),curve=sqrRecommendationCurve(frames,options.minFrames),trials=[];
      const test=keep=>{sqrTick(notify,'Testing stack: keep '+keep+' / '+frames.length);
         try{let measured=sqrRecommendationTrial(frames,keep,geometry,scratch,o);trials.push({...curve.find(p=>p.keep===keep),...measured});}
         catch(e){if(console.abortRequested)throw e;trials.push({keep,error:String(e)});}};
      for(let keep of sqrRecommendationTrialCounts(curve,options.snrPercent))test(keep);
      // Refine the best coarse cutoff with adjacent counts, reusing the same
      // normalized inputs. Keep failed trials visible, never silently omit them.
      let best=sqrRecommendationBest(trials,options.snrPercent);
      if(best)for(let keep of [best.keep-1,best.keep+1])if(keep>=options.minFrames&&keep<=frames.length&&!trials.some(p=>p.keep===keep))test(keep);
      best=sqrRecommendationBest(trials,options.snrPercent);
      if(!best)throw Error('No valid test stacks. '+(trials[0]?.error||'Check the ROI and star measurements.'));
      // A failed all-frame baseline could hide a higher-SNR alternative. Do
      // not promise preservation relative to a baseline we could not measure.
      if(trials.find(p=>p.keep===frames.length)?.error)throw Error('The all-frame baseline failed. No reliable recommendation. '+trials.find(p=>p.keep===frames.length).error);
      let peak=Math.max(...trials.filter(p=>!p.error).map(p=>p.snr));
      return {options:{...options},geometry:{crop:geometry.crop,photometryCrop:geometry.photometryCrop,aperture:geometry.aperture},rows:ranking.rows,scoreMode:ranking.scoreMode,
         curve,trials:trials.sort((a,b)=>a.keep-b.keep),best,peak,baseline:trials.find(p=>p.keep===frames.length),
         rejected:ranking.rows.slice(best.keep),reinstate:ranking.rows.slice(0,best.keep).filter(r=>r.reject),
         matchedScaleCount:frames.filter(f=>f.matched).length,created:new Date().toISOString(),incomplete:trials.some(p=>p.error)};
   }finally{
      // Only files in this unique, script-owned directory are removed.
      let find=new FileFind;if(find.begin(scratch+'/*'))do{if(find.isFile)TGFileProtection.removeFile(scratch+'/'+find.name,'Temporary recommendation image');}while(find.next());
      TGFileProtection.removeDirectory(scratch,"Temporary image directory");
   }
}
function sqrRecommendationApply(result){
   // Only explicitly applying an inclusive result can clear earlier marks.
   let count=0;for(let row of result.rejected)if(!row.isMaster&&!row.moved&&!row.reject){row.reject=true;++count;}
   if(result.options?.includeRejected)for(let row of result.reinstate)if(!row.isMaster&&!row.moved)row.reject=false;
   return count;
}
/** Review completion belongs to this analyzed group and these decisions.
 * Compare cached values only: rebuilding the table must not read image files.
 * Moving an already rejected original preserves completion; keeping it again
 * reopens review. Proposed rejects are normalized while a plan is in progress. */
function sqrRecommendationReviewKey(group,o,config,guideAvailable,rejected,reinstate){
   let proposed=new Set(rejected),kept=new Set(reinstate);
   let rows=group.rows.map(r=>proposed.has(r)?{...r,reject:true,moved:false}:kept.has(r)?{...r,reject:false}:r);
   return sqrRecommendationKey({...group,rows},o,config,guideAvailable,()=>null);
}
function sqrRecommendationPlanReview(group,o,result,guideAvailable,accept=false){
   let plan={options:result.options,rejected:result.rejected,reinstate:result.reinstate||[],confirmed:false,
      key:sqrRecommendationReviewKey(group,o,result.options,guideAvailable,result.rejected,result.reinstate)};
   // A fresh calculation is a proposal, not a reversal of an accepted review.
   // Keep a pending plan as well so manually accepting its rejects still works.
   if(!accept&&sqrRecommendationReviewComplete(group,o,guideAvailable)){group.recommendationPendingReview=plan;return;}
   group.recommendationReview=plan;delete group.recommendationPendingReview;
   group.reviewComplete=false;
}
function sqrRecommendationReviewComplete(group,o,guideAvailable){
   group.reviewComplete=false;let plan=group.recommendationReview,pending=group.recommendationPendingReview;
   const valid=p=>p&&p.key===sqrRecommendationReviewKey(group,o,group.recommendationSettings||p.options,guideAvailable,p.rejected,p.reinstate);
   const complete=p=>(p.confirmed||p.rejected.length>0||p.reinstate.length>0)&&p.rejected.every(r=>r.reject||r.moved)&&p.reinstate.every(r=>!r.reject&&!r.moved);
   if(!valid(plan)){delete group.recommendationReview;plan=null;}
   if(!valid(pending)){delete group.recommendationPendingReview;pending=null;}
   if(pending&&(!plan||complete(pending))){group.recommendationReview=plan=pending;delete group.recommendationPendingReview;}
   if(!plan)return false;
   group.reviewComplete=complete(plan);
   return group.reviewComplete;
}
function sqrRecommendationHTML(result,kpi=SQR_RECOMMENDATION_KPIS.find(k=>k.key==='score')){
   let label=sqrHTML(kpi.label);
   if(!result)return '<html><body style="background:#252536;color:#cdd6f4;font-family:sans-serif;padding:20px"><p>Analyze to compare retained-frame counts.</p><p>Blue: preserved SNR. Orange: '+label+'. Green: recommended count.</p></body></html>';
   let valid=result.trials.filter(p=>!p.error),first=result.options.minFrames,last=result.rows.length,
      measured=valid.map(p=>({point:p,value:sqrRecommendationPlotValue(result,p,kpi)})).filter(p=>p.value!==null);
   let values=measured.map(p=>p.value),low=values.length?Math.min(...values):0,high=values.length?Math.max(...values):1;
   let pad=(high-low||Math.abs(high)*.1||.1)*.08;low=Math.max(0,low-pad);high+=pad;
   if(kpi.unitInterval){low=Math.max(0,low);high=Math.min(1,high);}if(high<=low)high=low+1;
   // Place data in percentages of the available field. Keep labels, strokes and
   // markers in screen units so resizing either dimension preserves their shape.
   const x=n=>last===first?50:100*(n-first)/(last-first),
      ys=n=>100*(1-n/1.08),yk=n=>100*(high-n)/(high-low);
   let svg=['<rect width="100%" height="100%" fill="'+SQR_UNGRADED_PLOT.background+'"/>'];
   let rightTickChars=0;
   for(let i=0;i<=4;++i){
      const y=(100-25*i)+'%',tick=measured.length?sqrRecommendationFormat(low+(high-low)*i/4,kpi):'—';
      rightTickChars=Math.max(rightTickChars,tick.length);
      svg.push(`<line x2="100%" y1="${y}" y2="${y}" stroke="${SQR_UNGRADED_PLOT.grid}"/>
         <text y="${y}" dx="-.55em" dy=".35em" text-anchor="end" fill="#89b4fa">${Math.round(108*i/4)}%</text>
         <text x="100%" y="${y}" dx=".55em" dy=".35em" fill="#fab387">${tick}</text>`);
   }
   const limitY=ys(result.options.snrPercent/100)+'%',bestX=x(result.best.keep)+'%';
   svg.push(`<line x2="100%" y1="${limitY}" y2="${limitY}" stroke="#2d6cb5" stroke-dasharray="5,5"/>
      <line x1="${bestX}" x2="${bestX}" y2="100%" stroke="${SQR_UNGRADED_PLOT.mean}" stroke-width="2"/>`);
   for(let series of [{points:valid.map(point=>({point,value:point.snr/result.peak})),y:ys,color:'#2d6cb5'},
      {points:measured,y:yk,color:SQR_UNGRADED_PLOT.focus}]){
      const points=series.points.map(p=>x(p.point.keep)+','+series.y(p.value)).join(' ');
      svg.push(`<svg width="100%" height="100%" viewBox="0 0 100 100" preserveAspectRatio="none"><polyline fill="none" stroke="${series.color}" stroke-width="2" vector-effect="non-scaling-stroke" points="${points}"/></svg>`);
      for(let {point:p,value} of series.points){let selected=sqrRecommendationPlotValue(result,p,kpi);
         svg.push('<circle cx="'+x(p.keep)+'%" cy="'+series.y(value)+'%" r="4" fill="'+series.color+'"><title>Keep '+p.keep+'; SNR '+(100*p.snr/result.peak).toFixed(2)+'%; '+label+': '+(selected===null?'unavailable':String(selected))+'; FWHM '+p.fwhm.toFixed(4)+' px; exposure '+sqrRecommendationHours(p)+' h</title></circle>');}
   }
   const intervals=Math.min(4,last-first);
   for(let i=0;i<=intervals;++i){
      const n=first+Math.round((last-first)*i/Math.max(1,intervals));
      svg.push(`<text x="${x(n)}%" y="100%" dy="1.4em" text-anchor="middle" fill="#cdd6f4">${n}</text>`);
   }
   if(!measured.length)svg.push('<text x="50%" y="50%" text-anchor="middle" fill="'+SQR_UNGRADED_PLOT.focus+'">Selected KPI unavailable</text>');
   svg.push(`<text x="50%" y="100%" dy="2.9em" text-anchor="middle" fill="#cdd6f4">Retained frames</text>
      <text dy="-.95em" fill="#89b4fa">SNR (% of best tested)</text>
      <text x="100%" dy="-.95em" text-anchor="end" fill="#fab387">${label}</text>`);
   return `<!doctype html><html><head><meta charset="utf-8"><style>
      body{margin:0;background:#252536;font:clamp(13px,1.55vw,18px) sans-serif}
      main{position:absolute;inset:2.35em calc(${rightTickChars}ch + 1.6em) 3.65em calc(4ch + 1.6em)}
      main>svg{display:block;width:100%;height:100%;overflow:visible}
      </style></head><body><main><svg xmlns="http://www.w3.org/2000/svg">${svg.join('')}</svg></main></body></html>`;
}

// Only the displayed copy is resized and stretched. Rectangles are stored in
// registered-image coordinates, independent of the thumbnail or dialog size.
function sqrMasterROIBitmap(group){
   let image=sqrReadImage(group.master,true);
   try{
      if(image.width!==group.width||image.height!==group.height)throw Error('The master dimensions differ from the registered group. Use an aligned preview or enter registered-image coordinates.');
      let scale=Math.min(1,1600/Math.max(image.width,image.height));
      if(scale<1)image.resample(scale);
      image.applyDisplayFunction(image.computeAutoStretch());image.truncate();return image.render();
   }finally{image.free();}
}
class SQRMasterROIDialog extends Dialog {
   constructor(group,bitmap,roi){
      super();this.windowTitle='Draw object ROI — '+(group.filter||group.label);this.roi=roi?.slice()||null;
      this.canvas=new Control(this);let canvas=this.canvas;canvas.setScaledMinSize(400,250);
      let status=new Label(this),apply=sqrButton(this,'Use ROI',()=>this.ok()),cancel=sqrButton(this,'Cancel',()=>this.cancel());
      cancel.escapeButton=true;
      const layout=()=>{let scale=Math.min(canvas.width/group.width,canvas.height/group.height);
         return {scale,x:(canvas.width-group.width*scale)/2,y:(canvas.height-group.height*scale)/2};};
      const point=(x,y,clamp)=>{let l=layout(),field=group.roi;
         let px=Math.round((x-l.x)/l.scale),py=Math.round((y-l.y)/l.scale);
         if(!clamp&&(px<field[0]||py<field[1]||px>field[2]||py>field[3]))return null;
         return [Math.max(field[0],Math.min(field[2],px)),Math.max(field[1],Math.min(field[3],py))];};
      const showSelection=()=>{
         apply.enabled=false;
         if(!this.roi)status.text='Drag around the object inside the outlined usable field.';
         else try{sqrRecommendationGeometry(group,{useROI:true,roi:this.roi});apply.enabled=true;
            let [x,y,r,b]=this.roi;status.text='X '+x+'    Y '+y+'    Width '+(r-x)+'    Height '+(b-y)+' px';}
         catch(e){status.text=e.message||String(e);}
         canvas.update();
      };
      let anchor=null;
      const drag=(x,y)=>{let [a,b]=anchor,[c,d]=point(x,y,true);
         this.roi=[Math.min(a,c),Math.min(b,d),Math.max(a,c),Math.max(b,d)];showSelection();};
      canvas.onMousePress=(x,y,button)=>{if(button===MouseButton.Left&&(anchor=point(x,y,false)))drag(x,y);};
      canvas.onMouseMove=(x,y)=>{if(anchor)drag(x,y);};
      canvas.onMouseRelease=(x,y,button)=>{if(button===MouseButton.Left&&anchor){drag(x,y);anchor=null;}};
      canvas.onPaint=()=>{let g=new Graphics(canvas);try{
         let l=layout(),box=r=>[l.x+r[0]*l.scale,l.y+r[1]*l.scale,l.x+r[2]*l.scale,l.y+r[3]*l.scale].map(Math.round);
         g.fillRect(0,0,canvas.width,canvas.height,new Brush(0xff181818));
         g.drawScaledBitmap(...box([0,0,group.width,group.height]),bitmap);
         g.pen=new Pen(0xffaab2bd);g.drawRect(...box(group.roi));
         if(this.roi){let rect=box(this.roi);g.pen=new Pen(0xff152127,3);g.drawRect(...rect);
            g.pen=new Pen(0xffffd451);g.drawRect(...rect);}
      }finally{g.end();}};
      let buttons=new HorizontalSizer;buttons.spacing=8;buttons.add(status,100);buttons.add(apply);buttons.add(cancel);
      this.sizer=new VerticalSizer;this.sizer.margin=8;this.sizer.spacing=8;this.sizer.add(canvas,100);this.sizer.add(buttons);
      this.userResizable=true;this.resize(Math.min(this.logicalPixelsToPhysical(900),Math.round(this.availableScreenRect.width*.85)),Math.min(this.logicalPixelsToPhysical(650),Math.round(this.availableScreenRect.height*.8)));showSelection();
   }
}

class SQRRecommendationDialog extends Dialog {
   constructor(group,o,guideAvailable){super();this.windowTitle='Rejection recommendation — '+(group.filter||'group');this.group=group;this.o=o;this.guideAvailable=guideAvailable;this.recommendation=null;this.running=false;
      let config=sqrRecommendationOptions({recommendation:group.recommendationSettings||o.recommendation}),field=group.roi||[0,0,group.width,group.height],w=field[2]-field[0],h=field[3]-field[1];
      let geometryMatches=!config.geometry||config.geometry[0]===group.width&&config.geometry[1]===group.height;
      let roi=geometryMatches&&config.roi?config.roi:[Math.round(field[0]+w*.3),Math.round(field[1]+h*.3),Math.round(field[0]+w*.7),Math.round(field[1]+h*.7)];
      this.snr=sqrNumber(this,'Preserve SNR (%):',config.snrPercent,50,100,1);this.minimum=sqrNumber(this,'Minimum retained:',config.minFrames,7,100000,0);
      this.snr.toolTip='At least this percentage of the best measured SNR among the tested stacks. Default 95%. The estimate is specific to the test integration.';
      this.minimum.toolTip='Never recommend keeping fewer than this many frames in this group. At least seven are required for the test’s Winsorized pixel rejection. Default 20.';
      this.includeRejected=new CheckBox(this);this.includeRejected.text='Include rejected subframes';this.includeRejected.checked=config.includeRejected;
      this.includeRejected.visible=group.rows.some(r=>r.reject&&!r.moved&&!r.isMaster);
      this.includeRejected.toolTip='Analyze marked subframes alongside the others. Applying the recommendation clears the marks on frames it keeps. Originals already moved remain excluded.';
      this.includeRejected.onCheck=()=>this.changed();
      this.useROI=new CheckBox(this);this.useROI.text='Use object ROI';this.useROI.checked=config.useROI&&geometryMatches;
      this.preview=new ViewList(this);this.preview.getPreviews();this.preview.setScaledMinWidth(200);
      this.preview.toolTip='Optional: copy coordinates from a preview on an aligned image with the same dimensions. All ROI content contributes to aperture signal; avoid unrelated bright stars and leave clean sky outside.';
      this.drawROI=sqrButton(this,'Draw on master…',()=>{let bitmap=null;
         try{bitmap=sqrMasterROIBitmap(group);let dialog=new SQRMasterROIDialog(group,bitmap,this.useROI.checked?this.options().roi:null);
            if(dialog.execute())this.setObjectROI(dialog.roi);}
         catch(e){this.status.text=e.message||String(e);}finally{if(bitmap)bitmap.clear();}});
      this.hasROIMaster=!!group.roi&&!!group.master&&File.exists(group.master);
      this.drawROI.toolTip=this.hasROIMaster?'Drag a rectangle on the group master to select the object for SNR measurement.':'Requires a matched master and a measured common usable field.';
      this.coords=['X','Y','Width','Height'].map((name,i)=>sqrNumber(this,name+':',i<2?roi[i]:roi[i]-roi[i-2],i<2?0:32,i%2?group.height:group.width,0));
      this.preview.onViewSelected=view=>{if(view.isNull||!view.isPreview)return;let image=view.window.mainView.image;
         if(image.width!==group.width||image.height!==group.height){this.status.text='Preview dimensions do not match this registered group.';return;}
         let r=view.window.previewRect(view);this.setObjectROI([r.x0,r.y0,r.x1,r.y1]);};
      for(let c of [this.snr,this.minimum,...this.coords])c.onValueUpdated=()=>{if(!this.settingROI)this.changed();};this.useROI.onCheck=()=>this.changed();
      this.note=new Label(this);this.note.wordWrapping=true;this.note.text='Selected group only. Lowest Review scores are rejected first; the highest retained mean Score meeting the SNR and minimum-count limits is recommended. Object ROI affects SNR only. Other image KPIs use the common usable field.';
      this.plotKPI=new ComboBox(this);for(let kpi of SQR_RECOMMENDATION_KPIS)this.plotKPI.addItem(kpi.label);
      this.plotKPI.currentItem=Math.max(0,SQR_RECOMMENDATION_KPIS.findIndex(k=>k.key===config.plotKPI));this.plotKPI.setScaledMinWidth(200);
      this.plotKPI.onItemSelected=()=>{this.group.recommendationSettings=this.options();this.refreshResult();};
      this.plotKind=new Label(this);this.plotKind.text='Measured trial stack';
      let plotLabel=new Label(this);plotLabel.text='Plot KPI:';let plotRow=new HorizontalSizer;plotRow.spacing=10;plotRow.add(plotLabel);plotRow.add(this.plotKPI);plotRow.add(this.plotKind);plotRow.addStretch();
      this.plot=new WebView(this);this.plot.setScaledMinSize(760,310);this.plot.setHTML(sqrRecommendationHTML(null));
      this.table=new TreeBox(this);this.table.numberOfColumns=6;this.table.headerVisible=true;this.table.rootDecoration=false;this.table.alternateRowColor=true;this.table.setScaledMinHeight(150);
      ['Keep','Reject','SNR retained','FWHM (px)','Exposure (h)','Result'].forEach((s,i)=>this.table.setHeaderText(i,s));
      this.status=new Label(this);this.status.wordWrapping=true;this.status.setScaledMinHeight(54);this.status.text=(geometryMatches?'':'The saved ROI used a different image size and has been reset. ')+ 'For object SNR, draw on the master, select a preview or enter ROI coordinates. Otherwise Analyze uses stellar SNR.';
      this.analyzeButton=sqrButton(this,'Analyze',()=>this.analyze());this.applyButton=sqrButton(this,'Mark recommended rejects',()=>this.applyRecommendation());this.applyButton.enabled=false;
      this.cancelButton=sqrButton(this,'Close',()=>{if(this.running){this.abortRequested=true;this.status.text='Stopping after the current operation…';}else this.cancel();});this.cancelButton.escapeButton=true;
      this.cancelButton.toolTip='During analysis, request cancellation after the current native operation. The PixInsight console can also abort a running process.';
      this.infoButton=sqrTool(this,':/process-interface/browse-documentation.png','How the recommendation is measured',()=>new SQRPlotInfoDialog({title:'Rejection recommendation',html:"<p>Frames are ordered by the current Review Score, highest first. The selected R1, R2, R3 or R4 mode and its weights apply. Select R3 in Review to use its strongly correlated KPI score. Scores and their order stay fixed during analysis; table sorting has no effect.</p><p>Test integrations verify several retained counts and the adjacent counts around the best one. The highest mean retained Score meeting your SNR limit and minimum count is recommended. Equal means prefer more frames. FWHM and the other plotted image KPIs are comparisons, not separate decision criteria. This is the best tested cutoff, not a guaranteed global optimum.</p><p>With an object ROI, only Object SNR uses the selected aperture and a surrounding-sky margin. Its background-limited estimate includes short-range pixel covariance and background-fit uncertainty. It does not model source shot noise, shared calibration errors or longer-range correlated noise. Avoid unrelated bright stars in the aperture and leave clean surrounding sky. Without an ROI, native PSF SNR is a stellar proxy.</p><p>Every trial stack and all other image KPIs use the same common usable field, independent of the ROI. Tests use fixed PSF signal integration weights, field-based global normalization and Winsorized rejection (low 4, high 3); RGB uses green. They do not reproduce local normalization or drizzle. The default minimum is 20; seven is a statistical floor, not a guarantee.</p><p>Plot KPI changes only the graph and table. Score is the arithmetic mean of retained subframes’ Review scores at analysis time, not a score for the integrated image. Closing this dialog keeps results per group while the main review stays open. Changes to scores, scoring settings, calculation settings, measurements or inputs require new analysis; display changes reuse results.</p><p>Include rejected subframes also tests marked frames whose originals are still in place. Analyze leaves marks untouched. Applying the proposal marks new rejects and clears any rejection marks on frames the inclusive analysis keeps. The summary shows how many marks would be cleared. Applying or manually matching the proposed decisions completes score review. In groups retaining fewer than 40 subframes, inspect any remaining trail flags in Blink. Use Complete review to confirm a keep-all result with no changes. Changing relevant settings, measurements or decisions reopens it. File movement remains a separate action.</p>"}).execute());
      let top=new HorizontalSizer;top.spacing=14;top.add(this.snr);top.add(this.minimum);top.add(this.includeRejected);top.addStretch();top.add(this.infoButton);
      let roiRow=new HorizontalSizer;roiRow.spacing=10;roiRow.add(this.useROI);roiRow.add(this.preview,100);roiRow.add(this.drawROI);
      let coordinates=new HorizontalSizer;coordinates.spacing=14;for(let c of this.coords)coordinates.add(c);coordinates.addStretch();
      let buttons=new HorizontalSizer;buttons.spacing=10;buttons.add(this.analyzeButton);buttons.add(this.applyButton);buttons.addStretch();buttons.add(this.cancelButton);
      this.sizer=new VerticalSizer;this.sizer.margin=10;this.sizer.spacing=10;for(let c of [top,roiRow,coordinates,this.note,plotRow,this.plot,this.table,this.status,buttons])this.sizer.add(c,c===this.plot?100:0);
      this.onClose=()=>!this.running;this.changed(false);this.refreshResult();this.restoreResult();this.adjustToContents();
   }
   setObjectROI([x,y,r,b]){
      this.settingROI=true;
      try{[x,y,r-x,b-y].forEach((v,i)=>this.coords[i].setValue(v));this.useROI.checked=true;}
      finally{this.settingROI=false;}
      this.changed();
   }
   options(){let [x,y,w,h]=this.coords.map(c=>Math.round(c.value));return {snrPercent:this.snr.value,minFrames:Math.round(this.minimum.value),includeRejected:this.includeRejected.checked,useROI:this.useROI.checked,roi:[x,y,x+w,y+h],geometry:[this.group.width,this.group.height],plotKPI:this.selectedKPI().key};}
   selectedKPI(){return SQR_RECOMMENDATION_KPIS[this.plotKPI.currentItem]||SQR_RECOMMENDATION_KPIS.find(k=>k.key==='score');}
   key(fingerprint=sqrFingerprint,result=this.recommendation){
      let accepted=result?.applied&&result.options.includeRejected?new Set(result.rejected):null;
      return sqrRecommendationKey(this.group,this.o,this.options(),this.guideAvailable,fingerprint,accepted);
   }
   storeResult(key=this.key()){
      this.group.recommendationSettings=this.options();
      if(this.recommendation){this.analysisKey=key;this.group.recommendationCache={key:this.analysisKey,result:this.recommendation};}
   }
   applyRecommendation(){
      if(this.running||!this.recommendation||this.recommendation.applied)return;
      // Recheck immediately before changing any decision. Reuse this exact
      // fingerprint snapshot when caching the accepted result so a later file
      // change cannot silently bless old measurements with a new fingerprint.
      let fingerprints=new Map,current=this.key(path=>{let value=sqrFingerprint(path);fingerprints.set(path,value);return value;});
      if(current!==this.analysisKey){
         this.recommendation=null;this.analysisKey=current;delete this.group.recommendationCache;
         delete this.group.recommendationReview;delete this.group.recommendationPendingReview;this.group.reviewComplete=false;
         this.refreshResult();this.status.text='Inputs or settings changed since Analyze. No rejection decisions were changed. Check the measurements and Analyze again.';return;
      }
      this.applied=sqrRecommendationApply(this.recommendation);this.reviewApplied=true;this.recommendation.applied=true;
      sqrRecommendationPlanReview(this.group,this.o,this.recommendation,this.guideAvailable,true);
      this.group.recommendationReview.confirmed=true;
      if(sqrRecommendationReviewComplete(this.group,this.o,this.guideAvailable))for(let row of this.group.rows)row.candidate=false;
      this.storeResult(this.key(path=>fingerprints.get(path)));this.ok();
   }
   restoreResult(){
      let cache=this.group.recommendationCache;this.analysisKey=this.key(sqrFingerprint,cache?.result);
      if(cache?.key===this.analysisKey){this.recommendation=cache.result;this.refreshResult();}
      else if(cache){delete this.group.recommendationCache;this.status.text='Inputs, measurements or analysis settings changed. Analyze again to refresh the recommendation.';}
   }
   changed(clear=true){for(let c of [...this.coords,this.preview])c.enabled=this.useROI.checked&&!this.running;
      this.drawROI.enabled=this.hasROIMaster&&!this.running;
      this.group.recommendationSettings=this.options();
      if(clear){let key=this.key();if(key!==this.analysisKey){this.analysisKey=key;this.recommendation=null;delete this.group.recommendationCache;
         this.refreshResult();this.status.text='Analysis settings changed. Analyze again to obtain a current recommendation.';}}
   }
   refreshResult(){
      let r=this.recommendation,kpi=this.selectedKPI();this.plotKPI.toolTip=kpi.description;
      this.plotKind.text=kpi.key==='score'?'Mean retained subframe score':kpi.key==='exposureHours'||kpi.key==='effective'?'Retained set':'Common usable field';
      this.table.clear();this.table.setHeaderText(3,kpi.label);this.plot.setHTML(sqrRecommendationHTML(r,kpi));this.applyButton.enabled=false;
      if(!r)return;
      for(let p of r.trials){let node=new TreeBoxNode(this.table),value=sqrRecommendationPlotValue(r,p,kpi);
         let values=[p.keep,r.rows.length-p.keep,p.error?'—':(100*p.snr/r.peak).toFixed(1)+'%',sqrRecommendationFormat(value,kpi),p.error?'—':sqrRecommendationHours(p),p.error?'Failed':p===r.best?'Recommended':p.snr>=r.peak*r.options.snrPercent/100?'SNR limit met':'Below SNR limit'];
         values.forEach((v,i)=>node.setText(i,String(v)));
         let detail=p.error||'Effective weighted frame count: '+p.effective.toFixed(1)+'; measured stars: '+p.stars;
         for(let i=0;i<6;++i)node.setToolTip(i,detail);node.setToolTip(3,p.error||kpi.description+'\nValue: '+(value===null?'unavailable':String(value)));}
      for(let i=0;i<6;++i)this.table.adjustColumnWidthToContents(i);
      this.status.text='Keep '+r.best.keep+' / '+r.rows.length+'; reject '+r.rejected.length+'. Mean Score '+r.best.score.toFixed(3)+' ('+r.scoreMode+'; all frames '+r.baseline.score.toFixed(3)+'). SNR '+(100*r.best.snr/r.peak).toFixed(1)+'% of best tested. '+(r.options.useROI?'Background-limited object aperture estimate.':'Stellar SNR proxy.')+
         (r.matchedScaleCount?' Matched stars supplied the test-stack scale for '+r.matchedScaleCount+(r.matchedScaleCount===1?' frame.':' frames.'):'')+
         (r.options.includeRejected&&r.reinstate.length?' '+(r.applied?'Cleared':'Applying clears')+' '+r.reinstate.length+' existing rejection '+(r.reinstate.length===1?'mark.':'marks.'):'')+
         sqrTrailNotice(r.rows.slice(0,r.best.keep))+(r.applied?' Score recommendation applied.':'')+(r.incomplete?' Some trials failed; inspect their tooltips.':'');
      this.applyButton.text=r.options.includeRejected&&r.reinstate.length?'Apply keep/reject decisions':r.rejected.length?'Mark recommended rejects':'Complete review';
      this.applyButton.enabled=!this.running&&!r.applied;
   }
   analyze(){
      if(this.running)return;this.changed();let previous=this.recommendation,startKey=this.key(sqrFingerprint,null);this.applyButton.enabled=false;this.running=true;this.abortRequested=false;
      for(let c of [this.snr,this.minimum,this.includeRejected,this.useROI,this.preview,this.drawROI,...this.coords,this.plotKPI,this.analyzeButton,this.infoButton])c.enabled=false;
      this.cancelButton.text='Stop';let abort=console.abortEnabled;console.abortEnabled=true;console.show();
      try{
         let result=sqrRecommendationAnalyze(this.group,this.o,this.options(),this.guideAvailable,text=>{if(this.abortRequested)throw Error('Operation aborted.');this.status.text=text;});
         if(this.abortRequested)throw Error('Operation aborted.');
         if(this.key(sqrFingerprint,null)!==startKey){previous=null;delete this.group.recommendationCache;throw Error('Inputs changed during analysis. Measure the group again.');}
         this.recommendation=result;sqrRecommendationPlanReview(this.group,this.o,result,this.guideAvailable);this.storeResult();this.refreshResult();
      }catch(e){this.recommendation=previous;this.refreshResult();this.status.text=(e.message||String(e))+(previous?' Previous results retained.':'');}
      finally{console.abortEnabled=abort;this.running=false;for(let c of [this.snr,this.minimum,this.includeRejected,this.useROI,this.plotKPI,this.analyzeButton,this.infoButton])c.enabled=true;
         this.applyButton.enabled=!!this.recommendation&&!this.recommendation.applied;this.cancelButton.text='Close';this.changed(false);}
   }

}


// UI is below. Defining SQR_LIBRARY lets read-only test harnesses use the engine.
function sqrTool(parent,resource,tip,action){let b=new ToolButton(parent);b.icon=parent.scaledResource(resource);b.setScaledFixedSize(24,24);b.toolTip=tip;if(action)b.onClick=action;return b;}
function sqrButton(parent,text,fn){let b=new PushButton(parent);b.text=text;b.onClick=fn;return b;}
class SQRObservingSiteDialog extends Dialog {
   constructor(site,required,profiles,headers=null,headersOnly=false){
      super();this.windowTitle='Observing site';this.site=site;
      this.profiles=profiles.slice();
      if(sqrValidSite(site)&&!this.profiles.some(p=>p.name===site.name))this.profiles.push(site);
      let note=new Label(this);note.wordWrapping=true;
      note.text=required?'Some frames need an observing location to measure cloud extinction. Choose a site for this run, or make it the default for future runs.':'Runs without geographic coordinates use your default site. You can select another site for this review.';
      this.sizer=new VerticalSizer;this.sizer.margin=10;this.sizer.spacing=8;this.sizer.add(note);
      let selector=new ComboBox(this),profileRow=new HorizontalSizer;profileRow.spacing=8;profileRow.add(selector,100);
      let removed=false;
      const removalHint=required?'Select or enter a site, or click Skip for this run.':'Click Apply to save the removal.';
      let remove=sqrButton(this,'Remove profile',()=>{
         let [deleted]=this.profiles.splice(selector.currentItem-1,1);
         if(this.site?.name===deleted.name)this.site=null;
         removed=true;fill(0);hint.text=removalHint;
      });
      profileRow.add(remove);this.sizer.add(profileRow);
      const field=(name,value)=>{let row=new HorizontalSizer;row.spacing=8;let label=new Label(this);
         label.text=name;label.setScaledFixedWidth(175);let edit=new Edit(this);edit.text=Number.isFinite(value)?String(value):'';
         row.add(label);row.add(edit,100);this.sizer.add(row);return edit;};
      let name=field('Site name',''),lat=field('Latitude (° north positive)',site?.latitude),lon=field('Longitude (° east positive)',site?.longitude);
      let useDefault=new CheckBox(this);useDefault.text='Use as default observing site';this.sizer.add(useDefault);
      useDefault.toolTip='Use this site automatically when a WBPP run has no geographic coordinates and no site selected for that run.';
      const show=(i,p)=>{name.text=p?.name||'';lat.text=p?String(p.latitude):'';lon.text=p?String(p.longitude):'';remove.enabled=i>0;useDefault.checked=this.profiles[i-1]?.isDefault===true;};
      const fill=i=>{selector.clear();selector.addItem('New site');for(let p of this.profiles)selector.addItem(p.name+(p.isDefault===true?' (default)':''));
         selector.currentItem=i;show(i,this.profiles[i-1]);};
      selector.onItemSelected=i=>show(i,this.profiles[i-1]);
      let preferred=site||sqrDefaultSite(this.profiles);
      let index=preferred?this.profiles.findIndex(p=>p.name===preferred.name)+1:(this.profiles.length?1:0);fill(index);if(site&&index)show(index,site);
      let hint=new Label(this);hint.text='Enter decimal degrees.';this.sizer.add(hint);
      let buttons=new HorizontalSizer;buttons.spacing=8;buttons.addStretch();
      if(required)buttons.add(sqrButton(this,'Skip for this run',()=>{this.skipped=true;this.ok();}));
      else if(site||sqrDefaultSite(this.profiles)||headers?.site||headers?.pointing){
         let clear=sqrButton(this,headers?.site||headers?.pointing?'Use headers only':'Clear fallback',()=>{this.site=null;this.headersOnly=true;this.ok();});
         clear.toolTip='Use only recorded coordinates for this review, even if a default site is saved.';buttons.add(clear);
      }
      const decimal=text=>/^[+-]?(?:\d+(?:[.,]\d*)?|[.,]\d+)$/.test(text.trim())?Number(text.trim().replace(',','.')):NaN;
      buttons.add(sqrButton(this,'Apply',()=>{
         if(removed&&![name,lat,lon].some(edit=>edit.text.trim())){
            if(required){hint.text=removalHint;return;}
            this.headersOnly=headersOnly;this.ok();return;
         }
         let value={name:name.text.trim(),latitude:decimal(lat.text),longitude:decimal(lon.text)};
         if(!sqrValidSite(value)){hint.text='Enter latitude from −90 to +90 and longitude from −180 to +180.';return;}
         let i=selector.currentItem-1;
         if(!value.name||this.profiles.some((p,j)=>j!==i&&p.name.toLowerCase()===value.name.toLowerCase())){hint.text='Enter a distinct name for this site.';return;}
         if(useDefault.checked)this.profiles=this.profiles.map(p=>p.isDefault?{...p,isDefault:false}:p);
         let profile=useDefault.checked?{...value,isDefault:true}:value;
         if(i>=0)this.profiles[i]=profile;else this.profiles.push(profile);
         this.site=useDefault.checked?null:value;this.ok();
      }));
      buttons.add(sqrButton(this,required?'Cancel measurement':'Cancel',()=>this.cancel()));
      this.sizer.add(buttons);this.setScaledFixedWidth(470);this.adjustToContents();
   }
}
const SQR_SITE_KEY='TGScripts/SubframeQualityReview/observingSites';
function sqrSiteProfiles(){
   let stored=Settings.read(SQR_SITE_KEY,DataType.String);
   if(!Settings.lastReadOK||!stored)return [];
   let profiles=JSON.parse(stored);
   if(!Array.isArray(profiles)||!profiles.every(p=>sqrValidSite(p)&&typeof p.name==='string'&&p.name.trim()))
      throw Error('The saved observing-site profiles could not be read.');
   return profiles;
}
// Legacy profiles have no default marker. Their order is only for display.
function sqrDefaultSite(profiles){return profiles.find(p=>p.isDefault===true)||null;}
function sqrFallbackSite(o,profiles){
   if(o.siteHeadersOnly)return null;
   if(sqrValidSite(o.observingSite))return o.observingSite;
   if(profiles===undefined)try{profiles=sqrSiteProfiles();}catch(e){return null;}
   return sqrDefaultSite(profiles);
}
class SQRPlotInfoDialog extends Dialog {
   constructor(info){super();this.windowTitle=info.title;
      this.content=new TextBox(this);this.content.readOnly=true;this.content.font=this.font;this.content.setScaledMinSize(info.plot||info.model?780:720,info.plot||info.model?640:info.sky?620:480);this.content.text=info.html;this.content.home();
      this.closeButton=sqrButton(this,'Close',()=>this.ok());this.closeButton.defaultButton=true;this.closeButton.escapeButton=true;
      let buttons=new HorizontalSizer;buttons.addStretch();buttons.add(this.closeButton);
      this.sizer=new VerticalSizer;this.sizer.margin=10;this.sizer.spacing=10;this.sizer.add(this.content,100);this.sizer.add(buttons);this.adjustToContents();
   }
}
function sqrRejectIcon(parent,checked){
   let scale=parent.displayPixelRatio||1,size=Math.round(16*scale),bitmap=new Bitmap(size,size);bitmap.fill(0x00000000);
   let p=new Graphics(bitmap);try{p.pen=new Pen(0xff536475,scale);p.fillRect(2*scale,2*scale,14*scale,14*scale,new Brush(0xfff8fafc));p.drawRect(2*scale,2*scale,14*scale,14*scale);
      if(checked){p.pen=new Pen(0xffa12b2b,2*scale);p.drawLine(4*scale,8*scale,7*scale,11*scale);p.drawLine(7*scale,11*scale,12*scale,5*scale);}
   }finally{p.end();}return bitmap;
}
function sqrGroup(parent,title){let g=new GroupBox(parent);g.title=title;g.sizer=new VerticalSizer;g.sizer.margin=10;g.sizer.spacing=8;return g;}
function sqrNumber(parent,label,value,low,high,precision=0){let n=new NumericEdit(parent);n.label.text=label;n.setRange(low,high);n.setPrecision(precision);n.setValue(value);return n;}
const SQR_MEASUREMENT_LIMITS={percent:[0,100,1],minStars:[5,1000,0],margin:[0,15,1],patch:[10,SQR_MAX_CORNER_PERCENT,0]};
function sqrMeasurementOptions(o){
   let defaults=sqrDefaults(),result={autoCornerSize:o.autoCornerSize!==false};
   for(let [key,[low,high,precision]] of Object.entries(SQR_MEASUREMENT_LIMITS)){
      let value=Number.isFinite(o[key])?o[key]:defaults[key];
      result[key]=Math.max(low,Math.min(high,Math.roundTo(value,precision)));
   }
   return result;
}
class SQRMeasurementSettingsDialog extends Dialog {
   constructor(o,group,siteOptions,headers){
      super();this.windowTitle='Review configuration';
      let review=sqrGroup(this,'Review criteria'),regions=sqrGroup(this,'Measurement regions');
      const addField=(parent,key,label,units,tip)=>{
         let field=sqrNumber(parent,label,o[key],...SQR_MEASUREMENT_LIMITS[key]);
         if(!SQR_MEASUREMENT_LIMITS[key][2])field.setReal(false);
         field.enableFixedPrecision(true);field.label.textAlignment=TextAlignment.Left|TextAlignment.VertCenter;
         field.label.setScaledFixedWidth(108);field.edit.setScaledFixedWidth(62);field.toolTip=tip;
         let unit=new Label(parent);unit.text=units;
         let row=new HorizontalSizer;row.spacing=8;row.add(field);row.add(unit);
         parent.sizer.add(row);this[key]=field;return row;
      };
      addField(review,'percent','Review worst','% of each group','Shortlist this fraction of the group for review. Images with insufficient measurements can also require review.').addStretch();
      addField(review,'minStars','Minimum stars','per region','Minimum star count for usable measurements. Changing the threshold reassesses existing measurements.').addStretch();
      addField(regions,'margin','Edge guard','% at each edge','Inset from the image edges. Changing this setting clears field and corner measurements.').addStretch();
      let corner=addField(regions,'patch','Corner size','%','Width and height of each center and corner region as a percentage of the common usable field.');
      this.autoSize=new CheckBox(regions);this.autoSize.text='Auto per group';this.autoSize.checked=o.autoCornerSize;
      this.autoSize.toolTip='Show the size used for the selected group. Clear to use a fixed size for every group.';
      corner.addSpacing(6);corner.add(this.autoSize);corner.addStretch();
      // The displayed group size may exceed the starting size stored in process settings.
      this.autoStart=o.autoCornerSize?o.patch:sqrDefaults().patch;
      const accepted=o.autoCornerSize&&group?.measureSignature?(group.cornerPatch??o.patch):this.autoStart;
      let manual=o.autoCornerSize?null:o.patch;
      const showAutoSize=()=>{if(this.autoSize.checked)this.patch.setValue(this.margin.value===o.margin?accepted:this.autoStart);};
      this.autoSize.onCheck=checked=>{
         if(checked)manual=this.patch.value;
         this.patch.edit.readOnly=checked;
         if(checked)showAutoSize();else if(manual!==null)this.patch.setValue(manual);
      };
      this.patch.edit.readOnly=o.autoCornerSize;showAutoSize();
      this.margin.onValueUpdated=showAutoSize;
      let site=sqrGroup(this,'Observing site');
      this.siteStatus=new Label(site);this.siteStatus.wordWrapping=true;
      this.siteStatus.toolTip='Coordinates recorded in a WBPP run take priority over the selected fallback or default site.';
      let updateSite=()=>{
         let draft=this.siteDraft,choice=draft?{observingSite:draft.site,siteHeadersOnly:!!draft.headersOnly}:siteOptions;
         let location=headers?.site||sqrFallbackSite(choice,draft?.profiles);
         let source=headers?.site?(headers.fromMaster?'WBPP master':'WBPP headers'):
            location?(choice.observingSite?'Fallback: ':'Default site: ')+location.name:choice.siteHeadersOnly?'Headers only':'No fallback site';
         let position=location?' ('+Number(location.latitude.toFixed(5))+'°, '+Number(location.longitude.toFixed(5))+'°)':'';
         let coverage=headers?(headers.recorded?headers.recorded+' of '+headers.total+' frames record a site':'No geographic site in '+headers.total+' frame headers'):'Headers not scanned';
         this.siteStatus.text=source+position+'\n'+coverage+(headers?.pointing?' · '+headers.pointing+' with recorded pointing':'');
      };
      this.siteButton=sqrButton(site,'Edit sites…',()=>{
         try{
            let draft=this.siteDraft,profiles=draft?draft.profiles:sqrSiteProfiles();
            let editor=new SQRObservingSiteDialog(draft?draft.site:siteOptions.observingSite,false,profiles,headers,draft?draft.headersOnly:siteOptions.siteHeadersOnly);
            if(editor.execute()){this.siteDraft={site:editor.site,headersOnly:!!editor.headersOnly,profiles:editor.profiles};updateSite();this.adjustToContents();}
         }catch(e){(new MessageBox(String(e),this.windowTitle,StdIcon_Error,StdButton_Ok)).execute();}
      });
      this.siteButton.toolTip='Choose a fallback for this review or manage saved sites.';
      let siteRow=new HorizontalSizer;siteRow.spacing=10;siteRow.add(this.siteStatus,100);siteRow.add(this.siteButton);site.sizer.add(siteRow);
      updateSite();
      this.okButton=sqrButton(this,'OK',()=>this.ok());this.okButton.defaultButton=true;
      this.cancelButton=sqrButton(this,'Cancel',()=>this.cancel());this.cancelButton.escapeButton=true;
      let buttons=new HorizontalSizer;buttons.spacing=8;buttons.addStretch();buttons.add(this.okButton);buttons.add(this.cancelButton);
      this.sizer=new VerticalSizer;this.sizer.margin=14;this.sizer.spacing=12;this.sizer.add(review);this.sizer.add(regions);this.sizer.add(site);this.sizer.add(buttons);
      this.setScaledFixedWidth(425);this.adjustToContents();
   }
   options(){return {percent:this.percent.value,minStars:this.minStars.value,margin:this.margin.value,
      autoCornerSize:this.autoSize.checked,patch:this.autoSize.checked?this.autoStart:this.patch.value};}
}
class SQRAperturePresetsDialog extends Dialog {
   constructor(presets){
      super();this.windowTitle='Telescope aperture presets';
      let prompt=new Label(this);prompt.text='Enter telescope diameters in millimeters, separated by commas.';
      this.list=new Edit(this);this.list.text=presets.join(', ');
      this.hint=new Label(this);
      this.saveButton=sqrButton(this,'Save',()=>this.ok());this.saveButton.defaultButton=true;
      this.cancelButton=sqrButton(this,'Cancel',()=>this.cancel());this.cancelButton.escapeButton=true;
      this.list.onTextUpdated=()=>this.validate();this.validate();
      let buttons=new HorizontalSizer;buttons.spacing=8;buttons.addStretch();buttons.add(this.saveButton);buttons.add(this.cancelButton);
      this.sizer=new VerticalSizer;this.sizer.margin=12;this.sizer.spacing=8;
      this.sizer.add(prompt);this.sizer.add(this.list);this.sizer.add(this.hint);this.sizer.add(buttons);this.adjustToContents();
   }
   validate(){
      this.values=sqrParseAperturePresets(this.list.text);
      this.saveButton.enabled=this.values!==null;
      this.hint.text=this.saveButton.enabled?'Example: 80, 160, 250. Clear the list to remove all presets.':'Use whole numbers from 1 to 50000 mm.';
   }
}
/** Edit a draft only. Cancel leaves the main dialog, scores and plots intact.
 * Physical assumptions can be saved before a pixel scale becomes available. */
/** Use PixInsight's native date/time selector, but read its numeric fields as
 * civil wall time. Its Date object would otherwise normalize an acquisition
 * site's time using this computer's timezone/DST rules. Clamp day ranges here
 * so moving from January 31 to February stays in the month the user selected. */
class SQRSQMTimeDialog extends Dialog {
   constructor(value,seed=''){
      super();this.windowTitle='SQM reading time';this.setting=true;
      this.editor=new DateTimeEditor(this,2451545,0,70,true,55);this.editor.dateTime_Label.text='Local date and time:';
      this.editor.dateTimeToolTip='Local date and time at the observing site. The review’s inferred or custom UTC offset is applied after you choose Apply.';
      this.fields=['year','month','day','hour','minute','second'].map(k=>this.editor[k+'_SpinBox']);
      this.fields[0].setRange(100,9999);
      for(let field of this.fields)field.onValueUpdated=()=>this.updateDays();
      let initial=sqrNormalizeSQMTime(value)||sqrNormalizeSQMTime(seed),now=new Date;
      let values=initial?initial.match(/\d+/g).map(Number):[now.getFullYear(),now.getMonth()+1,now.getDate(),now.getHours(),now.getMinutes(),now.getSeconds()];
      this.fields.forEach((field,i)=>field.value=values[i]);this.setting=false;this.updateDays();
      this.applyButton=sqrButton(this,'Apply',()=>this.ok());this.applyButton.defaultButton=true;
      this.cancelButton=sqrButton(this,'Cancel',()=>this.cancel());this.cancelButton.escapeButton=true;
      let buttons=new HorizontalSizer;buttons.spacing=8;buttons.addStretch();buttons.add(this.applyButton);buttons.add(this.cancelButton);
      this.sizer=new VerticalSizer;this.sizer.margin=12;this.sizer.spacing=12;this.sizer.add(this.editor);this.sizer.add(buttons);this.adjustToContents();
   }
   updateDays(){if(this.setting)return;this.setting=true;try{
      this.fields[2].maxValue=new Date(Date.UTC(this.fields[0].value,this.fields[1].value,0)).getUTCDate();
   }finally{this.setting=false;}}
   value(){let v=this.fields.map(f=>f.value);return String(v[0]).padStart(4,'0')+'-'+String(v[1]).padStart(2,'0')+'-'+String(v[2]).padStart(2,'0')+' '+v.slice(3).map(n=>String(n).padStart(2,'0')).join(':');}
}
class SQRFWHMDialog extends Dialog {
   constructor(options,scale,filter=''){
      super();this.windowTitle='FWHM grading';this.scale=scale;this.filter=filter;this.fields={};let o=sqrFWHMOptions(options);
      this.baseOptions=o;this.apertureValue=o.fwhmAperture;this.seeingValue=o.fwhmSeeing;this.wavelengths={...o.fwhmWavelengths};this.filterBand=sqrFilterWavelength(filter);
      this.intro=new Label(this);this.intro.wordWrapping=true;this.intro.text='Set the Good, Medium and Bad bands for the FWHM plots.';
      this.enabledCheck=new CheckBox(this);this.enabledCheck.text='Show FWHM quality bands';this.enabledCheck.checked=o.fwhmEnabled;
      this.modelInfo=sqrTool(this,':/icons/info.png','About this grading model',()=>this.showModelInformation());
      let enabledRow=new HorizontalSizer;enabledRow.spacing=8;enabledRow.add(this.enabledCheck);enabledRow.addStretch();enabledRow.add(this.modelInfo);

      // Read-only inputs from the main window stay separate from editable
      // reference conditions. All form rows share one label and editor width.
      let current=sqrGroup(this,'Telescope and image');
      this.setupSummary=new Label(current);this.setupSummary.useRichText=true;this.setupSummary.wordWrapping=true;
      let scaleOK=!scale?.reason&&Number.isFinite(scale?.x)&&Number.isFinite(scale?.y)&&scale.x>0&&scale.y>0&&Math.abs(scale.x-scale.y)/Math.max(scale.x,scale.y)<=.001;
      this.setupSummary.text='<table width="100%" cellpadding="3"><tr>'+[
         ['Aperture',this.apertureValue>0?sqrFmt(this.apertureValue,0)+' mm':'Not set'],
         ['Zenith seeing',this.seeingValue>0?sqrFmt(this.seeingValue,2)+' arcsec':'Not supplied'],
         ['Image scale',scaleOK?sqrFmt((scale.x+scale.y)/2,3)+' arcsec/pixel':'Unavailable']
      ].map(([name,value])=>'<td width="33%"><b>'+name+'</b><br/>'+sqrHTML(value)+'</td>').join('')+'</tr></table>';
      current.sizer.add(this.setupSummary);
      this.parameters=new Control(this);this.parameters.sizer=new VerticalSizer;this.parameters.sizer.spacing=10;
      let setup=sqrGroup(this.parameters,'Observing conditions'),limits=sqrGroup(this.parameters,this.seeingValue>0?'Limits relative to expected FWHM':'Seeing limits at zenith');
      this.parameters.sizer.add(setup);this.parameters.sizer.add(limits);
      const field=(parent,key,label,value,low,high,precision,unit,tip)=>{
         let n=sqrNumber(parent,label,value,low,high,precision);n.enableFixedPrecision(true);n.label.setScaledFixedWidth(180);n.label.textAlignment=TextAlignment.Left|TextAlignment.VertCenter;n.edit.setScaledFixedWidth(80);n.toolTip=tip;n.onValueUpdated=()=>this.refreshModel();
         let row=new HorizontalSizer;row.spacing=8;row.add(n);let units=new Label(parent);units.text=unit;units.textAlignment=TextAlignment.Left|TextAlignment.VertCenter;row.add(units);
         parent.sizer.add(row);this.fields[key]=n;return {n,row};
      };
      field(setup,'fwhmAltitude','Target altitude',o.fwhmAltitude,15,90,1,'degrees','One reference altitude for the session; 90 degrees is zenith.').row.addStretch();
      let wavelength=Object.prototype.hasOwnProperty.call(this.wavelengths,this.filterBand.key)?this.wavelengths[this.filterBand.key]:this.filterBand.nm;
      let {n:wave,row:wavelengthRow}=field(setup,'fwhmWavelength','Wavelength',wavelength,300,2500,1,'nm','Starts at the filter default. Custom values are saved for this filter.');
      this.wavelengthReset=sqrTool(setup,':/icons/reload.png','Use filter default',()=>{wave.setValue(this.filterBand.nm);this.refreshModel();});
      this.wavelengthInfo=new Label(setup);this.wavelengthInfo.wordWrapping=true;this.wavelengthInfo.text='Default: '+sqrFilterWavelengthText(this.filterBand);
      wavelengthRow.add(this.wavelengthReset);wavelengthRow.add(this.wavelengthInfo,100);
      let optics=field(setup,'fwhmOptics','Additional optical blur',o.fwhmOptics,0,20,3,'arcsec','Optional allowance for independently calibrated focus or optical blur in the imaging telescope. Normally leave at zero.');
      let optional=new Label(setup);optional.text='Optional; normally 0';optics.row.addSpacing(12);optics.row.add(optional);optics.row.addStretch();
      if(this.seeingValue>0){
         field(limits,'fwhmGoodPercent','Good up to',o.fwhmGoodPercent,1,500,1,'% of expected FWHM','Upper boundary for Good.').row.addStretch();
         field(limits,'fwhmMediumPercent','Medium up to',o.fwhmMediumPercent,1,500,1,'% of expected FWHM','Upper boundary for Medium. Must be greater than the Good limit; larger values are Bad.').row.addStretch();
      }else{
         field(limits,'fwhmSeeingGood','Good up to',o.fwhmSeeingGood,.01,20,2,'arcsec','Chosen seeing boundary at zenith and 550 nm; not a measurement of the current atmosphere.').row.addStretch();
         field(limits,'fwhmSeeingMedium','Medium up to',o.fwhmSeeingMedium,.01,20,2,'arcsec','Seeing boundary at zenith and 550 nm. Must be greater than the Good limit.').row.addStretch();
      }
      let mode=new Label(limits);mode.wordWrapping=true;mode.text=this.seeingValue>0?'Uses the seeing estimate from Input files and observing conditions.':'No seeing estimate supplied. These limits define your acceptance criteria.';limits.sizer.add(mode);

      let result=sqrGroup(this,'FWHM limits in pixels');
      this.preview=new Label(result);this.preview.useRichText=true;this.preview.wordWrapping=true;this.preview.setFixedHeight(3*this.font.height+4);result.sizer.add(this.preview);
      this.gradeRows=[];
      for(let [name,color] of [['Good','#24753b'],['Medium','#946000'],['Bad','#b33333']]){
         let row=new HorizontalSizer;row.spacing=12;
         let label=new Label(result);label.useRichText=true;label.text='<b><font color="'+color+'">'+name+'</font></b>';label.textAlignment=TextAlignment.Left|TextAlignment.VertCenter;label.setScaledFixedWidth(120);
         let range=new Label(result);range.useRichText=true;range.textAlignment=TextAlignment.Left|TextAlignment.VertCenter;range.setFixedHeight(this.font.height+10);
         row.add(label);row.add(range,100);result.sizer.add(row);this.gradeRows.push(range);
      }
      this.note=new Label(this);this.note.wordWrapping=true;this.note.text='Bands guide visual review. Scores and rejection choices stay unchanged.';
      this.applyButton=sqrButton(this,'Apply',()=>this.ok());this.cancelButton=sqrButton(this,'Cancel',()=>this.cancel());this.applyButton.defaultButton=true;this.cancelButton.escapeButton=true;
      let buttons=new HorizontalSizer;buttons.spacing=8;buttons.addStretch();buttons.add(this.applyButton);buttons.add(this.cancelButton);
      this.sizer=new VerticalSizer;this.sizer.margin=12;this.sizer.spacing=10;this.sizer.add(this.intro);this.sizer.add(enabledRow);this.sizer.add(current);this.sizer.add(this.parameters);this.sizer.add(result);this.sizer.add(this.note);this.sizer.add(buttons);
      this.enabledCheck.onCheck=()=>this.refreshModel();this.setScaledFixedWidth(680);this.refreshModel();this.adjustToContents();
   }
   options(){let wavelengths={...this.wavelengths},value=this.fields.fwhmWavelength.value;
      if(value===this.filterBand.nm)delete wavelengths[this.filterBand.key];else wavelengths[this.filterBand.key]=value;
      return {...this.baseOptions,fwhmEnabled:this.enabledCheck.checked,fwhmAperture:this.apertureValue,fwhmSeeing:this.seeingValue,fwhmWavelengths:wavelengths,
         ...Object.fromEntries(Object.entries(this.fields).filter(([key])=>key!=='fwhmWavelength').map(([key,control])=>[key,control.value]))};}
   refreshModel(){
      let m=this.model=sqrFWHMModel(this.options(),this.scale,this.filter);this.parameters.enabled=this.enabledCheck.checked;this.applyButton.enabled=m.parametersValid;
      this.preview.text=m.valid?(m.mode==='relative'?'<b>Expected FWHM: '+sqrFmt(m.expected,1)+' px</b>':'Limits for the current telescope and observing conditions.')+'<br/>One decimal place; grading uses full precision.':sqrHTML(m.reason);
      let values=m.valid?['Up to '+sqrFmt(m.good,1)+' px','Above '+sqrFmt(m.good,1)+' to '+sqrFmt(m.medium,1)+' px','Above '+sqrFmt(m.medium,1)+' px']:['—','—','—'];
      this.gradeRows.forEach((row,i)=>row.text='<b>'+values[i]+'</b>');
   }
   showModelInformation(){(new SQRPlotInfoDialog(sqrFWHMModelInformation(this.model))).execute();}
}

// Use current PJSR dialog path properties; text edits and browsing invoke the
// same invalidation callback when an input directory changes.
function sqrFolderRow(parent,label,value,changed){
   let row=new HorizontalSizer;row.spacing=8;let l=new Label(parent);l.text=label;l.setScaledFixedWidth(135);
   let edit=new Edit(parent);edit.text=value;edit.setScaledFixedWidth(950);edit.onEditCompleted=()=>changed(edit.text);
   let browse=sqrTool(parent,':/icons/select-file.png','Choose '+label.toLowerCase(),()=>{let d=new GetDirectoryDialog;d.caption=label;d.initialPath=edit.text;if(d.execute()){edit.text=d.directoryPath;changed(edit.text,true);}});
   row.add(l);row.add(edit);row.add(browse);row.addStretch();parent.sizer.add(row);return {edit:edit,browse:browse};
}
/** Rearrange existing controls at a width breakpoint. The parent keeps its
 * permanent sizer: PJSR does not allow replacing an assigned control sizer.
 * Only row sizers are rebuilt, preserving focus, values and event handlers.
 * A null item is stretch space; numbers are fixed spacing; [control,weight]
 * gives a control the available row width. All other items are controls.
 * A breakpoint function returns a measured width in physical pixels. */
function sqrResponsiveRows(parent,wide,compact,breakpoint,spacing=8){
   parent.sizer=new VerticalSizer;parent.sizer.spacing=8;
   let rows=[],mode=null;
   for(let item of wide.flat()){let control=Array.isArray(item)?item[0]:item;
      if(control&&typeof control!=='number'&&control.parent!==parent){control.parent=parent;control.show();}}
   parent.reflow=width=>{
      let limit=typeof breakpoint==='function'?breakpoint():breakpoint*parent.displayPixelRatio;
      let next=width<limit;if(next===mode)return;
      mode=next;
      for(let entry of rows){for(let control of entry.controls)entry.row.remove(control);parent.sizer.remove(entry.row);}
      rows=[];
      for(let items of next?compact:wide){let row=new HorizontalSizer;row.spacing=spacing;let controls=[];
         for(let item of items){if(item===null)row.addStretch();else if(typeof item==='number')row.addSpacing(item);
            else{let control=Array.isArray(item)?item[0]:item;row.add(control,Array.isArray(item)?item[1]:0);controls.push(control);}}
         parent.sizer.add(row);rows.push({row,controls});
      }
   };
   parent.reflow(Infinity);return parent;
}
/** Review individual files before an undo. Selecting a moved Review row
 * preselects only that original; otherwise all eligible files start selected.
 * A journal chooser keeps undo available after rescanning or restarting. */
class SQRRestoreDialog extends Dialog {
   constructor(path='',selectedSource='',directory=''){
      super();this.windowTitle='Undo moved originals';this.record=null;this.plan=null;this.selectedSource=selectedSource;this.directory=directory;
      this.note=new Label(this);this.note.wordWrapping=true;this.note.text='Choose the original SQR-moves journal, then select the files to return to their original folders. Restored files will be marked as kept in the current review.';
      this.path=new Edit(this);this.path.readOnly=true;
      this.browse=sqrTool(this,':/icons/select-file.png','Choose an SQR-moves journal from a rejection folder.',()=>this.chooseJournal());
      let files=new HorizontalSizer;files.spacing=8;files.add(this.path,100);files.add(this.browse);
      this.table=new TreeBox(this);this.table.numberOfColumns=4;this.table.headerVisible=true;this.table.alternateRowColor=true;this.table.rootDecoration=false;this.table.setScaledMinSize(850,280);
      ['Restore','Original file','Restore to','Status'].forEach((text,i)=>this.table.setHeaderText(i,text));this.icons=[sqrRejectIcon(this,false),sqrRejectIcon(this,true)];
      this.table.onNodeClicked=(node,column)=>{if(column===0&&node?.entry&&!node.entry.problem){node.restore=!node.restore;this.refreshSelection();}};
      this.table.onKeyPress=key=>{if(key!==Key_Space)return false;let node=this.table.currentNode;if(node?.entry&&!node.entry.problem){node.restore=!node.restore;this.refreshSelection();}return true;};
      this.all=sqrButton(this,'Select available',()=>this.selectAll(true));this.none=sqrButton(this,'Clear selection',()=>this.selectAll(false));
      this.summary=new Label(this);this.summary.wordWrapping=true;this.summary.text='Choose a move journal to list its files.';
      this.restore=sqrButton(this,'Restore selected',()=>{try{this.plan=sqrRestorePlan(this.record,this.indices());this.ok();}catch(e){this.error(e);}});this.restore.enabled=false;
      this.close=sqrButton(this,'Cancel',()=>this.cancel());
      let actions=new HorizontalSizer;actions.spacing=8;actions.add(this.all);actions.add(this.none);actions.addStretch();actions.add(this.restore);actions.add(this.close);
      this.sizer=new VerticalSizer;this.sizer.margin=10;this.sizer.spacing=10;this.sizer.add(this.note);this.sizer.add(files);this.sizer.add(this.table,100);this.sizer.add(this.summary);this.sizer.add(actions);
      this.all.enabled=this.none.enabled=false;
      if(path)try{this.loadJournal(path);}catch(e){this.path.text=path;this.summary.text='Unable to read this move journal: '+String(e)+' Choose another journal.';}
      this.adjustToContents();
   }
   error(e){new MessageBox(String(e),'Restore originals',StdIcon.Error,StdButton.Ok).execute();}
   chooseJournal(){let d=new OpenFileDialog;d.multipleSelections=false;d.caption='Choose original SQR-moves journal';d.filters=[['SQR move journals','SQR-moves-*.json'],['JSON files','*.json']];d.initialPath=this.path.text||this.directory;
      if(d.execute())try{this.loadJournal(d.filePaths[0]);}catch(e){this.error(e);}}
   loadJournal(path){let record=sqrReadMoveJournal(path);this.record=record;this.path.text=record.path;this.table.clear();
      let selected=this.selectedSource&&record.entries.some(entry=>sqrKey(entry.source)===sqrKey(this.selectedSource));
      for(let entry of record.entries){let node=new TreeBoxNode(this.table);node.entry=entry;node.restore=!entry.problem&&(!selected||sqrKey(entry.source)===sqrKey(this.selectedSource));
         node.setText(1,sqrFileName(entry.source));node.setText(2,entry.source);node.setText(3,entry.problem||'Ready to restore');node.setToolTip(1,'Moved file: '+entry.target);node.setToolTip(2,entry.source);node.setToolTip(3,entry.problem||'Return this unchanged light file to its unoccupied original path.');}
      for(let i=0;i<4;++i)this.table.adjustColumnWidthToContents(i);this.table.setColumnWidth(0,65);this.refreshSelection();
   }
   indices(){let indices=[];for(let i=0;i<this.table.numberOfChildren;++i){let node=this.table.child(i);if(node.restore)indices.push(node.entry.index);}return indices;}
   selectAll(value){for(let i=0;i<this.table.numberOfChildren;++i){let node=this.table.child(i);node.restore=value&&!node.entry.problem;}this.refreshSelection();}
   refreshSelection(){let available=0;for(let i=0;i<this.table.numberOfChildren;++i){let node=this.table.child(i);if(!node.entry.problem){++available;node.setIcon(0,this.icons[node.restore?1:0]);}else node.setText(0,'—');}
      let count=this.indices().length;this.restore.enabled=count>0;this.all.enabled=this.none.enabled=available>0;
      this.summary.text=count+' selected · '+available+' available · '+(this.table.numberOfChildren-available)+' unavailable or already restored. Existing files are never overwritten.';
   }
}
// Read the displayed, unscaled bitmap without copying an Image or rereading a
// source file. The channel tag distinguishes grayscale from neutral RGB pixels.
function sqrPreviewPixel(bitmap,x,y){
   if(!bitmap||x<0||y<0||x>=bitmap.width||y>=bitmap.height)return null;
   let pixel=bitmap.pixel(x,y),rgb=[(pixel>>>16)&255,(pixel>>>8)&255,pixel&255];
   return (bitmap.sqrChannels===1?[rgb[0]]:rgb).map(v=>v/255);
}
// Extend the bundled viewer while preserving its navigation handlers. Repaint
// refreshes a stationary pointer after zoom, pan, blinking or region changes.
function sqrInstallPixelReadout(viewer,bitmapProvider){
   viewer.pixelName_Label=new Label(viewer);viewer.pixelName_Label.text='Value:';
   viewer.pixelValue_Label=new Label(viewer);viewer.pixelValue_Label.text='---';
   let row=viewer.coords_Control.sizer;row.insert(row.numberOfItems-1,viewer.pixelName_Label);row.insert(row.numberOfItems-1,viewer.pixelValue_Label);
   viewer.pixelValue_Label.toolTip='Displayed preview pixel value, normalized to 0–1, with 8-bit display precision. Includes Display STF and preview brightness alignment when enabled. X/Y are relative to the selected region or corner mosaic. RGB images show all three channels.';
   let pointer=null;
   const label=(control,text)=>{if(control.text!==text)control.text=text;};
   viewer.refreshPixelReadout=()=>{
      let pos=pointer&&viewer.isValid?viewer.viewportToImage(pointer.x,pointer.y):null;
      let values=pos?sqrPreviewPixel(bitmapProvider(),Math.floor(pos.x),Math.floor(pos.y)):null;
      label(viewer.xValue_Label,values?format('%8.2f',pos.x):'---');label(viewer.yValue_Label,values?format('%8.2f',pos.y):'---');
      label(viewer.pixelValue_Label,values?values.map((v,c)=>(values.length===3?['R ','G ','B '][c]:'')+v.toFixed(6)).join('  '):'---');
   };
   viewer.clearPixelReadout=()=>{pointer=null;viewer.refreshPixelReadout();};
   let viewport=viewer.scrollbox.viewport,move=viewport.onMouseMove,wheel=viewport.onMouseWheel,leave=viewport.onLeave,paint=viewport.onPaint,hide=viewport.onHide;
   viewport.tracking=true;
   viewport.onMouseMove=function(x,y,buttons,modifiers){if(move)move.call(this,x,y,buttons,modifiers);pointer={x,y};viewer.refreshPixelReadout();};
   viewport.onMouseWheel=function(x,y,delta,buttons,modifiers){if(wheel)wheel.call(this,x,y,delta,buttons,modifiers);pointer={x,y};viewer.refreshPixelReadout();};
   viewport.onLeave=function(){if(leave)leave.call(this);viewer.clearPixelReadout();};
   viewport.onHide=function(){if(hide)hide.call(this);viewer.clearPixelReadout();};
   viewport.onPaint=function(x0,y0,x1,y1){if(paint)paint.call(this,x0,y0,x1,y1);viewer.refreshPixelReadout();};
}
/** Copy a single region or the four corners into a temporary preview image.
 * Mosaic rectangles are TL, TR, BL, BR, copied at native pixel resolution.
 * Assemble before display calibration so all corners share one brightness
 * alignment and stretch; per-corner normalization would hide field differences.
 * Source images are neither modified nor retained by this helper. */
function sqrAssignPreview(image,source,rect){
   let channels=source.numberOfNominalChannels;
   if(!Array.isArray(rect[0])){image.assign(source,new Rect(...rect),0,channels-1);return;}
   let width=rect[0][2]-rect[0][0],height=rect[0][3]-rect[0][1];
   if(rect.length!==4||width<=0||height<=0||rect.some(r=>r.length!==4||!r.every(Number.isInteger)||
      r[0]<0||r[1]<0||r[2]>source.width||r[3]>source.height||r[2]-r[0]!==width||r[3]-r[1]!==height))
      throw new Error('Corner mosaic requires four equal-sized regions within the image.');
   image.allocate(2*width,2*height,channels,source.colorSpace);
   for(let i=0;i<4;++i)image.apply(source,ImageOp.Mov,new Point((i%2)*width,Math.floor(i/2)*height),0,new Rect(...rect[i]),0,channels-1);
}
/** Return two rendered preview bitmaps for identical image coordinates.
 * Brightness alignment and the shared reference-derived stretch modify temporary
 * images only. The dialog owns the returned bitmaps and releases them on reload. */
function sqrRenderFrames(a,b,o,rect,bands=null,refBands=null){
   let da=new Image,db=b?new Image:null,frames=[];
   try{
      if(b&&(a.width!==b.width||a.height!==b.height||a.numberOfNominalChannels!==b.numberOfNominalChannels))
         throw new Error('Reference and registered frame must have identical dimensions and channels.');
      sqrAssignPreview(da,a,rect);if(b)sqrAssignPreview(db,b,rect);
      if(b&&o.alignBrightness){
         // Robust affine background/contrast alignment for display only.
         for(let c=0;c<da.numberOfNominalChannels;++c){
            let whole=new Rect(0,0,da.width,da.height),ma=da.median(whole,c,c),mb=db.median(whole,c,c),sa=da.MAD(ma,whole,c,c),sb=db.MAD(mb,whole,c,c);
            let scale=sa>0&&sb>0?Math.max(.1,Math.min(10,sb/sa)):1;
            da.apply(ma,ImageOp.Sub,whole,c,c);da.apply(scale,ImageOp.Mul,whole,c,c);da.apply(mb,ImageOp.Add,whole,c,c);
         }
      }
      if(o.displaySTF){let stretch=(db||da).computeAutoStretch();da.applyDisplayFunction(stretch);if(db)db.applyDisplayFunction(stretch);}
      da.truncate();sqrApplyTrailBands(da,bands,rect);frames.push(da.render());if(db){db.truncate();sqrApplyTrailBands(db,refBands,rect);frames.push(db.render());}for(let frame of frames)frame.sqrChannels=da.numberOfNominalChannels;return frames;
   }catch(e){for(let frame of frames)frame.clear();throw e;}finally{da.free();if(db)db.free();}
}
/** Keep one reference bitmap and its numeric display calibration. No Image is
 * retained. The fingerprint, crop and display options invalidate the entry;
 * returned reference bitmaps are borrowed and released by the dialog cache. */
function sqrReferenceDisplay(path,o,rect,cache,bands){
   let key=JSON.stringify([sqrKey(path),sqrFingerprint(path),rect,!!o.alignBrightness,!!o.displaySTF,bands]);
   if(cache.data?.key===key)return cache.data;
   if(cache.data){cache.data.bitmap.clear();cache.data=null;}
   let source=null,crop=new Image,bitmap=null;
   try{
      source=sqrReadImage(path,true);
      let width=source.width,height=source.height,channels=source.numberOfNominalChannels;
      sqrAssignPreview(crop,source,rect);source.free();source=null;
      let whole=new Rect(0,0,crop.width,crop.height),stats=[];
      if(o.alignBrightness)for(let c=0;c<channels;++c){let median=crop.median(whole,c,c);stats.push({median,mad:crop.MAD(median,whole,c,c)});}
      let stretch=o.displaySTF?crop.computeAutoStretch():null;
      if(o.displaySTF)crop.applyDisplayFunction(stretch);
      crop.truncate();sqrApplyTrailBands(crop,bands,rect);bitmap=crop.render();bitmap.sqrChannels=channels;
      return cache.data={key,width,height,channels,stats,stretch,bitmap};
   }catch(e){if(bitmap)bitmap.clear();throw e;}finally{if(source)source.free();crop.free();}
}
function sqrFrames(path,reference,o,rect,isMaster=false,cache=null,bands=null,refBands=null){
   if(cache){let display=sqrReferenceDisplay(reference,o,rect,cache,refBands);
      return [sqrRotationFrame(path,o,rect,display,isMaster,bands).bitmap,display.bitmap];}
   let a=null,b=null;
   try{a=sqrReadImage(path,isMaster);b=sqrReadImage(reference,true);return sqrRenderFrames(a,b,o,rect,bands,refBands);}
   finally{if(a)a.free();if(b)b.free();}
}
// Read each source once for a complete regional cycle. Keep only rendered
// bitmaps afterwards; temporary images are released on success and failure.
function sqrRegionFrames(path,reference,o,regions,isMaster=false,bands=null,refBands=null){
   let a=null,b=null,frames=[];
   try{a=sqrReadImage(path,isMaster);if(reference)b=sqrReadImage(reference,true);
      for(let rect of regions)frames.push(sqrRenderFrames(a,b,o,rect,bands,refBands));return frames;
   }catch(e){for(let pair of frames)for(let frame of pair)frame.clear();throw e;}
   finally{if(a)a.free();if(b)b.free();}
}

/** Render one subframe for rotation, retaining only numeric display calibration.
 * The first displayed subframe supplies the common brightness/STF baseline.
 * Subsequent steps read only their own image; no master or full sequence is held.
 * A changed group, region or display option starts a new calibration. */
function sqrRotationFrame(path,o,rect,display=null,isMaster=false,bands=null){
   let source=null,image=new Image;
   try{
      source=sqrReadImage(path,isMaster);let channels=source.numberOfNominalChannels;
      if(display&&(source.width!==display.width||source.height!==display.height||channels!==display.channels))
         throw new Error(display.bitmap?'Reference and registered frame must have identical dimensions and channels.':'Rotating subframes must have identical dimensions and channels.');
      sqrAssignPreview(image,source,rect);
      let whole=new Rect(0,0,image.width,image.height),stats=[];
      if(o.alignBrightness)for(let c=0;c<channels;++c){let median=image.median(whole,c,c);stats.push({median,mad:image.MAD(median,whole,c,c)});}
      if(!display)display={width:source.width,height:source.height,channels,stats,stretch:o.displaySTF?image.computeAutoStretch():null};
      else if(o.alignBrightness)for(let c=0;c<channels;++c){
         let a=stats[c],b=display.stats[c],scale=a.mad>0&&b.mad>0?Math.max(.1,Math.min(10,b.mad/a.mad)):1;
         image.apply(a.median,ImageOp.Sub,whole,c,c);image.apply(scale,ImageOp.Mul,whole,c,c);image.apply(b.median,ImageOp.Add,whole,c,c);
      }
      if(o.displaySTF)image.applyDisplayFunction(display.stretch);
      image.truncate();sqrApplyTrailBands(image,bands,rect);let bitmap=image.render();bitmap.sqrChannels=channels;return {bitmap,display};
   }finally{if(source)source.free();image.free();}
}

/** Own UI state and keep selection, REVIEW candidacy and rejection independent.
 * current points to a row object; visibleRows is only the current table view.
 * populating guards programmatic table changes against selection callbacks.
 * selectionCleared preserves an intentional deselection across refreshes.
 * running prevents conflicting operations while processEvents keeps the UI alive.
 * frames holds rendered previews; frame selects image/reference; blinking and
 * the timer control pair alternation without rereading files. Subframe rotation
 * loads one image per tick with a common numeric display calibration. Regional
 * playback borrows frames from regionFrames; the cache owns their lifetime. */
function sqrWBPPLogSummary(report){
   if(!report)return 'No WBPP run log found.';
   const n=report.findings.length,marked=report.findings.filter(f=>f.eligible&&f.row.reject&&!f.row.moved).length;
   if(!n)return report.note||'WBPP log: no frame findings.';
   return 'WBPP log: '+n+' frame finding'+(n===1?'':'s')+' · '+marked+' marked for rejection.'+(report.note?' '+report.note:'');
}

class SQRWBPPLogDialog extends Dialog {
   constructor(report,allowImport){
      super();this.windowTitle='WBPP report';this.chooseSetup=false;this.changed=false;
      let note=new Label(this);note.wordWrapping=true;note.useRichText=false;note.toolTip=report.path;
      const summarize=()=>{note.text=sqrFileName(report.path)+' · '+sqrWBPPLogSummary(report);};summarize();
      this.table=new TreeBox(this);this.table.numberOfColumns=4;this.table.headerVisible=true;this.table.alternateRowColor=true;this.table.rootDecoration=false;this.table.setScaledMinSize(800,260);
      ['Decision','Exposure','Association','WBPP reason'].forEach((title,i)=>this.table.setHeaderText(i,title));
      const decision=f=>f.row?.moved?'Moved':f.row?.reject?'Rejected':f.eligible?'Kept':'Inspect';
      for(const f of report.findings){
         let node=new TreeBoxNode(this.table);node.finding=f;node.checkable=false;
         node.setText(0,decision(f));node.setText(1,sqrFileName(f.path));node.setToolTip(1,f.path);
         node.setText(2,!f.row?.original?'No verified match':f.row.registered?'Registered':'Original only');
         node.setText(3,f.reason);node.setToolTip(3,f.reason);
      }
      for(let i=0;i<4;++i)this.table.adjustColumnWidthToContents(i);
      let buttons=new HorizontalSizer;buttons.spacing=8;
      if(allowImport){
         this.importSetup=sqrButton(this,'Import setup…',()=>{this.chooseSetup=true;this.ok();});buttons.add(this.importSetup);
      }
      // Registered exposures already have a decision control in Review.
      // Preserve an override for verified lights that never reached registration.
      const originalOnly=f=>f?.eligible&&!f.row.registered&&!f.row.moved;
      if(report.findings.some(originalOnly)){
         this.override=sqrButton(this,'Keep original',()=>{
            const node=this.table.currentNode,f=node?.finding;if(!originalOnly(f))return;
            f.row.reject=!f.row.reject;this.changed=true;node.setText(0,decision(f));summarize();updateOverride();
         });
         const updateOverride=()=>{const f=this.table.currentNode?.finding;this.override.enabled=!!originalOnly(f);
            this.override.text=originalOnly(f)&&!f.row.reject?'Reject original':'Keep original';};
         this.override.toolTip='Change the mark for the selected original-only exposure.';buttons.add(this.override);
         this.table.onCurrentNodeUpdated=updateOverride;updateOverride();
      }
      let close=sqrButton(this,'Close',()=>this.ok());close.defaultButton=true;close.escapeButton=true;
      buttons.addStretch();buttons.add(close);
      this.sizer=new VerticalSizer;this.sizer.margin=10;this.sizer.spacing=8;this.sizer.add(note);this.sizer.add(this.table,100);this.sizer.add(buttons);this.adjustToContents();
   }
}
/** Both sources lead to the same decoded setup. Import validates files before replacing a review. */
class SQRWBPPImportDialog extends Dialog {
   constructor(savedData=null){super();this.windowTitle='Import WBPP setup';this.data=null;this.records=[];
      let label=new Label(this);label.text='WBPP instance:';
      this.instances=new ComboBox(this);this.instances.setScaledMinWidth(360);this.instances.onItemSelected=()=>this.select();
      this.file=sqrButton(this,'Open .xpsm…',()=>{let d=new OpenFileDialog;d.caption='Select saved WBPP process icons';d.filters=[['PixInsight process icons','*.xpsm']];d.multipleSelections=false;
         if(d.execute())try{this.addFile(d.fileName);}catch(e){this.fail(e);}});
      this.file.toolTip='Add WBPP instances from a saved .xpsm file to the selector. Loaded icons and entries from other files stay available. Opening the same file again refreshes its entries.';
      this.description=new Label(this);this.description.wordWrapping=true;this.description.useRichText=false;this.description.setScaledFixedSize(560,150);
      this.importButton=sqrButton(this,'Import',()=>{if(this.data)this.ok();});this.importButton.defaultButton=true;
      let cancel=sqrButton(this,'Cancel',()=>this.cancel());
      let row=new HorizontalSizer;row.spacing=8;row.add(label);row.add(this.instances,100);
      let sources=new HorizontalSizer;sources.spacing=8;sources.add(this.file);sources.addStretch();
      let buttons=new HorizontalSizer;buttons.spacing=8;buttons.addStretch();buttons.add(this.importButton);buttons.add(cancel);
      this.sizer=new VerticalSizer;this.sizer.margin=10;this.sizer.spacing=8;this.sizer.add(sources);this.sizer.add(row);this.sizer.add(this.description);this.sizer.add(buttons);
      try{let records=sqrWBPPIcons();if(savedData)records.unshift({id:'Saved WBPP setup',savedData});this.addRecords(records,'Loaded process icons','icons');}catch(e){this.fail(e);}
      this.adjustToContents();this.setFixedSize();
   }
   fail(e){this.data=null;this.importButton.enabled=false;this.description.text=String(e.message||e);this.description.toolTip='';}
   addFile(path){let source=sqrPath(path);this.addRecords(sqrWBPPFile(source),source,'file:'+sqrKey(source));}
   // Keep each source's entries and provenance together. Reopening one file
   // refreshes just that group in place; a failed read leaves the list intact.
   addRecords(records,source,sourceKey){let first=this.records.findIndex(r=>r.sourceKey===sourceKey);
      let retained=this.records.filter(r=>r.sourceKey!==sourceKey);if(first<0)first=retained.length;
      retained.splice(first,0,...records.map(r=>({...r,source,sourceKey})));this.records=retained;
      this.instances.clear();for(let r of this.records){
         let label=r.savedData?r.id:r.id+' — '+(r.sourceKey==='icons'?'loaded icon':sqrFileName(r.source));
         // Equal file names in different folders still need distinct labels.
         if(r.sourceKey!=='icons'&&this.records.some(other=>other.sourceKey!==r.sourceKey&&other.sourceKey!=='icons'&&sqrFileName(other.source)===sqrFileName(r.source)))label=r.id+' — '+r.source;
         this.instances.addItem(label);}
      this.instances.currentItem=records.length?first:this.records.length?0:-1;this.select();
   }
   select(){this.data=null;this.importButton.enabled=false;let record=this.records[this.instances.currentItem];
      this.instances.toolTip=record?(record.savedData?.source||record.source)+' · '+record.id:'';
      if(!record){this.description.text='No WBPP setup is available. Open a saved .xpsm file, or load a WBPP process icon in PixInsight and reopen this dialog.';return;}
      try{this.data=record.savedData?JSON.parse(JSON.stringify(record.savedData)):sqrWBPPDecodeRecord(record);if(!record.savedData)this.data.source=record.source+' · '+record.id;
         this.description.text='WBPP '+this.data.version+' · '+this.data.lights.length+' enabled lights · '+this.data.disabled+' disabled lights omitted\n\nOutput: '+this.data.wbpp+'\nOriginals: '+this.data.originals+'\n\nImport verifies the files and populates Review. Existing measurements and rejection selections are replaced.';
         this.description.toolTip=this.data.source+'\n'+this.description.text;this.importButton.enabled=true;
      }catch(e){this.fail(e);}
   }
}
class SQRTrailRepairDialog extends Dialog {
   constructor(source,row,preferredWidth=9){
      super();this.windowTitle='Remove trails — '+sqrFileName(row.registered.path);this.bands=null;this.preferredWidth=preferredWidth;
      let stf=source.computeAutoStretch(),saved=row.trailBands||[],bands=saved.slice(),history=[],selected=bands.length-1,syncing=false,manualWidth=preferredWidth;
      let view=this.view=new ImageView(this);view.setScaledMinSize(550,320);
      let status=new Label(this);status.wordWrapping=true;
      let width=sqrNumber(this,'Mask width (px):',bands.length?bands[bands.length-1].width:preferredWidth,1,200,0);width.setReal(false);
      width.toolTip='Width in registered pixels. Select a trail to adjust its mask. While drawing, this sets the manual width for the next band.';
      let autoWidth=new CheckBox(this);autoWidth.text='Auto width';autoWidth.checked=true;
      autoWidth.toolTip='Estimate a width for each new band from the registered image. Clear to apply the entered width.';
      const sizeBand=b=>{let estimate=autoWidth.checked?sqrEstimateTrailWidth(source,b):null;
         if(estimate!==null)b.width=estimate;return estimate!==null;};
      function render(after){let display=new Image;
         try{display.assign(source);display.applyDisplayFunction(stf);display.truncate();if(after)sqrApplyTrailBands(display,bands);return display.render();}
         finally{display.free();}}
      let original=render(false),after=null;view.setImage(original);
      let show=new CheckBox(this);show.text='Show masked pixels';show.checked=!!bands.length;
      let draw=new CheckBox(this);draw.text='Draw manually';draw.checked=false;
      draw.toolTip='Drag along the streak to draw a mask. Clear to pan and zoom with the mouse.';
      let start=null,end=null,viewport=view.scrollbox.viewport;
      const redraw=()=>{if(show.checked&&!after)after=render(true);view.regenerate(show.checked?after:original);};
      let list=new ComboBox(this);list.setScaledFixedWidth(155);
      list.toolTip='Choose a trail to edit its width, or remove the selected trail from the preview.';
      let extent=new ComboBox(this);for(let t of ['Automatic extent','Edge to edge','Visible segment'])extent.addItem(t);
      extent.toolTip='Automatic extent follows thin trails to the image edges and keeps bright, thick trails within their detected span. Applies when you click Remove trails.';
      const remember=()=>history.push({bands:bands.slice(),selected,width:width.value,manualWidth});
      const sync=()=>{
         syncing=true;list.clear();bands.forEach((_,i)=>list.addItem('Trail '+(i+1)));
         if(bands.length){list.addItem('Remove Trail '+(selected+1));list.currentItem=selected;}
         list.enabled=show.enabled=!!bands.length;undo.enabled=!!history.length;
         save.enabled=JSON.stringify(bands)!==JSON.stringify(saved)||(bands.length>0&&(!row.trailCopy||!File.exists(row.trailCopy)));
         save.text=!bands.length&&saved.length?'Remove saved repair':'Save repaired image';
         status.text=draw.checked?'Drag along the streak and release to preview the repair.':
            bands.length?bands.length+' trail band(s). Inspect the black pixels, then save or undo.':'Click Remove trails to preview automatic removal, or select Draw manually.';
         syncing=false;
      };
      const changed=()=>{if(after)after.clear();after=null;show.checked=!!bands.length;redraw();sync();};
      const point=(x,y,clamp)=>{let p=view.viewportToImage(x,y);
         if(!clamp&&(p.x<0||p.x>=source.width||p.y<0||p.y>=source.height))return null;
         return {x:Math.max(0,Math.min(source.width-1,Math.floor(p.x))),y:Math.max(0,Math.min(source.height-1,Math.floor(p.y)))};};
      const press=viewport.onMousePress,move=viewport.onMouseMove,release=viewport.onMouseRelease;
      viewport.onMousePress=function(x,y,b,state,mods){
         if(draw.checked&&b===MouseButton.Left&&!mods){start=end=point(x,y,false);this.update();}
         else press.call(this,x,y,b,state,mods);};
      viewport.onMouseMove=function(x,y,state,mods){
         if(start){end=point(x,y,true);this.update();}else move.call(this,x,y,state,mods);};
      viewport.onMouseRelease=function(x,y,b,state,mods){
         if(start&&b===MouseButton.Left){
            let a=start,z=point(x,y,true);start=end=null;
            if(a.x!==z.x||a.y!==z.y){remember();let band={start:a,end:z,width:autoWidth.checked?manualWidth:width.value},estimated=sizeBand(band);
               bands.push(band);selected=bands.length-1;selectWidth();changed();
               if(autoWidth.checked&&!estimated)status.text='Width could not be measured here. Using '+band.width+' px.';}
            this.update();
         }else release.call(this,x,y,b,state,mods);};
      view.onCustomPaint=g=>{if(!start||!end)return;
         g.pen=new Pen(0x907edee2,width.value);g.drawLine(start.x,start.y,end.x,end.y);
         g.pen=new Pen(0xffffdc64,1);g.drawLine(start.x,start.y,end.x,end.y);};
      draw.onCheck=()=>{start=end=null;viewport.update();sync();};
      const selectWidth=()=>{if(selected>=0){syncing=true;width.setValue(bands[selected].width);syncing=false;}};
      list.onItemSelected=i=>{if(syncing||i<0||!bands.length)return;
         if(i===bands.length){remember();bands.splice(selected,1);
            selected=Math.min(selected,bands.length-1);selectWidth();changed();return;}
         selected=i;draw.checked=false;selectWidth();sync();};
      width.onValueUpdated=v=>{if(syncing)return;
         if(!draw.checked&&selected>=0&&bands[selected].width!==v){remember();bands[selected]={...bands[selected],width:v};changed();}
         manualWidth=v;};
      let undo=sqrButton(this,'Undo',()=>{if(!history.length)return;start=end=null;
         let state=history.pop();bands=state.bands;selected=state.selected;manualWidth=state.manualWidth;
         syncing=true;width.setValue(selected>=0?bands[selected].width:state.width);syncing=false;changed();});
      undo.toolTip='Undo the last automatic removal, manual stroke, width change, or deletion.';
      let detect=sqrButton(this,'Remove trails',()=>{
         start=end=null;let fallback=autoWidth.checked?manualWidth:width.value;
         let found=sqrDetectTrailBands(source,fallback,['auto','full','segment'][extent.currentItem]||'auto');
         if(found.length){let measured=0;for(let band of found)if(sizeBand(band))++measured;
            remember();bands=found;selected=0;draw.checked=false;selectWidth();changed();
            if(autoWidth.checked&&measured<found.length)status.text+=' Used '+fallback+' px for '+(found.length-measured)+' unmeasured band(s).';}
         else{draw.checked=true;sync();status.text='No clear trail found. Drag along the streak to add a band.';}
      });
      detect.toolTip='Detect trails and preview their masks. Save to keep your changes.';
      show.onCheck=redraw;
      let save=sqrButton(this,'Save repaired image',()=>{this.bands=bands;this.preferredWidth=manualWidth;this.ok();});
      let cancel=sqrButton(this,'Cancel',()=>this.cancel());cancel.escapeButton=true;
      let trace=new HorizontalSizer;trace.spacing=8;for(let c of [width,autoWidth,extent,detect,draw])trace.add(c);trace.addStretch();
      let buttons=new HorizontalSizer;buttons.spacing=6;for(let c of [list,undo,show])buttons.add(c);buttons.addStretch();for(let c of [save,cancel])buttons.add(c);
      this.sizer=new VerticalSizer;this.sizer.margin=8;this.sizer.spacing=8;this.sizer.add(status);this.sizer.add(view,100);this.sizer.add(trace);this.sizer.add(buttons);
      this.userResizable=true;this.resize(Math.min(this.logicalPixelsToPhysical(950),this.availableScreenRect.width*.85),Math.min(this.logicalPixelsToPhysical(680),this.availableScreenRect.height*.85));
      this.onShow=()=>view.zoomToFit();show.checked=!!bands.length;if(show.checked)redraw();sync();
   }
}
class SQRMasterBlinkPage extends Control {
   constructor(parent,owner,o){
      super(parent);this.ownerDialog=owner;this.selections=new Map;this.referenceCache={};this.versions=[];this.indexShown=0;
      this.versionList=new ComboBox(this);this.versionList.setScaledFixedWidth(380);
      this.versionList.toolTip='Choose the reviewed integration to compare with the original WBPP master.';
      this.versionList.onItemSelected=()=>this.loadPair();
      let label=new Label(this);label.text='Reviewed master:';
      this.clock=new Timer(sqrBlinkInterval(o.blinkInterval),true,this);
      this.clock.onTimeout=()=>{if(this.playing&&this.ownerDialog.tabs.currentPageIndex===4&&!this.ownerDialog.running)this.showImage(1-this.indexShown);};
      this.interval=sqrNumber(this,'Interval (s):',this.clock.interval,.1,10,2);this.interval.edit.setScaledFixedWidth(48);
      this.interval.onValueUpdated=v=>{this.clock.interval=sqrBlinkInterval(v);if(this.playing)this.clock.start();};
      this.play=sqrTool(this,':/icons/play.png','Blink the two masters.',()=>this.setPlaying(!this.playing));
      this.step=sqrTool(this,':/icons/step-forward.png','Pause and show the other master.',()=>{this.setPlaying(false);if(this.pair)this.showImage(1-this.indexShown);});
      let row=new HorizontalSizer;row.spacing=6;row.add(label);row.add(this.versionList);row.addStretch();row.add(this.interval);row.add(this.play);row.add(this.step);
      this.view=new ImageView(this);this.view.setScaledMinSize(580,260);
      this.view.onShow=()=>{if(this.fitOnShow&&this.view.isValid){this.view.zoomToFit();this.fitOnShow=false;}this.view.scrollbox.viewport.update();};
      sqrInstallPixelReadout(this.view,()=>this.pair?.[this.indexShown]||null);
      this.stretch=new CheckBox(this);this.stretch.text='Display STF';this.stretch.checked=o.displaySTF;this.stretch.toolTip='Apply the original master’s display stretch to both images.';
      this.stretch.onCheck=()=>this.loadPair();this.view.appendTopControl(this.stretch);
      this.caption=new Label(this);this.caption.wordWrapping=true;this.caption.minHeight=this.font.height;
      this.sizer=new VerticalSizer;this.sizer.margin=6;this.sizer.spacing=6;this.sizer.add(row);this.sizer.add(this.view,100);this.sizer.add(this.caption);
      this.empty('Load the WBPP file list to compare masters.');
      this.onShow=()=>this.refresh(undefined,true);
      this.onHide=()=>this.setPlaying(false);
   }
   setPlaying(on){
      this.playing=!!on&&!!this.pair;this.clock.stop();if(this.playing)this.clock.start();
      this.play.icon=this.scaledResource(this.playing?':/icons/media-stop.png':':/icons/play.png');
      this.play.toolTip=this.playing?'Stop blinking.':'Blink the two masters.';
   }
   clearPair(){
      this.setPlaying(false);if(this.pair)this.pair[0].clear();this.pair=null;this.loadedKey=null;
      if(this.referenceCache.data)this.referenceCache.data.bitmap.clear();this.referenceCache={};
   }
   empty(message){
      this.clearPair();this.view.reset();this.view.setStatusMessage(message);this.view.clearPixelReadout();
      this.caption.text=message;this.caption.toolTip='';this.play.enabled=this.step.enabled=this.stretch.enabled=false;
      this.versionList.enabled=this.versions.length>0;
   }
   refresh(preferPath,revealing=false){
      let session=this.ownerDialog.session,g=this.ownerDialog.group(),wbpp=session?.options.wbpp;
      if(!g||!wbpp){this.versions=[];this.versionList.clear();this.empty('Load the WBPP file list to compare masters.');return;}
      this.selectionKey=JSON.stringify([sqrPath(wbpp),sqrMasterGroupKey(wbpp,g)]);
      if(preferPath)this.selections.set(this.selectionKey,preferPath);
      if(!revealing&&this.ownerDialog.tabs.currentPageIndex!==4){this.clearPair();this.view.reset();return;}
      let selected=this.selections.get(this.selectionKey);
      try{
         let list=sqrReviewedMasterVersions(wbpp,g,session.groups);this.versions=list.versions;
         this.versionList.clear();for(let v of this.versions)this.versionList.addItem(v.label);
         this.versionList.enabled=this.versions.length>0;
         if(!this.versions.length){this.empty(list.unreadable?'No readable reviewed master was found for this group. See the process console.':'Create a reviewed master for this group to compare it here.');return;}
         this.versionList.currentItem=Math.max(0,this.versions.findIndex(v=>v.path===selected));this.loadPair();
      }catch(e){this.empty('Cannot list the reviewed masters. '+e);}
   }
   loadPair(){
      let v=this.versions[this.versionList.currentItem],ref=this.ownerDialog.group()?.master;if(!v)return;
      this.selections.set(this.selectionKey,v.path);this.versionList.toolTip=v.label+'\n'+v.path;
      if(!ref||!File.exists(ref)){this.empty('The original WBPP master for this group is unavailable. Restore it and refresh the file list.');return;}
      let continuePlaying=this.playing;
      try{
         let key=JSON.stringify([ref,sqrFingerprint(ref),v.path,v.fingerprint,this.stretch.checked]);
         if(this.pair&&this.loadedKey===key)return;
         this.setPlaying(false);if(this.pair)this.pair[0].clear();this.pair=null;
         // Only the selected integration and the common WBPP reference are rendered.
         // Timer ticks reuse both bitmaps and leave the viewport transform intact.
         this.pair=sqrFrames(v.path,ref,{displaySTF:this.stretch.checked,alignBrightness:false},[0,0,v.width,v.height],true,this.referenceCache);
         this.view.setStatusMessage('');
         this.loadedKey=key;this.refPath=ref;this.reviewedPath=v.path;
         let fit=!this.view.isValid||this.imageW!==v.width||this.imageH!==v.height;this.imageW=v.width;this.imageH=v.height;
         this.showImage(0,fit);this.play.enabled=this.step.enabled=this.stretch.enabled=true;this.setPlaying(continuePlaying);
      }catch(e){this.empty('Cannot compare these masters. '+e);}
   }
   showImage(index,fit=false){
      this.indexShown=index;let bitmap=this.pair[index],path=index?this.refPath:this.reviewedPath;
      if(fit){this.view.setImage(bitmap);if(this.view.visible)this.view.zoomToFit();this.fitOnShow=!this.view.visible;}
      else this.view.regenerate(bitmap);
      this.view.refreshPixelReadout();this.caption.text=(index?'Original WBPP master':'Reviewed master')+'   '+sqrFileName(path);this.caption.toolTip=path;
   }
}
class SQRDialog extends Dialog {
   constructor(o,session=null){
      super();o={...sqrDefaults(),...o,logFolder:sqrLogFolderOption(o)};this.windowTitle='Subframe Quality Review '+SQR_VERSION;
      this.measurementOptions=sqrMeasurementOptions(o);
      this.fwhmOptions=sqrFWHMOptions(o);this.wbppImport=o.wbppImport||null;this.recommendationOptions=sqrRecommendationOptions(o);
      this.session=session;this.scannedInputs=session?.options;this.running=false;this.frames=null;this.blinking=false;this.frame=0;this.current=null;this.selectionCleared=false;this.qualityCollapsed=!!o.qualityCollapsed;this.inputsCollapsed=!!o.inputsCollapsed;this.reviewInfoCollapsed=!!o.reviewInfoCollapsed;this.messagesCollapsed=!!o.messagesCollapsed;this.fitPreviewOnShow=false;
      this.resumeBlinkOnReturn=false;this.referenceDisplay={};
      this.responsiveLayouts=[];
      this.layoutTimer=new Timer(.01,false,this);this.layoutTimer.onTimeout=()=>this.layoutBody();
      const responsive=(parent,wide,compact,breakpoint,spacing=8)=>{this.responsiveLayouts.push(sqrResponsiveRows(parent,wide,compact,breakpoint,spacing));return parent;};
      this.useCornerMeasurements=sqrHasCornerMeasurements(session)&&session.options.measureCorners!==false;
      this.cornerScoreChoice=sqrHasCornerMeasurements(session)?this.useCornerMeasurements:null;
      this.runFolders={wbpp:o.wbpp,originals:o.originals};
      this.timer=new Timer(sqrBlinkInterval(o.blinkInterval),false,this);this.timer.onTimeout=()=>{if(this.blinking&&!this.running&&this.tabs.currentPageIndex===1)this.advancePlayback();};
      this.inputs=new Control(this);this.inputs.sizer=new VerticalSizer;this.inputs.sizer.margin=10;this.inputs.sizer.spacing=8;
      this.inputsBar=new SectionBar(this,'Input files and observing conditions');this.inputsBar.setSection(this.inputs);
      this.inputsBar.toolTip='Click to collapse or expand input folders, log controls, telescope aperture, seeing, Session SQM and its reading time. Your paths, settings and measurements are retained.';
      this.inputsBar.toggleSection=()=>this.setInputsCollapsed(!this.inputsCollapsed);
      let apertureLabel=new Label(this.inputs);apertureLabel.text='Telescope aperture:';apertureLabel.setScaledFixedWidth(135);
      this.aperture=sqrNumber(this.inputs,'',this.fwhmOptions.fwhmAperture,0,50000,0);this.aperture.setReal(false);this.aperture.label.hide();this.aperture.edit.setScaledFixedWidth(54);
      this.fwhmOptions.fwhmAperture=this.aperture.value;
      let apertureUnit=new Label(this.inputs);apertureUnit.text='mm';
      this.aperture.toolTip='Enter the imaging telescope aperture diameter. Required for the FWHM grading bands; zero means not configured. This does not repeat image measurements or change scores.';
      this.aperture.onValueUpdated=()=>{if(this.fwhmOptions.fwhmAperture===this.aperture.value)return;
         this.fwhmOptions.fwhmAperture=this.aperture.value;this.syncOptions();if(this.histogram)this.updateHistogram();};
      this.apertureMenu=new ComboBox(this.inputs);this.apertureMenu.setScaledFixedWidth(84);
      this.apertureMenu.toolTip='Choose a saved telescope aperture, or edit the preset list for all reviews.';
      this.fillApertureMenu(sqrReadAperturePresets());
      this.apertureMenu.onItemSelected=index=>this.chooseAperturePreset(index);
      this.seeing=sqrNumber(this.inputs,'Zenith seeing (″):',this.fwhmOptions.fwhmSeeing,0,20,2);this.seeing.enableFixedPrecision(true);this.seeing.sizer.spacing=8;this.seeing.edit.setScaledFixedWidth(68);
      this.seeing.toolTip='Optional seeing estimate at zenith and a reference wavelength of 550 nm, in arcseconds. Zero keeps fixed seeing limits. A positive value grades FWHM relative to expected blur; adjust the Good/Medium percentages in FWHM grading. Forecasts are approximate; a value already corrected for target altitude must first be converted to zenith.';
      this.seeing.onValueUpdated=()=>{this.fwhmOptions.fwhmSeeing=this.seeing.value;this.syncOptions();if(this.histogram)this.updateHistogram();};
      this.sqm=sqrNumber(this.inputs,'Session SQM:',sqrSQMReading(o),0,30,2);this.sqm.enableFixedPrecision(true);this.sqm.sizer.spacing=8;this.sqm.edit.setScaledFixedWidth(68);
      this.sqm.toolTip='Optional sky-brightness reading in mag/arcsec². With a reading and its local date/time, the nearest eligible exposure midpoint selects a reference whose measured background is assigned this SQM value. Bortle class is estimated automatically; Gaia is not used. Zero enables manual Bortle selection and Gaia calibration on the Sky brightness plot. Scores are unchanged.';
      this.sqm.onValueUpdated=()=>this.bortleChanged();
      let sqmUnit=new Label(this.inputs);sqmUnit.text='mag/arcsec²';
      let sqmTimeLabel=new Label(this.inputs);sqmTimeLabel.text='SQM time (local):';
      this.sqmTime=new Edit(this.inputs);this.sqmTime.text=String(o.sqmTime||'');this.sqmTimePreset=o.sqmTimeFromLog?this.sqmTime.text.trim():'';this.sqmTime.setScaledMinWidth(135);this.sqmTime.setScaledMaxWidth(185);this.sqmTime.enabled=sqrSQMReading(o)>0;
      this.sqmTime.toolTip=SQR_SQM_TIME_HELP;
      this.sqmTime.onTextUpdated=()=>this.validateSQMTime();
      this.sqmTime.onEditCompleted=()=>this.sqmTimeChanged();
      this.sqmTimePicker=sqrButton(this.inputs,'Choose…',()=>this.editSQMTime());this.sqmTimePicker.toolTip='Choose the reading date and time. An empty value starts at the Autorun light-frame sequence, or at the selected exposure midpoint if no log preset is available. Apply confirms; Cancel leaves it unchanged.';this.sqmTimePicker.enabled=this.sqm.value>0;
      // Keep each label, value and unit together. Equal gaps between fields
      // remain stable when the SQM reading time wraps onto a second row.
      const conditionField=controls=>{let field=new Control(this.inputs);field.sizer=new HorizontalSizer;field.sizer.spacing=8;
         for(let control of controls){control.parent=field;control.show();field.sizer.add(control,control===this.sqmTime?100:0);}return field;};
      this.conditionFields=[conditionField([apertureLabel,this.aperture,apertureUnit,this.apertureMenu]),conditionField([this.seeing]),
         conditionField([this.sqm,sqmUnit]),conditionField([sqmTimeLabel,this.sqmTime,this.sqmTimePicker])];
      this.conditions=responsive(new Control(this.inputs),
         [[this.conditionFields[0],12,this.conditionFields[1],12,this.conditionFields[2],12,[this.conditionFields[3],100]]],
         [[this.conditionFields[0],12,this.conditionFields[1],12,this.conditionFields[2],null],[[this.conditionFields[3],100]]],
         ()=>this.conditionFields.reduce((width,field)=>width+field.smartMinWidth,3*12*this.displayPixelRatio),0);
      // Share the right edge of the path field and Autofocus times button.
      // The date editor takes the remaining space while retaining room for seconds.
      this.conditions.setScaledFixedWidth(135+8+950);
      this.folders={};for(let [key,label] of [['wbpp','WBPP output:'],['originals','Original-light root:']])
         this.folders[key]=sqrFolderRow(this.inputs,label,o[key],(value,chosen)=>this.inputFolderChanged(key,value,chosen));
      for(let key of ['wbpp','originals'])this.folders[key].edit.onTextUpdated=()=>{if(this.undoMoveButton)this.updateButtons();};
      this.inputControls=[this.aperture,this.apertureMenu,this.seeing,this.sqm,this.sqmTime,this.sqmTimePicker,...Object.values(this.folders).flatMap(x=>[x.edit,x.browse])];
      this.autofocusRuns=[];this.autorunFiles=[];this.autorunImagingStart=null;this.guideFiles=[];this.parsedGuideLog={sections:[],invalid:0,errors:0};this.loadedLogFolder='';
      this.logFolder=sqrFolderRow(this.inputs,'Log folder (optional):',o.logFolder,()=>this.loadAutorun());
      this.logFolder.edit.toolTip='Read all Autorun_log and PHD2_GuideLog files directly in this folder, excluding _CHN translations. Logs use acquisition-computer local time. Select the folder again to refresh. Clear it to remove autofocus and guiding results; image measurements are retained.';
      this.folders.destination=sqrFolderRow(this.inputs,'Rejected originals:',o.destination,()=>{this.syncOptions();this.updateButtons();});
      this.folders.destination.edit.onTextUpdated=()=>this.updateButtons();
      this.folders.destination.edit.toolTip='Choose the folder for rejected originals to enable Undo. Move also requires a marked original. Leave it blank to review and measure without moving files.';
      this.inputControls.push(this.folders.destination.edit,this.folders.destination.browse);
      let logLabel=new Label(this.inputs);logLabel.text='Log timestamps:';logLabel.setScaledFixedWidth(135);
      this.logTimeZone=new ComboBox(this.inputs);for(let name of ['Infer from image timestamps','Custom UTC offset'])this.logTimeZone.addItem(name);
      this.logTimeZone.setScaledFixedWidth(208);
      this.logTimeZone.currentItem=o.logTimeZone==='offset'?1:0;
      this.logTimeZone.toolTip='Infer local time minus UTC from filenames and UTC exposure metadata, accounting for filenames written at exposure completion. Ambiguous or missing evidence requires a custom UTC offset; this computer’s timezone is never assumed.';
      // Keep the original offset editor visible. A unique inferred offset
      // seeds its value so switching to Custom starts with that estimate.
      this.logUTCOffset=sqrNumber(this.inputs,'UTC offset (hours):',o.logUTCOffset,-12,14,2);
      this.logUTCOffset.edit.setScaledFixedWidth(58);
      let logOffsetLabelWidth=this.logUTCOffset.label.font.width(this.logUTCOffset.label.text);
      this.logUTCOffset.label.setFixedWidth(logOffsetLabelWidth);this.logUTCOffset.sizer.spacing=8;
      this.logUTCOffset.setFixedWidth(logOffsetLabelWidth+66*this.displayPixelRatio);
      this.logUTCOffset.toolTip='Log time minus UTC: for example, +2 for UTC+02:00, or +5.5 for UTC+05:30.';this.logUTCOffset.enabled=this.logTimeZone.currentItem===1;
      this.autorunStatus=new Label(this.inputs);this.autorunStatus.text='No log folder selected.';this.autorunStatus.wordWrapping=true;this.autorunStatus.setScaledFixedWidth(150);
      this.refreshFilesButton=sqrTool(this.inputs,':/icons/reload.png','Refresh file list',()=>this.refreshFileList());
      this.importWBPPButton=sqrButton(this.inputs,'Import WBPP…',()=>this.chooseWBPPImport());this.importWBPPButton.setScaledFixedSize(116,26);
      this.autorunTimes=sqrTool(this.inputs,':/icons/clock-info.png','Autofocus times: show all extracted autofocus start times, as written in the log and converted to UTC, with their final focus positions.',()=>this.showAutofocusTimes());
      this.logTimeZone.onItemSelected=()=>{this.parseAutorun();if(this.sqm.value>0)this.bortleChanged();};
      this.logUTCOffset.onValueUpdated=()=>{if(!this.settingLogOffset){this.parseAutorun();if(this.sqm.value>0)this.bortleChanged();}};
      this.logTools=new Control(this.inputs);this.logTools.sizer=new HorizontalSizer;this.logTools.sizer.spacing=8;
      // Match the fixed path text field's right edge. The summary takes
      // the remaining space, keeping Autofocus times at the same right edge.
      this.logTools.setScaledFixedWidth(135+8+950);
      for(let control of [logLabel,this.logTimeZone,this.logUTCOffset,this.autorunStatus,this.refreshFilesButton,this.importWBPPButton,this.autorunTimes]){
         control.parent=this.logTools;control.show();this.logTools.sizer.add(control,0,Alignment.Center);
      }
      this.logFixedControls=[logLabel,this.logTimeZone,this.logUTCOffset,this.refreshFilesButton,this.importWBPPButton,this.autorunTimes];
      this.inputs.sizer.add(this.logTools);
      this.inputControls.push(this.logFolder.edit,this.logFolder.browse,this.logTimeZone,this.logUTCOffset,this.refreshFilesButton,this.importWBPPButton,this.autorunTimes);
      this.updateLogOffsetControls();
      this.inputs.sizer.add(this.conditions);
      this.observingSite=sqrValidSite(o.observingSite)?o.observingSite:null;this.siteHeadersOnly=!!o.siteHeadersOnly;this.sitePromptSession=null;
      // Keep the active scoring controls together in the collapsible section.
      this.settings=new Control(this);
      this.scoreSelection=sqrGroup(this.settings,'Score selection');
      this.scoreSettings=sqrGroup(this.settings,'Score weights');
      this.guideSettings=sqrGroup(this.settings,'Guiding');
      for(let group of [this.scoreSelection,this.scoreSettings,this.guideSettings]){group.sizer.margin=8;group.sizer.spacing=6;}
      // Keep setup groups compact as the review table and plots gain more room.
      // These are logical pixels, so PixInsight still scales them for the display.
      for(let [group,width] of [[this.scoreSelection,400],[this.scoreSettings,400],[this.guideSettings,330]]){
         group.setScaledFixedWidth(width);
      }
      // The dialog minimum reserves this entire row, including the scrollbar.
      this.settings.sizer=new HorizontalSizer;this.settings.sizer.spacing=8;
      for(let group of [this.scoreSelection,this.scoreSettings,this.guideSettings])this.settings.sizer.add(group);
      this.settings.sizer.addStretch();
      this.qualityBar=new SectionBar(this,'Quality evaluation');this.qualityBar.setSection(this.settings);
      this.qualityBar.toolTip='Click to collapse or expand the quality controls. Your settings and measurements are retained.';
      this.qualityBar.toggleSection=()=>this.setQualityCollapsed(!this.qualityCollapsed);
      const qualityRow=(parent,controls,spacing=12)=>{let row=new HorizontalSizer;row.spacing=spacing;for(let c of controls)row.add(c);row.addStretch();parent.sizer.add(row);};
      let scoreChecks=new VerticalSizer;scoreChecks.spacing=6;
      this.cornerScoring=new CheckBox(this.scoreSelection);this.cornerScoring.text='Include corner measurements (R2)';
      this.cornerScoring.toolTip='With manual weights, choose R2 including corners instead of R1 field-only Score. In R3 mode, make corner KPIs eligible for correlation selection; in R4 mode, include R2 in the rank combination. Existing measurements are reused. Off uses field-only evaluation and whole-image sky background; no measurements are repeated.';
      this.cornerScoring.onCheck=()=>this.toggleCornerScoring();scoreChecks.add(this.cornerScoring);
      this.manualWeights=Object.fromEntries(SQR_SCORE_COMPONENTS.map(c=>[c.weight,o[c.weight]]));
      this.correlationOnly=new CheckBox(this.scoreSelection);this.correlationOnly.text='Use R3: strongly correlated KPIs';this.correlationOnly.checked=!!o.correlationOnly&&!o.rankOfRanks;
      this.correlationOnly.toolTip='Use the R3 correlation score as the current Score. Include KPIs with strong correlation (|r| ≥ 0.7) to PSF signal weight, with equal weights. PSF signal weight is the reference only and is excluded from R3. If no KPI qualifies, keep the manual score and leave R3 unavailable. R3 is evaluated from existing measurements even when this option is off. Manual weights are retained. Selecting this mode turns off R4 rank-of-ranks scoring.';
      this.correlationOnly.onCheck=()=>this.toggleCorrelationScoring();
      scoreChecks.add(this.correlationOnly);
      this.rankScoring=new CheckBox(this.scoreSelection);this.rankScoring.text='Use R4: rank of ranks';this.rankScoring.checked=!!o.rankOfRanks;
      this.rankScoring.toolTip='Use R4 as the current Score: the equal-weight mean of normalized R1, R2 and R3 ranks. Omit unavailable ranks and omit R2 while corner scoring is off. R4 remains visible when this option is off. Selecting this mode turns off correlation scoring.';
      this.rankScoring.onCheck=()=>this.toggleRankScoring();scoreChecks.add(this.rankScoring);
      this.scoreModeStatus=new Label(this.scoreSelection);this.scoreModeStatus.useRichText=true;this.scoreModeStatus.wordWrapping=true;this.scoreModeStatus.setScaledFixedWidth(130);this.scoreModeStatus.setFixedHeight(4*this.font.height);
      this.scoreModeStatus.toolTip='The Score column, REVIEW shortlist and current-score sort use this selection. With R3 and R4 off, the corner checkbox chooses R1 or R2. R3 and R4 are alternative scoring modes.';
      let scoreSelectionRow=new HorizontalSizer;scoreSelectionRow.spacing=10;scoreSelectionRow.add(scoreChecks);scoreSelectionRow.add(this.scoreModeStatus);scoreSelectionRow.addStretch();this.scoreSelection.sizer.add(scoreSelectionRow);
      this.scoreSelection.sizer.addStretch();
      this.weights={};
      for(let [key,label] of [['signalWeight','PSF signal:'],['starsWeight','Star count:'],['fwhmWeight','Field FWHM:'],['eccentricityWeight','Field eccentricity:'],['cornerWeight','Corner quality:'],['backgroundWeight','Weight:'],['belowMeanWeight','Below-mean Quality:']]){
         let n=sqrNumber(this.scoreSettings,label,o[key],0,100,0);this.weights[key]=n;n.label.setScaledFixedWidth(130);n.edit.setScaledFixedWidth(36);n.toolTip='Relative influence on the ranking. Zero disables this component.';
         n.onValueUpdated=()=>this.rerank();
      }
      let skyRow=new HorizontalSizer;skyRow.spacing=this.weights.signalWeight.sizer.spacing;
      this.skyScoreKPI=new ComboBox(this.scoreSettings);for(let choice of SQR_SKY_SCORE_CHOICES)this.skyScoreKPI.addItem(choice.label);
      this.skyScoreKPI.setScaledFixedWidth(125);
      this.skyScoreKPI.currentItem=SQR_SKY_SCORE_CHOICES.findIndex(c=>c.key===sqrSkyScoreChoice(o).key);
      this.skyScoreKPI.toolTip='Choose one sky indicator for Score. Sky quality (default) combines Transparency and Sky brightness. Transparency uses ImageAnalysis RelativeExtinction, converted to a percentage with the most transparent subframe at 100%; it is not absolute atmospheric transmission. Sky brightness is the measured background in image units, using the whole-image mean or lowest preview mean. R1/R2 and Below-mean Quality use the adjacent weight. R3 may select only this sky KPI if strongly correlated; R4 uses the resulting ranks. Changing this choice reuses measurements.';
      this.skyScoreKPI.onItemSelected=()=>this.rerank();this.weights.backgroundWeight.label.hide();
      // The compact selector occupies the label area of the left column. Its
      // right edge and the weight edit align with the NumericEdits above it.
      let skyLabel=new HorizontalSizer;skyLabel.addStretch();skyLabel.add(this.skyScoreKPI);
      skyRow.add(skyLabel,100);skyRow.add(this.weights.backgroundWeight);
      let weightGrid=new HorizontalSizer;weightGrid.spacing=16;weightGrid.addStretch();
      for(let keys of [['signalWeight','fwhmWeight','cornerWeight'],['starsWeight','eccentricityWeight','belowMeanWeight']]){
         let column=new VerticalSizer;column.spacing=6;for(let k of keys)column.add(this.weights[k]);
         if(keys[0]==='signalWeight')column.add(skyRow);else column.addStretch();weightGrid.add(column);
      }
      weightGrid.addStretch();this.scoreSettings.sizer.add(weightGrid);this.scoreSettings.sizer.addStretch();
      this.weights.eccentricityWeight.toolTip='Weight of field star elongation compared with the group. Higher eccentricity reduces Score. Zero disables this component; no extra measurement pass is needed.';
      this.weights.backgroundWeight.toolTip='Shared manual weight for the selected sky KPI. Higher combined Sky quality or Transparency is better; lower Sky brightness is better. Zero disables its manual contribution. R3 uses equal weights for qualifying KPIs and considers only the selected sky indicator.';
      this.weights.cornerWeight.toolTip='Weight of the worst corner deviation in FWHM, corner/center FWHM ratio or eccentricity. Each metric is compared with that same corner across the group. Zero disables the corner contribution.';
      this.weights.belowMeanWeight.toolTip='Relative weight of the fraction of underlying indicators with worse-than-mean quality. For example, 75% contributes 0.75 times this weight before normalization. Score and this fraction itself are excluded from the comparison. Zero removes this Score component without hiding the percentage.';
      this.guideModeLabel=new Label(this.guideSettings);this.guideModeLabel.text='Guiding in Score:';this.guideModeLabel.setScaledFixedWidth(100);
      this.guidingMode=new ComboBox(this.guideSettings);for(let label of ['Require guiding data','Use available guiding data','Ignore guiding KPI'])this.guidingMode.addItem(label);
      this.guidingMode.currentItem=Math.max(0,['require','available','ignore'].indexOf(o.guidingMode));
      this.guidingMode.toolTip='Require: missing or incomplete guiding data flags the frame for review. Use available: omit missing guiding from that frame’s Score and Below-mean Quality, without a missing-guiding review flag. Ignore: omit guiding from all scores and review flags. Measurements remain visible in every mode.';
      this.weights.guideWeight=sqrNumber(this.guideSettings,'Weight:',o.guideWeight,0,100,0);this.weights.guideWeight.label.setScaledFixedWidth(100);this.weights.guideWeight.edit.setScaledFixedWidth(36);this.weights.guideWeight.onValueUpdated=()=>this.rerank();
      this.guideHint=new Label(this.guideSettings);this.guideHint.wordWrapping=false;this.guideHint.text=sqrGuideThresholdText(null);
      this.guidingMode.onItemSelected=()=>this.rerank();this.weights.guideWeight.enabled=this.guidingMode.currentItem!==2;
      // Match both the label alignment and label-to-control spacing of NumericEdit.
      this.guideModeLabel.textAlignment=this.weights.guideWeight.label.textAlignment;
      qualityRow(this.guideSettings,[this.guideModeLabel,this.guidingMode],this.weights.guideWeight.sizer.spacing);
      qualityRow(this.guideSettings,[this.weights.guideWeight]);
      // Align to the visible text of the right-aligned label, not its wider box.
      let guideHintIndent=new Control(this.guideSettings);guideHintIndent.setFixedHeight(1);
      guideHintIndent.setFixedWidth(Math.max(0,this.guideModeLabel.width-this.guideModeLabel.font.width(this.guideModeLabel.text)));
      let guideHintRow=new HorizontalSizer;guideHintRow.spacing=0;guideHintRow.add(guideHintIndent);guideHintRow.add(this.guideHint,100);
      this.guideSettings.sizer.add(guideHintRow);this.guideSettings.sizer.addStretch();
      this.guideHint.setFixedHeight(this.font.height+2);
      this.updateCornerControls();
      this.maxFits=o.maxFits;
      this.groupRow=new Control(this);this.groupRow.sizer=new HorizontalSizer;this.groupRow.sizer.spacing=0;
      let groupLabel=new Label(this.groupRow);groupLabel.text='Filter / group:';
      this.groupSelect=new ComboBox(this.groupRow);this.groupSelect.setScaledFixedWidth(240);this.groupSelect.onItemSelected=()=>{this.clearPreviewKeepingView();this.current=null;this.selectionCleared=false;this.populateRows();this.masterBlink.refresh();};
      // Match the input section's left inset, but let this shorter label use
      // its natural width so the selector follows it with the standard gap.
      this.groupRow.sizer.addSpacing(10);
      for(let control of [groupLabel,this.groupSelect]){this.groupRow.sizer.add(control);this.groupRow.sizer.addSpacing(8);}
      this.groupRow.sizer.addStretch();
      this.tabs=new TabBox(this);this.reviewPage=new Control(this.tabs);this.blinkPage=new Control(this.tabs);this.histogramPage=new Control(this.tabs);this.scatterPage=new Control(this.tabs);
      this.table=new TreeBox(this.reviewPage);this.table.numberOfColumns=26;this.table.headerVisible=true;this.table.rootDecoration=false;
      this.table.alternateRowColor=true;this.table.multipleSelection=false;this.table.setScaledMinSize(800,320);
      let headers=['R1','R2','R3','R4','Reject','Review','Image','Acquisition time (UTC)','Score','PSF weight','FWHM (px)','Stars','Main issue','Field eccentricity','Corner quality','Below-mean Quality','Guiding quality (″)','Guide avg (″)','Guide min (″)','Guide max (″)','Worst corner','Original association','Sky brightness','Transparency','Sky quality','Cloud extinction (mag)','Trails'];
      this.baseReviewColumnCount=headers.length;
      for(let i=0;i<headers.length;++i)this.table.setHeaderText(i,headers[i]);
      this.rejectIcons=[sqrRejectIcon(this,false),sqrRejectIcon(this,true)];
      // Native mouse focus changes precede onMousePress/onNodeClicked. Mouse selection
      // is committed by the click handler; keyboard navigation is synchronized separately.
      this.table.onMousePress=()=>{this.keyboardNavigation=false;return false;};
      this.table.onCurrentNodeUpdated=node=>{if(this.keyboardNavigation&&!this.populating&&node?.row)this.selectRow(node.row);};
      this.table.onNodeClicked=(node,column)=>{if(!node?.row||this.populating)return;
         if(column===4){this.selectRow(node.row);this.decide(!node.row.reject);}
         else if(this.current===node.row)this.clearSelection();else this.selectRow(node.row);};
      this.table.onKeyPress=key=>{if(key===Key_Space){if(this.current)this.decide(!this.current.reject);return true;}
         this.keyboardNavigation=true;if(this.table.currentNode?.row)this.selectRow(this.table.currentNode.row);return false;};
      this.table.onKeyRelease=key=>{this.keyboardNavigation=false;if(key!==Key_Space&&this.table.currentNode?.row)this.selectRow(this.table.currentNode.row);return false;};
      this.table.onNodeDoubleClicked=(node,column)=>{if(node?.row&&column!==4){this.selectRow(node.row);this.populating=true;this.table.currentNode=node;node.selected=true;this.populating=false;this.inspect();this.resumeTabPlayback();}};
      this.reviewTop=new Control(this.reviewPage);this.reviewTop.sizer=new HorizontalSizer;this.reviewTop.sizer.spacing=8;
      this.reviewOptions=sqrGroup(this.reviewTop,'Sort and filter');this.reviewOptions.setScaledFixedWidth(390);
      let reviewTools=new HorizontalSizer;reviewTools.spacing=8;
      let sortLabel=new Label(this.reviewOptions);sortLabel.text='Sort by:';sortLabel.setScaledFixedWidth(45);
      this.order=new ComboBox(this.reviewOptions);for(let item of SQR_REVIEW_SORTS)this.order.addItem(item[1]);
      this.order.setScaledFixedWidth(165);this.order.toolTip='Choose a criterion, then use the direction button to switch ascending or descending order. A new criterion starts in its default direction: poorest quality first, filename A to Z, or earliest acquisition first. R1–R4 use rank 1 for worst. Score is higher-is-better; the default sort lists the lowest scores first. Acquisition time uses the original observation timestamp, then registered metadata; filename suffixes do not affect this order.';
      this.order.toolTip+=' Guide minimum, maximum and average start with the largest error first. Missing values follow in either direction, with the master last.';
      this.order.currentItem=sqrReviewOrderIndex(o.reviewOrder);
      this.reviewReverse=!!o.reviewReverse;
      this.sortDirection=sqrButton(this.reviewOptions,'',()=>{if(this.running)return;this.reviewReverse=!this.reviewReverse;this.changeReviewSort();});
      this.sortDirection.setScaledMinWidth(125);
      let filterLabel=new Label(this.reviewOptions);filterLabel.text='Filter:';filterLabel.setScaledFixedWidth(45);
      this.candidatesOnly=new CheckBox(this.reviewOptions);this.candidatesOnly.text='REVIEW candidates only';this.candidatesOnly.onCheck=()=>this.populateRows();
      this.candidatesOnly.setFixedWidth(this.order.minWidth);
      this.candidatesOnly.toolTip='Show only subframes flagged REVIEW. The master is hidden. This does not select originals for rejection.';
      this.order.onItemSelected=()=>{this.reviewReverse=false;this.changeReviewSort();};
      reviewTools.add(sortLabel);reviewTools.add(this.order);reviewTools.add(this.sortDirection,100);
      let reviewFilter=new HorizontalSizer;reviewFilter.spacing=reviewTools.spacing;reviewFilter.add(filterLabel);reviewFilter.add(this.candidatesOnly);
      reviewFilter.addStretch();
      this.reviewOptions.sizer.add(reviewTools);this.reviewOptions.sizer.add(reviewFilter);this.reviewOptions.sizer.addStretch();
      // Stable guidance and the selected image have separate visual groups.
      // Fixed content heights prevent long reasons/paths from moving the table.
      this.reviewInfo=new Control(this.reviewPage);
      this.reviewInfoBar=new SectionBar(this.reviewPage,'Review information');this.reviewInfoBar.setSection(this.reviewInfo);
      this.reviewInfoBar.toolTip='Collapse or expand the Reading the table guide beside Sort and filter and the Selected image panel below the table. The window size and selected image are retained.';
      this.reviewInfoBar.toggleSection=()=>this.setReviewInfoCollapsed(!this.reviewInfoCollapsed);
      this.reviewGuide=sqrGroup(this.reviewTop,'Reading the table');this.reviewGuide.setScaledFixedWidth(740);
      this.reviewLegend=new Label(this.reviewGuide);this.reviewLegend.useRichText=true;this.reviewLegend.wordWrapping=false;
      this.reviewLegend.setScaledFixedWidth(260);this.reviewLegend.textAlignment=TextAlignment.Left|TextAlignment.Top;
      this.reviewLegend.text='<table width="100%" cellspacing="0" cellpadding="1">'+
         [['R1','Manual field'],['R2','Manual with corners'],['R3','Strongly correlated KPIs'],['R4','Rank of ranks']]
         .map(row=>'<tr><td width="24" valign="top"><b>'+row[0]+'</b></td><td><nobr>'+row[1]+'</nobr></td></tr>').join('')+'</table>';
      this.reviewLegendValues=new Label(this.reviewGuide);this.reviewLegendValues.useRichText=true;this.reviewLegendValues.wordWrapping=false;
      this.reviewLegendValues.setScaledFixedWidth(440);this.reviewLegendValues.textAlignment=TextAlignment.Left|TextAlignment.Top;
      this.reviewLegendValues.text='<table width="100%" cellspacing="0" cellpadding="1">'+
         [['Ranks','1 = worst'],['Score','0–1; higher is better'],['Below-mean','Assessed KPIs worse than mean (%)'],
          ['Symbols','<b>*</b> Incomplete &nbsp; · &nbsp; <b>—</b> Unavailable']]
         .map(row=>'<tr><td width="90" valign="top"><b><nobr>'+row[0]+'</nobr></b></td><td><nobr>'+row[1]+'</nobr></td></tr>').join('')+'</table>';
      this.reviewLegend.toolTip='Click a selected row to deselect it. Click Reject or press Space to mark an original. Double-click an image to blink. Hover over REVIEW, Score or a rank for its full explanation.';
      let reviewGuideColumns=new HorizontalSizer;reviewGuideColumns.spacing=16;
      reviewGuideColumns.add(this.reviewLegend);reviewGuideColumns.add(this.reviewLegendValues);
      this.reviewGuide.sizer.add(reviewGuideColumns);this.reviewGuide.sizer.addStretch();
      this.detailsGroup=sqrGroup(this.reviewInfo,'Selected image');this.detailsGroup.sizer.spacing=4;
      this.details=new Label(this.detailsGroup);this.details.useRichText=true;this.details.setFixedHeight(2*this.font.height+4);
      this.detailMetrics=new Label(this.detailsGroup);this.detailMetrics.useRichText=true;this.detailMetrics.setFixedHeight(4*this.font.height+12);
      this.detailSource=new Label(this.detailsGroup);this.detailSource.useRichText=true;this.detailSource.setFixedHeight(this.font.height+4);
      this.detailsGroup.sizer.add(this.details);this.detailsGroup.sizer.add(this.detailMetrics);this.detailsGroup.sizer.add(this.detailSource);this.detailsGroup.sizer.addStretch();
      this.reviewTop.sizer.add(this.reviewOptions);this.reviewTop.sizer.add(this.reviewGuide);this.reviewTop.sizer.addStretch();
      this.reviewInfo.sizer=new VerticalSizer;this.reviewInfo.sizer.add(this.detailsGroup);
      this.table.toolTip='Click a selected row to deselect it. Click Reject or press Space to mark an original. Double-click an image to blink. Hover over a cell for its explanation.';
      this.reviewPage.sizer=new VerticalSizer;this.reviewPage.sizer.margin=6;this.reviewPage.sizer.spacing=8;
      this.reviewPage.sizer.add(this.reviewTop);this.reviewPage.sizer.add(this.table,100);this.reviewPage.sizer.add(this.reviewInfoBar);this.reviewPage.sizer.add(this.reviewInfo);
      this.viewer=new ImageView(this.blinkPage);this.viewer.setScaledMinSize(800,320);this.viewer.setStatusMessage('Double-click a registered frame in the Review table.');
      sqrInstallPixelReadout(this.viewer,()=>this.frames?.[this.frame]||null);
      // ImageView normally fits on every reveal. Fit a newly loaded hidden
      // preview once its viewport is visible, then retain zoom on later tab visits.
      this.viewer.onShow=()=>{if(this.fitPreviewOnShow&&this.viewer.isValid)this.fitPreview();this.viewer.scrollbox.viewport.update();};
      this.displaySTF=new CheckBox(this.blinkPage);this.displaySTF.text='Display STF';this.displaySTF.checked=o.displaySTF;
      this.alignBrightness=new CheckBox(this.blinkPage);this.alignBrightness.text='Align preview brightness';this.alignBrightness.checked=o.alignBrightness;
      this.alignBrightness.toolTip='Display-only background and contrast alignment. Turn off to compare transparency differences. Source pixels and quality measurements are unchanged.';
      this.viewer.appendTopControl(this.displaySTF);this.viewer.appendTopControl(this.alignBrightness);
      this.keepTrail=sqrButton(this.blinkPage,'Keep despite trail',()=>{
         if(this.running||!this.current?.trailReview)return;
         this.current.metrics[0].trailReviewed=true;this.populateRows(false);this.ensurePreview();
      });
      this.keepTrail.toolTip='Acknowledge the detected trail and keep this subframe. Other REVIEW reasons still apply.';
      this.viewer.appendTopControl(this.keepTrail);this.keepTrail.hide();
      this.reference=new ComboBox(this.blinkPage);for(let n of ['Filter master','Best scoring subframe','Rotate subframes (Review order)','Corner mosaic / master','Corner mosaic / best subframe','Trail mask / original'])this.reference.addItem(n);this.reference.currentItem=Math.max(0,SQR_BLINK_MODES.indexOf(o.reference));
      this.reference.toolTip='Compare with the filter master or best scoring kept subframe, or rotate through visible subframes in Review order. Corner mosaic blinks the same four corners of the usable field for both images. Adjust Mosaic corner (%) to frame them more tightly. Subframe rotation follows the current sort direction and REVIEW-only filter and skips the master.';
      this.reference.onItemSelected=()=>{if(this.running)return;const enteringMosaic=this.isCornerMosaic()&&!this.mosaicModeShown;if(this.reference.currentItem>=2)this.regionRotation.currentItem=0;this.updateButtons();this.reloadBlink(!enteringMosaic);this.syncOptions();};
      this.region=new ComboBox(this.blinkPage);for(let n of ['Usable field','Center','Top left','Top right','Bottom left','Bottom right'])this.region.addItem(n);
      this.region.onItemSelected=()=>this.reloadBlink(true);
      this.regionRotation=new ComboBox(this.blinkPage);for(let n of ['Off','Image only','Blink with reference'])this.regionRotation.addItem(n);
      this.regionRotation.currentItem=Math.max(0,['off','image','blink'].indexOf(o.regionRotation));this.normalizeRegionRotation();
      this.regionRotation.toolTip='Image only cycles Center, Top left, Top right, Bottom left and Bottom right, skipping Usable field; no reference is needed. Blink with reference includes Usable field and shows image then reference in each region before advancing. Rotation keeps the selected image and zoom. Choosing Rotate subframes switches region rotation off.';
      this.regionRotation.onItemSelected=()=>{if(this.running)return;this.normalizeRegionRotation();this.updateButtons();this.reloadBlink(true);this.syncOptions();};
      this.mosaicSize=sqrNumber(this.blinkPage,'Mosaic corner (%):',o.mosaicCornerPercent,1,50);this.mosaicSize.setReal(false);this.mosaicSize.edit.setScaledFixedWidth(40);
      this.mosaicSize.toolTip='Width and height of each tile as a percentage of the common usable field (1–50%). Smaller tiles show corner stars at higher zoom. Applies only to the blink mosaic.';
      this.mosaicSize.onValueUpdated=()=>{this.syncOptions();if(this.isCornerMosaic())this.reloadBlink(false);};
      this.displaySTF.onCheck=this.alignBrightness.onCheck=()=>{if(this.current)this.inspect();};
      this.blinkInterval=sqrNumber(this.blinkPage,'Interval (s):',this.timer.interval,.1,10,2);this.blinkInterval.edit.setScaledFixedWidth(64);
      this.blinkInterval.toolTip='Time each image is displayed before switching: 0.10–10 seconds. Applies to blinking, subframe rotation and region rotation. Region blinking spends one interval on the image and one on its reference before advancing. Subframe rotation adds the time needed to load each image.';
      this.blinkInterval.onValueUpdated=value=>{this.setBlinkInterval(value);this.syncOptions();};
      this.play=sqrTool(this.blinkPage,':/icons/play.png','Start blinking.',()=>{if(this.blinking)this.stopBlink();else this.startBlink();});
      this.step=sqrTool(this.blinkPage,':/icons/step-forward.png','Pause and advance the preview.',()=>{this.stopBlink();this.advancePlayback();});
      this.frameLabel=new Label(this.blinkPage);this.frameLabel.text='No frame loaded';this.frameLabel.minHeight=2*this.font.height;this.frameLabel.wordWrapping=true;
      let referenceLabel=new Label(this.blinkPage);referenceLabel.text='Blink mode:';
      this.rotationLabel=new Label(this.blinkPage);this.rotationLabel.text='Rotate regions:';
      this.previous=sqrTool(this.blinkPage,':/icons/arrow-left.png','Previous image in the Review list. Preserve zoom, position and playback.',()=>this.navigate(-1));
      this.next=sqrTool(this.blinkPage,':/icons/arrow-right.png','Next image in the Review list. Preserve zoom, position and playback.',()=>this.navigate(1));
      // The native right-arrow artwork sits one pixel lower than the left.
      // Mirror the scaled left icon to keep identical baselines at any DPI.
      this.next.icon=this.previous.icon.mirroredHorizontally();
      this.decisionToggle=sqrTool(this.blinkPage,':/icons/check.png','Keep original. Click to mark for rejection.',()=>{if(!this.running&&this.current)this.decide(!this.current.reject);});
      this.decisionToggle.checkable=true;
      // Keep playback controls together at every window width. Equal stretches
      // center interval/playback between the region and right-hand navigation.
      this.blinkTools=new Control(this.blinkPage);this.blinkTools.sizer=new HorizontalSizer;this.blinkTools.sizer.spacing=8;
      for(let control of [referenceLabel,this.reference,this.rotationLabel,this.regionRotation,this.region,this.mosaicSize,null,this.blinkInterval,this.play,this.step,null,this.previous,this.next,this.decisionToggle]){
         if(control){control.parent=this.blinkTools;control.show();this.blinkTools.sizer.add(control,0,Alignment.Center);}
         else this.blinkTools.sizer.addStretch();
      }
      this.blinkPage.sizer=new VerticalSizer;this.blinkPage.sizer.margin=6;this.blinkPage.sizer.spacing=8;
      this.blinkPage.sizer.add(this.viewer,100);this.blinkPage.sizer.add(this.blinkTools);this.blinkPage.sizer.add(this.frameLabel);
      let kpiLabel=new Label(this.histogramPage);kpiLabel.text='Quality indicator:';
      this.availableKPIs=[];this.kpiSelect=new ComboBox(this.histogramPage);this.kpiSelect.setScaledMinWidth(200);
      this.kpiSelect.onItemSelected=()=>{if(!this.updatingKPIs)this.updateHistogram();};
      this.fwhmSettings=sqrTool(this.histogramPage,':/icons/gear.png','FWHM grading',()=>this.editFWHMGrading());
      this.kpiDirection=new Label(this.histogramPage);this.kpiDirection.wordWrapping=true;
      this.bortleControls=new Control(this.histogramPage);this.bortleControls.sizer=new HorizontalSizer;this.bortleControls.sizer.spacing=6;
      let bortleLabel=new Label(this.bortleControls);bortleLabel.text='Bortle class:';
      this.bortle=new ComboBox(this.bortleControls);this.bortle.editEnabled=false;this.bortle.addItem('—');
      for(let i=1;i<=9;++i)this.bortle.addItem(sqrBortleLabel(i));this.bortle.currentItem=sqrBortleOptions(o).bortleClass;this.bortle.setScaledFixedWidth(65);
      this.bortle.toolTip='Choose the Bortle class.';
      this.bortle.onItemSelected=()=>this.bortleChanged();this.bortleControls.sizer.add(bortleLabel);this.bortleControls.sizer.add(this.bortle);
      this.calibrateSkyButton=sqrButton(this.histogramPage,'Calibrate sky',()=>this.calibrateSky());this.calibrateSkyButton.toolTip='Calibrate sky background.';
      this.plotInfoButton=sqrTool(this.histogramPage,':/icons/info.png','Histogram information',()=>this.showPlotInformation());this.plotInfoButton.hide();
      let plotOrderLabel=new Label(this.histogramPage);plotOrderLabel.text='Order by:';
      this.histogramOrder=new ComboBox(this.histogramPage);this.histogramOrder.addItem('KPI value');this.histogramOrder.addItem('Acquisition time');
      this.histogramOrder.currentItem=o.histogramOrder==='time'?1:0;this.histogramOrder.setScaledMinWidth(150);
      this.histogramOrder.toolTip='';
      this.histogramOrder.onItemSelected=()=>this.updateHistogram();
      this.histogramTools=responsive(new Control(this.histogramPage),[[kpiLabel,this.kpiSelect,[this.kpiDirection,100],this.bortleControls,this.calibrateSkyButton,this.fwhmSettings,this.plotInfoButton,plotOrderLabel,this.histogramOrder]],
         [[kpiLabel,this.kpiSelect,[this.kpiDirection,100]],[this.bortleControls,this.calibrateSkyButton,this.fwhmSettings,this.plotInfoButton,null,plotOrderLabel,this.histogramOrder]],1300);
      this.histogram=new SQRChartView(this.histogramPage,
         generation=>{if(generation===-1)this.plotDirty=true;this.plotReady=generation===this.plotGeneration&&!this.plotDirty;},
         value=>{if(typeof value==='string'){try{this.selectPlotImage(JSON.parse(value));}catch(e){this.error(e);}}});
      this.histogram.setScaledMinSize(800,320);
      this.histogram.toolTip='';
      this.plotGeneration=0;this.plotReady=false;this.plotDirty=false;
      this.plotTimer=new Timer(.15,true,this);
      this.plotTimer.onTimeout=()=>{
         let scatter=this.tabs.currentPageIndex===3;if(this.running||(!scatter&&this.tabs.currentPageIndex!==2))return;
         if(scatter?this.scatterReady:this.plotReady)(scatter?this.scatter:this.histogram).pollSelection();};
      this.histogram.onShow=()=>this.plotTimer.start();this.histogram.onHide=()=>{this.plotTimer.stop();this.histogram.discardSelection();};
      this.histogramSummary=new Label(this.histogramPage);this.histogramSummary.wordWrapping=true;this.histogramSummary.minHeight=2*this.font.height;
      this.histogramPage.sizer=new VerticalSizer;this.histogramPage.sizer.margin=6;this.histogramPage.sizer.spacing=10;
      this.histogramPage.sizer.add(this.histogramTools);this.histogramPage.sizer.add(this.histogram,100);this.histogramPage.sizer.add(this.histogramSummary);
      let scatterTools=new HorizontalSizer;scatterTools.spacing=10;
      this.scatterKPIs=[];this.updatingScatterKPIs=false;
      this.scatterX=new ComboBox(this.scatterPage);this.scatterY=new ComboBox(this.scatterPage);
      for(let [control,label] of [[this.scatterX,'X axis:'],[this.scatterY,'Y axis:']]){
         let caption=new Label(this.scatterPage);caption.text=label;scatterTools.add(caption);
         control.setScaledMinWidth(230);scatterTools.add(control);
         control.onItemSelected=()=>{if(!this.updatingScatterKPIs){this.updateScatter();this.syncOptions();}};
      }
      this.scatterSwap=new PushButton(this.scatterPage);this.scatterSwap.text='Swap axes';
      this.scatterSwap.onClick=()=>{let x=this.scatterX.currentItem;this.scatterX.currentItem=this.scatterY.currentItem;this.scatterY.currentItem=x;this.updateScatter();this.syncOptions();};
      scatterTools.add(this.scatterSwap);scatterTools.addStretch();
      this.setScatterOptions(o);
      this.scatter=new SQRChartView(this.scatterPage,
         generation=>{if(generation===-1)this.scatterDirty=true;this.scatterReady=generation===this.scatterGeneration&&!this.scatterDirty;},
         value=>{if(typeof value==='string'){try{this.selectPlotImage(JSON.parse(value),true);}catch(e){this.error(e);}}});
      this.scatter.setScaledMinSize(800,320);
      this.scatterGeneration=0;this.scatterReady=false;this.scatterDirty=false;
      this.scatter.onShow=()=>this.plotTimer.start();this.scatter.onHide=()=>{this.plotTimer.stop();this.scatter.discardSelection();};
      this.scatterSummary=new Label(this.scatterPage);this.scatterSummary.wordWrapping=true;this.scatterSummary.minHeight=2*this.font.height;
      this.scatterPage.sizer=new VerticalSizer;this.scatterPage.sizer.margin=6;this.scatterPage.sizer.spacing=10;
      this.scatterPage.sizer.add(scatterTools);this.scatterPage.sizer.add(this.scatter,100);this.scatterPage.sizer.add(this.scatterSummary);
      this.tabs.addPage(this.reviewPage,'Review and measurements');this.tabs.addPage(this.blinkPage,'Blink frame / reference');this.tabs.addPage(this.histogramPage,'Quality indicators');this.tabs.addPage(this.scatterPage,'Correlation plot');
      this.masterBlink=new SQRMasterBlinkPage(this.tabs,this,o);this.tabs.addPage(this.masterBlink,'Blink masters');
      this.status=new Label(this);this.status.wordWrapping=true;this.status.minHeight=this.font.height;
      this.status.text='Choose the WBPP output and original-light folders or import a WBPP setup. Click the magnifier to measure, or the grid to include corners. Blink against the master or best subframe. Use Move rejected originals to move the marked lights after confirmation.';
      this.reviewSummary=new Label(this);this.reviewSummary.wordWrapping=true;this.reviewSummary.minHeight=this.font.height;
      this.scoreInclusionStatus=new Label(this);this.scoreInclusionStatus.wordWrapping=true;this.scoreInclusionStatus.minHeight=2*this.font.height;
      this.pixelScaleStatus=new Label(this);this.pixelScaleStatus.wordWrapping=true;this.pixelScaleStatus.minHeight=this.font.height;
      this.messages=new Control(this);this.messages.sizer=new VerticalSizer;this.messages.sizer.spacing=2;
      for(let control of [this.status,this.reviewSummary,this.scoreInclusionStatus,this.pixelScaleStatus]){control.parent=this.messages;control.show();this.messages.sizer.add(control);}
      this.messagesBar=new SectionBar(this,'Messages');this.messagesBar.setSection(this.messages);
      this.messagesBar.toolTip='Collapse or expand status, review counts, scoring information and image scale. The window keeps its size and the messages keep updating.';
      this.messagesBar.toggleSection=()=>this.setMessagesCollapsed(!this.messagesCollapsed);
      this.instance=sqrTool(this,':/process-interface/new-instance.png','Drag to save folder and evaluation settings as a process icon.');
      this.instance.onMousePress=()=>{sqrSaveInstanceOptions(this.savedOptions());this.newInstance();};
      this.calculate=sqrTool(this,':/toolbar/view-zoom.png','Measure registered frames and rank review candidates. Loads the file list on first use.',()=>this.analyze());
      this.measureCornersButton=sqrTool(this,':/icons/grid.png','Measure corners: measure the center and four corners for all groups and matched masters. Loads the file list on first use and reuses existing field and regional measurements.',()=>this.analyze(true));
      this.recommendButton=sqrButton(this,'Recommend rejection…',()=>this.recommendRejection());
      this.rejectLowerButton=sqrTool(this,':/icons/table-arrow-down.png','Reject lower scores',()=>this.rejectLowerScores());
      this.recommendButton.toolTip='Compare SNR and sharpness for the selected group before marking recommended rejects. Optional object ROI; adjustable SNR preservation and minimum retained count.';
      this.configurationButton=sqrTool(this,':/icons/gear.png','Review configuration: review criteria, measurement regions and observing site.',()=>this.editMeasurementSettings());
      this.reset=sqrTool(this,':/process-interface/reset.png','Reset evaluation and display settings. Folder paths are retained.',()=>this.resetSettings());
      this.moveButton=sqrTool(this,':/icons/file-copy.png','Move rejected originals',()=>this.moveRejected());
      this.preferredTrailWidth=o.trailWidth;
      this.trailButton=sqrTool(this,':/icons/brush.png','Remove trails. Select a retained registered subframe with a measured Trails count of at least one.',()=>this.editRegisteredTrail());
      this.table.onNodeSelectionUpdated=()=>{if(!this.populating)this.updateSelectionActions();};
      this.masterButton=sqrTool(this,':/icons/documents-add.png','Integrate retained lights',()=>this.createReviewedMaster());
      const integrationIcon=CoreApplication.rscDirPath+'/icons/module/ImageIntegration/ImageIntegration.svg';
      if(File.exists(integrationIcon)){
         let size=Math.round(18*this.resourcePixelRatio);
         this.masterButton.icon=Bitmap.fromSVGFile(integrationIcon,size,size);
      }
      this.undoMoveButton=sqrTool(this,':/icons/undo.png','Undo moved originals. Select a moved row to restore that file, or choose a move journal to restore several files, including after reopening the script.',()=>this.restoreRejected());
      this.closeButton=sqrTool(this,':/process-interface/cancel.png','Close the review. Measurements and pending decisions are kept only while this dialog is open.',()=>this.cancel());
      this.helpButton=sqrTool(this,':/process-interface/browse-documentation.png','Open the PIDoc user guide.',sqrShowDocumentation);
      let actions=new HorizontalSizer;actions.spacing=8;actions.add(this.instance);actions.add(this.calculate);actions.add(this.measureCornersButton);actions.add(this.recommendButton);actions.add(this.rejectLowerButton);actions.add(this.configurationButton);actions.add(this.reset);actions.addStretch();actions.add(this.trailButton);actions.add(this.masterButton);actions.add(this.moveButton);actions.add(this.undoMoveButton);actions.add(this.closeButton);actions.add(this.helpButton);
      // The action row stays visible while the body can scroll independently.
      // Its natural minimum no longer fixes the whole window at expanded height.
      this.bodyScroll=new ScrollBox(this);this.bodyScroll.autoScroll=false;this.bodyScroll.tracking=true;
      this.bodyScroll.horizontalScrollBarVisible=false;this.bodyScroll.verticalScrollBarVisible=false;
      this.bodyScroll.setScaledMinSize(1180,400);this.body=new Control(this.bodyScroll.viewport);
      for(let control of [this.inputsBar,this.inputs,this.qualityBar,this.settings,this.groupRow,this.tabs,this.messagesBar,this.messages]){
         control.parent=this.body;control.show();
      }
      let content=new VerticalSizer;content.spacing=8;content.add(this.inputsBar);content.add(this.inputs);content.add(this.qualityBar);content.add(this.settings);content.add(this.groupRow);content.add(this.tabs,100);content.add(this.messagesBar);content.add(this.messages);this.body.sizer=content;
      this.sizer=new VerticalSizer;this.sizer.margin=10;this.sizer.spacing=8;this.sizer.add(this.bodyScroll,100);this.sizer.add(actions);
      this.bodyScroll.viewport.onResize=()=>this.layoutBody();
      this.body.onResize=()=>this.layoutBody();
      this.bodyScroll.onHorizontalScrollPosUpdated=()=>this.positionBody();this.bodyScroll.onVerticalScrollPosUpdated=()=>this.positionBody();
      this.onShow=()=>{this.layoutBody();this.layoutTimer.start();};
      this.onClose=()=>{if(this.running)return false;this.plotTimer.stop();this.stopBlink();this.clearFrames();this.masterBlink.clearPair();return true;};
      this.onHide=()=>{this.layoutTimer.stop();this.plotTimer.stop();this.resumeBlinkOnReturn=false;this.stopBlink();this.masterBlink.setPlaying(false);};
      this.tabs.onPageSelected=()=>{
         let page=this.tabs.currentPageIndex;
         if(page!==1&&this.blinking){this.resumeBlinkOnReturn=true;this.stopBlink();}
         this.plotTimer.stop();
         // The WebViews keep their documents while hidden. Returning to a
         // current chart only resumes click polling; changed data needs a draw.
         if(page===2&&(this.plotDirty||!this.histogramData))this.updateHistogram();
         if(page===3&&(this.scatterDirty||!this.scatterData))this.updateScatter();
         if(page===2||page===3)this.plotTimer.start();
         if(page===1){this.ensurePreview();this.resumeTabPlayback();}
         this.layoutTimer.start();
      };
      this.loadAutorun(false);if(this.session){this.syncOptions();if(this.session.groups.some(g=>g.rows.some(r=>r.metrics[0])))sqrRank(this.session);}this.populateGroups();this.updateButtons();
      this.setInputsCollapsed(o.inputsCollapsed);this.setQualityCollapsed(o.qualityCollapsed);this.setReviewInfoCollapsed(o.reviewInfoCollapsed);this.setMessagesCollapsed(o.messagesCollapsed);
      let available=this.availableScreenRect,scale=this.displayPixelRatio;
      // Hidden controls can report a zero smart minimum before first show.
      // Use a useful preferred width, then let the screen constrain both axes.
      this.resize(Math.min(1360*scale,available.width-40*scale),Math.min(1000*scale,available.height-80*scale));this.layoutBody();
   }
   positionBody(){if(this.body)this.body.move(0,-this.bodyScroll.verticalScrollPosition);}
   // Reflow only the virtual contents. Section toggles keep the user's window
   // size, and scroll positions clamp when formerly hidden space disappears.
   layoutBody(){
      if(!this.body?.sizer||this.layingOutBody)return;this.layingOutBody=true;
      try{
         let scroll=this.bodyScroll,view=scroll.viewport;scroll.horizontalScrollBarVisible=false;scroll.setHorizontalScrollRange(0,0);
         // Query the layout's minimum at the available width. Measuring with
         // adjustToContents() would shrink the live WebView before expanding it.
         let containers=[this.inputs,this.conditions,this.logTools,this.settings,this.tabs,this.reviewPage,this.reviewTop,this.reviewOptions,this.reviewInfo,this.reviewGuide,this.detailsGroup,
            this.blinkPage,this.blinkTools,this.histogramPage,this.histogramTools,this.scatterPage,this.messages];
         for(let pass=0;pass<3;++pass){
            let width=view.width;
            for(let layout of this.responsiveLayouts)layout.reflow(width-24*this.displayPixelRatio);
            if(this.tabs.minWidth!==width)this.tabs.setFixedWidth(width);
            if(this.body.minWidth!==width)this.body.setFixedWidth(width);
            this.body.ensureLayoutUpdated();this.layoutLogStatus();
            let height=Math.max(view.height,this.body.smartMinHeight);
            if(this.body.height!==height)this.body.resize(width,height);
            for(let fit=0;fit<3;++fit){
               this.body.ensureLayoutUpdated();
               let shortage=Math.max(0,...containers.filter(c=>c.visible).map(c=>c.smartMinHeight-c.height));
               if(!shortage)break;
               this.body.resize(width,this.body.height+shortage);
            }
            scroll.verticalScrollBarVisible=this.body.height>view.height;
            if(view.width===width)break;
         }
         scroll.pageWidth=view.width;scroll.pageHeight=view.height;scroll.lineWidth=scroll.lineHeight=3*this.font.height;
         scroll.setVerticalScrollRange(0,Math.max(0,this.body.height-view.height));this.positionBody();
      }finally{this.layingOutBody=false;}
   }
   // Snapshot controls into serializable settings; derived measurements and
   // rejection decisions stay in the session and are never process parameters.
   options(){let o={...sqrDefaults(),...sqrFWHMOptions(this.fwhmOptions),wbppImport:this.wbppImport,bortleClass:this.bortle.currentItem,sqmReading:this.sqm.value,sqmTime:this.sqmTime.text.trim(),sqmTimeFromLog:!!this.sqmTimePreset&&this.sqmTime.text.trim()===this.sqmTimePreset};o.fwhmAperture=this.aperture.value;o.fwhmSeeing=this.seeing.value;for(let k of Object.keys(this.folders))o[k]=this.folders[k].edit.text.trim();
      Object.assign(o,this.measurementOptions);
      o.rankOfRanks=this.rankScoring.checked;o.correlationOnly=this.correlationOnly.checked&&!o.rankOfRanks;for(let k of Object.keys(this.weights))o[k]=o.correlationOnly?this.manualWeights[k]:this.weights[k].value;
      o.skyScoreKPI=SQR_SKY_SCORE_CHOICES[this.skyScoreKPI.currentItem].key;o.recommendation={...this.recommendationOptions};
      let sameRun=sqrSameRunFolders(this.runFolders,o);
      o.observingSite=sameRun&&this.observingSite?{...this.observingSite}:null;
      o.siteHeadersOnly=sameRun&&this.siteHeadersOnly;
      o.measureCorners=this.useCornerMeasurements;o.reference=SQR_BLINK_MODES[this.reference.currentItem];o.blinkInterval=this.blinkInterval.value;
      o.regionRotation=['off','image','blink'][this.regionRotation.currentItem];o.mosaicCornerPercent=this.mosaicSize.value;
      o.trailWidth=this.preferredTrailWidth;
      o.logFolder=this.logFolder.edit.text.trim();o.logTimeZone=['auto','offset'][this.logTimeZone.currentItem];o.logUTCOffset=this.logUTCOffset.value;
      o.guidingMode=['require','available','ignore'][this.guidingMode.currentItem];
      o.qualityCollapsed=this.qualityCollapsed;o.inputsCollapsed=this.inputsCollapsed;o.reviewInfoCollapsed=this.reviewInfoCollapsed;o.messagesCollapsed=this.messagesCollapsed;
      o.scatterX=sqrKPIKey(this.scatterKPIs[this.scatterX.currentItem]);o.scatterY=sqrKPIKey(this.scatterKPIs[this.scatterY.currentItem]);
      o.reviewOrder=SQR_REVIEW_SORTS[this.order.currentItem][0];o.reviewReverse=this.reviewReverse;
      o.maxFits=this.maxFits;o.displaySTF=this.displaySTF.checked;o.alignBrightness=this.alignBrightness.checked;o.histogramOrder=this.histogramOrder.currentItem===1?'time':'value';return o;}
   savedOptions(){let o=this.options();delete o.measureCorners;return o;}
   recommendRejection(){
      if(this.running||!this.session||this.scanRequired||!this.group())return;
      this.stopBlink();this.syncOptions();sqrRank(this.session);let dialog=new SQRRecommendationDialog(this.group(),this.session.options,!!this.session.guiding?.enabled);
      dialog.execute();this.recommendationOptions=dialog.options();this.syncOptions();sqrRank(this.session);
      if(dialog.reviewApplied){this.clearFrames();let reinstated=dialog.recommendation.reinstate.length;
         this.status.text='Recommendation applied for '+(this.group().filter||'the selected group')+'. New rejection marks: '+dialog.applied+'.'+(reinstated?' Rejection marks cleared: '+reinstated+'.':'')+' No originals moved.'+sqrTrailNotice(this.group().rows.filter(r=>!r.reject&&!r.moved&&!r.isMaster));}
      this.populateRows(false);
      this.updateButtons();
   }
   showPlotInformation(){if(this.running)return;let info=this.plotInformation;if(info)(new SQRPlotInfoDialog(info)).execute();}
   requestObservingSite(){
      let dialog=new SQRObservingSiteDialog(this.observingSite,true,sqrSiteProfiles(),sqrRunSite(this.session));
      if(!dialog.execute())return false;
      this.sitePromptSession=this.session;
      if(!dialog.skipped)this.applyObservingSite(dialog);
      return true;
   }
   applyObservingSite(dialog){
      let profiles=sqrSiteProfiles(),old=sqrFallbackSite(this,profiles),headers=sqrRunSite(this.session);
      if(JSON.stringify(dialog.profiles)!==JSON.stringify(profiles))Settings.write(SQR_SITE_KEY,DataType.String,JSON.stringify(dialog.profiles));
      this.observingSite=dialog.site;this.siteHeadersOnly=!!dialog.headersOnly;let current=sqrFallbackSite(this,dialog.profiles);
      this.syncOptions();
      let changed=false;
      for(let g of this.session?.groups||[]){
         if(!headers?.site&&(old?.latitude!==current?.latitude||old?.longitude!==current?.longitude)&&
            g.rows.some(r=>r.nativeExtinction)&&sqrGroupNeedsSite(g)){
            g.refreshExtinction=true;g.cloudExtinctionSummary='Click Measure to update cloud extinction for the observing site.';
            for(let r of g.rows){
               if(r.nativeExtinction)r.nativeExtinction.cloud=null;
               r.cloudExtinction=null;r.cloudExtinctionInfo={error:g.cloudExtinctionSummary};
            }
            changed=true;
         }
      }
      return changed;
   }
   fillApertureMenu(presets){
      this.aperturePresets=presets;this.apertureMenu.clear();this.apertureMenu.addItem('Presets');
      for(let diameter of presets)this.apertureMenu.addItem(diameter+' mm');
      this.apertureMenu.addItem('Edit list…');this.apertureMenu.currentItem=0;
   }
   chooseAperturePreset(index){
      this.apertureMenu.currentItem=0;
      if(this.running||index<=0)return;
      if(index<=this.aperturePresets.length){
         this.aperture.setValue(this.aperturePresets[index-1]);this.aperture.onValueUpdated();
      }else{
         let dialog=new SQRAperturePresetsDialog(sqrReadAperturePresets());
         if(dialog.execute()){
            Settings.write(SQR_APERTURE_PRESETS_KEY,DataType.String,dialog.values.join(','));
            this.fillApertureMenu(dialog.values);
         }
      }
   }
   editSQMTime(){if(this.running||!this.sqm.value)return;let dialog=new SQRSQMTimeDialog(this.sqmTime.text,sqrSQMTimeSeed(this.session,this.current,this.autorunImagingStart));
      if(dialog.execute()){this.sqmTime.text=dialog.value();this.sqmTimeChanged();}}
   // Mark invalid input without replacing it or trapping focus. The user can
   // correct it directly or open the picker. No image work runs while typing.
   validateSQMTime(normalize=false){
      let stamp=sqrNormalizeSQMTime(this.sqmTime.text);
      if(normalize&&stamp)this.sqmTime.text=stamp;
      this.sqmTimeError=this.sqm.value>0&&!stamp?'Invalid SQM time. Enter a valid local date and time as YYYY-MM-DD HH:MM[:SS], for example 2026-11-08 22:30:00, or use Choose.':'';
      this.sqmTime.styleSheet=this.sqmTimeError?'QLineEdit { color: #a02020; background-color: #fff2ef; }':'';
      this.sqmTime.toolTip=(this.sqmTimeError?this.sqmTimeError+'\n\n':'')+SQR_SQM_TIME_HELP;
      if(this.sqmTimeError&&this.calibrateSkyButton)this.calibrateSkyButton.enabled=false;
      return !this.sqmTimeError;
   }
   sqmTimeChanged(){let valid=this.validateSQMTime(true);if(this.sqmTime.text.trim()!==this.sqmTimePreset)this.sqmTimePreset='';this.bortleChanged();
      // Live validation clears the field error while typing. Retain ownership
      // of the published message until commit, without replacing newer results.
      if(!valid){this.sqmTimeReportedError=this.sqmTimeError;this.setMessagesCollapsed(false);this.setStatus(this.sqmTimeError);}
      else{if(this.sqmTimeReportedError&&this.status.text===this.sqmTimeReportedError)this.setStatus('SQM reading time updated.');this.sqmTimeReportedError='';}}
   // Replace an empty value or our untouched preset; never overwrite a manual
   // reading time. Remember ownership in saved settings so a new log folder
   // can update an inherited preset after reopening the script as well.
   applySQMTimePreset(){let current=this.sqmTime.text.trim();
      if(current&&current!==this.sqmTimePreset){this.sqmTimePreset='';return false;}
      let preset=this.autorunImagingStart?.text||'';this.sqmTime.text=preset;this.sqmTimePreset=preset;return current!==preset;
   }
   calibrateSky(){
      if(this.running||!this.group()||!sqrSkyComparisonEnabled(this.options()))return;this.stopBlink();this.busy(true);let abort=console.abortEnabled;console.abortEnabled=true;console.show();
      try{this.syncOptions();let c=sqrCalibrateSky(this.session,this.group(),text=>this.setStatus(text));this.setStatus(sqrSkyCalibrationText(c));}
      catch(e){this.group().skyCalibrationError=e.message||String(e);this.error(e);}finally{console.abortEnabled=abort;this.busy(false);this.updateHistogram();}
   }
   bortleChanged(){
      if(this.running)return;this.sqmTime.enabled=this.sqmTimePicker.enabled=this.sqm.value>0;this.validateSQMTime();this.syncOptions();this.updateHistogram();
      if(!sqrSkyComparisonEnabled(this.options())||!this.session?.groups.some(g=>g.rows.some(r=>r.metrics[0])))return;
      if(this.sqm.value>0&&sqrSQMTime(this.options(),this.session).time===null)return;
      // A changed comparison value only redraws the plot when calibration is
      // already available. Avoid flashing disabled controls for a cache hit.
      let pending=this.session.groups.some(g=>sqrSkyFilterSupported(g)&&g.rows.some(r=>r.metrics[0])&&!sqrCurrentSkyCalibration(this.session,g));
      if(!pending){for(let g of this.session.groups){let c=sqrCurrentSkyCalibration(this.session,g);if(c){g.skyCalibration=c;delete g.skyCalibrationError;}}return;}
      // SQM calibration only rescales cached means: no PSF fitting, catalog
      // query, image opening or modal busy transition is needed.
      if(this.sqm.value>0){try{let result=sqrAutoCalibrateSky(this.session);this.setStatus(sqrSkyCalibrationSummary(result).trim());}
         catch(e){this.error(e);}finally{this.updateHistogram();}return;}
      this.stopBlink();this.busy(true);let abort=console.abortEnabled;console.abortEnabled=true;console.show();
      try{let result=sqrAutoCalibrateSky(this.session,s=>this.setStatus(s));this.setStatus(sqrSkyCalibrationSummary(result).trim()||'No measured broadband group is available for sky calibration.');}
      catch(e){this.error(e);}finally{console.abortEnabled=abort;this.busy(false);this.updateHistogram();}
   }
   editFWHMGrading(){if(this.running)return;let dialog=new SQRFWHMDialog(this.fwhmOptions,sqrSessionPixelScale(this.session),this.group()?.filter);if(dialog.execute())this.applyFWHMGrading(dialog.options());}
   // Only plot settings change: do not invalidate measurements or rerank.
   applyFWHMGrading(options){this.fwhmOptions=sqrFWHMOptions(options);this.aperture.setValue(this.fwhmOptions.fwhmAperture);this.fwhmOptions.fwhmAperture=this.aperture.value;this.seeing.setValue(this.fwhmOptions.fwhmSeeing);this.syncOptions();this.updateHistogram();}
   editMeasurementSettings(){
      if(this.running)return;
      let dialog=new SQRMeasurementSettingsDialog(this.measurementOptions,this.group(),this,sqrRunSite(this.session));
      if(!dialog.execute())return;
      try{
         let refreshSite=dialog.siteDraft&&this.applyObservingSite(dialog.siteDraft);
         if(dialog.siteDraft)this.sitePromptSession=null;
         this.applyMeasurementSettings(dialog.options(),refreshSite);
      }catch(e){this.error(e);}
   }
   applyMeasurementSettings(next,refreshSite=false){
      let old=this.measurementOptions;
      let resize=next.patch!==old.patch||next.autoCornerSize!==old.autoCornerSize;
      let reassess=next.percent!==old.percent||next.minStars!==old.minStars;
      if(!resize&&!reassess&&next.margin===old.margin&&!refreshSite)return;
      this.measurementOptions=next;
      // Apply the strongest change once, after all settings have been accepted.
      if(next.margin!==old.margin){this.invalidateMeasurements();return;}
      let changedRegions=false;
      if(resize)for(let g of this.session?.groups||[])if(g.measureSignature&&sqrConfigureCornerSize(g,next)){
         delete g.recommendationCache;delete g.recommendationReview;delete g.recommendationPendingReview;g.reviewComplete=false;changedRegions=true;
      }
      if(changedRegions){this.clearFrames();this.updateCornerControls();}
      if(changedRegions||reassess)this.rerank();
      else{this.syncOptions();if(this.session)this.populateRows(false);}
      if(changedRegions)this.status.text='Corner size changed. Click Measure corners to update the affected groups. Full-field measurements were retained.';
      else if(refreshSite)this.status.text='Observing site changed. Click Measure to update cloud extinction.';
      else if(reassess&&this.session)this.status.text='Review criteria updated. Existing measurements were reassessed.';
   }
   updateCornerControls(){let available=sqrHasCornerMeasurements(this.session);
      if(!available)this.useCornerMeasurements=false;
      this.cornerScoring.checked=this.useCornerMeasurements;this.cornerScoring.enabled=available&&!this.running;
      this.updateScoreWeightControls();}
   toggleCornerScoring(){
      if(this.running)return;
      if(!sqrHasCornerMeasurements(this.session))return;
      this.cornerScoreChoice=this.useCornerMeasurements=this.cornerScoring.checked;
      this.updateCornerControls();this.rerank();
      this.status.text=this.useCornerMeasurements?'Corner measurements included in Score. Existing results reused.':'Field-only scoring active. Corner measurements retained; no remeasurement.';
   }
   // Keep saved manual values independent of the displayed effective 0/1 weights.
   toggleCorrelationScoring(){
      if(this.correlationOnly.checked){this.rankScoring.checked=false;for(let k of Object.keys(this.weights))this.manualWeights[k]=this.weights[k].value;}
      else for(let k of Object.keys(this.weights))this.weights[k].setValue(this.manualWeights[k]);
      this.rerank();
   }
   toggleRankScoring(){
      if(this.rankScoring.checked&&this.correlationOnly.checked){this.correlationOnly.checked=false;for(let k of Object.keys(this.weights))this.weights[k].setValue(this.manualWeights[k]);}
      this.rerank();
   }
   updateScoreWeightControls(){
      let auto=this.correlationOnly.checked,selection=this.groupSelect?this.group()?.correlationScoring:null;
      let fallback=auto&&selection?.available===false;
      let activeScore=this.rankScoring.checked?'R4 · rank of ranks':auto&&!fallback?'R3 · strongly correlated KPIs':this.useCornerMeasurements?'R2 · manual weights, with corners':'R1 · manual weights, field only';
      if(fallback)activeScore+=' (R3 unavailable)';
      let scoreCode=this.rankScoring.checked?'R4':auto&&!fallback?'R3':this.useCornerMeasurements?'R2':'R1';
      let scoreLabel={R1:'Field only',R2:'With corners',R3:'Correlated KPIs',R4:'Rank of ranks'}[scoreCode];
      this.scoreModeStatus.text='<b>Current Score: '+scoreCode+'</b><br/>'+scoreLabel+(fallback?'<br/>R3 unavailable':'');
      for(let [k,control] of Object.entries(this.weights)){
         if(auto)control.setValue(fallback?this.manualWeights[k]:selection?.weights[k]??0);
         control.enabled=!auto&&(k!=='cornerWeight'||this.useCornerMeasurements)&&(k!=='guideWeight'||this.guidingMode?.currentItem!==2);
      }
      // This report stays visible on every tab, even with Quality evaluation
      // collapsed. It follows the current group and each fresh correlation pass.
      if(this.scoreInclusionStatus){
         let mode='Score: '+activeScore+'.';
         this.scoreInclusionStatus.text=mode+(selection?selection.available?' R3 KPIs (equal weights): '+selection.components.filter(c=>c.included).map(c=>c.label).join(', '):' No strongly correlated KPIs. R3 unavailable.':' R3/R4: pending measurements.');
         this.scoreInclusionStatus.toolTip=(this.rankScoring.checked?'R4 averages normalized available ranks, omitting R2 when corner scoring is off. Manual weights still control R1 and R2.\n':'')+sqrScoreCorrelationReport(selection);
      }
   }
   // Visibility also depends on ancestors: before the dialog is shown, every
   // child reports hidden. Persist the requested state independently, and set
   // the body visibility explicitly when restoring a saved process instance.
   // SectionBar normally calls dialog.adjustToContents(), resizing the window.
   // Our toggles reflow the virtual body without resizing the window itself.
   setQualityCollapsed(collapsed){this.qualityCollapsed=!!collapsed;this.settings.visible=!this.qualityCollapsed;this.qualityBar.updateIcon();this.layoutBody();this.layoutTimer.start();this.syncOptions();}
   setInputsCollapsed(collapsed){this.inputsCollapsed=!!collapsed;this.inputs.visible=!this.inputsCollapsed;this.inputsBar.updateIcon();this.layoutBody();this.layoutTimer.start();this.syncOptions();}
   setReviewInfoCollapsed(collapsed){this.reviewInfoCollapsed=!!collapsed;this.reviewInfo.visible=this.reviewGuide.visible=!this.reviewInfoCollapsed;this.reviewInfoBar.updateIcon();this.layoutBody();this.layoutTimer.start();this.syncOptions();}
   setMessagesCollapsed(collapsed){this.messagesCollapsed=!!collapsed;this.messages.visible=!this.messagesCollapsed;this.messagesBar.updateIcon();this.layoutBody();this.layoutTimer.start();this.syncOptions();}
   syncOptions(){if(this.session)this.session.options=this.options();}
   group(){return this.session?.groups[this.groupSelect.currentItem]||null;}
   updatePixelScale(){let s=sqrSessionPixelScale(this.session);this.pixelScaleStatus.text=sqrPixelScaleText(s);
      this.guideHint.text=sqrGuideThresholdText(sqrGuidingScale(s));
      this.guideHint.toolTip='Category thresholds in arcseconds, derived from the image scale. Thresholds are unavailable when the imaging pixel scale is unavailable. Medium includes its upper boundary. For unequal X/Y scales, the smaller available scale is used.';
      this.weights.guideWeight.toolTip='Relative Score weight for guiding. Composite error = (minimum + 2 × average + maximum) / 4, in arcseconds. '+this.guideHint.text+'. Zero disables guiding in Score. Missing or incomplete data never counts as zero error.';
      this.pixelScaleStatus.toolTip='Shared nominal scale across all filters, from master focal length and effective pixel size, including binning.\n'+
         'Scale (arcsec/pixel) = 206.264806 × pixel size (µm) / focal length (mm).\n'+
         s.masters.map(m=>'Master: '+m.path+'\nFocal length: '+sqrFmt(m.focalLength,3)+' mm · Pixel size X/Y: '+sqrFmt(m.pixelSizeX,3)+' / '+sqrFmt(m.pixelSizeY,3)+' µm'+(m.error?'\n'+m.error:'')).join('\n')+
         (s.missingCamera.length?'\nMissing camera identity in '+s.missingCamera.length+' image(s):\n'+s.missingCamera.slice(0,10).join('\n')+(s.missingCamera.length>10?'\n…':''):'')+
         '\nUse Refresh file list to update the metadata and camera check.';}
   // sqrTick pumps events once after notifying us, retaining progress and abort
   // handling without a second redraw/event dispatch for every status change.
   setStatus(s){if(this.status.text!==s)this.status.text=s;}
   error(e){this.status.text='Error: '+(e.message||String(e));new MessageBox(this.status.text,'Subframe Quality Review',StdIcon.Error,StdButton.Ok).execute();}
   isRegionRotating(){return this.regionRotation?.currentItem>0;}
   isCornerMosaic(){return this.reference?.currentItem===3||this.reference?.currentItem===4;}
   isRotating(){return this.reference?.currentItem===2&&!this.isRegionRotating();}
   // Region and subframe rotation are alternatives. Restore a usable comparison
   // reference when entering regional playback from the subframe sequence.
   normalizeRegionRotation(){if(this.isCornerMosaic())this.regionRotation.currentItem=0;if(this.isRegionRotating()&&this.reference.currentItem===2)this.reference.currentItem=1;if(this.regionRotation.currentItem===1&&this.region.currentItem===0)this.region.currentItem=1;}
   rotationRows(){return (this.visibleRows||[]).filter(r=>!r.isMaster);}
   updateBlinkButton(){if(this.play){this.play.icon=this.scaledResource(this.blinking?':/icons/media-stop.png':':/icons/play.png');
      let interval=this.timer.interval.toFixed(2);
      this.play.toolTip=this.blinking?'Stop playback.':this.isRegionRotating()?(this.regionRotation.currentItem===1?'Rotate Center and the four corners every '+interval+' seconds, skipping Usable field.':'Show the selected image and reference for '+interval+' seconds each, then advance to the next region.'):this.isRotating()?'Rotate through subframes in Review order, skipping the master. Each image is shown for '+interval+' seconds before loading the next.':'Start blinking the selected image and reference every '+interval+' seconds.';
      this.step.toolTip=this.isRegionRotating()?(this.regionRotation.currentItem===1?'Pause and show the next region of this image.':'Pause and advance one step: image, reference, then next region.'):this.isRotating()?'Pause and show the next subframe in Review order. The master is skipped.':'Pause and switch frame / reference.';}}
   // One timer drives every playback mode. In regional blink mode a complete
   // image/reference pair is shown before advancing the region, with wraparound.
   advancePlayback(){
      if(this.running)return;
      if(this.isRotating()){this.navigate(1);return;}
      if(!this.frames)return;
      if(this.isRegionRotating()&&(this.regionRotation.currentItem===1||this.frame===1)){
         let next=(this.region.currentItem+1)%this.region.numberOfItems;this.region.currentItem=this.regionRotation.currentItem===1&&next===0?1:next;
         if(!this.inspect(true,true,this.blinking))return;
      }else this.showFrame(1-this.frame);
      if(this.blinking)this.timer.start();
   }
   // Restart the current dwell time without reloading images, changing selection,
   // toggling controls, or disturbing zoom/pan and the active Stop symbol.
   setBlinkInterval(value){this.timer.stop();this.blinkInterval.setValue(sqrBlinkInterval(value));this.timer.interval=this.blinkInterval.value;
      if(this.blinking&&!this.running)this.timer.start();this.updateBlinkButton();}
   startBlink(){
      if(this.running)return;
      if(this.isRotating()){
         if(this.rotationRows().length<2){this.stopBlink();return;}
         if((!this.frames||!this.rotationRows().includes(this.current))&&!this.inspect(true,true))return;
      }else if(this.isRegionRotating()){
         if(this.regionRotation.currentItem===1&&this.region.currentItem===0){this.region.currentItem=1;if(!this.inspect(true,true))return;}
         else if(!this.frames&&!this.inspect(true,true))return;
      }
      if(this.frames){this.blinking=true;this.updateBlinkButton();this.timer.start();}
   }
   stopBlink(){this.blinking=false;this.timer.stop();this.updateBlinkButton();}
   // A Review double-click opens Blink programmatically, without firing
   // onPageSelected. Both entry paths resume after the preview is ready.
   resumeTabPlayback(){
      if(!this.resumeBlinkOnReturn||this.running||this.tabs.currentPageIndex!==1)return;
      this.resumeBlinkOnReturn=false;
      if(this.frames)this.startBlink();
   }
   // Stop the timer before releasing its bitmaps. Navigation can retain the
   // ImageView transform while replacing pixels by passing resetView=false.
   // Preview reloads can pause only the timer, keeping the Stop icon steady.
   clearFrames(resetView=true,preserveRotation=false,preservePlayback=false,preserveRegions=false){if(preservePlayback)this.timer.stop();else this.stopBlink();if(!preserveRotation)this.rotationDisplay=null;if(resetView){this.viewer.reset();this.viewer.clearPixelReadout();this.fitPreviewOnShow=false;this.savedPreviewView=null;}if(this.frames&&!this.framesFromRegions)for(let b of this.frames)if(b!==this.referenceDisplay?.data?.bitmap)b.clear();this.frames=null;this.framesFromRegions=false;this.loadedReference=null;if(!preserveRegions)this.clearRegionFrames();
      // Navigation keeps the single reference. Reset/close and other playback
      // modes release it after any borrowed frame array has been detached.
      if(resetView||preserveRotation||preserveRegions)this.clearReferenceDisplay();}
   clearReferenceDisplay(){if(this.referenceDisplay?.data)this.referenceDisplay.data.bitmap.clear();this.referenceDisplay={};}
   // Regional views borrow cached bitmaps. Release each exactly once when the
   // image, reference, geometry, display settings or playback mode changes.
   clearRegionFrames(){if(this.regionFrames)for(let pair of this.regionFrames)for(let frame of pair)frame.clear();this.regionFrames=null;this.regionFramesKey='';}
   // A hidden tab can still have a provisional viewport size. Refit only this
   // initial view when it becomes visible; navigation keeps the established view.
   fitPreview(){this.fitPreviewOnShow=!this.viewer.visible;
      const mosaic=this.isCornerMosaic()&&this.frames?.[0];
      // Native zoom-to-fit stops at 1:1. Small corner tiles can fill more of the viewport.
      if(mosaic&&this.viewer.visible&&typeof this.viewer.zoomToRect==='function')this.viewer.zoomToRect(0,0,mosaic.width,mosaic.height);
      else this.viewer.zoomToFit();}
   // Deselecting clears the displayed bitmap, but a following selection (including
   // the click sequence of a double-click) can still restore its view. Derive zoom
   // from the public coordinate mapping rather than reading ImageView internals.
   previewTransform(){if(!this.viewer.isValid)return this.savedPreviewView||null;
      let scale=this.viewer.imageToViewport(1,0).x-this.viewer.imageToViewport(0,0).x;
      return {zoom:scale>=1?Math.round(scale):-Math.round(1/scale),x:this.viewer.scrollbox.horizontalScrollPosition,y:this.viewer.scrollbox.verticalScrollPosition,fitOnShow:this.fitPreviewOnShow};}
   // Release the old group's pixels and reference even if the next group has
   // no preview. The next successful load restores the saved zoom and pan.
   clearPreviewKeepingView(){let view=this.previewTransform();this.clearFrames();this.savedPreviewView=view;}
   setPreviewImage(bitmap,keepView){
      if(keepView&&this.viewer.isValid)this.viewer.regenerate(bitmap);
      else{this.viewer.setImage(bitmap);let saved=keepView?this.savedPreviewView:null;
         if(saved){this.viewer.regenerate(null,saved.zoom);this.viewer.scrollbox.horizontalScrollPosition=saved.x;this.viewer.scrollbox.verticalScrollPosition=saved.y;this.fitPreviewOnShow=saved.fitOnShow;}
         else this.fitPreview();}
      this.savedPreviewView=null;
   }
   // ImageView owns a separate bitmap copy. Retain its transform while releasing
   // the old frame cache; the next load replaces its pixels at the same zoom/pan.
   selectRow(row){let changed=this.current!==row;if(changed)this.clearFrames(false);this.current=row;this.selectionCleared=false;
      this.updateDetails();this.updateButtons();if(changed&&this.histogram)this.updatePlots();if(changed)this.ensurePreview();}
   clearSelection(){this.clearPreviewKeepingView();this.current=null;this.selectionCleared=true;this.populating=true;
      this.table.deselectAllNodes();this.populating=false;this.updateDetails();this.updateButtons();this.updatePlots();}
   ensurePreview(){if(!this.running&&this.tabs.currentPageIndex===1&&!this.frames&&((this.options().reference==='trail'&&this.current?.trailBands?.length)||(this.group()?.regions&&(this.isRotating()?this.rotationRows().length:this.current?.metrics[0]))))this.inspect(false);}
   // Compare the data behind an existing preview before/after measurement.
   // A new ROI, changed file signature, selected row or best reference makes
   // it stale. Re-ranking identical results must not reload/stretch the images.
   measurementPreviewSignature(useLoaded=false){let g=this.group();if(!g)return '';
      let noReference=this.isRotating()||(this.isRegionRotating()&&this.regionRotation.currentItem===1);
      let reference=noReference?'':useLoaded&&this.frames?this.loadedReference?.path||'':sqrReference(g,this.options().reference,this.current).path;
      return JSON.stringify([g.measureSignature,g.masterRow?.measureSignature,this.current?.registered.path,g.regions,reference]);}
   loadAutorun(refresh=true){
      if(this.running)return;
      this.autofocusRuns=[];this.autorunFiles=[];this.guideFiles=[];this.ignoredAutorunCHN=0;this.autorunError='';this.loadedLogFolder=this.logFolder.edit.text.trim();
      if(this.loadedLogFolder)try{let loaded=sqrReadLogFolder(this.loadedLogFolder);this.autorunFiles=loaded.files;this.guideFiles=loaded.guideFiles;this.ignoredAutorunCHN=loaded.ignoredCHN;}
      catch(e){this.autorunError='Cannot read log folder: '+(e.message||String(e));}
      this.autorunImagingStart=sqrAutorunImagingStart(this.autorunFiles);let presetChanged=this.applySQMTimePreset();
      this.parsedGuideLog=sqrParseGuideFiles(this.guideFiles);
      this.parseAutorun(refresh);
      if(refresh&&presetChanged&&this.sqm.value>0)this.bortleChanged();
   }
   // A unique inferred offset becomes the editor's default. Unknown or multiple
   // offsets have no single numeric representation; keep the evidence in the
   // tooltip and show a dash, without changing the clock conversion itself.
   updateLogOffsetControls(){
      let manual=this.logTimeZone.currentItem===1,clock=this.logClock;
      this.logUTCOffset.enabled=manual&&!this.running;
      this.settingLogOffset=true;
      try{
         if(manual)this.logUTCOffset.setValue(this.logUTCOffset.value);
         else if(clock?.offsets.length===1)this.logUTCOffset.setValue(clock.offsets[0]/3600000);
         else this.logUTCOffset.edit.text='—';
      }finally{this.settingLogOffset=false;}
      let detail=clock?clock.mode==='offset'?'Custom offset applied to both Autorun and PHD2 logs.':
         clock.anchors.length+' image timestamps support the offset; '+clock.endNames+' filenames use exposure completion; '+clock.unresolved+' unresolved image timestamps. Logs and SQM reading time use this same conversion.':
         'Scan images to infer local time minus UTC from image filenames and UTC metadata, or select a custom UTC offset.';
      if(clock?.offsets.length)detail=sqrClockText(clock)+'\n'+detail;
      if(!manual)detail+='\nA single inferred offset fills this field. Select Custom UTC offset to edit it.';
      if(!manual&&(!clock||clock.offsets.length!==1))detail+='\nNo single inferred value is available; the field shows a dash. Multiple offsets, when known, are still applied to their matching exposures.';
      this.logUTCOffset.toolTip='Local log/SQM time minus UTC, in hours (for example +2 or +5.5).\n'+detail;
   }
   // Convert both log types with the same camera-derived clock. Guide CSV is
   // cached; rematching/ranking never repeats PSF measurements or pixel reads.
   parseAutorun(refresh=true){
      let zone=['auto','offset'][this.logTimeZone.currentItem],clock=sqrInferLogClock(this.session,zone,this.logUTCOffset.value);
      let result=sqrParseAutorunFiles(this.autorunFiles,wall=>sqrLocalToUTC(wall,clock));
      this.logClock=clock;this.updateLogOffsetControls();
      let hadGuiding=!!this.session?.guiding?.enabled;
      this.syncOptions();sqrApplyGuiding(this.session,this.parsedGuideLog,clock,this.guideFiles.length>0);
      if(this.session&&(hadGuiding||this.guideFiles.length)&&this.session.groups.some(g=>g.rows.some(r=>r.metrics[0])))sqrRank(this.session);
      result.ignoredCHN=this.ignoredAutorunCHN;this.autofocusRuns=result.runs;this.autorunResult=result;
      let measured=this.session?.groups.flatMap(g=>g.rows).filter(r=>r.guiding?.scorable).length||0;
      this.autorunStatus.text=this.autorunError?'Log folder could not be read.':!this.loadedLogFolder?'No log folder selected.':
         result.files.length+' Autorun · '+result.runs.length+' AF · '+this.guideFiles.length+' PHD2 · guiding: '+measured+'/'+(this.session?.groups.reduce((n,g)=>n+g.rows.length,0)||0)+' frames';
      this.layoutLogStatus();this.layoutTimer.start();
      this.autorunStatus.toolTip=this.autorunError||'Ignored '+result.ignoredCHN+' _CHN translations; '+result.duplicates+' duplicate autofocus starts merged; '+result.invalid+' unresolved/invalid autofocus times; '+result.errors+' Autorun read errors. PHD2: '+this.parsedGuideLog.errors+' read errors; '+this.parsedGuideLog.invalid+' invalid rows; '+(this.session?.guiding?.duplicates||0)+' duplicate samples merged; '+(this.session?.guiding?.conflicts||0)+' conflicts; '+(this.session?.guiding?.unresolved||0)+' sections with unresolved clocks. Hover over guiding measurements for coverage and quality details.';
      this.autorunReport=this.loadedLogFolder?sqrAutofocusReport(this.loadedLogFolder,result,zone,this.logUTCOffset.value,this.autorunError,'Local log time → UTC: '+sqrClockText(clock)):'';
      this.autorunTimes.enabled=!!this.loadedLogFolder&&!this.running;
      if(this.autorunReport&&this.autorunReport!==this.reportedAutorunText)console.writeln('<end><cbr><b>Extracted autofocus start times</b>\n'+sqrHTML(this.autorunReport));
      this.reportedAutorunText=this.autorunReport;
      if(refresh&&this.histogram)this.populateRows(false);
   }
   layoutLogStatus(){
      // Native size hints become reliable after the first visible layout.
      // Reserve the remaining row width for the log summary, then measure
      // its wrapped height without shifting the Autofocus button horizontally.
      if(this.logFixedControls.every(control=>control.smartMinWidth>0)){
         // NumericEdit's minimum hint can omit label space. Use laid-out
         // widths and reserve the full fixed button width before allocating text.
         let width=this.logTools.width-this.logFixedControls.reduce((n,control)=>n+control.width,this.logFixedControls.length*8*this.displayPixelRatio);
         if(width>=150*this.displayPixelRatio&&width!==this.autorunStatus.width)this.autorunStatus.setFixedWidth(width);
      }
      let line='',lines=1;
      for(let word of this.autorunStatus.text.split(/\s+/)){
         let next=line?line+' '+word:word;
         if(line&&this.autorunStatus.font.width(next)>this.autorunStatus.width-4){++lines;line=word;}else line=next;
      }
      let height=lines*this.autorunStatus.font.height+2;
      if(height!==this.autorunStatus.height)this.autorunStatus.setFixedHeight(height);
   }
   showAutofocusTimes(){
      if(!this.autorunReport)return;
      let dialog=new Dialog;dialog.windowTitle='Extracted autofocus start times';
      let text=new TextBox(dialog);text.readOnly=true;text.setScaledMinSize(760,280);text.text=sqrHTML(this.autorunReport);
      let close=sqrButton(dialog,'Close',()=>dialog.ok()),buttons=new HorizontalSizer;buttons.addStretch();buttons.add(close);
      dialog.sizer=new VerticalSizer;dialog.sizer.margin=10;dialog.sizer.spacing=8;dialog.sizer.add(text,100);dialog.sizer.add(buttons);dialog.adjustToContents();dialog.execute();
   }
   inputFolderChanged(key,value,chosen=false){if(this.running)return;
      // Explicit folder selection switches methods even when the chosen path
      // equals an imported one; simply focusing/leaving an edit does not.
      if((chosen&&this.wbppImport)||!sqrSameRunFolders(this.runFolders,{...this.runFolders,[key]:value}))this.invalidate();else this.updateButtons();}
   // Source choice follows the paths the user committed. Imported paths keep
   // their explicit list; manually editing either input returns to folder mode.
   inputMode(){let wbpp=this.folders.wbpp.edit.text.trim(),originals=this.folders.originals.edit.text.trim();
      if(this.wbppImport&&sqrSameRunFolders(this.wbppImport,{wbpp,originals}))return 'import';
      return wbpp?'manual':'choose';}
   // Keep the folders used to build the list separate from editable session options.
   get scanRequired(){return !this.session||!sqrSameRunFolders(this.scannedInputs,{wbpp:this.folders.wbpp.edit.text,originals:this.folders.originals.edit.text});}
   hasInputFolders(){return !!(this.folders.wbpp.edit.text.trim()&&this.folders.originals.edit.text.trim());}
   invalidate(){if(this.running)return;
      this.runFolders={wbpp:this.folders.wbpp.edit.text.trim(),originals:this.folders.originals.edit.text.trim()};
      this.observingSite=null;this.siteHeadersOnly=false;this.sitePromptSession=null;this.cornerScoreChoice=null;
      this.wbppImport=null;this.session=null;this.scannedInputs=null;this.useCornerMeasurements=false;this.current=null;this.clearFrames();this.updateCornerControls();this.parseAutorun(false);this.populateGroups();this.status.text=this.inputMode()==='manual'?'Folder selection changed. Choose a measurement button, or use Refresh file list to inspect the matches.':'Import a WBPP setup or select the WBPP output and original-light folders.';}
   // Geometry/measurement changes invalidate metrics and derived scores, but
   // keep original associations and the user's manual rejection decisions.
   invalidateMeasurements(){
      if(this.running)return;
      let hadCorners=sqrHasCornerMeasurements(this.session);this.useCornerMeasurements=false;
      if(this.session){for(let g of this.session.groups){delete g.recommendationReview;delete g.recommendationPendingReview;delete g.recommendationCache;g.reviewComplete=false;g.measureSignature='';g.correlationScoring=null;g.transparencySummary='';g.cloudExtinctionSummary='';g.skyQualitySummary='';for(let r of sqrGroupRows(g)){r.measureSignature='';r.metrics={};sqrClearTransparency(r);delete r.backgroundMeans;r.skyBackground=null;r.score=null;r.scoreWithoutCorners=null;r.scoreWithCorners=null;r.scoreCorrelated=null;r.rankCorrelated=null;r.scoreRankOfRanks=null;r.rankOfRanks=null;r.rankComponents=[];r.rankOfRanksDetail='';r.rankWithoutCorners=null;r.rankWithCorners=null;r.candidate=false;r.reasons=[];r.dataReviewReasons=[];r.mainIssue='';r.mainIssueDetail='';r.scoreContributions=[];r.cornerSeverity=null;r.measuredCornerSeverity=null;r.worstCorner='';r.belowMeanCount=null;r.belowMeanFraction=null;r.belowMeanFieldFraction=null;r.belowMeanCornerFraction=null;r.belowMeanAvailable=0;r.belowMeanTotal=0;r.belowMeanComplete=false;r.belowMeanDetail='';}}}
      this.updateCornerControls();this.syncOptions();this.clearFrames();this.populateRows();
      this.status.text='Measurement settings changed.'+(hadCorners?' Corner measurements were cleared.':'')+' Click Measure corners beside the magnifier to measure the previews, or use the magnifier for field measurements.';
   }
   rerank(){if(this.running)return;if(!this.session){this.updateScoreWeightControls();this.updateHistogram();return;}try{this.syncOptions();for(let g of this.session.groups)for(let r of sqrGroupRows(g))r.guidingIgnored=sqrIgnoreGuiding(r,this.session.options);if(this.session.groups.some(g=>g.rows.some(r=>r.metrics[0])))sqrRank(this.session);this.populateRows();}catch(e){this.error(e);}}
   busy(value){this.running=value;for(let c of [...this.inputControls,this.inputsBar,this.qualityBar,this.settings,this.groupSelect,this.tabs,this.instance,this.calculate,this.measureCornersButton,this.configurationButton,this.reset,this.moveButton,this.undoMoveButton,this.closeButton,this.helpButton])c.enabled=!value;this.updateLogOffsetControls();this.autorunTimes.enabled=!value&&!!this.loadedLogFolder;this.updateButtons();}
   // Override only the face color. PixInsight supplies the standard border,
   // font and interactive states; clearing the style restores its normal face.
   updateFileButtons(){
      let mode=this.inputMode(),available=!this.running&&this.hasInputFolders();
      this.refreshFilesButton.enabled=this.calculate.enabled=this.measureCornersButton.enabled=available;
      this.refreshFilesButton.toolTip='Refresh file list: '+(mode==='import'?'recheck the lights in the imported WBPP setup.':'read the selected folders and match registered lights to their originals.')+
         ' Refresh clears measurements and keeps your decision for unchanged WBPP log findings.';
      const report=this.session?.wbppLog&&!this.scanRequired;
      this.importWBPPButton.text=report?'WBPP report…':'Import WBPP…';
      this.importWBPPButton.enabled=!this.running&&(mode!=='manual'||!!report);
      let highlight=mode==='choose'&&this.importWBPPButton.enabled;
      if(this.importHighlighted!==highlight){this.importHighlighted=highlight;this.importWBPPButton.styleSheet=highlight?'QPushButton { background-color: #b9c6d0; }':'';}
      this.importWBPPButton.toolTip=report?'Show the current WBPP log findings and rejection decisions.'+(mode==='import'?' Choose Import setup to open another WBPP instance.':''):
         mode==='manual'?(this.scanRequired?'Load the file list to check for a WBPP run log.':'No WBPP run log found.')+' Clear WBPP output to import a setup instead.':
         'Import from a loaded WBPP icon or saved .xpsm file and populate Review automatically.'+(this.wbppImport?' Choose Saved WBPP setup to recheck the imported list, or select another source.':'');
   }
   updateButtons(){let ready=!!this.session&&!this.running,selected=!!this.current,original=selected&&!this.current.isMaster&&!this.current.moved;
      this.updateFileButtons();
      this.recommendButton.enabled=ready&&!this.scanRequired&&!!this.group()?.roi&&this.group().rows.some(r=>r.metrics[0]?.valid);
      if(this.plotInfoButton)this.plotInfoButton.enabled=!this.running&&!!this.plotInformation;
      if(this.sqmTime){this.sqmTime.enabled=this.sqmTimePicker.enabled=!this.running&&this.sqm.value>0;this.validateSQMTime();}
      if(this.calibrateSkyButton)this.calibrateSkyButton.enabled=ready&&sqrSkyComparisonEnabled(this.options())&&!!this.group()&&sqrSkyFilterSupported(this.group())&&
         (!this.sqm.value||sqrSQMTime(this.options(),this.session).time!==null);
      this.cornerScoring.enabled=!this.running&&sqrHasCornerMeasurements(this.session);
      const mosaic=this.isCornerMosaic();
      if(mosaic!==this.mosaicModeShown){
         this.mosaicModeShown=mosaic;this.rotationLabel.visible=this.regionRotation.visible=this.region.visible=!mosaic;this.mosaicSize.visible=mosaic;
      }
      this.reference.enabled=!this.running&&this.regionRotation.currentItem!==1;this.regionRotation.enabled=this.region.enabled=!this.running&&!mosaic;this.mosaicSize.enabled=!this.running&&mosaic;
      // A typed or browsed destination enables file actions without rescanning.
      // Whitespace is empty; the move preflight still validates the actual path.
      let destinationSet=!!this.folders.destination.edit.text.trim(),scanned=!!this.session&&!this.scanRequired;
      this.updateSelectionActions();
      const decisions=sqrDecisionRows(this.session);
      let pending=decisions.some(r=>r.reject&&!r.moved);
      this.moveButton.enabled=!this.running&&scanned&&destinationSet&&pending;
      this.undoMoveButton.enabled=!this.running&&this.hasInputFolders()&&destinationSet;
      const retained=this.group()?.rows.filter(sqrRetainedRegistered).length||0;
      const fromWBPP=this.inputMode()==='import'&&sqrImportedRun(this.session?.options);
      this.masterButton.enabled=!this.running&&scanned&&fromWBPP&&retained>=3;
      this.masterButton.toolTip='Integrate retained lights. '+(fromWBPP?'Create a master from '+retained+' registered lights in this group using its WBPP settings. At least 3 are required.':'Import the WBPP setup for this run to enable master creation.');
      let unavailable=!destinationSet?'Choose a folder in Rejected originals under Input files and observing conditions.':
         !this.hasInputFolders()?'Select both image folders or import WBPP.':this.running?'Wait for the current operation to finish.':'';
      this.moveButton.toolTip='Move rejected originals. '+(unavailable||(!scanned?'Load the file list and mark an original to move.':!pending?'Mark at least one original as rejected.':'Confirm the list to move only original lights marked Reject across all groups.'));
      this.undoMoveButton.toolTip=unavailable?'Undo moved originals: '+unavailable:'Undo moved originals. Loads the file list if needed. Select a moved row to restore that file, or choose a move journal to restore several files, including after reopening the script.';
      let rotation=this.isRotating(),count=rotation?this.rotationRows().length:0,canRotate=ready&&!!this.group()?.regions;
      this.play.enabled=rotation?canRotate&&count>1:!!this.frames&&!this.running;
      this.step.enabled=rotation?canRotate&&count>0:!!this.frames&&!this.running;
      this.decisionToggle.enabled=ready&&original;
      let rejected=selected&&!this.current.isMaster&&!!this.current.reject;
      if(this.decisionToggle.checked!==rejected||this.decisionIconRejected!==rejected){
         this.decisionToggle.checked=rejected;this.decisionIconRejected=rejected;
         this.decisionToggle.icon=this.scaledResource(rejected?':/icons/cancel.png':':/icons/check.png');
      }
      this.decisionToggle.toolTip=!selected?'Select a subframe to keep or reject its original.':this.current.isMaster?'Integrated masters cannot be rejected.':
         this.current.moved?'This original has already been moved. Use Undo moved originals to restore it.':
         (rejected?'Reject original (pressed). Click to keep it.':'Keep original. Click to mark for rejection.')+' This changes the review decision only; no file is moved.';
      this.previous.enabled=this.next.enabled=rotation?canRotate&&count>0:ready&&selected;
      this.updateBlinkButton();
      this.sortDirection.enabled=ready&&this.visibleRows?.length>1;}
   populateGroups(){this.selectionCleared=false;this.groupSelect.clear();let groups=this.session?.groups||[];
      this.groupRow.visible=groups.length>1;
      for(let g of groups){let duplicate=groups.some(other=>other!==g&&other.filter===g.filter&&other.exposure===g.exposure);
         this.groupSelect.addItem((g.filter||'Group')+' · '+g.exposure+' s · '+g.rows.length+' frames'+(duplicate?' — '+g.directoryName:''));}
      if(this.groupSelect.numberOfItems)this.groupSelect.currentItem=0;this.populateRows();this.masterBlink.refresh();}
   // Sort presentation only: retain selection, decisions, measurements and the
   // existing blink frames. The next/previous controls use the rebuilt row order.
   changeReviewSort(){
      if(this.running)return;
      this.syncOptions();this.populateRows(false);
      // TreeBox needs its native node-scrolling method to expose the new start.
      if(this.table.numberOfChildren)this.table.setNodeAtViewportTop(this.table.child(0));
   }
   // Rebuild native nodes while preserving row-object selection. Respect an
   // explicit deselection, or choose a visible fallback if a filter hides it.
   populateRows(loadPreview=true){
      this.populating=true;this.table.clear();this.reviewNodes=new Map;let g=this.group();
      if(g)sqrRefreshTrailReview(g);
      // Undoing a moved original also changes its rejection decision. Refresh
      // completion here so every decision path restores REVIEW when needed.
      if(g?.recommendationReview){let completed=!!g.reviewComplete;
         if(sqrRecommendationReviewComplete(g,this.session.options,!!this.session.guiding?.enabled)!==completed)sqrRank(this.session);}
      this.groupSelect.toolTip=g?(g.filter||'Group')+' · '+g.exposure+' s · '+g.rows.length+' frames\n'+g.directoryName:'Select a filter group after scanning files.';
      // Append only corner KPIs that actually contribute. Keep every established
      // column index stable for selection, rejection, tooltips and saved sorting.
      let extraKPIs=(this.correlationOnly.checked||this.rankScoring.checked)&&this.useCornerMeasurements?g?.correlationScoring?.components.filter(c=>c.corner&&c.included)||[]:[];
      this.table.numberOfColumns=this.baseReviewColumnCount+extraKPIs.length;
      for(let i=0;i<extraKPIs.length;++i)this.table.setHeaderText(this.baseReviewColumnCount+i,extraKPIs[i].label+(extraKPIs[i].metric==='fwhm'?' (px)':''));
      this.updatePixelScale();this.updateScoreWeightControls();
      let mode=SQR_REVIEW_SORTS[this.order.currentItem][0],rows=sqrReviewRows(g,this.candidatesOnly.checked,mode,this.reviewReverse);
      this.visibleRows=rows;
      let descending=[3,4,9,10,11,12,14,18].includes(mode)!==this.reviewReverse;
      this.sortDirection.text=descending?'Descending ↓':'Ascending ↑';
      let directions=this.reviewReverse?
         ['Highest first (best first)','Highest first (best first)','Most first (best first)','Smallest first (best first)','Lowest first (best first)','Z to A','Highest rank first (best first)','Highest rank first (best first)','Latest first · undated frames next · master last','Lowest % first · incomplete last']:
         ['Lowest first (worst first)','Lowest first (worst first)','Fewest first (worst first)','Largest first (worst first)','Highest first (worst first)','A to Z','Rank 1 first (worst first)','Rank 1 first (worst first)','Earliest first · undated frames next · master last','Highest % first · incomplete last'];
      let guideDirection=(this.reviewReverse?'Smallest error first (best first)':'Largest error first (worst first)')+' · unavailable next · master last';
      this.sortDirection.toolTip=(mode===18?(this.reviewReverse?'Lowest cloud extinction first':'Highest cloud extinction first')+' · unavailable next · master last':[13,15].includes(mode)?(this.reviewReverse?'Highest rank first (best first)':'Rank 1 first (worst first)'):mode===14?(this.reviewReverse?'Lowest background first (best first)':'Highest background first (worst first)')+' · unavailable last':mode>=10?guideDirection:directions[mode])+'. Click to reverse the order. Sorting preserves the selected image and rejection decisions.';
      this.reviewSummary.text=g?'Showing '+rows.filter(r=>!r.isMaster).length+' of '+g.rows.length+' subframes'+(g.reviewComplete&&!g.rows.some(r=>r.trailReview)?' · REVIEW complete':' · '+g.rows.filter(sqrNeedsReview).length+' REVIEW candidates')+
         (g.measureSignature&&g.cornerPatch?' · Center and corners: '+g.cornerPatch+'% (started at '+this.measurementOptions.patch+'%)':
          g.measureSignature&&g.cornerRetryMinimum?' · Center and corners: kept '+this.measurementOptions.patch+'% after retry':'')+
         (g.master?(this.candidatesOnly.checked?' · master hidden by filter':' · master included for comparison'):''):'';
      // The native visible flag is also false when Messages is collapsed.
      // A rerank of the same group doesn't change the summary row's layout.
      if(this.reviewSummaryHasGroup!==!!g){this.reviewSummaryHasGroup=!!g;this.reviewSummary.visible=!!g;this.layoutTimer.start();}
      let kpiCell=(value,digits=3)=>Number.isFinite(value)?sqrFmt(value,digits):'—';
      let correlationReport=sqrScoreCorrelationReport(g?.correlationScoring);
      if(g)for(let r of rows){let node=new TreeBoxNode(this.table);node.row=r;this.reviewNodes.set(r,node);if(!r.isMaster&&!r.moved)node.setIcon(4,this.rejectIcons[r.reject?1:0]);
         let scoreInfo=kpi=>r.isMaster?SQR_MASTER_SCORE_INFO:sqrKPIScoreInfo(kpi,this.session.options,!!this.session.guiding?.enabled,g.correlationScoring);
         let guideReport=sqrGuideReport(r)+(r.guiding&&!r.guiding.scorable?'\n* Partial/unusable for Score.'+(r.guidingIgnored?'':' Inspect manually.'):'');
         let m=r.metrics[0]||{},cells=[r.rankWithoutCorners===null||r.rankWithoutCorners===undefined?'—':String(r.rankWithoutCorners),r.rankWithCorners===null||r.rankWithCorners===undefined?'—':String(r.rankWithCorners),Number.isFinite(r.rankCorrelated)?String(r.rankCorrelated):'—',Number.isFinite(r.rankOfRanks)?String(r.rankOfRanks):'—',r.isMaster?'—':r.moved?'Moved':'',r.isMaster?'Master':sqrNeedsReview(r)?'REVIEW':'',sqrFileName(r.registered.path),sqrAcquisitionText(r),sqrFmt(r.score,3),sqrFmt(m.signal),sqrFmt(m.fwhm,1),Number.isFinite(m.stars)?String(m.stars):'—',r.mainIssue||'—',kpiCell(sqrEccentricityValid(m)?m.eccentricity:null),kpiCell(sqrKPIValue(r,SQR_KPIS.find(k=>k.key==='cornerSeverity'))),sqrMeanQualityLabel(r),(Number.isFinite(r.guideQuality)?sqrGuideNumber(r.guideQuality):'—'),sqrGuideCell(r,'guideAvg'),sqrGuideCell(r,'guideMin'),sqrGuideCell(r,'guideMax'),r.worstCorner||'—',r.match,Number.isFinite(r.skyBackground)?sqrFmt(r.skyBackground,6):'—',Number.isFinite(r.relativeTransparency)?sqrPercent(r.relativeTransparency):'—',Number.isFinite(r.skyQuality)?sqrPercent(r.skyQuality):'—'];
         if(r.isMaster)cells[8]='—'; // Score is inapplicable, not an unmeasured subframe value.
         cells.push(r.isMaster?'—':kpiCell(r.cloudExtinction,4));
         cells.push(Number.isInteger(m.trails)?String(m.trails):'—');
         cells.push(...extraKPIs.map(c=>kpiCell(sqrKPIValue(r,c),c.metric==='fwhm'?1:3)));
         for(let i=0;i<cells.length;++i){node.setText(i,cells[i]);node.setToolTip(i,i===6?r.registered.path+(r.isMaster?'':'\n'+sqrAcquisitionLabel(r)):i===21?(r.original?.path||r.match):cells[i]);}
         for(let i=0;i<extraKPIs.length;++i){let c=extraKPIs[i];node.setToolTip(this.baseReviewColumnCount+i,c.label+(c.metric==='fwhm'?' in pixels':' (0 = round, toward 1 = elongated)')+'. Lower is better.'+(r.isMaster?'\n'+SQR_MASTER_SCORE_INFO:(this.rankScoring.checked?'\nIncluded via R3 in R4':'\nIncluded in Score with equal weight')+'; correlation with PSF signal weight: '+sqrFmt(c.r)+' ('+c.count+' subframes).')+(sqrKPIValue(r,c)===null?'\nMeasurement unavailable for this image; inspect manually.':''));}
         node.setToolTip(0,'Field-only rank: 1 = worst Score. Subframes only; independent of table filters. Field-only Score: '+sqrFmt(r.scoreWithoutCorners));
         node.setToolTip(1,Number.isFinite(r.rankWithCorners)?'Rank including corner FWHM and eccentricity: 1 = worst Score. Subframes only; computed from available measurements. Score: '+sqrFmt(r.scoreWithCorners):'Requires valid field, center and all four corner measurements including corner eccentricity, and a positive enabled weight.');
         node.setToolTip(2,Number.isFinite(r.rankCorrelated)?'Correlation rank: 1 = worst Score. Higher Score is better. Score: '+sqrFmt(r.scoreCorrelated)+'\n'+correlationReport:g.correlationScoring?.available===false?correlationReport:'R3 unavailable for this image; check the field and selected KPI measurements.\n'+correlationReport);
         node.setToolTip(3,r.rankOfRanksDetail||'Measure this image to calculate R4 from its available ranks.');
         node.setToolTip(4,sqrRejectTip(r));
         node.setToolTip(5,sqrReviewToolTip(r,g,this.session.options));
         node.setToolTip(7,r.isMaster?'Integrated master: no single acquisition time.':sqrAcquisitionLabel(r)+'\nSame timestamp used for acquisition-time sorting and histograms. Original observation time, with registered metadata as fallback.');
         for(let i=17;i<=19;++i)node.setToolTip(i,['Arithmetic average','Minimum','Maximum'][i-17]+' combined RA/Dec displacement during the exposure, in arcseconds; not RMS.\n'+guideReport);
         for(let [column,key,meaning] of [
            [13,'0:eccentricity','Field star eccentricity, from 0 (round) toward 1 (elongated). Lower is rounder.'],
            [14,'cornerSeverity','Largest corner-quality penalty from corner FWHM, corner/center FWHM ratio, or eccentricity, relative to the group. Lower is better. Stored measurements remain visible when corner scoring is off.'],
            [16,'guideQuality','Combined guiding quality = (minimum + 2 × average + maximum) / 4, in arcseconds. Lower is better. Only usable exposure coverage produces a value.']]){
            let kpi=SQR_KPIS.find(k=>sqrKPIKey(k)===key);
            let inclusion=scoreInfo(kpi);
            node.setToolTip(column,meaning+'\n'+inclusion+'.'+(column===16?'\n'+sqrGuideReport(r):'')+(sqrKPIValue(r,kpi)===null?'\nMeasurement unavailable for this image.':''));
         }
         node.setToolTip(22,sqrBackgroundDescription(r,this.useCornerMeasurements)+'\n'+scoreInfo(SQR_KPIS.find(k=>k.key==='skyBackground'))+(r.skyBackground===null?'\nMeasurement unavailable; measure the images.':''));
         node.setToolTip(23,sqrTransparencyDescription(r)+'\n'+scoreInfo(SQR_KPIS.find(k=>k.key==='relativeTransparency')));
         node.setToolTip(24,sqrSkyQualityDescription(r)+'\n'+scoreInfo(SQR_KPIS.find(k=>k.key==='skyQuality')));
         node.setToolTip(25,sqrCloudExtinctionDescription(r)+'\nExcluded from Score (comparison only).');
         node.setToolTip(26,r.isMaster?'Subframes only.':!Number.isInteger(m.trails)?'Trail count unavailable.':
            m.trails+' linear trail(s) detected in the common usable field.'+(r.trailBands?.length?' Saved trail mask.':m.trailReviewed?' Inspected and kept.':r.trailReview?' Inspect in Blink before deciding.':''));
         node.setToolTip(8,r.mainIssueDetail||'Measure the image to calculate its weighted quality Score.');
         node.setToolTip(15,r.belowMeanDetail||'Measure the image to calculate the percentage of assessed indicators with worse-than-mean quality. Score is excluded.');
         node.setToolTip(12,r.mainIssueDetail||'Measure the image to identify the largest weighted contribution to Score.');
         if(r.isMaster)for(let column of [0,1,2,3,8,12])node.setToolTip(column,SQR_MASTER_SCORE_INFO);
      }
      for(let i=0;i<this.table.numberOfColumns;++i)this.table.adjustColumnWidthToContents(i);this.table.setColumnWidth(6,Math.round(250*this.displayPixelRatio));
      let found=false;for(let i=0;i<this.table.numberOfChildren;++i)if(this.table.child(i).row===this.current){this.table.currentNode=this.table.child(i);found=true;break;}
      if(!found){let next=this.selectionCleared?null:rows[0]||null;if(this.current!==next)this.clearFrames(!next);this.current=next;if(next)this.table.currentNode=this.table.child(0);else this.table.deselectAllNodes();}
      this.populating=false;
      this.updateDetails();this.updateButtons();this.updatePlots();
      if(loadPreview)this.ensurePreview();
   }
   setScatterOptions(o){this.refreshScatterKPIs(o,this.session?.groups[0]||null);}
   // Regional values must exist in the plotted subframes, not just the master.
   // Match identities across list changes so guiding and other surviving choices
   // never move to a different KPI. Only an unavailable axis falls back to default.
   refreshScatterKPIs(saved=null,group=this.group()){
      let defaults=sqrDefaults(),selected=saved||{};
      if(!saved)for(let name of ['scatterX','scatterY']){let kpi=this.scatterKPIs[this[name].currentItem];selected[name]=kpi?sqrKPIKey(kpi):defaults[name];}
      let available=sqrAvailableKPIs(group,false),changed=available.length!==this.scatterKPIs.length||available.some((kpi,i)=>kpi!==this.scatterKPIs[i]);
      this.updatingScatterKPIs=true;
      try{
         this.scatterKPIs=available;
         for(let name of ['scatterX','scatterY']){
            if(changed){this[name].clear();for(let kpi of available)this[name].addItem(kpi.label);}
            let index=available.findIndex(kpi=>sqrKPIKey(kpi)===selected[name]);
            this[name].currentItem=index>=0?index:available.findIndex(kpi=>sqrKPIKey(kpi)===defaults[name]);
         }
      }finally{this.updatingScatterKPIs=false;}
   }
   updatePlots(){this.updateHistogram();this.updateScatter();}
   updateScatter(){
      this.refreshScatterKPIs();
      // Build each page once for its initial layout. Later hidden refreshes
      // reconcile selectors but defer statistics/HTML until the tab is opened.
      // Invalidate any queued click from the previously rendered generation.
      if(this.scatterData&&this.tabs&&this.tabs.currentPageIndex!==3){
         if(!this.scatterDirty)++this.scatterGeneration;this.scatterDirty=true;this.scatterReady=false;return;}
      this.scatterDirty=false;
      let xKPI=this.scatterKPIs[this.scatterX.currentItem],yKPI=this.scatterKPIs[this.scatterY.currentItem];
      for(let [control,kpi] of [[this.scatterX,xKPI],[this.scatterY,yKPI]])control.toolTip=kpi.direction+(kpi.corners?' · Requires regional measurements; stored values remain available with corner scoring off.':kpi.guiding?' · Requires guiding logs matched to the exposure.':'');
      let data=this.scatterData=sqrScatterPlot(this.group(),xKPI,yKPI,this.current);
      this.scatterSummary.text=data.count+' of '+data.total+' subframes plotted'+(data.missing?' · '+data.missing+' missing one or both measurements':'')+'. Hover for values; click a point to select its image.\nCyan: selected · purple: REVIEW · blue: other kept · red: rejected.';
      this.scatterReady=false;this.scatter.displayPlot(sqrScatterContent(data,++this.scatterGeneration));
   }
   // Reconcile available KPI choices, then publish a new plot generation.
   // Separate chart ordering and filtering from the table's visible row list.
   updateHistogram(){
      let g=this.group(),kpi=this.availableKPIs[this.kpiSelect.currentItem]||SQR_KPIS[0],available=sqrAvailableKPIs(g);
      if(available.length!==this.availableKPIs.length||available.some((item,i)=>item!==this.availableKPIs[i])){
         this.updatingKPIs=true;this.kpiSelect.clear();for(let item of available)this.kpiSelect.addItem(item.label);
         this.availableKPIs=available;this.kpiSelect.currentItem=Math.max(0,available.indexOf(kpi));this.updatingKPIs=false;
         kpi=available[this.kpiSelect.currentItem];
      }
      if(this.histogramData&&this.tabs&&this.tabs.currentPageIndex!==2){
         if(!this.plotDirty)++this.plotGeneration;this.plotDirty=true;this.plotReady=false;return;}
      this.plotDirty=false;
      let options=this.options(),scale=sqrSessionPixelScale(this.session),fwhmModel=sqrFWHMModel(this.fwhmOptions,scale,g?.filter);
      let sky=kpi.key==='skyBackground',calibration=sky?sqrCurrentSkyCalibration(this.session,g):null;
      let skyModel=sky?sqrBortleModel(options,g,this.session,calibration):null;
      let data=this.histogramData=sqrMetricPlot(g,kpi,this.useCornerMeasurements,this.current,this.histogramOrder.currentItem===1?'time':'value',this.autofocusRuns||[],sqrGuidingScale(scale),fwhmModel,skyModel);
      if(kpi.key==='score')data.scoreDefinition=options.rankOfRanks?
         'Score is the equal-weight mean of the available normalized R1, R2 and R3 ranks. Each rank is normalized as (rank − 1) / (ranked images − 1); a single ranked image uses 0.5. R2 is omitted when corner scoring is off or unavailable.':
         'Score = 1 − weighted mean penalty / 10. '+(options.correlationOnly&&g?.correlationScoring?.available!==false?'The selected strongly correlated KPIs receive equal weight.':'The configured manual KPI weights are used.'+(options.correlationOnly?' No strongly correlated KPIs; R3 is unavailable.':''))+' A value of 1.000 means no measured penalty.';
      let info=this.plotInformation=sqrPlotInformation(data);this.plotInfoButton.visible=!!info;this.plotInfoButton.enabled=!this.running&&!!info;
      this.plotInfoButton.toolTip=info?'Histogram information':'';
      this.bortleControls.visible=kpi.key==='skyBackground'&&this.sqm.value===0;
      this.calibrateSkyButton.visible=sky&&!calibration;
      this.calibrateSkyButton.enabled=!this.running&&sqrSkyComparisonEnabled(this.options())&&!!g&&sqrSkyFilterSupported(g)&&
         (!this.sqm.value||sqrSQMTime(this.options(),this.session).time!==null);
      this.fwhmSettings.visible=kpi.metric==='fwhm';
      this.fwhmSettings.enabled=!this.running;
      this.fwhmSettings.toolTip='FWHM grading';
      this.kpiDirection.text=kpi.direction+' · '+sqrKPIScoreInfo(kpi,options,!!this.session?.guiding?.enabled,g?.correlationScoring);
      this.kpiDirection.toolTip='';
      this.histogramSummary.text=data.message?'':data.count+' subframes'+(data.missing?' · '+data.missing+' unavailable':'')+(data.hasMaster?' · master included':'')+' · '+(data.order==='time'?'acquisition order':'value order');
      this.histogramSummary.toolTip='';
      this.plotReady=false;this.histogram.displayPlot(sqrHistogramContent(data,++this.plotGeneration));
   }
   // Validate asynchronous WebView messages against the current generation.
   // Reveal a hidden row before selecting it; this action never changes rejection.
   selectPlotImage(selection,scatter=false){
      if(this.running||this.tabs.currentPageIndex!==(scatter?3:2)||selection?.generation!==(scatter?this.scatterGeneration:this.plotGeneration)||!Number.isInteger(selection.index))return false;
      let item=(scatter?this.scatterData:this.histogramData)?.items[selection.index],g=this.group();if(!item||!g||!sqrGroupRows(g).includes(item.row))return false;
      let reveal=this.candidatesOnly.checked&&(item.row.isMaster||!sqrNeedsReview(item.row));
      if(reveal)this.candidatesOnly.checked=false;
      this.clearFrames(false);this.current=item.row;this.selectionCleared=false;this.tabs.currentPageIndex=0;this.plotTimer.stop();this.populateRows();this.table.hasFocus=true;
      this.status.text='Selected '+sqrFileName(item.row.registered.path)+' from the plot.'+(reveal?' REVIEW-only filter cleared to show this image.':'');
      return true;
   }
   updateDetails(){let r=this.current,info=sqrReviewDetails(r);
      this.keepTrail.visible=!!r?.trailReview;
      for(let [control,key] of [[this.details,'summary'],[this.detailMetrics,'metrics'],[this.detailSource,'source']]){control.text=info[key];control.toolTip=info[key+'Tip'];}
      if(!r){this.frameLabel.text='No frame selected';return;}
      this.frameLabel.text=(this.isRotating()?'SUBFRAME '+(this.rotationRows().indexOf(r)+1)+' / '+this.rotationRows().length+': ':this.frame===0?(r.isMaster?'MASTER: ':r.trailBands?.length?'MASKED: ':'REGISTERED: '):(this.loadedReference?.label||'REFERENCE')+': ')+(this.frame===0?sqrFileName(r.registered.path):sqrFileName(this.loadedReference?.path||''))+(this.isCornerMosaic()?' · Corner mosaic (TL / TR above BL / BR)':this.isRegionRotating()?' · '+(this.region.currentItem?SQR_REGIONS[this.region.currentItem]:'Usable field'):'')+(r.isMaster?'\nINTEGRATED MASTER · cannot be rejected':r.moved?'\nOriginal already moved':'');
   }
   chooseWBPPImport(){
      if(this.running)return;
      const allowImport=this.inputMode()!=='manual';
      let report=this.scanRequired?null:this.session.wbppLog;
      if(!allowImport&&!report)return;
      this.stopBlink();
      try{
         for(;;){
            if(report){
               let view=new SQRWBPPLogDialog(report,allowImport);view.execute();
               if(view.changed){this.updateButtons();this.scanSummary();}
               if(!view.chooseSetup)return;
            }
            let picker=new SQRWBPPImportDialog(this.wbppImport);
            if(!picker.execute()||!picker.data||!this.importWBPP(picker.data))return;
            report=this.session.wbppLog;
            if(!report?.findings.length&&!report?.note)return;
         }
      }catch(e){this.error(e);}
   }
   importWBPP(data){if(this.running)return;this.stopBlink();this.busy(true);let abort=console.abortEnabled,imported=false;console.abortEnabled=true;
      try{let options={...this.options(),wbpp:data.wbpp,originals:data.originals,wbppImport:data,measureCorners:false};
         let sameRun=this.wbppImport&&sqrSameRunFolders(this.runFolders,data)&&this.wbppImport.source===data.source&&
            JSON.stringify(this.wbppImport.lights)===JSON.stringify(data.lights);
         if(!sameRun){options.observingSite=null;options.siteHeadersOnly=false;}
         let cornerChoice=sameRun?this.cornerScoreChoice:null,prompted=sameRun&&this.session&&this.sitePromptSession===this.session;
         // Build first: invalid files or an abort preserve the current review.
         let session=sqrScan(options,s=>this.setStatus(s),sameRun?this.session:null);this.setSession(session);imported=true;
         this.cornerScoreChoice=cornerChoice;this.sitePromptSession=prompted?session:null;
      }catch(e){this.error(e);}finally{console.abortEnabled=abort;this.busy(false);}
      // setSession cannot load logs while busy. Rebind the selected logs only
      // after a successful replacement, using the new image timestamps/scale.
      if(imported)try{this.loadAutorun(false);this.populateRows(false);this.scanSummary();}catch(e){this.error(e);}
      return imported;
   }
   scanSummary(){let rows=this.session.groups.flatMap(g=>g.rows),masters=this.session.groups.filter(g=>g.master).length;
      this.status.text=(this.session.importSummary?this.session.importSummary+'\n':'')+rows.length+' registered lights · '+rows.filter(r=>r.original).length+' verified originals · '+this.session.groups.length+' groups · '+masters+' masters matched by filter.'+'\n'+sqrWBPPLogSummary(this.session.wbppLog)+(this.session.warnings.length?'\n'+this.session.warnings.join('\n'):'');}
   // A saved WBPP instance supplies its own light list. Only replace the
   // active review after discovery and header validation have succeeded.
   readFileList(){
      let options=this.options();options.measureCorners=false;
      if(this.inputMode()!=='import')options.wbppImport=null;
      let session=sqrScan(options,s=>this.setStatus(s),this.session);
      let sameRun=sqrSameRunFolders(this.runFolders,options);
      this.sitePromptSession=sameRun&&this.session&&this.sitePromptSession===this.session?session:null;
      if(!sameRun)this.cornerScoreChoice=null;
      this.runFolders={wbpp:options.wbpp,originals:options.originals};this.observingSite=options.observingSite;this.siteHeadersOnly=options.siteHeadersOnly;
      this.clearFrames();this.session=session;this.scannedInputs=session.options;this.wbppImport=options.wbppImport;
      this.useCornerMeasurements=false;this.current=null;this.updateCornerControls();
      this.parseAutorun(false);this.populateGroups();this.scanSummary();
   }
   refreshFileList(){
      if(this.running||!this.hasInputFolders())return false;
      this.stopBlink();this.busy(true);let abort=console.abortEnabled;console.abortEnabled=true;
      try{this.readFileList();return true;}
      catch(e){this.error(e);return false;}finally{console.abortEnabled=abort;this.busy(false);}
   }
   analyze(withCorners=this.useCornerMeasurements){
      if(this.running||!this.hasInputFolders())return;
      this.stopBlink();this.busy(true);let abort=console.abortEnabled;console.abortEnabled=true;console.show();
      let started=false,measured=false,previewSignature,skyResult=null,calibrationError='';
      try{
         if(this.scanRequired)this.readFileList();
         if(!sqrRunSite(this.session).site&&!sqrFallbackSite(this)&&!this.siteHeadersOnly&&this.sitePromptSession!==this.session&&
            this.session.groups.some(g=>g.rows.length>=5&&sqrGroupNeedsSite(g))&&!this.requestObservingSite())return;
         previewSignature=this.measurementPreviewSignature(true);
         this.syncOptions();this.session.options.measureCorners=withCorners;started=true;
         sqrAnalyze(this.session,s=>this.setStatus(s));
         measured=true;
         skyResult=sqrAutoCalibrateSky(this.session,s=>this.setStatus(s));
      }catch(e){
         // Preserve completed regions after a failure or abort, but refresh the
         // selection so the report cannot retain an obsolete corner decision.
         if(measured)calibrationError=e.message||String(e);this.error(e);
      }finally{
         if(started){
            // First regional measurement activates corner scoring. Later runs
            // preserve an explicit exclusion, even when filling missing regions.
            this.useCornerMeasurements=sqrHasCornerMeasurements(this.session)&&(this.cornerScoreChoice??withCorners);this.syncOptions();
            if(!measured||withCorners!==this.useCornerMeasurements)try{sqrRank(this.session);}catch(rankError){for(let g of this.session.groups)g.correlationScoring=null;}
            this.updateCornerControls();this.populateRows(false);
            if(previewSignature!==this.measurementPreviewSignature())this.clearFrames(false);
         }
         console.abortEnabled=abort;this.busy(false);
      }
      if(measured){let n=this.session.groups.reduce((s,g)=>s+g.rows.filter(sqrNeedsReview).length,0);
         let summary='Measured. '+n+' review candidates; no originals selected automatically.'+sqrSkyCalibrationSummary(skyResult)+(calibrationError?' Sky brightness: '+calibrationError:'');this.status.text=summary;
         // Full-resolution display alignment and STF are expensive. Build them
         // only when Blink is visible; a cached preview remains ready to reuse.
         if(!calibrationError)this.ensurePreview();this.status.text=summary+(this.frames?' Blink preview ready.':' Open the Blink tab to preview an image.');
      }}
   // Load both comparison bitmaps once. Use only a reentry guard during these
   // synchronous reads, just as in rotation: do not disable controls or pump
   // events midway through a preview replacement. Retain zoom/pan on navigation.
   inspect(openBlink=true,preserveView=true,preservePlayback=false){
      if(this.isRegionRotating())return this.inspectRegions(openBlink,preserveView,preservePlayback);
      if(this.isRotating())return this.inspectRotation(openBlink,preserveView,preservePlayback);
      let r=this.current,g=this.group();if(!r||!g||this.running)return false;
      let keepView=preserveView&&(this.viewer.isValid||!!this.savedPreviewView);
      this.running=true;try{
         this.clearFrames(!keepView,false,preservePlayback);let reference=sqrReference(g,this.options().reference,this.current);
         if(!reference.path){this.clearPreviewKeepingView();if(openBlink&&this.tabs.currentPageIndex!==1)this.tabs.currentPageIndex=1;this.status.text=this.options().reference==='trail'?'Select a light with a saved trail mask to compare it with its original.':this.reference.currentItem===1||this.reference.currentItem===4?'No scored, kept subframe is available. Measure the group or choose Filter master.':'No unique master matches this filter in WBPP/master. Check master filenames or choose Best scoring subframe.';return false;}
         if(!g.regions&&this.options().reference!=='trail'){this.clearPreviewKeepingView();this.status.text='Measure this group before using the registered comparison regions.';return false;}
         let rect=this.isCornerMosaic()?sqrRegions(g.regions[0],this.mosaicSize.value).slice(2):g.regions?.[this.region.currentItem]||[0,0,g.width,g.height];
         let display=this.options(),path=r.registered.path;
         if(display.reference==='trail'){
            display.alignBrightness=false;
            if(r.trailCopy){if(sqrFingerprint(r.trailCopy)!==r.trailCopyFingerprint)throw Error('Saved repaired image changed: '+r.trailCopy);path=r.trailCopy;}
         }
         this.frames=sqrFrames(path,reference.path,display,rect,!!r.isMaster,this.referenceDisplay,sqrBlinkBands(r),sqrBlinkBands(reference.row));this.loadedReference=reference;this.frame=0;
         // ImageView.regenerate replaces pixels while retaining its native zoom and
         // scroll positions, clamped to the new bounds when changing regions.
         this.setPreviewImage(this.frames[0],keepView);
         if(openBlink&&this.tabs.currentPageIndex!==1)this.tabs.currentPageIndex=1;this.showFrame(0);
         this.viewer.setStatusMessage((this.isCornerMosaic()?'Corner mosaic · ':'')+'Blink against '+reference.label.toLowerCase()+': '+sqrFileName(reference.path));
         this.status.text=this.options().reference==='trail'?'Black pixels are excluded from integration. Blink to compare with the unmasked registered light.':sqrKey(reference.path)===sqrKey(r.registered.path)?'This image is also the selected blink reference.':r.isMaster?'Integrated master compared with the selected reference. The master cannot be rejected.':'Blink uses identical coordinates and zoom. Mark Keep or Reject, then review the next frame.';
         return true;
      }catch(e){this.clearPreviewKeepingView();this.error(e);return false;}finally{this.running=false;this.updateButtons();}}
   // Synchronize selection without rebuilding the table or hidden quality plot
   // on every timer tick. The plot is refreshed when its tab is opened.
   selectBlinkRow(row){
      this.current=row;this.selectionCleared=false;this.populating=true;
      try{this.table.deselectAllNodes();let node=this.reviewNodes?.get(row);if(node){this.table.currentNode=node;node.selected=true;}}
      finally{this.populating=false;}
   }
   inspectRegions(openBlink=true,preserveView=true,preservePlayback=false){
      let r=this.current,g=this.group();if(this.running||!r||!g)return false;
      let keepView=preserveView&&(this.viewer.isValid||!!this.savedPreviewView);this.running=true;
      try{
         this.clearFrames(!keepView,false,preservePlayback,true);
         if(!g.regions){this.clearPreviewKeepingView();this.status.text='Measure this group before rotating its preview regions.';return false;}
         let reference=this.regionRotation.currentItem===2?sqrReference(g,this.options().reference,this.current):null;
         if(reference&&!reference.path){this.clearPreviewKeepingView();this.status.text='No matching reference is available. Choose another reference or Rotate regions: Image only.';return false;}
         let o=this.options(),key=JSON.stringify([r.registered.path,!!r.isMaster,reference?.path||'',sqrBlinkBands(r),sqrBlinkBands(reference?.row),g.regions,o.displaySTF,o.alignBrightness]);
         if(this.regionFramesKey!==key){this.clearRegionFrames();this.regionFrames=sqrRegionFrames(r.registered.path,reference?.path||'',o,g.regions,!!r.isMaster,r.trailBands,reference?.row?.trailBands);this.regionFramesKey=key;}
         this.frames=this.regionFrames[this.region.currentItem];this.framesFromRegions=true;this.loadedReference=reference;this.frame=0;
         this.setPreviewImage(this.frames[0],keepView);
         if(openBlink&&this.tabs.currentPageIndex!==1)this.tabs.currentPageIndex=1;
         this.viewer.refreshPixelReadout();this.updateDetails();this.viewer.setStatusMessage('Rotate regions · '+(reference?'blink against '+reference.label.toLowerCase():'selected image only'));
         this.status.text='Region rotation keeps the selected image and zoom. '+(reference?'Image and reference are shown in each region before advancing.':'Each interval advances to the next region.');return true;
      }catch(e){this.clearPreviewKeepingView();this.error(e);return false;}finally{this.running=false;this.updateButtons();}
   }
   inspectRotation(openBlink=true,preserveView=true,preservePlayback=false){
      if(this.running)return false;
      let rows=this.rotationRows(),g=this.group();
      if(!rows.length||!g?.regions){this.clearPreviewKeepingView();this.updateDetails();this.updateButtons();this.status.text=rows.length?'Measure this group before rotating subframes.':'No subframes are visible in the Review list.';return false;}
      let r=rows.includes(this.current)?this.current:rows[0];this.selectBlinkRow(r);
      let keepView=preserveView&&(this.viewer.isValid||!!this.savedPreviewView),o=this.options(),rect=g.regions[this.region.currentItem];
      let key=JSON.stringify([g.directoryName,g.rows[0]?.registered.path,rect,o.displaySTF,o.alignBrightness]);
      let display=this.rotationDisplay?.key===key?this.rotationDisplay.data:null;
      // A synchronous frame read needs the reentry guard, not the whole-dialog
      // busy state. Do not pump UI events or change enabled states mid-frame.
      this.clearFrames(!keepView,true,preservePlayback);this.running=true;
      try{
         let rendered=sqrRotationFrame(r.registered.path,o,rect,display,false,sqrBlinkBands(r));
         this.rotationDisplay={key,data:rendered.display};this.frames=[rendered.bitmap];this.frame=0;
         this.setPreviewImage(this.frames[0],keepView);
         if(openBlink&&this.tabs.currentPageIndex!==1)this.tabs.currentPageIndex=1;
         this.viewer.refreshPixelReadout();this.updateDetails();this.viewer.setStatusMessage('Subframes in Review order · master excluded');
         this.status.text='Subframe '+(rows.indexOf(r)+1)+' / '+rows.length+' in Review order. Keep and Reject apply to the displayed subframe.';
         return true;
      }catch(e){this.clearPreviewKeepingView();this.error(e);return false;}finally{this.running=false;this.updateButtons();}
   }
   showFrame(index){if(!this.frames||!this.frames[index])return;this.frame=index;this.viewer.regenerate(this.frames[index]);this.viewer.refreshPixelReadout();this.updateDetails();}
   // Save blink status before loading the next visible row, then resume only
   // if the replacement preview succeeded. Navigation wraps at either list end.
   navigate(step){let rows=this.isRotating()?this.rotationRows():this.visibleRows;if(this.running||!rows?.length)return;let resume=this.blinking,i=rows.indexOf(this.current);
      let preservePlayback=resume;
      if(preservePlayback)this.timer.stop();else this.stopBlink();this.selectBlinkRow(rows[i<0?(step<0?rows.length-1:0):(i+step+rows.length)%rows.length]);
      if(this.inspect(true,true,preservePlayback)&&resume)this.startBlink();}
   // Reference/region changes share this path so active blinking survives them.
   reloadBlink(preserveView=false){if(this.running)return;if(!this.current&&!this.isRotating()){this.updateButtons();return;}let resume=this.blinking;this.rotationDisplay=null;
      if(this.inspect(true,preserveView,resume)&&resume)this.startBlink();}
   selectedScoreCutoff(){
      const r=this.current;
      return this.session&&!this.running&&!this.scanRequired&&Number.isFinite(r?.score)&&!r.isMaster&&this.reviewNodes?.get(r)?.selected?r:null;
   }
   updateSelectionActions(){
      this.trailButton.enabled=this.canEditRegisteredTrail();
      const cutoff=this.selectedScoreCutoff(),count=cutoff?sqrLowerScoreTargets(this.group(),cutoff).length:0;
      this.rejectLowerButton.enabled=count>0;
      this.rejectLowerButton.toolTip='Reject lower scores. '+(count?'Mark '+count+' lower-scoring subframe'+(count===1?'':'s')+' in this group, including rows hidden by the REVIEW filter. The comparison uses the full-precision Score.':
         cutoff?'No unmarked subframes have a lower Score in this group.':'Select a scored subframe in the Review table.');
   }
   rejectLowerScores(){
      const group=this.group(),targets=sqrLowerScoreTargets(group,this.selectedScoreCutoff());
      if(!targets.length)return;
      for(const row of targets)row.reject=true;
      // Refresh trail flags, recommendation completion and the visible table once for the batch.
      this.populateRows();
      this.status.text='Marked '+targets.length+' lower-scoring subframe'+(targets.length===1?'':'s')+' for rejection in '+group.label+'.';
   }
   decide(reject){if(!this.current||this.current.isMaster||this.current.moved)return;this.current.reject=reject;
      let group=this.group(),wasComplete=!!group?.reviewComplete;
      if(group?.recommendationReview&&sqrRecommendationReviewComplete(group,this.session.options,!!this.session.guiding?.enabled)!==wasComplete){
         sqrRank(this.session);this.populateRows(false);this.ensurePreview();return;
      }
      if(group&&sqrRefreshTrailReview(group)){this.populateRows(false);this.ensurePreview();return;}
      // Rejection changes neither scores nor the Review filter/sort keys. Keep
      // all nodes, column widths and the selection; update just this decision.
      let node=this.reviewNodes?.get(this.current);
      if(!node){this.populateRows();return;}
      this.populating=true;try{this.table.currentNode=node;}finally{this.populating=false;}
      node.setIcon(4,this.rejectIcons[reject?1:0]);
      node.setToolTip(4,sqrRejectTip(this.current));
      this.updateDetails();this.updateButtons();this.updatePlots();this.ensurePreview();}
   setSession(s){this.clearFrames();this.session=s;this.scannedInputs=s.options;this.useCornerMeasurements=sqrHasCornerMeasurements(s)&&s.options.measureCorners!==false;this.current=null;let o={...sqrDefaults(),...s.options,logFolder:sqrLogFolderOption(s.options)};
      this.runFolders={wbpp:o.wbpp,originals:o.originals};this.cornerScoreChoice=sqrHasCornerMeasurements(s)?this.useCornerMeasurements:null;
      this.wbppImport=o.wbppImport||null;
      this.fwhmOptions=sqrFWHMOptions(o);this.recommendationOptions=sqrRecommendationOptions(o);
      this.observingSite=sqrValidSite(o.observingSite)?o.observingSite:null;this.siteHeadersOnly=!!o.siteHeadersOnly;
      this.aperture.setValue(this.fwhmOptions.fwhmAperture);this.fwhmOptions.fwhmAperture=this.aperture.value;
      this.seeing.setValue(this.fwhmOptions.fwhmSeeing);
      this.bortle.currentItem=sqrBortleOptions(o).bortleClass;
      this.sqm.setValue(sqrSQMReading(o));
      this.sqmTime.text=String(o.sqmTime||'');this.sqmTimePreset=o.sqmTimeFromLog?this.sqmTime.text.trim():'';this.sqmTime.enabled=this.sqmTimePicker.enabled=this.sqm.value>0;
      this.measurementOptions=sqrMeasurementOptions(o);
      for(let k of Object.keys(this.folders))this.folders[k].edit.text=o[k];
      this.logFolder.edit.text=o.logFolder;this.logTimeZone.currentItem=o.logTimeZone==='offset'?1:0;this.logUTCOffset.setValue(o.logUTCOffset);this.logClock=null;this.updateLogOffsetControls();
      this.skyScoreKPI.currentItem=SQR_SKY_SCORE_CHOICES.findIndex(c=>c.key===sqrSkyScoreChoice(o).key);
      this.rankScoring.checked=!!o.rankOfRanks;this.correlationOnly.checked=!!o.correlationOnly&&!o.rankOfRanks;for(let k of Object.keys(this.weights)){this.manualWeights[k]=o[k];this.weights[k].setValue(o[k]);}this.reference.currentItem=Math.max(0,SQR_BLINK_MODES.indexOf(o.reference));this.updateCornerControls();
      this.regionRotation.currentItem=Math.max(0,['off','image','blink'].indexOf(o.regionRotation));this.normalizeRegionRotation();
      this.guidingMode.currentItem=Math.max(0,['require','available','ignore'].indexOf(o.guidingMode));this.weights.guideWeight.enabled=this.guidingMode.currentItem!==2;
      this.setBlinkInterval(o.blinkInterval);
      this.mosaicSize.setValue(o.mosaicCornerPercent);
      this.preferredTrailWidth=o.trailWidth;
      this.maxFits=o.maxFits;this.displaySTF.checked=o.displaySTF;this.alignBrightness.checked=o.alignBrightness;this.histogramOrder.currentItem=o.histogramOrder==='time'?1:0;
      this.setScatterOptions(o);
      this.order.currentItem=sqrReviewOrderIndex(o.reviewOrder);this.reviewReverse=!!o.reviewReverse;this.loadAutorun(false);if(this.session){this.syncOptions();if(this.session.groups.some(g=>g.rows.some(r=>r.metrics[0])))sqrRank(this.session);}this.populateGroups();this.setInputsCollapsed(o.inputsCollapsed);this.setQualityCollapsed(o.qualityCollapsed);this.setReviewInfoCollapsed(o.reviewInfoCollapsed);this.setMessagesCollapsed(o.messagesCollapsed);}
   resetSettings(){let defaults=sqrDefaults(),folders=this.options();this.measurementOptions=sqrMeasurementOptions(defaults);this.recommendationOptions=sqrRecommendationOptions(defaults);if(this.session)for(let g of this.session.groups)delete g.recommendationSettings;this.correlationOnly.checked=false;this.rankScoring.checked=false;this.manualWeights=Object.fromEntries(SQR_SCORE_COMPONENTS.map(c=>[c.weight,defaults[c.weight]]));for(let k of Object.keys(this.weights))this.weights[k].setValue(defaults[k]);
      this.skyScoreKPI.currentItem=0;
      this.fwhmOptions=sqrFWHMOptions(defaults);
      this.observingSite=null;this.siteHeadersOnly=false;this.sitePromptSession=null;
      this.cornerScoreChoice=null;
      this.aperture.setValue(defaults.fwhmAperture);
      this.seeing.setValue(defaults.fwhmSeeing);
      this.bortle.currentItem=defaults.bortleClass;
      this.sqm.setValue(defaults.sqmReading);
      this.sqmTime.text=defaults.sqmTime;this.sqmTimePreset='';this.applySQMTimePreset();this.sqmTime.enabled=this.sqmTimePicker.enabled=false;
      this.setScatterOptions(defaults);this.updateScatter();
      this.guidingMode.currentItem=['require','available','ignore'].indexOf(defaults.guidingMode);this.weights.guideWeight.enabled=true;
      this.useCornerMeasurements=defaults.measureCorners;this.reference.currentItem=defaults.reference==='best'?1:0;this.updateCornerControls();
      this.regionRotation.currentItem=0;
      this.setBlinkInterval(defaults.blinkInterval);
      this.mosaicSize.setValue(defaults.mosaicCornerPercent);
      this.preferredTrailWidth=defaults.trailWidth;
      this.displaySTF.checked=defaults.displaySTF;this.alignBrightness.checked=defaults.alignBrightness;this.histogramOrder.currentItem=0;this.order.currentItem=sqrReviewOrderIndex(defaults.reviewOrder);this.reviewReverse=defaults.reviewReverse;this.setInputsCollapsed(defaults.inputsCollapsed);this.setQualityCollapsed(defaults.qualityCollapsed);this.setReviewInfoCollapsed(defaults.reviewInfoCollapsed);this.setMessagesCollapsed(defaults.messagesCollapsed);this.invalidateMeasurements();if(!this.session)this.updateHistogram();this.status.text='Evaluation defaults restored. Folder paths retained.';}
   canEditRegisteredTrail(){
      const row=this.current,count=row?.metrics?.[0]?.trails;
      return !!this.session&&!this.running&&!this.scanRequired&&sqrRetainedRegistered(row)&&
         Number.isInteger(count)&&count>0&&!!this.reviewNodes?.get(row)?.selected;
   }
   editRegisteredTrail(){
      if(!this.canEditRegisteredTrail())return;
      let r=this.current,g=this.group();
      this.stopBlink();let image=null;
      try{
         this.busy(true);image=sqrReadImage(r.registered.path);
         let editor=new SQRTrailRepairDialog(image,r,this.preferredTrailWidth);
         if(!editor.execute()||editor.bands===null)return;
         image.free();image=null;
         sqrSaveTrailBands(this.session.options.wbpp,r,editor.bands);
         this.preferredTrailWidth=editor.preferredWidth;
         sqrRefreshTrailReview(g);this.clearFrames(false);this.clearReferenceDisplay();this.populateRows(false);
      }catch(e){this.error(e);return;}finally{if(image)image.free();this.busy(false);}
      if(r.trailBands.length){
         this.selectBlinkRow(r);this.regionRotation.currentItem=0;this.reference.currentItem=SQR_BLINK_MODES.indexOf('trail');this.updateButtons();
         this.region.currentItem=0;
         if(this.inspect(true,false))this.status.text='Saved repaired image: '+r.trailCopy;
         this.syncOptions();
      }else{if(this.options().reference==='trail')this.reference.currentItem=0;this.ensurePreview();this.status.text='Trail mask removed.';}
   }
   integrationInputDialog(group,plan){
      const folder=sqrPath(this.session.options.wbpp)+'/master';
      let confirm=new Dialog;confirm.windowTitle='Create reviewed master light';
      let details=new Label(confirm);details.wordWrapping=true;details.setScaledMinWidth(380);
      let extra=new CheckBox(confirm);extra.text='Include '+plan.extra.length+' retained light(s) absent from the saved WBPP integration';
      extra.checked=false;extra.visible=plan.extra.length>0;extra.toolTip=plan.extra.map(e=>e.row.registered.path).join('\n');
      let masks=new CheckBox(confirm);masks.checked=true;
      masks.toolTip='Clear to create a comparison master using the unmasked lights. Your saved traces remain available.';
      let create=sqrButton(confirm,'Create master',()=>confirm.ok()),buttons=new HorizontalSizer;buttons.spacing=6;buttons.addStretch();buttons.add(create);buttons.add(sqrButton(confirm,'Cancel',()=>confirm.cancel()));
      const refresh=()=>{
         let included=extra.checked?plan.enabled.concat(plan.extra):plan.enabled,count=included.length,masked=included.filter(e=>e.row.trailBands?.length).length;
         details.text='Integrate '+count+' retained registered lights in '+group.label+'?'+(plan.disabled?'\nDisabled by WBPP: '+plan.disabled+'.':'')+
            (count<3?'\nAt least three inputs are required.':'')+'\nDestination: '+folder;
         masks.text='Apply saved trail masks ('+masked+' lights)';masks.visible=masked>0;create.enabled=count>=3;
      };
      extra.onCheck=refresh;
      confirm.sizer=new VerticalSizer;confirm.sizer.margin=10;confirm.sizer.spacing=8;confirm.sizer.add(details);confirm.sizer.add(extra);confirm.sizer.add(masks);confirm.sizer.add(buttons);refresh();confirm.adjustToContents();
      confirm.inputChoice=()=>({includeExtra:extra.checked,useMasks:masks.checked});
      return confirm;
   }
   createReviewedMaster(){
      let group=this.group();if(this.running||this.scanRequired||!group||this.inputMode()!=='import'||!sqrImportedRun(this.session?.options))return;
      this.stopBlink();try{
         this.busy(true);let path=sqrIntegrateReviewedGroup(this.session.options,group,t=>this.setStatus(t),true,plan=>{
            const dialog=this.integrationInputDialog(group,plan);
            return dialog.execute()?dialog.inputChoice():null;
         });
         if(!path)return;
         this.status.text='Created reviewed master: '+path;
         this.masterBlink.refresh(path);
      }catch(e){this.error(e);}finally{this.busy(false);}
   }
   // Confirmation is the boundary between a read-only review and file changes.
   // The engine independently validates the plan again when executing it.
   moveRejected(rethrow=false){
      if(!this.session||this.running||this.scanRequired||!this.folders.destination.edit.text.trim())return;this.syncOptions();this.stopBlink();
      try{
         let plan=sqrMovePlan(this.session),destination=sqrPath(this.session.options.destination);
         let text='Move '+plan.length+' rejected original light file(s) from this review?\n\nDestination: '+destination+'\n\n'+
            plan.map(p=>p.target.slice(destination.length+1)).join('\n')+'\n\nThe move preserves the relative folders and records an undo journal.';
         if(new MessageBox(text,'Move rejected originals',StdIcon.Question,StdButton.Yes,StdButton.No).execute()!==StdButton.Yes)return;
         this.busy(true);let result=sqrMove(this.session,s=>this.setStatus(s));
         this.populateRows();this.status.text='Moved '+result.count+' original lights. Journal: '+result.journal;return result;
      }catch(e){this.populateRows();if(rethrow)throw e;this.error(e);}finally{this.lastMoveJournal=this.session?.lastMoveJournal||this.lastMoveJournal;this.busy(false);}}
   restoreRejected(){
      if(this.running||!this.hasInputFolders()||!this.folders.destination.edit.text.trim())return;
      if(this.scanRequired&&!this.refreshFileList())return;
      this.syncOptions();this.stopBlink();let abort=console.abortEnabled;
      try{
         let path=this.current?.moveJournal||this.session?.lastMoveJournal||this.lastMoveJournal||'';
         let dialog=new SQRRestoreDialog(path&&File.exists(path)?path:'',this.current?.moved?this.current.original?.path||'':'',this.folders.destination.edit.text);
         if(!dialog.execute())return;
         this.busy(true);console.abortEnabled=true;
         let result=sqrRestore(dialog.record.path,dialog.indices(),this.session,s=>this.setStatus(s),dialog.plan);
         this.populateRows();this.status.text='Restored '+result.count+' original lights and cleared their rejection marks. Undo journal: '+result.journal;
      }catch(e){this.populateRows();this.error(e);}finally{console.abortEnabled=abort;this.busy(false);}
   }
}

// PixInsight passes Script process parameters through its command parser.
// Encode the UTF-8 payload so quotes and commas in imported WBPP settings survive.
function sqrSaveInstanceOptions(options){
   const payload=ByteArray.stringToUTF8(JSON.stringify(options)).toBase64();
   Parameters.clear();Parameters.set('configBase64',payload);
}
function sqrLoadInstanceOptions(){
   const defaults=sqrDefaults();
   if(!Parameters.has('configBase64')&&!Parameters.has('configJSON'))return defaults;
   let saved;
   try{
      const json=Parameters.has('configBase64')?ByteArray.fromBase64(Parameters.getString('configBase64')).utf8ToString():Parameters.getString('configJSON');
      saved=JSON.parse(json);
   }catch(e){throw Error('Cannot read the saved Subframe Quality Review settings.');}
   if(!saved||typeof saved!=='object'||Array.isArray(saved))throw Error('Invalid saved Subframe Quality Review settings.');
   return {...defaults,...saved,logFolder:sqrLogFolderOption(saved),measureCorners:false};
}

#ifndef SQR_LIBRARY
// Run globally with optional saved settings. SQR_LIBRARY suppresses this entry
// point so validation harnesses can exercise the engine without opening the UI.
function sqrMain(){
   CoreApplication.ensureMinimumVersion(1,9,6);
   if(typeof ImageAnalysis==='undefined')throw new Error('The ImageAnalysis process is required. Check your PixInsight installation.');
   if(Parameters.isViewTarget)throw new Error('Run this file-based review script globally.');
   let dialog=new SQRDialog(sqrLoadInstanceOptions());console.hide();dialog.execute();dialog.clearFrames();dialog.masterBlink.clearPair();
}
sqrMain();
#endif

