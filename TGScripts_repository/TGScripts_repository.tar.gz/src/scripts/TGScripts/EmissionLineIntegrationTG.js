#engine v8
// V8 migration (2026-10-19); requires PixInsight 1.9.5 or later.
/*
	EmissionLineIntegration.js: Narrow-band application on RGB images
================================================================================

Schmalband-Filter werden in der Astronomie eingesetzt, um die Intensität von
Emissionsstrahlern zu messen. Da diese Filter einen Durchlassbereich von einigen
Nanometer (nm) haben, addieren sich Fehler, die aus eng benachbarten Quellen
stammen. So ist z.B. Ein H-alpha Filter mit 6 nm Bandbreite noch aufnahmefähig
für die NII Linie, deren Wellenlänge nur einen Abstand von 2 nm hat.
Die Continuum Subtraction (kurz CS) soll hier helfen, die Strahlung aus dem
Continuum herauszufiltern. Das Ergebnis kann dann für die Berechnung der
Intensität eines Objektes genutzt werden. In der Astrofotografie erzeugt
die Addition des Differenzbildes auf einen Breitbandkanal eine merkliche
Verstärkung der Objekte.

Formeln

	NB 	= Schmalband
	BB 	= Breitband
	BB*	= Breitband intensiviert
	mue	= Anteil Continuum im Schmalband

	Ie 	= NB - mue x BB							(1)
	BB*	= BB + Ie									(2)


Narrow-band filters see use in astronomy to measure the intensity of emission
emitters. Since these filters have a range of bandwidth of around a few
nanometers (nm), errors from neighbouring sources will accumulate. For example,
a H-alpha-filter with 6nm bandwidth is receptive to the NII line with a
wavelength distance of 2nm. This is where the continuum subtraction (CS) helps
filter the emission out of the continuum. The resulting data can be used to
calculate the intensity of an object. In astro-photography, the addition of
the difference image onto a broadband channel generates a noticeable
amplification of the objects.

Formula

	NB 	= narrow band
	BB 	= braod band
	BB*	= braod band intensified
	mue	= fraction of continuum found in narrow band

	Ie 	= NB - mue x BB							(1)
	BB*	= BB + Ie									(2)

================================================================================


 Input

 1. Active window, RGB after ChannelCombination

 2. A narrowband at least for one channel

	It is recommended, that a DynamicBackroundExtraction-process has been
	applied to RGB and NB-channel[s] prior to ContinuumSub

 Copyright Hartmut V. Bornemann, 2017, 2018


History

   23.07.20 Release 2.1.0, mask removed in emission application (PixelMath)
   13.06.20 Release 2.0.3, error, graphics object not disposed
   25.09.19 Release 2.0.2, quadratic solver solveQ added
   25.09.19 Release 2.0.1, minor changes
   23.09.19 Release 2.0.0, new layout with better performance
   01.03.19 curve analysis strategy
   12.02.19 curve analysis
   02.02.19 curve analysis error, index limits corrected
	30.10.18 continuumsub reworked, improved mue evaluation
	27.10.18 mask application moved to function continuumsub
	23.10.18 mask and GUI handling improved
	22.10.18 dialog window handling improved
	21.08.18	slope criteria changed to half of maximum (slope <= ms * 0.2)
	12.05.18	temporary views excluded from ViewLists
	27.04.18	Release and introduced on PI-Workshop in Austria (Attersee)
*/

/*
   EmissionLineIntegrationTG.js v2.0

   Modified 2022 by Thorsten Glebe (based on EmissionLineIntegration.js version 2.1.0)

   This program is free software: you can redistribute it and/or modify it
   under the terms of the GNU General Public License as published by the
   Free Software Foundation, version 3 of the License.

   This program is distributed in the hope that it will be useful, but WITHOUT
   ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
   FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for
   more details.

   You should have received a copy of the GNU General Public License along with
   this program.  If not, see <http://www.gnu.org/licenses/>.

   Change history:
   v2.0
      1. increase step size to speed up calculation by factor 3, mu result changes by ~1% only, no difference in results visible
*/

#feature-id    EmissionLineIntegrationTG : TG Scripts > EmissionLineIntegrationTG

CoreApplication.ensureMinimumVersion(1, 9, 5);

#include "lib/TGScriptsLib.js"
#include "lib/TGContinuumSubtractionLib.js"


// TG script version is independent of the upstream shared-library VERSION.
#define ELI_TG_VERSION "2.1"

#define TAB '\t'
#define TEST 0

/* *****************************************************************************
 * *****************************************************************************
 *		DIALOG
 * *****************************************************************************
 * *****************************************************************************
 *
*/

// ----------------------------------------------------------------------------
// eliParams
// ----------------------------------------------------------------------------
function eliParms()
{
   this.dialogWindowWidth = 0;
   this.dialogWindowHeight = 0;
   this.amplify_R = 1;
   this.amplify_G = 1;
   this.amplify_B = 1;
   this.version = ELI_TG_VERSION;
}

// ----------------------------------------------------------------------------
// showDialog
// ----------------------------------------------------------------------------
var showDialog = class extends Dialog
{
   constructor(viewRGB)
   {
      super();
      showDialog_initialize.call(this, viewRGB);
   }
};

// Keep legacy with-based control setup outside the strict class body.
function showDialog_initialize(viewRGB)
{
   this.userResizable = true;

   var RGB = "RGBM"

   var dialog = this;

   var setVal = Settings.read('EmissionLineIntegration', DataType.String8);
   var parms  = new eliParms();
   if (setVal != null) parms = JSON.parse(setVal);
   parms.version = ELI_TG_VERSION;

   this.cancel = false;

	var nbTested = false;
   var testing  = false;

   // control arrays
   var ctls    				= [null, null, null];
   var c_views 				= [null, null, null];
	this.contingentControls = [null, null, null];
	this.greenLabelControls = [null, null, null];
	this.radioButtons 		= [null, null, null, null];

	//
	this.NRGB = new csNRGB(viewRGB, this);
	this.NRGB.refreshed = function (dialog)
	{
		if (dialog.radioButtons[0].checked)
		{
         dialog.imageview.SetImage(dialog.NRGB.bitmap);
		}
		dialog.applyButton.enabled = false;
	}

	this.csChannels = [null, null, null];

	for (var i = 0; i < 3; i++)
	{
		this.csChannels[i] = new csChannel(this.NRGB, i);
		with (this.csChannels[i])
		{
			this.csChannels[i].csSubtracted = function(channel)
			{
				with (channel)
				{
					//
					// is this channel selected by radioButton?
					//
					dialog.radioButtons[channelIndex + 1].enabled = true;
				 	for (var i = 0; i < 3; i++)
					{
						if (dialog.radioButtons[i + 1].checked)
						{
                     dialog.imageview.SetImage(bitmap);
						}
					}
				}
			}
		}
	}

   this.progress = 0;

   //
   Console.writeln("Narrowband application on RGB images");
   Console.writeln("====================================");
   Console.writeln("Processing " + viewRGB.id);

	// ------------------------------------------------------------------------
   // main panels left (preview), right (controls)
   // ------------------------------------------------------------------------
   this.panelLeft = new Frame(this);
   this.panelRight = new Frame(this);

   with (this.panelLeft)
   {
      backgroundColor  = 0xff000080;
      setMinSize(800, 600 );
      onResize = function( wNew, hNew, wOld, hOld )
      {
         Console.writeln(wNew+'\t'+ hNew+'\t'+ wOld+'\t'+ hOld );
         dialog.imageview.resize(wNew, hNew);
      }
   }

   this.imageview = new ImageView(this.panelLeft, this);

   this.lblHeadLine = new Label(this)
   with (this.lblHeadLine)
   {
      useRichText = true;
      text ="<b>RGB: " + viewRGB.id +"</b>";
   }

   // my ©
   // -------------------------------------------------------------------------
   this.lblCopyright = new Label(this)
   this.lblCopyright.text = "© 2017, Hartmut V. Bornemann · TG version " + ELI_TG_VERSION;

	for (var i = 0; i < 4; i++)
	{
		var radioButton = new RadioButton(this);
		with (radioButton)
		{
			if (i == 0)
			{
				checked = true;
				text = "RGB";
				toolTip = "View the current RGB image";
			}
			else
			{
				text = "E" + i;
				enabled = false;
				toolTip = "View the emission line image";
			}
			onCheck = function( checked )
			{
				if (parent == null) return;
				for (var j = 0; j < dialog.radioButtons.length; j++)
				{
					if (dialog.radioButtons[j] == this)
					{
						if (j > 0)
						{
							//
							// view RGB
							//
                     dialog.imageview.SetImage(dialog.csChannels[j - 1].bitmap);
						}
						else
						{
							//
							// view narrowband
							//
                     dialog.imageview.SetImage(dialog.NRGB.bitmap);
						}
					}
				}
			}
		}
		dialog.radioButtons[i] = radioButton;
	}

   // -------------------------------------------------------------------------
	this.testButton =  new PushButton( this );
	with (this.testButton)
	{
		enabled = false;
      defaultButton = true;
		text = "Test";
		toolTip = "<p>Evaluate subtraction quantity for each channel" +
					 " and display the result in the preview</p>";
		onClick = function(checked)
      {
         testing = true;
         dialog.resetLights();
         dialog.cancel = false;
			enabled = false;
			dialog.okButton.enabled = false;
			dialog.applyButton.enabled = false;

			dialog.NRGB.refresh();

			for (var i = 0; i < dialog.csChannels.length; i++)
			{
            if (!dialog.csChannels[i].canEvaluate()) continue;

            dialog.greenLabelControls[i].foregroundColor = 0xffffff00;

            dialog.advanceProgress(0);

            CoreApplication.processEvents();

				if (dialog.csChannels[i].getEmission())
				{
               if (dialog.cancel) break;
					with (dialog.csChannels[i])
					{
						if (mue > 0.0)
						{
							Console.writeln(emission.id + " = " + narrowBand.id +
							" - " + mue.toFixed(5) + " * " + broadBand.id);
                     dialog.radioButtons[i + 1].enabled = true;
                     dialog.greenLabelControls[i].foregroundColor = 0xFF00FF00;
						}
                  else
                  {
                     dialog.radioButtons[i + 1].enabled = false;
                  }
					}
					continue;
				}
			}

         if (!dialog.cancel)
         {
            dialog.NRGB.addEmission();
            if (dialog.radioButtons[0].checked)
            {
               //this.parent.previewControl.RefreshImage(this.parent.NRGB.bitmap);
               //this.parent.previewControl.SetImage(this.parent.NRGB.bitmap);
               dialog.imageview.SetImage(dialog.NRGB.bitmap);
            }
         }

			enabled = true;
			nbTested = true;
			dialog.okButton.enabled = true;
			dialog.applyButton.enabled = true;
			dialog.advanceProgress(0);
         testing = false;
		}
	}

   // -------------------------------------------------------------------------
	this.lblTick = new Label(this);
	with (this.lblTick)
	{
      backgroundColor = 0xff8fcfef;
      frameStyle = FrameStyle.Box;
		textAlignment = TextAlignment.Right|TextAlignment.VertCenter;
      var w = this.font.width( 'MMMMMM' );
      setFixedWidth( w * 2);

      onPaint = function( x0, y0, x1, y1 )
      {
         var g = new Graphics(dialog.lblTick);
         var str = (dialog.progress * 100).toFixed() + '%';
         var r = g.textRect( x0, y0, x1, y1, str, (TextAlignment.HorzCenter | TextAlignment.VertCenter) );
         g.drawTextRect( r, str);
         if (dialog.progress > 0)
         {
            var x = (x1 - x0) * dialog.progress;
            g.pen = new Pen(0xffff0000, 5);
            g.drawLine(0, 2, x, 2);
         }
         g.end();
      }
   }

   // -------------------------------------------------------------------------
	this.cancelButton = new PushButton(this);
	with (this.cancelButton)
	{
		text = "Cancel";
		toolTip = "<p>Interrupt evaluation process</p>";
		onClick = function(checked) {
         dialog.cancel = true;
         if (!testing)
         {
            // cancel in idle state terminates the dialog
            Console.hide();
            dialog.done(1);
         }
		}
	}

   // -------------------------------------------------------------------------
	this.applyButton = new PushButton( this );
	with (this.applyButton)
	{
      defaultButton = false;
		text = "Apply";
		toolTip = "<p>Apply the reduced NB images to the MainView</p>";
		enabled = false;
		onClick = function(checked) {
			if (dialog.NRGB.apply())
			{
				stfMainView(parent);
			}
			else
				Console.writeln("Update failed");
			enabled = false;
			nbTested = false;
		}
	}

   // -------------------------------------------------------------------------
   this.okButton = new PushButton( this );
   with (this.okButton)
   {
      defaultButton = false;
      icon = this.scaledResource( ":/icons/ok.png" );
      text = "OK";
		toolTip = "<p>Exit this dialog</p>";

      onClick = function(checked)
      {
			if (nbTested)
			{
				var query = new MessageBox("The image was modified'\r\n'"
							+ "'Yes' copies to view '\r\n'"
							+ "'Cancel' continues '\r\n'"
							+ "'No' quits without updating",
							"Save view",
											StdIcon.Question,
											StdButton.Yes,
											StdButton.No,
											StdButton.Cancel);
				var answ = query.execute();
				if (answ == StdButton.Yes)
				{
					if (dialog.NRGB.apply())
					{
						stfMainView(dialog);
					}
					else
					{
						Console.writeln("Update failed");
					}
				}
				else if (answ == StdButton.Cancel)
				{
					return; // continue script
				}
				else
				{
					Console.writeln("Image not updated");
				}
			}
         //
			// show or remove views
			//
			if (dialog.retainNB.checked)
			{
 		 		keepEmissionLineViews(dialog);
				stfEmissionViews(dialog);
				//
				// add the graphical analysis
				//
				dialog.NRGB.graphicalAnalysis(dialog.NRGB.mainView);
			}
			//
			//
			//
			dialog.NRGB.maskShow();
			//
			// current parameters to Settings
			//
         parms.dialogWindowWidth  = dialog.width;
         parms.dialogWindowHeight = dialog.height;
         parms.amplify_R = dialog.csChannels[0].contingent;
         parms.amplify_G = dialog.csChannels[1].contingent;
         parms.amplify_B = dialog.csChannels[2].contingent;
         var strVal = JSON.stringify(parms);
         Settings.write('EmissionLineIntegration', DataType.String8, strVal);

			//
			// write files in test-mode
			//
			if (TEST)
			{
				for (var i = 0; i < 3; i++)
				{
					if (dialog.csChannels[i].xy != null)
					{
						var filename = File.systemTempDirectory +
											"\\XYEmission" + "RGB"[i] + ".csv";
						var f = new File(filename,FileMode.Create);
						f.outTextLn( "mue" + TAB + "count")
						for (var j = 0; j < dialog.csChannels[i].xy.length; j++)
						{
							f.outTextLn(dialog.csChannels[i].xy[j][0] + TAB +
                                 dialog.csChannels[i].xy[j][1])
						}
						f.close();
					}
					if (dialog.csChannels[i].xy != null)
					{
						var filename = File.systemTempDirectory +
											"\\DXYEmission" + "RGB"[i] + ".csv";
						var f = new File(filename,FileMode.Create);
						f.outTextLn( "mue" + TAB + "count")
						for (var j = 0; j < dialog.csChannels[i].dxy.length; j++)
						{
							f.outTextLn( dialog.csChannels[i].dxy[j][0] + TAB +
											 dialog.csChannels[i].dxy[j][1])
						}
						f.close();
					}
				}
			}
			//
			// end dialog
			//
         Console.hide();
			dialog.done(0);
      }
   }

   // -------------------------------------------------------------------------
   // create a controlbox for each channel and one optional mask
   // -------------------------------------------------------------------------
   for (var i = 0; i < 4; i++)
   {
      var gbx = new GroupBox( this );
      with (gbx)
      {
         sizer = new HorizontalSizer;
         sizer.margin = 6;
         sizer.spacing = 4;
         if (i < 3)
			{
            title = "Narrowband on channel " + RGB[i];
			}
         else
			{
            title = "Star Mask [opt.]";
			}
      }
      ctls[i] = gbx;


      // image select
      // ----------------------------------------------------------------------
		var vList = new ViewList( this );
      vList.index = i;
      with (vList)
      {
			setVariableSize();
			excludeIdentifiersPattern  = TEMPVIEW;
         getMainViews();
         excludeMainViewsByColor(vList, false /*excludeMono*/);

         onViewSelected = function( view )
			{
            this.cursor = new Cursor(StdCursor.Watch);
				if (this.index < 3)
				{
					dialog.csChannels[this.index].setNarrowBand(view);
					//
					// set controls with mue, contingent from view
					//
					with (dialog.csChannels[this.index])
					{
						dialog.radioButtons[this.index + 1].enabled = hasNarrowBand &&
						emission != null;;
					}
               dialog.greenLabelControls[this.index].foregroundColor = 0x40880000;
				}
				else
				{
					//
					// set mask
					//
					dialog.NRGB.setMask(view);
               //
               // reset lights
               //
               dialog.resetLights();
				}
            this.cursor = new Cursor(StdCursor.Arrow);
				//
				// at least one channel selected?
				//
				dialog.testButton.enabled = false;
				for (var j in dialog.csChannels)
				{
					if (dialog.csChannels[j].hasNarrowBand)
					{
						dialog.testButton.enabled = true;
						break;
					}
				}
            dialog.advanceProgress(0);
			}
		}

      // ----------------------------------------------------------------------
		// label greenLight
      // ----------------------------------------------------------------------
		if (i < 3)
		{
			var lblGreenLight  = new Label(this);
			lblGreenLight.font = new Font("WebDings", 11)
			lblGreenLight.text = "n";
			lblGreenLight.foregroundColor = 0x40808080;
			this.greenLabelControls[i] = lblGreenLight;
		}

      // ----------------------------------------------------------------------
      // label: Contingent
      // ----------------------------------------------------------------------
      if (i < 3)
      {
         var numContingent = new NumericEdit (this);
         numContingent.index = i;
         with (numContingent)
         {
				autoEditWidth = true;
            label.text = "Amplify:";
				edit.rightAlignment = true;
            setPrecision( 2 );
				setRange(0, 100);
				setReal( true );
            setValue( 1.00 );
            toolTip = "<p>Apply a factor for this emission image, when added to the broadband channel" +
                      " (0..100). Default = 1</p>";
            onValueUpdated = function( value )
            {
             	dialog.csChannels[this.index].setContingent(value);
            }
            onMouseDoubleClick = function( x, y, buttonState, modifiers )
            {
               setValue (1.00);
           		dialog.csChannels[this.index].setContingent(1.0);
            }
				onMouseWheel = function( x, y, delta, buttonState, modifiers )
				{
					var step = 0.1 * Math.sign(delta);
					var v = value - step;
					if (v > upperBound) v = upperBound;
					if (v < lowerBound) v = lowerBound;
					setValue(v);
             	dialog.csChannels[this.index].setContingent(v);
				}
         }
			this.contingentControls[i] = numContingent;
      }

      // fill the groupBox
		with (gbx.sizer)
      {
         spacing = 4;

         add( vList );
       	if (i < 3)
         {
            addSpacing( 8 );
				add( lblGreenLight );
            addSpacing( 8 );
            add( numContingent );
            addSpacing( 8 );
            addStretch();
         }
			else
			{
				addStretch();
			}
     	}

      // save controls
      c_views[i] = vList;
   }

   // CheckBoxes
   // -------------------------------------------------------------------------
   this.retainNB = new CheckBox(this);
   with (this.retainNB)
   {
      text = "Retain emission view(s)";
      toolTip = "<p>Keep emission line view for visual or scientific analysis.</p>";
   }

   this.checkBoxSizer = new HorizontalSizer();
   this.checkBoxSizer.margin = 4;
   this.checkBoxSizer.addStretch()
   this.checkBoxSizer.add(this.retainNB);

   this.testButtonSizer = new HorizontalSizer;
   with (this.testButtonSizer) {
      margin = 4;
		add( this.testButton );
      addSpacing(8);
      add(this.lblTick);
   }

   // OK and Cancel button
   // -------------------------------------------------------------------------
   this.mainButtons = new HorizontalSizer;
   with (this.mainButtons) {
      margin = 4;
		add(this.cancelButton);
		addStretch();
		add( this.applyButton );
		addStretch();
      add( this.okButton );
   }

   this.viewlabel = new Label(this);
   this.viewlabel.text = 'View:';

	this.radioButtonSizer = new HorizontalSizer;
	with (this.radioButtonSizer)
	{
		//add( this.lblCopyright );
		addStretch();
      add(this.viewlabel);
		for (var i = 0; i < this.radioButtons.length; i++)
		{
      	addSpacing( 16 );
			add(this.radioButtons[i]);
		}
	}

   try
   {
      this.contingentControls[0].setValue( parms.amplify_R );
      this.contingentControls[1].setValue( parms.amplify_G );
      this.contingentControls[2].setValue( parms.amplify_B );
      this.csChannels[0].setContingent( parms.amplify_R );
      this.csChannels[1].setContingent( parms.amplify_G );
      this.csChannels[2].setContingent( parms.amplify_B );
   }
   catch (ex)
   {
   }

   // all controls together
   // -------------------------------------------------------------------------
   this.panelRight.sizer = new VerticalSizer();
   with ( this.panelRight.sizer ) {
      margin = 4;
      spacing = 8;
      add(this.lblHeadLine);
      spacing = 8;
      add(this.lblCopyright);

      for (var i = 0; i < ctls.length; i++)
      {
         spacing = 8;
         add(ctls[i]);
      }
      spacing = 8;
      add(this.radioButtonSizer);
      spacing = 8;
      add(this.checkBoxSizer);
      addStretch();
      add(this.testButtonSizer);
      spacing = 8;
      add(this.mainButtons);
   }


   // -------------------------------------------------------------------------
   // stfMainView
   // -------------------------------------------------------------------------
	function stfMainView(dialog)
	{
		//
		// ApplyAutoSTF on image
		//
		ApplyAutoSTF( viewRGB,
					DEFAULT_AUTOSTRETCH_SCLIP,
					DEFAULT_AUTOSTRETCH_TBGND, true );
	}

   // -------------------------------------------------------------------------
   // stfEmissionViews
   // -------------------------------------------------------------------------
	function stfEmissionViews(dialog)
	{
		//
		// ApplyAutoSTF emission line view(s)
		//
		for (var i = 0; i < 3; i++)
		{
			if (dialog.csChannels[i].emission != null)
			{
				if (dialog.retainNB.checked)
				{
					Console.writeln("Emission on " + RGB[i] + ", View " +
						dialog.csChannels[i].emission.id+ ", mue = " +
						dialog.csChannels[i].mue );
					//
					// retain emission line views?
					//
					ApplyAutoSTF(dialog.csChannels[i].emission,
							DEFAULT_AUTOSTRETCH_SCLIP,
							DEFAULT_AUTOSTRETCH_TBGND, true );
				}
			}
		}
	}

   // -------------------------------------------------------------------------
   // keepEmissionLineViews
   // -------------------------------------------------------------------------
	function keepEmissionLineViews(dialog)
	{
		//
		// keep or retain emission line views depending on dislog's checkBox
		//
		for (var i = 0; i < 3; i++)
		{
			if (dialog.csChannels[i].emission != null)
			{
				//
				// keep away from disposal function
				//
				setDisposal(dialog.csChannels[i].emission, false);
				dialog.csChannels[i].emission.window.show();
			}
		}
	}

   // -------------------------------------------------------------------------
   // advanceProgress
   // -------------------------------------------------------------------------
   this.advanceProgress = function(progress)
   {
      //dialog.lblTick.text = (progress * 100).toFixed() + '%';
      dialog.progress = progress;
      dialog.lblTick.repaint();
      CoreApplication.processEvents();
   }

   // -------------------------------------------------------------------------
   // resetLights
   // -------------------------------------------------------------------------
   this.resetLights = function()
   {
      for (var j in dialog.csChannels)
      {
         if (dialog.csChannels[j].hasNarrowBand)
            dialog.greenLabelControls[j].foregroundColor = 0x40880000;
         else
            dialog.greenLabelControls[j].foregroundColor = 0x40808080;
      }
   }

   this.imageview.SetImage(this.NRGB.bitmap);

   this.sizer = new HorizontalSizer();
   with (this.sizer)
   {
      margin = 4;
      add(this.panelLeft);
      addSpacing(8);
      add(this.panelRight);
   }

   // dialog window
   this.windowTitle = TITLE + " " + ELI_TG_VERSION;
   this.adjustToContents();

   this.panelRight.setFixedWidth(this.panelRight.width);


   if (parms.dialogWindowWidth > 0 && parms.dialogWindowHeight > 0)
	{
		this.width  = parms.dialogWindowWidth;
		this.height = parms.dialogWindowHeight;
	}

}

// ----------------------------------------------------------------------------
// Display with ImageView Control
// ----------------------------------------------------------------------------
var ImageView = class extends Frame
{
   constructor(parent, dialog)
   {
      super(parent);
      ImageView_initialize.call(this, parent, dialog);
   }
};

// Keep legacy with-based control setup outside the strict class body.
function ImageView_initialize(parent, dialog)
{

   var frame   = parent;

/*
   var prnt = frame;
   while (prnt.parent != null)
   {
      prnt = prnt.parent;
   }
*/
   var bitmap = null;
   var scaledImage = null;

   this.SetImage = function(bitmap_)
   {
      bitmap = null;
      try
      {gc();} catch (ex) {};
      bitmap = bitmap_;
      resize_();
      frame.repaint();
   }

   frame.onPaint = function (x0, y0, x1, y1)
   {
      if (bitmap == null) return;

      var graphics = new Graphics(this);

      graphics.fillRect(x0,y0, x1, y1, new Brush(0xff000000));

      var x = (frame.width - scaledImage.width) / 2;
      var y = (frame.height - scaledImage.height) / 2;

      graphics.drawBitmap(x, y, scaledImage);

      graphics.pen = new Pen(0xffffffff,0);
      graphics.drawRect(x-1, y-1, x + scaledImage.width + 1, y + scaledImage.height + 1);
      graphics.end();
   }

   frame.onResize = function (wNew, hNew, wOld, hOld)
   {
      resize_();
      frame.repaint();
   }

   function resize_()
   {
      if (bitmap == null) return;
      var zoom = Math.min(((frame.width - 7) / bitmap.width), ((frame.height - 7) / bitmap.height));
      scaledImage = bitmap.scaled(zoom);
   }

   dialog.onResize = function (wNew, hNew, wOld, hOld)
   {
      var dx = wNew - wOld;
      var dy = hNew - hOld;
      frame.resize(frame.width + dx, frame.height + dy);
   }
}


// ----------------------------------------------------------------------------
// ApplyHistogram
// ----------------------------------------------------------------------------
function ApplyHistogram(view)
{
   Console.writeln('ApplyHistogram '+view.id);
	var stf = view.stf;

	var H = [[  0, 0.0, 1.0, 0, 1.0],
				[  0, 0.5, 1.0, 0, 1.0],
				[  0, 0.5, 1.0, 0, 1.0],
				[  0, 0.5, 1.0, 0, 1.0],
				[  0, 0.5, 1.0, 0, 1.0]];;

	if (view.image.isColor)
	{
		for (var c = 0; c < 3; c++)
		{
			H[c][0] = stf[c][1];
			H[c][1] = stf[c][0];
		}
	}
	else
	{
		H[3][0] = stf[0][1];
		H[3][1] = stf[0][0];
	}

	var STF = new ScreenTransferFunction;

	view.stf =  [ // c0, c1, m, r0, r1
	[0.00000, 1.00000, 0.50000, 0.00000, 1.00000],
	[0.00000, 1.00000, 0.50000, 0.00000, 1.00000],
	[0.00000, 1.00000, 0.50000, 0.00000, 1.00000],
	[0.00000, 1.00000, 0.50000, 0.00000, 1.00000]
	];

	STF.executeOn(view)

	var HT = new HistogramTransformation;
	HT.H = H;
	HT.executeOn(view);
}

// ----------------------------------------------------------------------------
// replaceAll
// ----------------------------------------------------------------------------


// Helper functions
// ----------------------------------------------------------------------------
// getNewName
// ----------------------------------------------------------------------------
function getNewName(view, suffix)
{
   var newName = TEMPVIEW + view.id + suffix;
   return uniqueViewId(newName);
}

// ----------------------------------------------------------------------------
// setDisposal
// ----------------------------------------------------------------------------
function setDisposal(view, b)
{
	//
	// set/reset disposal flag in view
	//
	view.setPropertyValue(DISPOSE, b);
}

// ----------------------------------------------------------------------------
// housekeeping
// ----------------------------------------------------------------------------
function houseKeeping()
{
	var views = getAllMainViews();
	for (var i = 0; i < views.length; i++)
	{
		if (views[i].hasProperty(DISPOSE))
		{
			var dispose = views[i].propertyValue(DISPOSE);
			if (dispose) views[i].window.forceClose();
		}
	}
}



//////////////////////////////////////////////////////////////////////////////
//
// Main script entry point
//
//////////////////////////////////////////////////////////////////////////////
function main()
{
	houseKeeping();
   // get active image window.
   var window = ImageWindow.activeWindow;
   if ( (window == null || window.isNull) )
   {
      errorMessageOk( "No active image", TITLE );
   }
   else
   {
      var img = window.currentView.image;
      if (!img.isColor)
      {
         errorMessageOk( "This script for RGB images only", TITLE );
      }
      else
      {
         Console.hide();
			Console.show();
		   Console.abortEnabled = true;

         try
         {
            var dialog = new showDialog(window.currentView);
            dialog.execute();
         }
         catch (ex)
         {
            Console.writeln(ex);
         }
         houseKeeping();

      }
   }
}

main();
